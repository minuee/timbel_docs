import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

const options = {
	definition: {
		openapi: '3.0.0',
		info: {
			title: 'Timblo Backoffice Service API',
			version: '1.0.0',
			description: `Timblo Backoffice Service API Documentation\n
				오류에 대한 message는 예시값으로 errorCode값을 기준으로 오류메시지 작성해주세요.`,
			contact: {
				name: 'inc. timbel',
				email: 'shimsj@timbel.net',
			},
		},
		servers:
			process.env.SWAGGER_SERVER === 'local' ?
				[
					{
						url: `http://localhost:${process.env.PORT || 9010}`,
						description: 'Local server',
					},
				]
			:	[
					{
						url: `https://dev.timblo.io/api/bo`,
						description: 'develop server',
					},
					{
						url: `https://aimm.timblo.io/api/bo`,
						description: 'AWS server',
					},
				],
		components: {
			securitySchemes: {
				bearerAuth: {
					type: 'http',
					scheme: 'bearer',
					bearerFormat: 'JWT',
				},
			},
		},
		security: [
			{
				bearerAuth: [],
			},
			{
				timbloTokenAuth: [],
			},
		],
	},
	apis: ['./docs/**/*.js', './src/docs/**/*.js'],
};

const specs = swaggerJsdoc(options);

const uiOptions = {
	explorer: true,
	customCss: '.swagger-ui .topbar { display: none }',
	customSiteTitle: 'Timblo Backoffice Service API',
	swaggerOptions: {
		persistAuthorization: true,
		withCredentials: true,
		requestInterceptor: req => {
			req.credentials = 'include';
			return req;
		},
	},
};

export { swaggerUi, specs, uiOptions };
