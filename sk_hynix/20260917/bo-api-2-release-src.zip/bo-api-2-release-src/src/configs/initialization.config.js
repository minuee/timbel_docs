import prisma from '@timbel-timblo-onpremise/prisma';
import { menuService, roleService } from '../services/index.js';

global.mariaDB = new prisma('BackOfficeService').mariaDB;

const mariaDBConnectionPromise = mariaDB.$connect().then(async () => {
	log.i('[mariaDB] Connected');
	await menuService.initMenu();
	await roleService.initRole();
});

export default mariaDBConnectionPromise;
