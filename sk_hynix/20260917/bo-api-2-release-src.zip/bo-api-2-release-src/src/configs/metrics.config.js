import client from 'prom-client';

// 메트릭 prefix 상수 (서비스별 구분)
const METRIC_PREFIX = 'bo_api_';

// Prometheus Registry 생성
const register = new client.Registry();

// Node.js 기본 메트릭 자동 수집 활성화
// CPU, 메모리, 이벤트 루프, 힙 메모리 등의 런타임 메트릭 포함
client.collectDefaultMetrics({
	register,
	prefix: METRIC_PREFIX,
});

// HTTP 요청 Duration 메트릭 (히스토그램)
const httpRequestDuration = new client.Histogram({
	name: `${METRIC_PREFIX}http_request_duration_seconds`,
	help: 'Duration of HTTP requests in seconds',
	labelNames: ['method', 'route', 'status_code'],
	buckets: [0.1, 0.3, 0.5, 0.7, 1, 3, 5, 7, 10], // 응답 시간 구간 (초)
	registers: [register],
});

// HTTP 요청 카운트 메트릭 (카운터)
const httpRequestTotal = new client.Counter({
	name: `${METRIC_PREFIX}http_requests_total`,
	help: 'Total number of HTTP requests',
	labelNames: ['method', 'route', 'status_code'],
	registers: [register],
});

// Metrics 엔드포인트 핸들러 (미들웨어 형식)
const metricsHandler = async (req, res) => {
	try {
		res.set('Content-Type', register.contentType);
		res.end(await register.metrics());
	} catch (err) {
		res.status(500).end(err);
	}
};

// HTTP 메트릭 자동 수집 미들웨어
const httpMetricsMiddleware = (req, res, next) => {
	const start = Date.now();
	let logged = false; // 중복 로깅 방지

	const recordMetrics = () => {
		if (logged) return; // 이미 기록됨
		logged = true;

		const duration = (Date.now() - start) / 1000; // 초 단위 변환

		// route 추출: req.route가 있으면 사용, 없으면 req.path 사용
		const route = req.route?.path || req.path || 'unknown';

		// 디버깅 로그 (개발 환경에서만)
		if (process.env.NODE_ENV === 'development') {
			log.i(`[Metrics] ${req.method} ${route} - ${res.statusCode} (${duration.toFixed(3)}s)`);
		}

		// HTTP 요청 Duration 기록 (히스토그램)
		httpRequestDuration.observe(
			{
				method: req.method,
				route,
				status_code: res.statusCode,
			},
			duration
		);

		// HTTP 요청 Count 증가 (카운터)
		httpRequestTotal.inc({
			method: req.method,
			route,
			status_code: res.statusCode,
		});
	};

	// finish와 close 이벤트 모두 리스닝 (OpenTelemetry 호환성)
	res.on('finish', recordMetrics);
	res.on('close', recordMetrics);

	next();
};

// Default export (discovery 패턴과 일관성)
export default { register, httpRequestDuration, httpRequestTotal, metricsHandler, httpMetricsMiddleware };
