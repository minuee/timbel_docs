const connectionOptions = {
	host: process.env.REDIS_HOST,
	port: process.env.REDIS_PORT,
	password: process.env.REDIS_PASS,
	maxRetriesPerRequest: null, // Essential for BullMQ
};

export default connectionOptions;
