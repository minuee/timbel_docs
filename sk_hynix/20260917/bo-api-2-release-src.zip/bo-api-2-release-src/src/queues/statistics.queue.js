import { Queue } from 'bullmq';
import connectionOptions from '../configs/bullmq.config.js';

const dailyStatisticsQueue = new Queue('daily-statistics', {
	connection: connectionOptions,
	defaultJobOptions: {
		removeOnComplete: true, // Keep DB clean
		removeOnFail: {
			count: 1000, // Keep last 1000 failed jobs
		},
	},
});

// Queue 이벤트 로깅
dailyStatisticsQueue.on('error', err => {
	log.e('[BullMQ:Queue] ❌ Queue error:', err.message);
});

dailyStatisticsQueue.on('waiting', job => {
	log.i(`[BullMQ:Queue] Job waiting - ID: ${job.id}, Name: ${job.name}`);
});

/**
 * 기존 repeatable job을 모두 제거
 */
const removeExistingJobs = async () => {
	try {
		const repeatableJobs = await dailyStatisticsQueue.getRepeatableJobs();
		log.i(`[BullMQ:Queue] Found ${repeatableJobs.length} existing repeatable jobs`);

		for (const job of repeatableJobs) {
			await dailyStatisticsQueue.removeRepeatableByKey(job.key);
			log.i(`[BullMQ:Queue] Removed repeatable job: ${job.key}`);
		}
	} catch (err) {
		log.e(`[BullMQ:Queue] ❌ Failed to remove existing jobs:`, err.message);
		throw err;
	}
};

/**
 * Adds the repeatable job to the queue.
 * Schedule: Daily at 02:00 KST
 */
const addDailyStatisticsJob = async () => {
	const cronExpression = process.env.BATCH_STATISTICS_CRON || '0 2 * * *';
	log.i(`[BullMQ:Queue] Registering daily statistics job with cron: ${cronExpression}`);

	try {
		// 기존 job 제거 후 새로 등록
		await removeExistingJobs();

		await dailyStatisticsQueue.add(
			'calculate-daily-stats',
			{},
			{
				repeat: {
					cron: cronExpression,
				},
				jobId: 'daily-statistics-job',
			}
		);
		log.i(`[BullMQ:Queue] ✅ Daily Statistics Job scheduled successfully (cron: ${cronExpression})`);

		// 등록된 반복 작업 확인
		const repeatableJobs = await dailyStatisticsQueue.getRepeatableJobs();
		log.i(`[BullMQ:Queue] Registered repeatable jobs: ${JSON.stringify(repeatableJobs)}`);
	} catch (err) {
		log.e(`[BullMQ:Queue] ❌ Failed to schedule job:`, err.message);
		throw err;
	}
};

// BATCH_STATISTICS_CRON 환경변수 변경 감지
process.on('storageChanged', async () => {
	log.i(`[BullMQ:Queue] 🔄 storageChanged event received, re-registering daily statistics job...`);
	try {
		await addDailyStatisticsJob();
		log.i(`[BullMQ:Queue] ✅ Job re-registered successfully after storageChanged`);
	} catch (err) {
		log.e(`[BullMQ:Queue] ❌ Failed to re-register job after storageChanged:`, err.message);
	}
});

export { dailyStatisticsQueue, addDailyStatisticsJob };
