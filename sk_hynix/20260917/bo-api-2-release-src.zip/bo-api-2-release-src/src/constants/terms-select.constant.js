/**
 * Terms 조회용 select 상수들
 */
export const TERMS_SELECT = {
	/**
	 * 모든 정보 포함 (목록 조회용)
	 */
	FULL: {
		id: true,
		title: true,
		version: true,
		status: true,
		isRequired: true,
		publishedAt: true,
		archivedAt: true,
		createAt: true,
		updateAt: true,
		category: { select: { id: true, name: true } },
		creator: { select: { user: { select: { profile: true } } } },
		updater: { select: { user: { select: { profile: true } } } },
		workspaceId: true,
		content: true, // 설정 변경 이력 데이터 적재를 위해 추가
	},

	/**
	 * 기본 정보만 (간단한 조회용)
	 */
	BASIC: {
		id: true,
		title: true,
		content: true,
		version: true,
		status: true,
		category: { select: { id: true, name: true } },
		workspaceId: true,
	},
};
