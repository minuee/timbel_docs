import { Enums } from '@timbel-timblo-onpremise/prisma';

/**
 * 콘텐츠 보관기간 정책 설정 상수
 */
export const LIFECYCLE_POLICY_SETTINGS = [
	{
		group: Enums.WorkspaceSettingGroup.EXPIRATION,
		key: Enums.PolicyType.FILE,
		name: '원본 파일 보존 기간',
		description: '업로드된 미디어 원본 파일의 보존 기간을 설정합니다.',
		valueType: Enums.SettingValueType.STRING,
		uiType: Enums.WorkspaceSettingUiType.SELECT,
		defaultValue: '-1', // 영구
		priority: 1,
		options: [
			{ value: '-1', unit: Enums.Unit.DAYS, label: '영구' },
			{ value: '7', unit: Enums.Unit.DAYS, label: '7일' },
			{ value: '30', unit: Enums.Unit.DAYS, label: '30일' },
			{ value: null, unit: null, label: '직접 입력', unitOptions: [Enums.Unit.DAYS, Enums.Unit.HOURS] },
		],
		validation: {
			min: -1,
			max: 9999,
			message: '보존 기간 값은 -1 이상 9999 이하여야 합니다.',
		},
	},
	{
		group: Enums.WorkspaceSettingGroup.EXPIRATION,
		key: Enums.PolicyType.SEGMENT,
		name: '음성 전사 보존 기간',
		description: '음성 전사 기록의 보존 기간을 설정합니다.',
		valueType: Enums.SettingValueType.STRING,
		uiType: Enums.WorkspaceSettingUiType.SELECT,
		defaultValue: '-1', // 영구
		priority: 2,
		options: [
			{ value: '-1', unit: Enums.Unit.DAYS, label: '영구' },
			{ value: '7', unit: Enums.Unit.DAYS, label: '7일' },
			{ value: '30', unit: Enums.Unit.DAYS, label: '30일' },
			{ value: null, unit: null, label: '직접 입력', unitOptions: [Enums.Unit.DAYS, Enums.Unit.HOURS] },
		],
		validation: {
			min: -1,
			max: 9999,
			message: '보존 기간 값은 -1 이상 9999 이하여야 합니다.',
		},
	},
];
