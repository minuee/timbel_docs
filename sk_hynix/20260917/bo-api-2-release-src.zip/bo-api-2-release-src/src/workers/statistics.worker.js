import { Worker } from 'bullmq';
import connectionOptions from '../configs/bullmq.config.js';
import statisticsService from '../services/statistics.service.js';
import { date } from '../utils/index.js';
import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone.js';
import utc from 'dayjs/plugin/utc.js';

dayjs.extend(utc);
dayjs.extend(timezone);

const dailyStatisticsWorker = new Worker(
	'daily-statistics',
	async job => {
		const startTime = Date.now();
		log.i(`[BullMQ:Worker] ▶ Job started - Name: ${job.name}, ID: ${job.id}, Attempt: ${job.attemptsMade + 1}/${job.opts.attempts || 1}`);

		try {
			// Step 1: 날짜 계산
			log.i(`[BullMQ:Worker] Step 1: Calculating target date...`);
			const yesterday = dayjs().tz('Asia/Seoul').subtract(1, 'day').format('YYYY-MM-DD');
			log.i(`[BullMQ:Worker] Step 1 ✅ Target date: ${yesterday}`);

			// Step 2: DTO 생성
			log.i(`[BullMQ:Worker] Step 2: Preparing dateDto...`);
			const dateDto = {
				fromDate: date.formatDate(yesterday),
				toDate: date.formatDate(yesterday, 1),
			};
			log.i(`[BullMQ:Worker] Step 2 ✅ dateDto: ${JSON.stringify(dateDto)}`);

			// Step 3: 통계 생성 서비스 호출
			log.i(`[BullMQ:Worker] Step 3: Calling statisticsService.createDailyStatistics...`);
			const result = await statisticsService.createDailyStatistics(dateDto);
			log.i(`[BullMQ:Worker] Step 3 ✅ Service returned successfully`);

			const duration = Date.now() - startTime;
			log.i(`[BullMQ:Worker] ✅ Job completed - ID: ${job.id}, Date: ${yesterday}, Duration: ${duration}ms`);
			return result;
		} catch (err) {
			const duration = Date.now() - startTime;
			log.e(`[BullMQ:Worker] ❌ Job failed - ID: ${job.id}, Duration: ${duration}ms, Error: ${err.message}`);
			log.e(`[BullMQ:Worker] Stack trace:`, err.stack);
			throw err;
		}
	},
	{
		connection: connectionOptions,
		concurrency: 1,
		attempts: 3,
		backoff: {
			type: 'exponential',
			delay: 1000,
		},
	}
);

// Worker 이벤트 로깅
dailyStatisticsWorker.on('ready', () => {
	log.i(`[BullMQ:Worker] ✅ Worker is ready and listening for jobs`);
});

dailyStatisticsWorker.on('active', job => {
	log.i(`[BullMQ:Worker] Job active - ID: ${job.id}, Name: ${job.name}`);
});

dailyStatisticsWorker.on('completed', job => {
	log.i(`[BullMQ:Worker] ✅ Job completed - ID: ${job.id}, Name: ${job.name}`);
});

dailyStatisticsWorker.on('failed', (job, err) => {
	log.e(`[BullMQ:Worker] ❌ Job failed - ID: ${job.id}, Attempts: ${job.attemptsMade}/${job.opts.attempts || 1}, Error: ${err.message}`);
});

dailyStatisticsWorker.on('error', err => {
	log.e(`[BullMQ:Worker] ❌ Worker error:`, err.message);
});

dailyStatisticsWorker.on('stalled', jobId => {
	log.w(`[BullMQ:Worker] ⚠️ Job stalled - ID: ${jobId}`);
});

export default dailyStatisticsWorker;
