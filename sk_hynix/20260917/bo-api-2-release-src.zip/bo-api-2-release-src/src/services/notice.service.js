import noticeModel from '../models/notice.model.js';
import { HttpError } from '../handlers/error.handler.js';
import { historyService, workspaceService } from '../services/index.js';

const vaildFieldExtraction = notice => {
	try {
		const { title, content, postAt, withdrawalAt, ignoreDays } = notice;
		return {
			title,
			content,
			postAt,
			withdrawalAt,
			ignoreDays,
		};
	} catch (error) {
		throw error;
	}
};

const getNoticeList = async noticeDto => {
	try {
		const [notices, total] = await noticeModel.getNoticeList(noticeDto);
		return { notices, total };
	} catch (error) {
		log.e(`[getNoticeList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getNotice = async noticeDto => {
	try {
		const notice = await noticeModel.getNotice(noticeDto);
		if (!notice) throw new HttpError(1704);
		return notice;
	} catch (error) {
		log.e(`[getNotice] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createNotice = async (noticeDto, settingHistoryDto) => {
	try {
		const { workspaceId } = noticeDto;
		await workspaceService.getWorkspace({ id: workspaceId });
		const createdNotice = await noticeModel.createNotice(noticeDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			changeItem: '공지사항 생성',
			tableName: 'NOTICE',
			tableKey: createdNotice.id,
			afterData: vaildFieldExtraction(createdNotice),
		});
		return createdNotice;
	} catch (error) {
		log.e(`[createNotice] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updateNotice = async (noticeDto, settingHistoryDto) => {
	try {
		const { id } = noticeDto;

		const beforeNotice = await getNotice({ id });

		const updatedNotice = await noticeModel.updateNotice(noticeDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedNotice.workspaceId,
			changeItem: '공지사항 수정',
			tableName: 'NOTICE',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeNotice),
			afterData: vaildFieldExtraction(updatedNotice),
			requiredFields: ['title'],
		});
		return await getNotice({ id });
	} catch (error) {
		log.e(`[updateNotice] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updateNoticesStatus = async (noticeDto, settingHistoryDto) => {
	try {
		const { ids, status, updaterId } = noticeDto;

		const { notices: beforeNotices } = await getNoticeList({ ids });
		if (beforeNotices.length !== ids.length) throw new HttpError(1704);

		const now = new Date();
		const updatedNotices = await Promise.all(
			beforeNotices.map(notice =>
				notice.status !== status ?
					noticeModel.updateNoticeStatus({
						id: notice.id,
						postAt: noticeDto.status === 'POST' ? now : notice.postAt,
						withdrawalAt:
							notice.status === 'DRAFT' ? notice.withdrawalAt
							: noticeDto.status === 'WITHDRAWAL' ? now
							: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000),
						updaterId,
					})
				:	Promise.resolve(notice)
			)
		);

		await Promise.all(
			beforeNotices.map((beforeNotice, index) => {
				const updatedNotice = updatedNotices[index];
				if (beforeNotice.status === updatedNotice.status) return Promise.resolve();
				return historyService.createSettingHistory({
					...settingHistoryDto,
					workspaceId: updatedNotice.workspaceId,
					changeItem: '공지사항 상태 수정',
					tableName: 'NOTICE',
					tableKey: beforeNotice.id,
					beforeData: vaildFieldExtraction(beforeNotice),
					afterData: vaildFieldExtraction(updatedNotice),
					requiredFields: ['title'],
				});
			})
		);

		return updatedNotices;
	} catch (error) {
		log.e(`[updateNoticesStatus] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteNotices = async (noticeDto, settingHistoryDto) => {
	try {
		const { ids } = noticeDto;

		const { notices: beforeNotices } = await getNoticeList({ ids });
		if (beforeNotices.length !== ids.length) throw new HttpError(1704);

		const deletedNotices = await noticeModel.deleteNotices(ids);

		await Promise.all(
			beforeNotices.map(notice =>
				historyService.createSettingHistory({
					...settingHistoryDto,
					workspaceId: notice.workspaceId,
					changeItem: '공지사항 삭제',
					tableName: 'NOTICE',
					tableKey: notice.id,
					beforeData: vaildFieldExtraction(notice),
				})
			)
		);

		return deletedNotices;
	} catch (error) {
		log.e(`[deleteNotices] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default { getNoticeList, getNotice, createNotice, updateNotice, updateNoticesStatus, deleteNotices };
