import generate from '../utils/generate.util.js';
import transform from '../utils/transform.util.js';
import templateModel from '../models/template.model.js';
import { HttpError } from '../handlers/error.handler.js';
import {
	templateZipUpload,
	filterLatestTemplatesByKeyAndInputType,
	filterTemplateVersions,
} from '../utils/template.util.js';

const TAG = '[templateService] ';

const uploadTemplate = async file => {
	try {
		const { result, success } = await templateZipUpload(file);
		if (!success) throw new HttpError(5400);

		const { prompt } = result;

		const { instruction, status, variables, input_type: inputType, ...rest } = prompt;
		if (status !== 'success') throw new HttpError(5400);
		log.i(TAG, `[uploadTemplate] variables: ${JSON.stringify(variables)}`);

		return { inputType, ...rest };
	} catch (err) {
		log.e(`[uploadTemplate] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const getTemplateCategories = async member => {
	try {
		const categories = await templateModel.findAllTemplateCategories(member);
		log.i(TAG, `[getTemplateCategories] categories: ${JSON.stringify(categories)}`);
		return categories;
	} catch (err) {
		log.e(`[getTemplateCategories] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const createCategory = async (name, member) => {
	try {
		const isExists = await templateModel.isTemplateCategoryExists(name, member);
		if (isExists) throw new HttpError(5401);

		const result = await templateModel.createTemplateCategory(name, member);
		if (!result) throw new HttpError(5402);
		log.i(TAG, `[createCategory] result: ${JSON.stringify(result)}`);

		const categories = await templateModel.findAllTemplateCategories(member);
		log.i(TAG, `[createCategory] categories: ${JSON.stringify(categories)}`);

		return categories;
	} catch (err) {
		log.e(`[createCategory] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const deleteCategory = async (id, member) => {
	try {
		const isExists = await templateModel.isTemplateCategoryExistsById(id, member);
		if (!isExists) throw new HttpError(5404);

		await templateModel.deleteCategory(id, member);
		log.i(TAG, `[deleteCategory] id: ${id}`);
	} catch (err) {
		log.e(`[deleteCategory] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const updateCategory = async (id, name, member) => {
	try {
		const category = await templateModel.isTemplateCategoryExistsById(id, member);
		if (!category) throw new HttpError(5404);

		if (category.name === name) throw new HttpError(5406);

		const result = await templateModel.updateCategory(id, name, member);
		if (!result) throw new HttpError(5405);

		const categories = await templateModel.findAllTemplateCategories(member);
		log.i(TAG, `[updateCategory] categories: ${JSON.stringify(categories)}`);

		return categories;
	} catch (err) {
		log.e(`[updateCategory] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const createTemplate = async (templateInfo, member) => {
	try {
		const { categoryId, key, version } = templateInfo;
		const category = await templateModel.isTemplateCategoryExistsById(categoryId, member);
		if (!category) throw new HttpError(5404);

		const templateId = generate.templateId(key);
		const templates = await templateModel.findTemplatesById(templateId, member);
		log.i(TAG, `[createTemplate] templates: ${JSON.stringify(templates)}`);
		if (templates.length !== 0) {
			for (const template of templates) {
				if (template.version === version) throw new HttpError(5407);
			}
		}

		const { creator, editor, ...rest } = await templateModel.createTemplate(templateId, templateInfo, member);
		if (!rest) throw new HttpError(5408);

		return {
			...rest,
			creator: creator.user.profile,
			editor: editor.user.profile,
		};
	} catch (err) {
		log.e(`[createTemplate] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const getTemplates = async templateDto => {
	try {
		const templates = await templateModel.findAllTemplates(templateDto);
		const latestTemplates = filterLatestTemplatesByKeyAndInputType(templates.templates);
		return {
			...templates,
			templates: transform.transformTemplateProfile(latestTemplates),
		};
	} catch (err) {
		log.e(`[getTemplates] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const getTemplateDetail = async (id, member, version = null) => {
	try {
		const templates = await templateModel.findTemplatesById(id, member);
		if (templates.length === 0) throw new HttpError(5409);

		const latestTemplate = filterLatestTemplatesByKeyAndInputType(templates, version)[0];

		return {
			...transform.transformTemplateProfile(latestTemplate),
			versions: filterTemplateVersions(templates, latestTemplate),
		};
	} catch (err) {
		log.e(`[getTemplateDetail] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const updateTemplate = async (id, version, member, updateData) => {
	try {
		const template = await templateModel.findTemplateByIdAndVersion(id, version, member);
		if (!template) throw new HttpError(5409);

		const { categoryId } = updateData;
		if (categoryId) {
			const category = await templateModel.isTemplateCategoryExistsById(categoryId, member);
			if (!category) throw new HttpError(5404);
		}

		const result = await templateModel.updateTemplate(id, version, member, updateData);
		if (!result) throw new HttpError(5410);

		log.i(TAG, `[updateTemplate] id: ${id}, version: ${version} result: ${JSON.stringify(result)}`);
		return transform.transformTemplateProfile(result);
	} catch (err) {
		log.e(`[updateTemplate] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const updateTemplateIsUsed = async (id, version, member) => {
	try {
		const template = await templateModel.findTemplateByIdAndVersion(id, version, member);
		if (!template) throw new HttpError(5409);

		const { isUsed } = template;

		await templateModel.updateTemplateIsUsed(id, version, member, isUsed === 'Y' ? 'N' : 'Y');

		const templateDto = {
			workspaceId: template.workspaceId,
		};

		return getTemplates(templateDto);
	} catch (err) {
		log.e(`[updateTemplateIsUsed] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

export default {
	uploadTemplate,
	createTemplate,
	createCategory,
	getTemplateCategories,
	deleteCategory,
	updateCategory,
	getTemplates,
	getTemplateDetail,
	updateTemplate,
	updateTemplateIsUsed,
};
