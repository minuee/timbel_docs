import policyModel from '../models/policy.model.js';
import historyService from './history.service.js';
import { HttpError } from '../handlers/error.handler.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';

const vaildFieldExtraction = policy => {
	try {
		const { category, status, title, version, content, isUsed, publishedAt } = policy;
		return {
			category,
			status,
			title,
			version,
			content,
			isUsed,
			publishedAt,
		};
	} catch (error) {
		throw error;
	}
};

const getPolicyList = async policyDto => {
	try {
		const { isUsed, orderByField } = policyDto;
		if (isUsed !== null)
			policyDto.status =
				isUsed ? [Enums.PolicyStatus.PUBLISHED] : [Enums.PolicyStatus.ARCHIVED, Enums.PolicyStatus.DRAFT];

		if (orderByField === 'isUsed') policyDto.orderByField = 'status';

		const [policies, total] = await policyModel.getPolicyList(policyDto);
		return { policies, total };
	} catch (err) {
		log.e(`[getPolicyList] error: ${JSON.stringify(error)}`);
		throw err;
	}
};

const getPolicy = async policyDto => {
	try {
		const policy = await policyModel.getPolicy(policyDto);
		if (!policy) throw new HttpError(1604);
		return policy;
	} catch (err) {
		log.e(`[getPolicy] error: ${JSON.stringify(error)}`);
		throw err;
	}
};

const createPolicy = async (policyDto, settingHistoryDto) => {
	try {
		const { category } = policyDto;
		if (!Object.values(Enums.PolicyCategory).includes(category)) throw new HttpError(1600);

		const createdPolicy = await policyModel.createPolicy(policyDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			changeItem: '약관 생성',
			tableName: 'POLICY',
			tableKey: createdPolicy.id,
			afterData: vaildFieldExtraction(createdPolicy),
		});
		return createdPolicy;
	} catch (err) {
		log.e(`[createPolicy] error: ${JSON.stringify(error)}`);
		throw err;
	}
};

const updatePublishedSameCategoryPolicies = async (policyDto, beforePolicy) => {
	try {
		const { status, updaterId } = policyDto;
		const isPublished = status === Enums.PolicyStatus.PUBLISHED;

		const publishedSameCategoryPolicies = await policyModel.getPolicy({
			category: beforePolicy.category,
			status: Enums.PolicyStatus.PUBLISHED,
		});
		if (!publishedSameCategoryPolicies && !isPublished) throw new HttpError(1601);

		if (isPublished) {
			const latestVersionPolicy = await policyModel.getPolicy({
				category: beforePolicy.category,
				orderByField: 'version',
				sortOrder: 'desc',
			});
			policyDto.version =
				latestVersionPolicy.version ? (parseFloat(latestVersionPolicy.version) + 0.1).toFixed(1) : '1.0';

			if (publishedSameCategoryPolicies) {
				await policyModel.updatePolicyStatus({
					id: publishedSameCategoryPolicies.id,
					status: Enums.PolicyStatus.ARCHIVED,
					updaterId,
				});
			}
		}
		return await policyModel.updatePolicyStatus(policyDto);
	} catch (error) {
		log.e(`[updatePublishedSameCategoryPolicies] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updatePolicy = async (policyDto, settingHistoryDto) => {
	try {
		const { id } = policyDto;

		const beforePolicy = await getPolicy({ id });
		if (beforePolicy.status !== Enums.PolicyStatus.DRAFT) throw new HttpError(1605);

		const updatedPolicy = await policyModel.updatePolicy(policyDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			changeItem: '약관 수정',
			tableName: 'POLICY',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforePolicy),
			afterData: vaildFieldExtraction(updatedPolicy),
			requiredFields: ['title'],
		});
		return updatedPolicy;
	} catch (err) {
		log.e(`[updatePolicy] error: ${JSON.stringify(error)}`);
		throw err;
	}
};

const updatePolicyStatus = async (policyDto, settingHistoryDto) => {
	try {
		const { id, status } = policyDto;

		const beforePolicy = await getPolicy({ id });
		if (beforePolicy.status === Enums.PolicyStatus.ARCHIVED) throw new HttpError(1602);
		if (status === beforePolicy.status) throw new HttpError(1603);

		const updatedPolicy = await updatePublishedSameCategoryPolicies(policyDto, beforePolicy);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			changeItem: '약관 상태 수정',
			tableName: 'POLICY',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforePolicy),
			afterData: vaildFieldExtraction(updatedPolicy),
			requiredFields: ['title', 'status'],
		});
		return updatedPolicy;
	} catch (err) {
		log.e(`[updatePolicyStatus] error: ${JSON.stringify(error)}`);
		throw err;
	}
};

const deletePolicy = async (policyDto, settingHistoryDto) => {
	try {
		const { id } = policyDto;

		const beforePolicy = await getPolicy({ id });
		if (beforePolicy.status !== Enums.PolicyStatus.DRAFT) throw new HttpError(1605);

		const deletedPolicy = await policyModel.deletePolicy(id);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			changeItem: '약관 삭제',
			tableName: 'POLICY',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforePolicy),
		});
		return deletedPolicy;
	} catch (err) {
		log.e(`[deletePolicy] error: ${JSON.stringify(error)}`);
		throw err;
	}
};

export default {
	getPolicyList,
	getPolicy,
	createPolicy,
	updatePolicy,
	updatePolicyStatus,
	deletePolicy,
};
