import logModel from '../models/log.model.js';

const createErrorLog = async logDto => {
	try {
		return await logModel.createErrorLog(logDto);
	} catch (error) {
		log.e(`[createErrorLog] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default { createErrorLog };
