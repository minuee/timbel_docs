import corpusService from './corpus.service.js';
import historyService from './history.service.js';
import logService from './log.service.js';
import memberService from './member.service.js';
import menuService from './menu.service.js';
import noticeService from './notice.service.js';
import policyService from './policy.service.js';
import roleService from './role.service.js';
import statsService from './stats.service.js';
import templateService from './template.service.js';
import userService from './user.service.js';
import workspaceService from './workspace.service.js';
import termsService from './terms.service.js';

export {
	corpusService,
	historyService,
	logService,
	memberService,
	menuService,
	noticeService,
	policyService,
	roleService,
	statsService,
	templateService,
	userService,
	workspaceService,
	termsService,
};
