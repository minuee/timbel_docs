import workspaceModel from '../models/workspace.model.js';
import { HttpError } from '../handlers/error.handler.js';
import userService from './user.service.js';
import memberService from './member.service.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import {
	transformSettingsToHierarchy,
	validateSettingValue,
	sortSettingsByHierarchy,
	needsSync,
	syncWorkspaceSettingItems,
} from '../utils/workspace-settings.util.js';
import { notify, security } from '../utils/index.js';
import DriveUtil from '../utils/drive.util.js';
import historyService from './history.service.js';
import licenseMonitor from '../utils/license-monitor.util.js';
import { DEFAULT_SETTING_ITEMS } from '../constants/workspace-settings.constants.js';
import { LIFECYCLE_POLICY_SETTINGS } from '../constants/lifecycle-policy.constants.js';

const TAG = '[workspaceService] ';

const vaildFieldExtraction = workspace => {
	try {
		const { name, domain, description, thumbnailUrl = null } = workspace;
		return {
			name,
			domain,
			description,
			thumbnailUrl,
		};
	} catch (error) {
		throw error;
	}
};

const vaildFieldExtractionWorkspaceSetting = workspaceSetting => {
	try {
		const { key, value } = workspaceSetting;
		return {
			key,
			value,
		};
	} catch (error) {
		throw error;
	}
};

const findWorkspaceList = async workspaceDto => {
	try {
		const { workspaceList, workspaceCount } = await workspaceModel.findWorkspaceList(workspaceDto);
		const workspaceIds = workspaceList.map(workspace => workspace.id);
		const memberCountData = await memberService.getWorkspaceMemberCount(workspaceIds);

		const workspaceAdminCounts = {};
		const workspaceMemberCounts = {};
		memberCountData.forEach(item => {
			if (!workspaceMemberCounts[item.workspaceId]) workspaceMemberCounts[item.workspaceId] = 0;
			if (!workspaceAdminCounts[item.workspaceId]) workspaceAdminCounts[item.workspaceId] = 0;

			if (item.role === Enums.WorkspaceRole.ADMIN || item.role === Enums.WorkspaceRole.OWNER)
				workspaceAdminCounts[item.workspaceId] += item._count;
			else workspaceMemberCounts[item.workspaceId] += item._count;
		});

		workspaceList.forEach(workspace => {
			workspace.adminCount = workspaceAdminCounts[workspace.id] || 0;
			workspace.memberCount = workspaceMemberCounts[workspace.id] || 0;
			workspace.totalCount = workspace.adminCount + workspace.memberCount;
		});

		return { workspaceCount, workspaces: workspaceList };
	} catch (err) {
		log.e(`[findWorkspaceList] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const getWorkspaceList = async workspaceDto => {
	try {
		const workspaceList = await workspaceModel.getWorkspaceList(workspaceDto);
		return workspaceList;
	} catch (err) {
		log.e(`[getWorkspaceList] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const getWorkspace = async workspaceDto => {
	try {
		const workspace = await workspaceModel.getWorkspace(workspaceDto);
		if (!workspace) throw new HttpError(1104);
		return workspace;
	} catch (err) {
		log.e(`[getWorkspace] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 워크스페이스 기본 정보 조회
const getMyWorkspaceInfo = async workspaceId => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		const { simpleSettings } = await findFeatureSettings({ workspaceId });

		return {
			id: workspace.id,
			name: workspace.name,
			domain: workspace.domain,
			thumbnailUrl: workspace.thumbnailUrl,
			createAt: workspace.createAt,
			simpleSettings,
		};
	} catch (err) {
		log.e(`[getMyWorkspaceInfo] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 워크스페이스 기본 정보 조회
const getWorkspaceInfo = async workspaceId => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		return {
			id: workspace.id,
			name: workspace.name,
			domain: workspace.domain,
			thumbnailUrl: workspace.thumbnailUrl,
			createAt: workspace.createAt,
		};
	} catch (err) {
		log.e(`[getWorkspaceInfo] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const createWorkspace = async (workspaceDto, settingHistoryDto) => {
	try {
		if (!workspaceDto.name) workspaceDto.name = workspaceDto.domain.split('.')[0];
		workspaceDto.inviteCode = security.getInviteCode(workspaceDto.domain);

		const createdWorkspace = await workspaceModel.createWorkspace(workspaceDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: createdWorkspace.id,
			changeItem: '워크스페이스 생성',
			tableName: 'WORKSPACE',
			tableKey: createdWorkspace.id,
			afterData: vaildFieldExtraction(createdWorkspace),
		});

		return createdWorkspace;
	} catch (err) {
		log.e(`[createWorkspace] error: ${JSON.stringify(err)}`);
		if (err.code === 'P2002') throw new HttpError(1109);
		throw err;
	}
};

const updateWorkspace = async (workspaceDto, settingHistoryDto) => {
	try {
		const { id } = workspaceDto;
		const beforeWorkspace = await getWorkspace({ id });

		const updatedWorkspace = await workspaceModel.updateWorkspace(workspaceDto);
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedWorkspace.id,
			changeItem: '워크스페이스 수정',
			tableName: 'WORKSPACE',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeWorkspace),
			afterData: vaildFieldExtraction(updatedWorkspace),
			requiredFields: ['name'],
		});
		return updatedWorkspace;
	} catch (err) {
		log.e(`[updateWorkspace] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const updateWorkspaceMemberLimit = async workspaceMemberDto => {
	try {
		const { workspaceId, memberMaxCount: requestedMemberMaxCount } = workspaceMemberDto;

		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		const currentMemberCount = await workspaceModel.getMemberCount(workspaceId);
		if (requestedMemberMaxCount < currentMemberCount) throw new HttpError(1110);

		const licenseInfo = await getLicenseInfo();
		const seats = licenseInfo?.seats;

		if (seats !== -1) {
			if (typeof seats !== 'number' || Number.isNaN(seats)) throw new HttpError(1015);

			const currentTotalMemberMaxCount = await workspaceModel.getTotalWorkspaceMemberMaxCount(workspaceId);
			const requestedTotalMemberSeats = currentTotalMemberMaxCount + requestedMemberMaxCount;

			if (requestedTotalMemberSeats > seats)
				throw new HttpError(1016, { seats, currentTotalMemberMaxCount, requestedTotalMemberSeats });
		}

		const updatedConfig = await workspaceModel.updateWorkspaceMemberMaxCount(workspaceId, requestedMemberMaxCount);

		return {
			workspaceId,
			memberMaxCount: updatedConfig.memberMaxCount,
		};
	} catch (err) {
		log.e(`[updateWorkspaceMemberLimit] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

const deleteWorkspace = async (workspaceDto, settingHistoryDto) => {
	try {
		const { id } = workspaceDto;

		const workspace = await getWorkspace({ id });
		log.i(`[deleteWorkspaces] workspace => ${JSON.stringify(workspace)}`);

		const updatedWorkspace = await workspaceModel.updateWorkspaceOwner({ id });
		log.i(`[deleteWorkspaces] updatedWorkspace => ${JSON.stringify(updatedWorkspace)}`);

		const deletedUsers = await userService.deleteUsersData({ workspaceId: id });
		log.i(`[deleteWorkspaces] deletedUsers => ${JSON.stringify(deletedUsers)}`);

		const drive = new DriveUtil({});
		await drive.removeThumbnailObject({ workspaceId: id }, 'workspace');

		const deletedWorkspace = await workspaceModel.deleteWorkspace(id);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: deletedWorkspace.id,
			workspaceName: deletedWorkspace.name,
			changeItem: '워크스페이스 삭제',
			tableName: 'WORKSPACE',
			tableKey: deletedWorkspace.id,
			beforeData: vaildFieldExtraction(workspace),
		});
		return deletedWorkspace;
	} catch (err) {
		log.e(`[deleteWorkspace] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 워크스페이스 기능 설정 동기화 (필요시)
const syncFeatureSettingsIfNeeded = async workspaceId => {
	try {
		// 현재 상수에 정의된 모든 키 목록 (부모+자식 포함)
		const expectedKeys = DEFAULT_SETTING_ITEMS.map(item => item.key);

		// DB에 있는 설정 항목 키 목록
		const dbSettingItemKeys = await workspaceModel.getFeatureSettingItemKeys();

		// 설정 항목이 전혀 없는 경우 (DB 초기 설정)
		if (dbSettingItemKeys.length === 0) {
			console.log('🔧 설정 항목이 없습니다. 초기 설정을 생성합니다...');
			await syncWorkspaceSettingItems(workspaceModel.mariaDB);
			await workspaceModel.syncWorkspaceFeatureSettings(workspaceId);
			return;
		}

		// 설정 항목이 누락되거나 변경된 경우 (더 정확한 비교)
		const settingItemsNeedSync = needsSync(expectedKeys, dbSettingItemKeys);

		if (settingItemsNeedSync) {
			console.log('🔄 설정 항목 동기화가 필요합니다...');
			await syncWorkspaceSettingItems(workspaceModel.mariaDB);
		}

		// 워크스페이스에 있는 설정값 키 목록
		const workspaceSettingKeys = await workspaceModel.getWorkspaceFeatureSettingKeys(workspaceId);

		// 워크스페이스 설정값이 누락되거나 변경된 경우
		const workspaceSettingsNeedSync = needsSync(expectedKeys, workspaceSettingKeys);

		if (workspaceSettingsNeedSync) {
			console.log('🔄 워크스페이스 설정값 동기화가 필요합니다...');
			await workspaceModel.syncWorkspaceFeatureSettings(workspaceId);
		}
	} catch (err) {
		console.error('기능 설정 동기화 중 오류 발생:', err);
		// 동기화 실패는 치명적이지 않으므로 에러를 던지지 않음
	}
};

// 워크스페이스 기능 설정 조회
const findFeatureSettings = async workspaceDto => {
	try {
		const { workspaceId, groupList } = workspaceDto;

		await syncFeatureSettingsIfNeeded(workspaceId);

		const rawSettings = await workspaceModel.findFeatureSettings(workspaceId, groupList);
		const transformedSet = transformSettingsToHierarchy(sortSettingsByHierarchy(rawSettings));

		return transformedSet;
	} catch (err) {
		log.e(`[findFeatureSettings] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 자식 설정이 업데이트된 경우, 부모의 설정값 업데이트 연동
const updateParentSettingFromChildren = async (workspaceId, parentKey, recursive = false) => {
	try {
		const rawSettings = await workspaceModel.findFeatureSettings(workspaceId);

		const parentSetting = rawSettings.find(setting => setting.settingItem.key === parentKey);
		if (!parentSetting) return;

		const children = rawSettings.filter(setting => {
			const defaultItem = DEFAULT_SETTING_ITEMS.find(item => item.key === setting.settingItem.key);
			return defaultItem && defaultItem.parentKey === parentKey;
		});

		if (children.length === 0) return;

		const anyTrue = children.some(child => child.value === 'true');
		const allFalse = children.every(child => child.value === 'false');

		let newParentValue = null;
		if (anyTrue) newParentValue = 'true';
		else if (allFalse) newParentValue = 'false';

		if (newParentValue && parentSetting.value !== newParentValue) {
			await workspaceModel.updateFeatureSetting({
				workspaceId,
				key: parentKey,
				value: newParentValue,
			});

			if (recursive) {
				const parentDefaultItem = DEFAULT_SETTING_ITEMS.find(item => item.key === parentKey);
				if (parentDefaultItem && parentDefaultItem.parentKey) {
					await updateParentSettingFromChildren(workspaceId, parentDefaultItem.parentKey, true);
				}
			}
		}
	} catch (err) {
		log.e(`[updateParentSettingFromChildren] error: ${JSON.stringify(err)}`);
	}
};

// 워크스페이스 기능 설정 업데이트
const updateFeatureSetting = async (featureSettingDto, settingHistoryDto) => {
	try {
		const { workspaceId, key, value } = featureSettingDto;

		const settingItem = await workspaceModel.findFeatureSettingItemByKey(key);
		if (!settingItem) {
			throw new HttpError(1100, '기능 설정 항목을 찾을 수 없습니다.');
		}

		const { valueType, validation } = settingItem;

		validateSettingValue({
			value,
			valueType,
			validation,
		});

		const beforeSetting = await workspaceModel.getWorkspaceSetting(workspaceId, key);

		const updatedFeatureSetting = await workspaceModel.updateFeatureSetting({ workspaceId, key, value });

		// 자식 설정이 업데이트된 경우, 부모 설정을 자동으로 업데이트
		// DEFAULT_SETTING_ITEMS에서 현재 설정의 parentKey 찾기
		const childItem = DEFAULT_SETTING_ITEMS.find(item => item.key === key);
		if (childItem && childItem.parentKey) {
			await updateParentSettingFromChildren(workspaceId, childItem.parentKey, true);
		}

		const updatedSettings = await findFeatureSettings({ workspaceId });
		notify.featureSettingsUpdated(workspaceId, {
			simpleSettings: updatedSettings.simpleSettings,
		});

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId,
			changeItem: settingHistoryDto.menuCode === 'W100' ? '기능 권한 수정' : '캘린더 권한 수정',
			tableName: 'WORKSPACE_SETTING',
			tableKey: String(updatedFeatureSetting.id),
			beforeData: vaildFieldExtractionWorkspaceSetting(beforeSetting),
			afterData: vaildFieldExtractionWorkspaceSetting(updatedFeatureSetting),
			requiredFields: ['key', 'value'],
		});

		return updatedSettings;
	} catch (err) {
		log.e(`[updateFeatureSetting] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 라이선스 정보 조회
const getLicenseInfo = async () => {
	try {
		const licenseInfo = licenseMonitor.getLicenseInfo();
		const { seats, isFileWatching, verifiedAt } = licenseInfo;

		if (!isFileWatching) {
			throw new HttpError(400, '라이선스 파일 모니터링이 활성화되지 않았습니다.');
		}

		if (seats !== -1 && (typeof seats !== 'number' || Number.isNaN(seats))) {
			throw new HttpError(1015);
		}

		const usingSeats = await workspaceModel.getUsingLicenseCount();
		const leftSeats = seats === -1 ? -1 : seats - usingSeats;

		return { isFileWatching, verifiedAt, seats, usingSeats, leftSeats };
	} catch (err) {
		log.e(`[getLicenseInfo] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '라이선스 정보 조회 중 오류가 발생했습니다.');
	}
};

// 라이선스 파일 업로드
const uploadLicenseFile = async (file, settingHistoryDto) => {
	try {
		const fs = await import('fs');
		const jwt = await import('jsonwebtoken');

		const licensePath = '/license/license.jwt';
		const tempLicensePath = '/license/temp-license.jwt';
		let isBackupCreated = false;

		try {
			// 기존 라이선스 파일 검증
			log.i('기존 라이선스 파일 검증을 시작합니다.');
			const currentLicenseInfo = licenseMonitor.getLicenseInfo();
			const isCurrentLicenseValid = licenseMonitor.isVerified();

			log.d(`기존 라이선스 상태: isVerified=${isCurrentLicenseValid}, licenseId=${currentLicenseInfo.licenseId}`);

			if (!isCurrentLicenseValid) {
				log.w('기존 라이선스 파일이 유효하지 않습니다.');
				throw new HttpError(
					400,
					'기존 라이선스 파일이 유효하지 않습니다. 유효한 라이선스 파일을 업로드해주세요.'
				);
			}

			log.i('기존 라이선스 파일 검증이 완료되었습니다.');

			// 기존 라이선스 검증 완료 후 임시 백업
			isBackupCreated = licenseMonitor.createLicenseBackup(licensePath, tempLicensePath, currentLicenseInfo);

			// 새 파일 검증
			licenseMonitor.validateNewLicenseFile(file, jwt);

			// 새 라이선스 파일 저장
			fs.writeFileSync(licensePath, file.buffer, { mode: 0o644 });
			log.i('새 라이선스 파일을 저장했습니다.');

			// 신규 검증 완료 대기
			log.i('신규 라이선스 검증을 시작합니다.');
			const validationResult = await licenseMonitor.validateNewLicense();
			if (!validationResult.isValid) {
				throw new HttpError(400, '라이선스 파일이 유효하지 않습니다.');
			}
			log.i('신규 라이선스 검증이 완료되었습니다.');

			const licenseInfo = licenseMonitor.getLicenseInfo();
			log.i('라이선스 교체가 성공적으로 완료되었습니다.');

			await historyService.createSettingHistory({
				...settingHistoryDto,
				changeItem: '라이선스 업로드',
				tableName: 'LICENSE',
				tableKey: licenseInfo.licenseId,
				beforeData: { seats: currentLicenseInfo.seats },
				afterData: { seats: licenseInfo.seats },
				requiredFields: ['seats'],
			});

			return { seats: licenseInfo.seats, verifiedAt: licenseInfo.verifiedAt };
		} catch (error) {
			// 예외 발생 시 라이선스 복원 (검증 실패 포함)
			if (isBackupCreated) {
				await licenseMonitor.restoreLicenseFile(licensePath, tempLicensePath, isBackupCreated);
			}

			// 원래 에러 처리
			if (error instanceof HttpError) throw error;

			log.e(`라이선스 파일 업로드 실패: ${error}`);
			throw new HttpError(
				500,
				'라이선스 파일 업로드 중 예상치 못한 오류가 발생했습니다. 시스템 관리자에게 문의하세요.'
			);
		} finally {
			// 임시 파일 정리 (성공/실패 관계없이 항상 실행)
			if (isBackupCreated && fs.existsSync(tempLicensePath)) {
				try {
					fs.unlinkSync(tempLicensePath);
					log.i('임시 백업 파일을 정리했습니다.');
				} catch (cleanupError) {
					log.e(`임시 파일 정리 실패: ${cleanupError}`);
				}
			}
		}
	} catch (err) {
		log.e(`[uploadLicenseFile] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 워크스페이스 로고 업로드
const updateThumbnail = async (workspaceId, file, pid, settingHistoryDto) => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		const drive = new DriveUtil({});
		const thumbnailUrl = await drive.putThumbnailObject(workspaceId, 'workspace', file);
		if (!thumbnailUrl) throw new HttpError(500, '파일 업로드에 실패했습니다.');

		const result = await workspaceModel.updateThumbnailUrl(workspaceId, thumbnailUrl);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId,
			changeItem: '워크스페이스 로고 업로드',
			tableName: 'WORKSPACE',
			tableKey: result.id,
			beforeData: vaildFieldExtraction(workspace),
			afterData: vaildFieldExtraction(result),
		});
		return { thumbnailUrl: result.thumbnailUrl };
	} catch (err) {
		log.e(`[updateThumbnail] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '로고 업로드 중 오류가 발생했습니다.');
	}
};

// 워크스페이스 로고 삭제
const deleteThumbnail = async (workspaceId, settingHistoryDto) => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		const deletedWorkspaceThumbnail = await workspaceModel.deleteThumbnail(workspaceId);

		const drive = new DriveUtil({});
		await drive.removeThumbnailObject({ workspaceId }, 'workspace');

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId,
			changeItem: '워크스페이스 로고 삭제',
			tableName: 'WORKSPACE',
			tableKey: workspaceId,
			beforeData: vaildFieldExtraction(workspace),
			afterData: vaildFieldExtraction(deletedWorkspaceThumbnail),
		});
		return deletedWorkspaceThumbnail;
	} catch (err) {
		log.e(`[deleteThumbnail] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '로고 삭제 중 오류가 발생했습니다.');
	}
};

// 라이프사이클 정책 설정 포맷팅 (재사용 함수)
const formatLifecyclePolicySettings = async workspaceId => {
	const settings = LIFECYCLE_POLICY_SETTINGS;
	const policies = await workspaceModel.getLifecyclePolicyByWorkspaceId(workspaceId);

	return settings
		.sort((a, b) => a.priority - b.priority)
		.map(setting => {
			const policy = policies.find(policy => policy.policyType === setting.key);
			if (!policy) log.i(TAG, `[${workspaceId}] ${setting.key} Not Found Policy Record, Not Expired`);
			const { key, name, description, valueType, uiType, options, defaultValue } = setting;
			return {
				key,
				policyType: policy?.policyType || null,
				name,
				description,
				valueType,
				uiType,
				options,
				value: policy ? policy.value : defaultValue,
				unit: policy ? policy.unit : Enums.Unit.DAYS,
			};
		});
};

// 워크스페이스 콘텐츠 보존 정책 조회
const getLifecyclePolicy = async workspaceId => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		return await formatLifecyclePolicySettings(workspaceId);
	} catch (err) {
		log.e(`[getLifecyclePolicy] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '워크스페이스 콘텐츠 보존 정책 조회 중 오류가 발생했습니다.');
	}
};

// 워크스페이스 콘텐츠 보존 정책 개별 업데이트
const updateEachLifecyclePolicy = async (workspaceId, policyDto, settingHistoryDto) => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		const { key, value, unit } = policyDto;

		const beforePolicy = await workspaceModel.getLifecyclePolicyByWorkspaceIdAndPolicyType(workspaceId, key);

		const dto = { workspaceId, policyType: key, value, unit };

		const updatedPolicy = await workspaceModel.upsertLifecyclePolicy(dto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId,
			changeItem: '워크스페이스 콘텐츠 보존 정책 수정',
			tableName: 'WORKSPACE_POLICY',
			tableKey: updatedPolicy.id,
			beforeData: { policyType: beforePolicy.policyType, value: beforePolicy.value },
			afterData: { policyType: updatedPolicy.policyType, value: updatedPolicy.value },
			requiredFields: ['policyType', 'value'],
		});

		return await formatLifecyclePolicySettings(workspaceId);
	} catch (err) {
		log.e(`[updateEachLifecyclePolicy] error: ${JSON.stringify(err)}`);
		throw err;
	}
};

// 워크스페이스 콘텐츠 보존 정책 생성/업데이트
const createLifecyclePolicy = async (workspaceId, policyDto) => {
	try {
		const workspace = await workspaceModel.getWorkspaceById(workspaceId);
		if (!workspace) throw new HttpError(1104);

		const { policyType, value, unit } = policyDto;

		const policies = await workspaceModel.getLifecyclePolicyByWorkspaceId(workspaceId);

		if (policyType === Enums.PolicyType.ALL && policies.length > 0) {
			await workspaceModel.deleteWorkspaceLifecyclePolicy(workspaceId);
		}

		if (
			policyType !== Enums.PolicyType.ALL &&
			policies.some(policy => policy.policyType === Enums.PolicyType.ALL)
		) {
			await workspaceModel.deleteWorkspaceLifecyclePolicyByPolicyType(workspaceId, Enums.PolicyType.ALL);
		}

		let settings = LIFECYCLE_POLICY_SETTINGS;
		settings = settings.find(setting => setting.key === policyType);

		const dto = {
			workspaceId,
			policyType,
			value: value || settings.defaultValue,
			unit: unit || Enums.Unit.DAYS,
		};
		await workspaceModel.upsertLifecyclePolicy(dto);

		return dto;
	} catch (err) {
		log.e(`[createLifecyclePolicy] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '워크스페이스 콘텐츠 보존 정책 생성/업데이트 중 오류가 발생했습니다.');
	}
};

export default {
	findWorkspaceList,
	getWorkspaceList,
	getWorkspace,
	getWorkspaceInfo,
	getMyWorkspaceInfo,
	createWorkspace,
	updateWorkspace,
	deleteWorkspace,
	updateWorkspaceMemberLimit,
	findFeatureSettings,
	updateFeatureSetting,
	getLicenseInfo,
	uploadLicenseFile,
	updateThumbnail,
	deleteThumbnail,
	getLifecyclePolicy,
	updateEachLifecyclePolicy,
	createLifecyclePolicy,
};
