import keywordBoostingModel from '../models/keywordBoosting.model.js';
import keywordBoostingExportUtil from '../utils/keywordBoostingExport.util.js';
import { common } from '../utils/index.js';

const getKeywordBoostingList = async keywordDto => {
	try {
		const [keywordList, total] = await keywordBoostingModel.findKeywordBoostingList(keywordDto);
		return { keywordList: common.jsonBigintToInt(keywordList), total };
	} catch (error) {
		log.e(`[getKeywordBoostingList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

// 필터 조건과 동일하게(페이지네이션 무시) 전체 키워드를 조회해 XLSX 버퍼로 반환
const exportKeywordBoostingList = async keywordDto => {
	try {
		const keywords = await keywordBoostingModel.findKeywordsForExport(keywordDto);
		return await keywordBoostingExportUtil.generateKeywordXlsx(keywords);
	} catch (error) {
		log.e(`[exportKeywordBoostingList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default { getKeywordBoostingList, exportKeywordBoostingList };
