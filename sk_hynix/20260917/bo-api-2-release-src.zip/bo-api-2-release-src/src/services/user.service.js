import contentModel from '../models/content.model.js';
import userModel from '../models/user.model.js';
import { roleService, memberService, historyService, workspaceService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';
import { password as passwordUtil, generate } from '../utils/index.js';
import { v5 as uuidv5 } from 'uuid';
import DriveUtil from '../utils/drive.util.js';

const getUser = async userDto => {
	try {
		const user = await userModel.getUser(userDto);
		if (!user) throw new HttpError(1504);
		return user;
	} catch (error) {
		log.e(`[getUser] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createUser = async (userDto, settingHistoryDto) => {
	try {
		const { workspaceId, name, email, password, roleId } = userDto;

		const [licenseInfo, userList] = await Promise.all([
			workspaceService.getLicenseInfo(),
			userModel.getUserList(),
		]);
		if (licenseInfo.seats != -1 && licenseInfo.seats <= userList.length) throw new HttpError(1016);

		await workspaceService.getWorkspace({ id: workspaceId });
		log.i(`process.env.ENC_NAMESPACE => ${process.env.ENC_NAMESPACE}`);

		const pid = uuidv5(email, process.env.ENC_NAMESPACE);
		log.i(`user create pid => ${pid}`);

		const existingUser = await userModel.getUser({ email });
		if (existingUser) throw new HttpError(1509);

		let roleName = '구성원';
		if (roleId) {
			const role = await roleService.getRole({ id: roleId });
			roleName = role.name;
		}

		const workspace = await workspaceService.getWorkspace({ id: workspaceId });

		const hashedPassword = await passwordUtil.hashPassword(password, pid);
		const user = await userModel.createUser({
			pid,
			domain: workspace.domain,
			name,
			email,
			password: hashedPassword,
		});

		const member = await memberService.createMember({ pid, workspaceId, roleId });

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId,
			changeItem: '사용자 생성',
			tableName: 'MEMBER',
			tableKey: member.id,
			afterData: {
				workspaceName: workspace.name,
				nickName: name,
				email: email,
				roleName,
			},
		});
		return { user, member };
	} catch (error) {
		log.e(`[createUser] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updateUserPassword = async (userDto, settingHistoryDto) => {
	try {
		const { pid, newPassword } = userDto;
		const user = await getUser({ pid });

		const hashedPassword = await passwordUtil.hashPassword(newPassword, pid);

		const afterUser = await userModel.updateUserPassword({ pid, hashedPassword });

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: user.memberWorkspaces[0]?.workspace?.id || null,
			changeItem: '사용자 비밀번호 초기화',
			tableName: 'USER',
			tableKey: pid,
			beforeData: {
				email: user.profile.email,
			},
			afterData: {
				email: user.profile.email,
			},
			requiredFields: ['email'],
		});
		return afterUser;
	} catch (error) {
		log.e(`[updateUserPassword] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteFileData = async members => {
	try {
		log.i(`[deleteFileData] members length => ${members.length}`);
		if (members.length === 0) return;

		const drive = new DriveUtil({});

		for (const member of members) {
			if (member.user.profile.thumbnailUrl) await drive.removeThumbnailObject({ pid: member.pid }, 'thumbnail');

			const salt = `${member.id}${member.workspace.id}`;
			const key = generate.keyFromString(salt);
			await drive.removeContents(key);
		}
	} catch (error) {
		log.e(`[deleteFileData] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteMongoData = async contentIds => {
	try {
		log.i(`[deleteMongoData] contents length => ${contentIds.length}`);
		if (contentIds.length === 0) return;

		const fileList = await contentModel.getFileListByContentIds(contentIds);
		const fileIds = fileList.map(file => file.id);

		await Promise.all([
			contentModel.deleteFile(contentIds),
			contentModel.deleteNote(contentIds),
			contentModel.deleteBookmark(contentIds),
			contentModel.deleteTranscribeResult(fileIds),
		]);
	} catch (error) {
		log.e(`[deleteMongoData] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteMariaDBData = async pids => {
	try {
		if (pids.length === 0) return { count: 0 };
		const companies = await userModel.getUserCompanyByPids(pids);
		if (companies.length > 0) {
			const companyUserIds = companies.flatMap(c => c?.company?.userId).filter(userId => userId != null);
			log.i(`[deleteMariaDBData] companyUserIds => ${JSON.stringify(companyUserIds)}`);
			if (companyUserIds.length > 0) await userModel.deleteCompanyByUserIds(companyUserIds);
		}
		return await userModel.deleteUsers(pids);
	} catch (error) {
		log.e(`[deleteMariaDBData] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteUsersData = async userDto => {
	try {
		const { members, contentIds } = await memberService.findMembersForDelete(userDto);
		const pids = members.map(member => member.pid);
		log.i(`[deleteUsersData] pids => ${JSON.stringify(pids)}`);

		const [_, __, deletedUserCount] = await Promise.all([
			deleteFileData(members),
			deleteMongoData(contentIds),
			deleteMariaDBData(pids),
		]);
		log.i(`[deleteUsersData] deletedUserCount => ${JSON.stringify(deletedUserCount)}`);
		return { deletedUserCount, deletedMembers: members };
	} catch (error) {
		log.e(`[deleteUsersData] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteUsers = async (userDto, settingHistoryDto) => {
	try {
		const { pids } = userDto;

		const { deletedUserCount, deletedMembers } = await deleteUsersData({ pids });

		await Promise.all(
			deletedMembers.map(member =>
				historyService.createSettingHistory({
					...settingHistoryDto,
					workspaceId: member.workspace.id,
					changeItem: '사용자 삭제',
					tableName: 'USER',
					tableKey: member.pid,
					beforeData: member.user.profile,
				})
			)
		);

		return deletedUserCount;
	} catch (error) {
		log.e(`[deleteUsers] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default { createUser, updateUserPassword, deleteUsers, deleteUsersData };
