import menuModel from '../models/menu.model.js';
import { historyService, workspaceService } from '../services/index.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import { HttpError } from '../handlers/error.handler.js';
import { DEFAULT_MENU_ITEMS } from '../constants/workspace-menu.constants.js';

const vaildFieldExtraction = menu => {
	try {
		const { group, name, urlPath, isUsed } = menu;
		return {
			group,
			name,
			urlPath,
			isUsed,
		};
	} catch (error) {
		throw error;
	}
};

const initMenu = async () => {
	try {
		const menus = await getMenuList({});
		log.i(`[initMenu] menus count: ${menus.length}`);
		if (menus.length > 0) return;

		const defaultMenuData = DEFAULT_MENU_ITEMS;

		const globalWorkspace = await workspaceService.getWorkspace({ domain: 'global' });

		for (const menuData of defaultMenuData) {
			await createDefaultMenu({ ...menuData, workspaceId: globalWorkspace.id });
		}
		log.i(`[initMenu] default menu created`);
	} catch (error) {
		log.e(`[initMenu] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getMenuList = async menuDto => {
	try {
		const { group } = menuDto;

		if (group) {
			const groupList = group.split(',');
			if (!groupList.every(g => Object.values(Enums.MenuGroup).includes(g))) throw new HttpError(1201);
			menuDto.group = groupList;

			if (groupList.includes(Enums.MenuGroup.SYSTEM) || groupList.includes(Enums.MenuGroup.SYSTEM_ADDON))
				menuDto.workspaceId = null;
		}

		return await menuModel.getMenuList(menuDto);
	} catch (error) {
		log.e(`[getMenuList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getMenu = async menuDto => {
	try {
		const menu = await menuModel.getMenu(menuDto);
		if (!menu) throw new HttpError(1203);
		return menu;
	} catch (error) {
		log.e(`[getMenu] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createMenu = async menuDto => {
	try {
		return await menuModel.createMenu(menuDto);
	} catch (error) {
		log.e(`[createMenu] error: ${JSON.stringify(error)}`);
		if (error.code === 'P2002') throw new HttpError(1200);
		throw error;
	}
};

const createMenus = async menuDto => {
	try {
		const workspaceList = await workspaceService.getWorkspaceList({});
		const menuList = workspaceList.map(workspace => ({
			...menuDto,
			workspaceId: workspace.id,
		}));
		const createdMenus = await menuModel.createMenus(menuList);
		return createdMenus;
	} catch (error) {
		log.e(`[createMenus] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createAddonMenu = async (menuDto, settingHistoryDto) => {
	try {
		const { group, workspaceId } = menuDto;
		const allowGroupList = ['SYSTEM_ADDON', 'WORKSPACE_ADDON'];
		if (!allowGroupList.includes(group)) throw new HttpError(1202);

		if (group === Enums.MenuGroup.WORKSPACE_ADDON) await workspaceService.getWorkspace({ id: workspaceId });

		if (group === Enums.MenuGroup.SYSTEM_ADDON) menuDto.workspaceId = null;

		const createdMenu = await createMenu(menuDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: createdMenu.workspaceId,
			changeItem: '메뉴 생성',
			tableName: 'MENU',
			tableKey: createdMenu.id,
			afterData: vaildFieldExtraction(createdMenu),
		});
		return createdMenu;
	} catch (error) {
		log.e(`[createAddonMenu] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createDefaultMenu = async menuDto => {
	try {
		const { group } = menuDto;
		const allowGroupList = ['SYSTEM', 'WORKSPACE', 'DETAIL', 'HISTORY'];
		if (!allowGroupList.includes(group)) throw new HttpError(1202);

		// 부트스트랩 시 기본 메뉴(SYSTEM + WORKSPACE/DETAIL/HISTORY)를 모두 전달된 워크스페이스(global)에 생성한다.
		// 그래야 글로벌 역할이 시스템 화면뿐 아니라 워크스페이스 화면 권한도 부여받을 수 있다.
		// (일반 워크스페이스의 W/D/H 메뉴는 워크스페이스 생성/가입 시 auth-api가 별도로 시드한다.)
		return await createMenu(menuDto);
	} catch (error) {
		log.e(`[createDefaultMenu] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updateMenu = async (menuDto, settingHistoryDto) => {
	try {
		const { id, group } = menuDto;

		const allowGroupList = ['SYSTEM_ADDON', 'WORKSPACE_ADDON'];
		if (!allowGroupList.includes(group)) throw new HttpError(1202);

		const beforeMenu = await getMenu({ id });

		const updatedMenu = await menuModel.updateMenu(menuDto);
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedMenu.workspaceId,
			changeItem: '메뉴 수정',
			tableName: 'MENU',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeMenu),
			afterData: vaildFieldExtraction(updatedMenu),
			requiredFields: ['name'],
		});
		return updatedMenu;
	} catch (error) {
		log.e(`[updateMenu] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updateMenuIsUsed = async (menuDto, settingHistoryDto) => {
	try {
		const { id } = menuDto;

		const beforeMenu = await getMenu({ id });

		const updatedMenu = await menuModel.updateMenuIsUsed(menuDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedMenu.workspaceId,
			changeItem: '메뉴 사용 여부 수정',
			tableName: 'MENU',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeMenu),
			afterData: vaildFieldExtraction(updatedMenu),
			requiredFields: ['name', 'isUsed'],
		});
		return updatedMenu;
	} catch (error) {
		log.e(`[updateMenuIsUsed] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteMenu = async (menuDto, settingHistoryDto) => {
	try {
		const { id } = menuDto;
		const beforeMenu = await getMenu({ id });

		const allowGroupList = ['SYSTEM_ADDON', 'WORKSPACE_ADDON'];
		if (!allowGroupList.includes(beforeMenu.group)) throw new HttpError(1202);

		const deletedMenu = await menuModel.deleteMenu(id);
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: beforeMenu.workspaceId,
			changeItem: '메뉴 삭제',
			tableName: 'MENU',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeMenu),
		});
		return deletedMenu;
	} catch (error) {
		log.e(`[deleteMenu] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default {
	initMenu,
	getMenuList,
	getMenu,
	createAddonMenu,
	createDefaultMenu,
	updateMenu,
	updateMenuIsUsed,
	deleteMenu,
};
