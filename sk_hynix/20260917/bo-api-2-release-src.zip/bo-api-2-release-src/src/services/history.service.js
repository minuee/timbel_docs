import historyModel from '../models/history.model.js';
import workspaceService from './workspace.service.js';
import menuService from './menu.service.js';
import { common, settingHistory } from '../utils/index.js';

const getPolicyHistoryList = async policyHistoryDto => {
	try {
		const [histories, total] = await historyModel.getPolicyHistoryList(policyHistoryDto);
		return { histories, total };
	} catch (error) {
		log.e(`[getPolicyHistoryList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getLoginHistoryList = async loginHistoryDto => {
	try {
		const [histories, total] = await historyModel.getLoginHistoryList(loginHistoryDto);
		return { histories: common.jsonBigintToInt(histories), total };
	} catch (error) {
		log.e(`[getLoginHistoryList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getDownloadHistoryList = async downloadHistoryDto => {
	try {
		const { type } = downloadHistoryDto;
		if (type) {
			if (type.toUpperCase() === 'DOCS') {
				downloadHistoryDto.type = ['DOCUMENT_TXT', 'DOCUMENT_PDF', 'DOCUMENT_DOCX', 'DOCUMENT_HWP'];
			} else if (type.toUpperCase() === 'MEDIA') {
				downloadHistoryDto.type = ['MEDIA_FILE'];
			} else throw new HttpError(2200);
		}
		const [histories, total] = await historyModel.getDownloadHistoryList(downloadHistoryDto);
		return { histories, total };
	} catch (error) {
		log.e(`[getDownloadHistoryList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getSettingHistoryList = async settingHistoryDto => {
	try {
		const [histories, total] = await historyModel.getSettingHistoryList(settingHistoryDto);
		for (const history of histories) {
			const comparison = settingHistory.formatHistoryComparison(history);
			history.beforeData = comparison.beforeDetails;
			history.afterData = comparison.afterDetails;
		}
		return { histories: common.jsonBigintToInt(histories), total };
	} catch (error) {
		log.e(`[getSettingHistoryList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createSettingHistory = async settingHistoryDto => {
	try {
		const { workspaceId, workspaceName, menuCode, userName } = settingHistoryDto;

		// 시스템 초기화 등 사용자 컨텍스트가 없는 경우(예: initRole)엔 설정변경 이력을 남기지 않는다.
		// (userName 은 설정변경 이력의 필수값이며, 시스템 트리거 동작엔 존재하지 않는다)
		if (!userName) return null;

		if (workspaceId && !workspaceName) {
			const workspace = await workspaceService.getWorkspace({ id: workspaceId });
			if (workspace) settingHistoryDto.workspaceName = workspace.name;
		}
		// 이력 라벨(menuName)은 code→이름이 워크스페이스와 무관하다. 반면 SYSTEM 메뉴(예: S400)는
		// global 워크스페이스에만 존재하므로, 역할의 워크스페이스로 스코프해 조회하면 시스템 역할
		// 생성/삭제/수정 시 메뉴를 못 찾아 BE1203(404)이 발생한다. 따라서 code로만 조회한다.
		const menu = await menuService.getMenu({ code: menuCode });

		return await historyModel.createSettingHistory({
			...settingHistoryDto,
			menuName: menu.name,
		});
	} catch (error) {
		log.e(`[createSettingHistory] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getContentHistoryList = async contentHistoryDto => {
	try {
		const [histories, total] = await historyModel.getContentHistoryList(contentHistoryDto);
		return { histories, total };
	} catch (error) {
		log.e(`[getContentHistoryList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default {
	getPolicyHistoryList,
	getLoginHistoryList,
	getDownloadHistoryList,
	getSettingHistoryList,
	createSettingHistory,
	getContentHistoryList,
};
