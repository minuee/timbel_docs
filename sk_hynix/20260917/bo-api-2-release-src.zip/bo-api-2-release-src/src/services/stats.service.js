import statsModel from '../models/stats.model.js';
import { HttpError } from '../handlers/error.handler.js';
import { convert, date as dateUtil } from '../utils/index.js';
import memberModel from '../models/member.model.js';
import contentModel from '../models/content.model.js';

const getYears = async () => {
	try {
		return await statsModel.getYears();
	} catch (error) {
		log.e(`[getYears] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getWorkspaceYearlyStats = async statsDto => {
	try {
		const { startPeriod, endPeriod } = statsDto;
		const period = parseInt(endPeriod) - parseInt(startPeriod) + 1;
		if (period > 5) throw new HttpError(2101);
		return await statsModel.getWorkspaceYearlyStats(statsDto);
	} catch (error) {
		log.e(`[getWorkspaceYearlyStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getWorkspaceMonthlyStats = async statsDto => {
	try {
		const { startPeriod = '2025.01', endPeriod = '2025.12' } = statsDto;

		const [startYear, startMonth] = startPeriod.split('.').map(Number);
		const [endYear, endMonth] = endPeriod.split('.').map(Number);
		const period = endYear * 12 + endMonth - (startYear * 12 + startMonth) + 1;
		if (period > 12) throw new HttpError(2101);

		return await statsModel.getWorkspaceMonthlyStats(statsDto);
	} catch (error) {
		log.e(`[getWorkspaceMonthlyStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const findWorkspaceStats = async statsDto => {
	try {
		const { workspaceId, periodType, page, limit, orderByField, sortOrder } = statsDto;
		if (periodType !== 'MONTHLY' && periodType !== 'YEARLY') throw new HttpError(2100);

		if (!workspaceId && page && limit) {
			const targetWorkspaceIds = await statsModel.getStatsWorkspaceIds({ page, limit, orderByField, sortOrder });
			statsDto.workspaceIds = targetWorkspaceIds.map(targetWorkspaceId => targetWorkspaceId.workspaceId);
		}

		return await (periodType === 'YEARLY' ? getWorkspaceYearlyStats(statsDto) : getWorkspaceMonthlyStats(statsDto));
	} catch (error) {
		log.e(`[findWorkspaceStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const downloadWorkspaceStats = async statsDto => {
	try {
		const { periodType } = statsDto;
		const stats = await findWorkspaceStats(statsDto);

		const periodKey = periodType === 'YEARLY' ? 'yyyy' : 'yyyymm';
		const headers = [
			'workspaceId',
			'workspaceName',
			periodKey,
			'totalSTTCount',
			'totalSTTDuration',
			'successSTTCount',
			'successSTTDuration',
			'failSTTCount',
			'failSTTDuration',
			'totalLLMCount',
			'totalLLMToken',
			'successLLMCount',
			'failLLMCount',
		];

		const forceQuoteFields = [periodKey];
		const csv = convert.arrayToCsv(stats, headers, forceQuoteFields);
		return csv;
	} catch (error) {
		log.e(`[downloadWorkspaceStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const findMemberStats = async statsDto => {
	try {
		const { stats, total } = await statsModel.getMemberStats(statsDto);
		const transformedStats = stats.map(stat => {
			const { _sum, ...rest } = stat;
			return {
				...rest,
				..._sum,
			};
		});
		return { stats: transformedStats, total };
	} catch (error) {
		log.e(`[findMemberStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const downloadMemberStats = async statsDto => {
	try {
		const { stats } = await findMemberStats(statsDto);

		const headers = [
			'workspaceId',
			'workspaceName',
			'memberId',
			'userName',
			'email',
			'totalContentCount',
			'totalContentDuration',
			'totalLLMToken',
			'totalLLMCount',
		];

		// 텍스트 필드를 항상 따옴표로 감싸서 컬럼 밀림 방지 및 한글 깨짐 방지
		const forceQuoteFields = ['workspaceName', 'userName', 'email'];
		return convert.arrayToCsv(stats, headers, forceQuoteFields);
	} catch (error) {
		log.e(`[downloadMemberStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const contentCaptureStatsFormat = captures => {
	try {
		const statsMap = new Map();

		captures.forEach(capture => {
			const key = `${capture.creatorId}_${capture.contentId}`;

			if (!statsMap.has(key)) {
				statsMap.set(key, {
					creatorId: capture.creatorId,
					contentId: capture.contentId,
					successSTTCount: 0,
					successSTTDuration: 0,
					failSTTCount: 0,
					failSTTDuration: 0,
					successLLMCount: 0,
					failLLMCount: 0,
				});
			}

			const stats = statsMap.get(key);

			if (capture.captureAction === 'RECOG') {
				stats.failSTTCount += 1;
				stats.failSTTDuration += capture.duration || 0;
			}

			if (capture.captureAction === 'CREATE') {
				stats.successSTTCount += 1;
				stats.successSTTDuration += capture.duration || 0;
				stats.successLLMCount += 1;
			}

			if (capture.captureAction === 'LLM') {
				stats.successSTTCount += 1;
				stats.successSTTDuration += capture.duration || 0;
				stats.failLLMCount += 1;
			}
		});

		return Array.from(statsMap.values());
	} catch (error) {
		log.e(`[contentCaptureStatsFormat] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const contentStatsFormat = ({ contentStats, usageStats }) => {
	const contentStatsMap = new Map();
	contentStats.forEach(cs => {
		const key = `${cs.creatorId}`;
		if (!contentStatsMap.has(key)) {
			contentStatsMap.set(key, {
				creatorId: cs.creatorId,
				totalContentCount: 0,
				totalContentDuration: 0,
				totalLLMToken: 0,
			});
		}

		const stats = contentStatsMap.get(key);
		stats.totalContentCount += cs._count?.creatorId || 0;
		stats.totalContentDuration += cs._sum?.duration || 0;

		const contentUsageStats = usageStats.filter(us => us.contentId === cs.contentId);
		contentUsageStats.forEach(us => {
			stats.totalLLMToken += parseInt(us._sum?.count || 0);
		});
	});
	return Array.from(contentStatsMap.values());
};

const dailyStatsFormat = ({ dateDto, members, contentStats, contentCaptureStats }) => {
	const { fromDate } = dateDto;
	const dailyStatsMap = new Map();

	members.forEach(member => {
		const key = `${member.id}`;

		if (!dailyStatsMap.has(key)) {
			dailyStatsMap.set(key, {
				createDate: dateUtil.getDate(fromDate, 'YYYY-MM-DD'),
				yyyy: dateUtil.getDate(fromDate, 'YYYY'),
				yyyymm: dateUtil.getDate(fromDate, 'YYYY.MM'),
				workspaceId: member.workspaceId,
				memberId: member.id,
				totalContentCount: 0,
				totalContentDuration: 0,
				totalSTTCount: 0,
				totalSTTDuration: 0,
				successSTTCount: 0,
				successSTTDuration: 0,
				failSTTCount: 0,
				failSTTDuration: 0,
				totalLLMCount: 0,
				totalLLMToken: 0,
				successLLMCount: 0,
				failLLMCount: 0,
			});
		}

		const stats = dailyStatsMap.get(key);

		const memberContentStat = contentStats.find(cs => cs.creatorId === member.id);
		if (memberContentStat) {
			stats.totalContentCount = memberContentStat.totalContentCount || 0;
			stats.totalContentDuration = memberContentStat.totalContentDuration || 0;
			stats.totalLLMToken = memberContentStat.totalLLMToken || 0;
		}

		const memberCaptureStats = contentCaptureStats.filter(ccs => ccs.creatorId === member.id);
		memberCaptureStats.forEach(ccs => {
			stats.totalSTTCount += (ccs.successSTTCount || 0) + (ccs.failSTTCount || 0);
			stats.totalSTTDuration += (ccs.successSTTDuration || 0) + (ccs.failSTTDuration || 0);
			stats.successSTTCount += ccs.successSTTCount || 0;
			stats.successSTTDuration += ccs.successSTTDuration || 0;
			stats.failSTTCount += ccs.failSTTCount || 0;
			stats.failSTTDuration += ccs.failSTTDuration || 0;
			stats.totalLLMCount += ccs.successLLMCount + ccs.failLLMCount || 0;
			stats.successLLMCount += ccs.successLLMCount || 0;
			stats.failLLMCount += ccs.failLLMCount || 0;
		});
	});
	return Array.from(dailyStatsMap.values());
};

const getContentCaptureStats = async dateDto => {
	try {
		const { fromDate, toDate } = dateDto;
		const captures = await contentModel.getContentCaptureStats(fromDate, toDate, ['RECOG', 'LLM', 'CREATE']);

		return contentCaptureStatsFormat(captures);
	} catch (error) {
		log.e(`[getContentCaptureStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getContentStats = async dateDto => {
	try {
		const [contentStats, usageStats] = await Promise.all([
			contentModel.getContentStats(dateDto),
			statsModel.getUsageStats(dateDto, 'LLM'),
		]);
		return contentStatsFormat({ contentStats, usageStats });
	} catch (error) {
		log.e(`[getContentStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createDailyStats = async dateDto => {
	try {
		const { fromDate } = dateDto;
		const dailyStats = await statsModel.getDailyStats(dateUtil.getDate(fromDate, 'YYYY-MM-DD'));
		if (dailyStats.length > 0) {
			log.d(`[createDailyStats] dailyStats already exists`);
			throw new HttpError(2109);
		}

		const [members, contentStats, contentCaptureStats] = await Promise.all([
			memberModel.getStatsMembers(dateDto),
			getContentStats(dateDto),
			getContentCaptureStats(dateDto),
		]);

		const createdDailyStats = dailyStatsFormat({ dateDto, members, contentStats, contentCaptureStats });
		return await statsModel.createDailyStats(createdDailyStats);
	} catch (error) {
		log.e(`[createDailyStats] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default {
	getYears,
	findWorkspaceStats,
	downloadWorkspaceStats,
	findMemberStats,
	downloadMemberStats,
	createDailyStats,
};
