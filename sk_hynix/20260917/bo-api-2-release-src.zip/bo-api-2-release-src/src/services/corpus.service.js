import corpusModel from '../models/corpus.model.js';
import { common } from '../utils/index.js';

const getCorpusList = async corpusDto => {
	try {
		const [corpusList, total] = await corpusModel.findCorpusList(corpusDto);
		return { corpusList: common.jsonBigintToInt(corpusList), total };
	} catch (error) {
		log.e(`[getCorpusList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default { getCorpusList };
