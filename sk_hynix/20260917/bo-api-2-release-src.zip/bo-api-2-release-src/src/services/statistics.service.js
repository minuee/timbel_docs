import workspaceService from './workspace.service.js';
import memberService from './member.service.js';
import statisticsModel from '../models/statistics.model.js';
import { convert, date as dateUtil } from '../utils/index.js';
import contentModel from '../models/content.model.js';
import { HttpError } from '../handlers/error.handler.js';

const formatPeriod = (periodType, item) => {
	switch (periodType) {
		case 'DAILY':
			return item.dateKst || '';
		case 'WEEKLY':
			return `${item.yearKst}-W${String(item.weekNumber || 0).padStart(2, '0')}`;
		case 'MONTHLY':
			return `${item.yearKst}-${String(item.monthKst || 0).padStart(2, '0')}`;
		case 'YEARLY':
			return String(item.yearKst || '');
		default:
			return item.dateKst || '';
	}
};

const formatStatistics = param => {
	const { statistics, periodType, workspaceList, memberList } = param;

	const workspaceMap = new Map(workspaceList.map(w => [w.id, w.name]));
	const userNameMap = memberList ? new Map(memberList.map(m => [m.id, m.user?.profile?.nickName || null])) : null;
	const emailMap = memberList ? new Map(memberList.map(m => [m.id, m.user?.profile?.email || null])) : null;

	return statistics
		.map(item => {
			const workspaceName = workspaceMap.get(item.workspaceId) || null;
			const userName = userNameMap?.get(item.creatorId) || null;
			const email = emailMap?.get(item.creatorId) || null;

			const baseItem = {
				period: formatPeriod(periodType, item),
				workspaceId: item.workspaceId,
				workspaceName,
				...item._sum,
			};

			if (userName && email) {
				const memberId = item.creatorId;
				if (memberId) {
					baseItem.memberId = memberId;
					baseItem.userName = userName;
					baseItem.email = email;
				}
			}

			return baseItem;
		})
		.filter(item => item !== null);
};

const sortStatistics = (statistics, orderByField, sortOrder) => {
	return statistics.sort((a, b) => {
		const aValue = a[orderByField] || 0;
		const bValue = b[orderByField] || 0;

		if (typeof aValue === 'string' || typeof bValue === 'string') {
			if (sortOrder === 'asc') {
				return String(aValue).localeCompare(String(bValue), undefined, { numeric: true });
			} else {
				return String(bValue).localeCompare(String(aValue), undefined, { numeric: true });
			}
		}

		if (sortOrder === 'asc') {
			return aValue - bValue;
		} else {
			return bValue - aValue;
		}
	});
};

const pagenationStatistics = async (statistics, page, limit) => {
	try {
		const total = statistics.length;
		const startIndex = (page - 1) * limit;
		const endIndex = startIndex + limit;
		return { statistics: statistics.slice(startIndex, endIndex), total };
	} catch (error) {
		log.e(`[pagenationStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getMemberStatistics = async statisticsDto => {
	try {
		const { workspaceId, memberId, periodType, orderByField, sortOrder } = statisticsDto;

		const [statistics, workspaceList, memberList] = await Promise.all([
			await statisticsModel.getMemberStats(statisticsDto),
			await workspaceService.getWorkspaceList({
				ids: workspaceId ? [workspaceId] : undefined,
			}),
			await memberService.getStatisticsMemberList({
				workspaceId,
				memberId,
			}),
		]);

		const formattedStatistics = formatStatistics({
			statistics,
			periodType,
			workspaceList,
			memberList,
		});

		const sortedStatistics = sortStatistics(formattedStatistics, orderByField, sortOrder);

		return sortedStatistics;
	} catch (error) {
		log.e(`[getMemberStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getWorkspaceStatistics = async statisticsDto => {
	try {
		const { workspaceId, periodType, orderByField, sortOrder } = statisticsDto;

		const [statistics, workspaceList] = await Promise.all([
			await statisticsModel.getWorkspaceStats(statisticsDto),
			await workspaceService.getWorkspaceList(workspaceId ? { ids: [workspaceId] } : {}),
		]);

		const formattedStatistics = formatStatistics({
			statistics,
			periodType,
			workspaceList,
		});

		const sortedStatistics = sortStatistics(formattedStatistics, orderByField, sortOrder);

		return sortedStatistics;
	} catch (error) {
		log.e(`[getWorkspaceStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const findMemberStatistics = async statisticsDto => {
	try {
		const { page, limit } = statisticsDto;
		const statistics = await getMemberStatistics(statisticsDto);
		return pagenationStatistics(statistics, page, limit);
	} catch (error) {
		log.e(`[findMemberStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const findWorkspaceStatistics = async statisticsDto => {
	try {
		const { page, limit } = statisticsDto;
		const statistics = await getWorkspaceStatistics(statisticsDto);
		return pagenationStatistics(statistics, page, limit);
	} catch (error) {
		log.e(`[findWorkspaceStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const downloadMemberStatistics = async statisticsDto => {
	try {
		const statistics = await getMemberStatistics(statisticsDto);

		const headers = [
			'period',
			'workspaceId',
			'workspaceName',
			'totalContentCount',
			'totalSeconds',
			'mobileContentCount',
			'mobileSeconds',
			'transcribeDoneCount',
			'transcribeErrorCount',
			'transcribeOtherCount',
			'duration0_1Min',
			'duration1_30Min',
			'duration30_60Min',
			'duration60_120Min',
			'duration120_180Min',
			'durationOver180Min',
			'memberId',
			'userName',
		];

		const forceQuoteFields = ['workspaceName', 'userName'];
		return convert.arrayToCsv(statistics, headers, forceQuoteFields);
	} catch (error) {
		log.e(`[downloadMemberStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const downloadWorkspaceStatistics = async statisticsDto => {
	try {
		const statistics = await getWorkspaceStatistics(statisticsDto);

		const headers = [
			'period',
			'workspaceId',
			'workspaceName',
			'totalContentCount',
			'totalSeconds',
			'mobileContentCount',
			'mobileSeconds',
			'transcribeDoneCount',
			'transcribeErrorCount',
			'transcribeOtherCount',
			'duration0_1Min',
			'duration1_30Min',
			'duration30_60Min',
			'duration60_120Min',
			'duration120_180Min',
			'durationOver180Min',
		];

		const forceQuoteFields = ['workspaceName'];
		return convert.arrayToCsv(statistics, headers, forceQuoteFields);
	} catch (error) {
		log.e(`[downloadWorkspaceStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const contentStatisticsFormat = contentStatistics => {
	const contentStatisticsMap = new Map();
	contentStatistics.forEach(item => {
		const dateKst = dateUtil.getDate(item.createAt, 'YYYY-MM-DD');
		const key = `${item.creatorId}_${item.workspaceId}_${dateKst}`;
		if (!contentStatisticsMap.has(key)) {
			const weekNumber = dateUtil.getWeekNumber(dateKst);
			contentStatisticsMap.set(key, {
				yearKst: parseInt(dateKst.split('-')[0]),
				monthKst: parseInt(dateKst.split('-')[1]),
				dayKst: parseInt(dateKst.split('-')[2]),
				weekNumber,
				dateKst,
				workspaceId: item.workspaceId,
				creatorId: item.creatorId,
				totalContentCount: 0,
				totalSeconds: 0,
				mobileContentCount: 0,
				mobileSeconds: 0,
				transcribeDoneCount: 0,
				transcribeErrorCount: 0,
				transcribeOtherCount: 0,
				duration0_1Min: 0,
				duration1_30Min: 0,
				duration30_60Min: 0,
				duration60_120Min: 0,
				duration120_180Min: 0,
				durationOver180Min: 0,
			});
		}
		const statistics = contentStatisticsMap.get(key);
		statistics.totalContentCount += 1;
		statistics.totalSeconds += item.duration / 1000 || 0;
		if (item.isMobile) {
			statistics.mobileContentCount += 1;
			statistics.mobileSeconds += item.duration / 1000 || 0;
		}
		if (item.transcribeStatus === 'DONE') {
			statistics.transcribeDoneCount += 1;
		} else if (item.transcribeStatus === 'ERROR') {
			statistics.transcribeErrorCount += 1;
		} else {
			statistics.transcribeOtherCount += 1;
		}
		if (item.duration < 60000) {
			statistics.duration0_1Min += 1;
		} else if (item.duration < 180000) {
			statistics.duration1_30Min += 1;
		} else if (item.duration < 360000) {
			statistics.duration30_60Min += 1;
		} else if (item.duration < 720000) {
			statistics.duration60_120Min += 1;
		} else if (item.duration < 1080000) {
			statistics.duration120_180Min += 1;
		} else {
			statistics.durationOver180Min += 1;
		}
	});
	return Array.from(contentStatisticsMap.values());
};

const createDailyStatistics = async dateDto => {
	try {
		const { fromDate } = dateDto;
		const dailyStatistics = await statisticsModel.getDailyStatistics(dateUtil.getDate(fromDate, 'YYYY-MM-DD'));
		if (dailyStatistics.length > 0) {
			log.d(`[createDailyStatistics] dailyStatistics already exists`);
			throw new HttpError(2109);
		}

		const contentStatistics = await contentModel.getContentStatistics(dateDto);
		const formattedContentStatistics = contentStatisticsFormat(contentStatistics);

		const roundedStatistics = formattedContentStatistics.map(stat => ({
			...stat,
			totalSeconds: Math.round(stat.totalSeconds),
			mobileSeconds: Math.round(stat.mobileSeconds),
		}));

		const result = await statisticsModel.createDailyStatistics(roundedStatistics);
		return result;
	} catch (error) {
		log.e(`[createDailyStatistics] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default {
	findMemberStatistics,
	findWorkspaceStatistics,
	downloadMemberStatistics,
	downloadWorkspaceStatistics,
	createDailyStatistics,
};
