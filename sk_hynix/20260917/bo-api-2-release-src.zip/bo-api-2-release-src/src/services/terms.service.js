import termsModel from '../models/terms.model.js';
import { HttpError } from '../handlers/error.handler.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import { historyService } from './index.js';

const vaildFieldExtraction = terms => {
	try {
		const { version, title, content, status, publishedAt, archivedAt, category } = terms;
		const { name: categoryName } = category;
		return {
			version,
			title,
			content,
			status,
			publishedAt,
			archivedAt,
			categoryName,
		};
	} catch (error) {
		throw error;
	}
};

// 데이터베이스 사용자 프로필 구조를 UserInfoDto로 변환
const mapDbUserToUserInfo = dbUser => {
	if (!dbUser?.user?.profile) {
		return null;
	}

	const profile = dbUser.user.profile;
	return {
		pid: profile.pid,
		name: profile.name || '',
		nickName: profile.nickName,
		thumbnailUrl: profile.thumbnailUrl || '',
		email: profile.email || '',
	};
};

// 환경변수에서 동의서 카테고리 설정을 파싱합니다.
const parseTermsCategories = categoriesString => {
	if (!categoriesString || categoriesString.trim() === '') {
		return [];
	}

	return categoriesString
		.split(',')
		.map(name => name.trim())
		.filter(name => name.length > 0)
		.map(name => ({ name }));
};

// 동의서 초안 생성
const createTerms = async (createTermsDto, settingHistoryDto) => {
	try {
		const { workspaceId, categoryId } = createTermsDto;
		const existingCategory = await termsModel.findTermsCategoryById(workspaceId, categoryId);
		if (!existingCategory) {
			throw new HttpError(5502);
		}

		const createdTerms = await termsModel.createTerms(createTermsDto);
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: createdTerms.workspaceId,
			changeItem: '동의서 생성',
			tableName: 'TERMS',
			tableKey: createdTerms.id,
			afterData: vaildFieldExtraction(createdTerms),
		});
		return createdTerms;
	} catch (err) {
		log.e(`[createTerms] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 생성 중 오류가 발생했습니다.');
	}
};

// 동의서 목록 조회
const findTermsList = async findTermsDto => {
	try {
		const { workspaceId } = findTermsDto;
		if (workspaceId) await createDefaultTermsCategories(workspaceId);
		const resultSet = await termsModel.findTermsList(findTermsDto);

		const items = resultSet.data.map(item => ({
			...item,
			version: item.version?.toString() || null,
			creator: mapDbUserToUserInfo(item.creator),
			updater: mapDbUserToUserInfo(item.updater),
		}));

		const { total, page, limit, totalPages } = resultSet;
		return { items, total, page, limit, totalPages };
	} catch (err) {
		log.e(`[findTermsList] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 목록 조회 중 오류가 발생했습니다.');
	}
};

// 환경변수에서 설정된 기본 동의서 카테고리들이 존재하는지 확인하고, 없으면 생성
const createDefaultTermsCategories = async workspaceId => {
	const categoriesString = process.env.DEFAULT_TERMS_CATEGORIES || '개인정보,유의사항';
	const defaultCategories = parseTermsCategories(categoriesString);

	for (const categoryConfig of defaultCategories) {
		const existingCategory = await termsModel.findTermsCategoryByName(workspaceId, categoryConfig.name);

		if (!existingCategory) {
			await termsModel.createTermsCategory({
				workspaceId,
				name: categoryConfig.name,
				description: '',
				isEnabled: true,
			});
		}
	}
};

// 동의서 상세 조회
const findTermsById = async termsId => {
	try {
		const terms = await termsModel.findTermsById(termsId);
		if (!terms) throw new HttpError(5500);

		return {
			...terms,
			creator: mapDbUserToUserInfo(terms.creator),
			updater: mapDbUserToUserInfo(terms.updater),
		};
	} catch (err) {
		log.e(`[findTermsById] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 조회 중 오류가 발생했습니다.');
	}
};

// 동의서 수정
const updateTerms = async (updateTermsDto, settingHistoryDto) => {
	try {
		const { id, workspaceId, updaterId } = updateTermsDto;
		const existingTerms = await termsModel.findTermsById(id);
		if (!existingTerms) throw new HttpError(5500);

		const existingTermsCategory = await termsModel.findTermsCategoryById(workspaceId, updateTermsDto.categoryId);
		if (!existingTermsCategory) throw new HttpError(5502);

		if (existingTerms.status !== Enums.TermsStatus.DRAFT)
			throw new HttpError(5501, '시행된 동의서는 수정할 수 없습니다.');

		const result = await termsModel.updateTerms(updateTermsDto, updaterId);
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: result.workspaceId,
			changeItem: '동의서 수정',
			tableName: 'TERMS',
			tableKey: id,
			beforeData: vaildFieldExtraction(existingTerms),
			afterData: vaildFieldExtraction(result),
			requiredFields: ['title'],
		});
		return {
			...result,
			creator: mapDbUserToUserInfo(result.creator),
			updater: mapDbUserToUserInfo(result.updater),
		};
	} catch (err) {
		log.e(`[updateTerms] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 수정 중 오류가 발생했습니다.');
	}
};

// 동의서 삭제
const deleteTerms = async (id, settingHistoryDto) => {
	try {
		const existingTerms = await termsModel.findTermsById(id);
		if (!existingTerms) throw new HttpError(5500);

		if (existingTerms.status !== Enums.TermsStatus.DRAFT)
			throw new HttpError(5501, '시행된 동의서는 삭제할 수 없습니다.');

		await termsModel.deleteTerms(id);
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: existingTerms.workspaceId,
			changeItem: '동의서 삭제',
			tableName: 'TERMS',
			tableKey: id,
			beforeData: vaildFieldExtraction(existingTerms),
		});
	} catch (err) {
		log.e(`[deleteTerms] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 삭제 중 오류가 발생했습니다.');
	}
};

// 동의서 상태 변경
const updateTermsStatus = async (dto, settingHistoryDto) => {
	try {
		const { id, status, updaterId } = dto;

		const existingTerms = await termsModel.findTermsById(id);
		if (!existingTerms) throw new HttpError(5500);

		let result;
		if (status === Enums.TermsStatus.PUBLISHED) {
			result = await publishTerms(dto);
		} else if (status === Enums.TermsStatus.ARCHIVED) {
			if (existingTerms.status !== Enums.TermsStatus.PUBLISHED)
				throw new HttpError(5501, '시행된 동의서만 보관할 수 있습니다.');
			const archivedTerms = await termsModel.archiveTerms(id, updaterId);

			result = {
				...archivedTerms,
				creator: mapDbUserToUserInfo(archivedTerms.creator),
				updater: mapDbUserToUserInfo(archivedTerms.updater),
			};
		} else {
			throw new HttpError(5501, '유효하지 않은 상태입니다.');
		}

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: result.workspaceId,
			changeItem: '동의서 상태 변경',
			tableName: 'TERMS',
			tableKey: id,
			beforeData: vaildFieldExtraction(existingTerms),
			afterData: vaildFieldExtraction(result),
			requiredFields: ['title'],
		});
		return result;
	} catch (err) {
		log.e(`[updateTermsStatus] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 상태 변경 중 오류가 발생했습니다.');
	}
};

// 동의서 시행
const publishTerms = async dto => {
	try {
		const { id, workspaceId, updaterId } = dto;

		const existingTerms = await termsModel.findTermsById(id);
		if (!existingTerms || !existingTerms.category) throw new HttpError(5500);

		if (existingTerms.status !== Enums.TermsStatus.DRAFT)
			throw new HttpError(5501, '시행된 동의서는 시행할 수 없습니다.');

		const existingTermsCategory = await termsModel.findTermsCategoryById(workspaceId, existingTerms.category.id);
		if (!existingTermsCategory) throw new HttpError(5502);

		const existingPublished = await termsModel.findPublishedInCategory(workspaceId, existingTerms.category.id);

		if (existingPublished) {
			await termsModel.archiveTerms(existingPublished.id, updaterId);
		}

		let newVersion;
		try {
			const findTermsDto = {
				workspaceId: workspaceId,
				categoryId: existingTerms.category.id,
				status: [Enums.TermsStatus.PUBLISHED, Enums.TermsStatus.ARCHIVED],
			};

			const latestPublishedTerms = await termsModel.findLatestTermsByCategoryId(findTermsDto);

			if (!latestPublishedTerms || !latestPublishedTerms.version) {
				newVersion = '0.1';
			} else {
				const currentVersion = parseFloat(latestPublishedTerms.version);
				newVersion = (currentVersion + 0.1).toFixed(1);
			}
		} catch {
			throw new HttpError(500, '동의서 시행 중 버전 처리 오류가 발생했습니다.');
		}

		const publishedTerms = await termsModel.publishTerms(id, newVersion, updaterId);

		return {
			...publishedTerms,
			creator: mapDbUserToUserInfo(publishedTerms.creator),
			updater: mapDbUserToUserInfo(publishedTerms.updater),
		};
	} catch (err) {
		log.e(`[publishTerms] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 시행 중 오류가 발생했습니다.');
	}
};

// 동의서 제출 이력 목록 조회
const findAgreementHistoryList = async dto => {
	try {
		const result = await termsModel.findAgreementHistoryList(dto);
		return result;
	} catch (err) {
		log.e(`[findAgreementHistoryList] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 제출 이력 조회 중 오류가 발생했습니다.');
	}
};

// 사용 가능한 동의서 카테고리 목록 조회
const findEnabledTermsCategories = async workspaceId => {
	try {
		return await termsModel.findEnabledTermsCategories(workspaceId);
	} catch (err) {
		log.e(`[findEnabledTermsCategories] error: ${JSON.stringify(err)}`);
		if (err instanceof HttpError) throw err;
		throw new HttpError(500, '동의서 카테고리 조회 중 오류가 발생했습니다.');
	}
};

export default {
	createTerms,
	findTermsList,
	findTermsById,
	updateTerms,
	deleteTerms,
	updateTermsStatus,
	findAgreementHistoryList,
	findEnabledTermsCategories,
};
