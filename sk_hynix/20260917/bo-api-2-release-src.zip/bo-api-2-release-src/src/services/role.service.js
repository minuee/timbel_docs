import roleModel from '../models/role.model.js';
import { menuService, workspaceService, historyService } from './index.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import { HttpError } from '../handlers/error.handler.js';

const vaildFieldExtraction = role => {
	try {
		const { adminType, name, description } = role;
		return {
			adminType,
			name,
			description,
		};
	} catch (error) {
		throw error;
	}
};

// global workspace 역할 생성
const initRole = async () => {
	try {
		// global workspace와 GLOBAL 역할 조회
		const [globalWorkspace, existingRole] = await Promise.all([
			workspaceService.getWorkspace({ domain: 'global' }),
			roleModel.getGlobalRole(),
		]);
		if (!globalWorkspace) throw new HttpError(1104, 'Global Workspace를 찾을 수 없습니다.');
		if (existingRole) {
			log.i(`[initRole] Global role already exists`);
			return;
		}

		// global workspace 역할 생성
		const role = await createRole({
			workspaceId: globalWorkspace.id,
			adminType: 'GLOBAL',
			name: '시스템 관리자(Global)',
			description: '시스템 관리자 역할',
		});

		// get global workspace Menu
		const menus = await menuService.getMenuList({ workspaceId: globalWorkspace.id });
		menus.forEach(menu => {
			menu.isAllowed = true;
		});

		// global workspace 역할 메뉴 연결
		await updatedRoleMenus({ id: role.id, menus });

		// GLOBAL 역할을 global 워크스페이스의 관리자(ADMIN) 멤버에 자동 할당한다.
		// (auth-api 부트스트랩이 만든 admin Member 는 menuRoleId 가 없어 BO 접근이 불가하므로,
		//  신규 구축 시 관리자가 바로 BO 시스템 관리에 접근할 수 있도록 여기서 연결한다.
		//  워크스페이스 OWNER 는 시스템 관리 대상이 아니므로 제외한다)
		const assigned = await mariaDB.member.updateMany({
			where: {
				workspaceId: globalWorkspace.id,
				role: Enums.WorkspaceRole.ADMIN,
			},
			data: { menuRoleId: role.id },
		});
		log.i(`[initRole] Global role assigned to ${assigned.count} admin member(s)`);
	} catch (error) {
		log.e(`[initRole] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getRoleList = async roleDto => {
	try {
		const { adminType } = roleDto;
		if (adminType && adminType === Enums.AdminType.GLOBAL) throw new HttpError(1401);
		const [roles, total] = await roleModel.findRoleList(roleDto);
		return { roles, total };
	} catch (error) {
		log.e(`[getRoleList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getWorkspaceRoleList = async roleDto => {
	try {
		const roles = await roleModel.getWorkspaceRoleList(roleDto);
		return roles;
	} catch (error) {
		log.e(`[getWorkspaceRoleList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getRole = async roleDto => {
	try {
		const { id, workspaceId = null } = roleDto;

		const role = await roleModel.getRole({ id });
		if (!role) throw new HttpError(1404);

		const menus = await menuService.getMenuList({ workspaceId: workspaceId || role.workspace.id, isUsed: true });

		// 시스템 역할(SYSTEM/GLOBAL)은 시스템 화면(SYSTEM/SYSTEM_ADDON) 권한도 부여할 수 있어야 한다.
		// 해당 메뉴는 global 워크스페이스에만 있어 워크스페이스 스코프 조회에서 빠지므로 별도로 합친다.
		if (role.adminType === Enums.AdminType.SYSTEM || role.adminType === Enums.AdminType.GLOBAL) {
			const systemMenus = await menuService.getMenuList({
				group: `${Enums.MenuGroup.SYSTEM},${Enums.MenuGroup.SYSTEM_ADDON}`,
				isUsed: true,
			});
			const seenCodes = new Set(menus.map(menu => menu.code));
			menus.push(...systemMenus.filter(menu => !seenCodes.has(menu.code)));
		}

		const allowedMenuCodeSet = new Set((role.menus || []).map(menu => menu.code));
		role.menus = menus.map(menu => ({
			id: menu.id,
			group: menu.group,
			code: menu.code,
			name: menu.name,
			urlPath: menu.urlPath,
			isAllowed: allowedMenuCodeSet.has(menu.code),
		}));

		return role;
	} catch (error) {
		log.e(`[getRole] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const createRole = async (roleDto, settingHistoryDto) => {
	try {
		const { adminType, workspaceId } = roleDto;
		if (!Object.values(Enums.AdminType).includes(adminType)) throw new HttpError(1401);

		await workspaceService.getWorkspace({ id: workspaceId });

		const createdRole = await roleModel.createRole(roleDto);

		if (adminType !== Enums.AdminType.GLOBAL) {
			await historyService.createSettingHistory({
				...settingHistoryDto,
				workspaceId: createdRole.workspaceId,
				changeItem: '역할 생성',
				tableName: 'ROLE',
				tableKey: createdRole.id,
				afterData: vaildFieldExtraction(createdRole),
			});
		}
		return createdRole;
	} catch (error) {
		log.e(`[createRole] error: ${JSON.stringify(error)}`);
		if (error.code === 'P2002') throw new HttpError(1409);
		throw error;
	}
};

const updateRole = async (roleDto, settingHistoryDto) => {
	try {
		const { id, adminType } = roleDto;
		if (!Object.values(Enums.AdminType).includes(adminType)) throw new HttpError(1401);

		const beforeRole = await getRole({ id });
		if (adminType === Enums.AdminType.WORKSPACE) {
			const restrictedMenus = beforeRole.menus.filter(
				menu => menu.isAllowed && (menu.group === 'SYSTEM' || menu.group === 'SYSTEM_ADDON')
			);
			if (restrictedMenus.length > 0) throw new HttpError(1402);
		}

		const updatedRole = await roleModel.updateRole(roleDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedRole.workspaceId,
			changeItem: '역할 수정',
			tableName: 'ROLE',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeRole),
			afterData: vaildFieldExtraction(updatedRole),
			requiredFields: ['name'],
		});
		return updatedRole;
	} catch (error) {
		log.e(`[updateRole] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updatedRoleMenus = async (roleDto, settingHistoryDto) => {
	try {
		const { id, menus } = roleDto;

		const beforeRole = await getRole({ id });

		const attachMenuIds = menus.filter(menu => menu.isAllowed).map(menu => menu.id);
		const detachMenuIds = menus.filter(menu => !menu.isAllowed).map(menu => menu.id);

		const updatedRole = await roleModel.updatedRoleMenus({ id, attachMenuIds, detachMenuIds });

		const afterRole = await getRole({ id });
		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedRole.workspaceId,
			changeItem: '역할 메뉴 권한 수정',
			tableName: '_MENUTOROLE',
			tableKey: id,
			beforeData: { name: beforeRole.name, menus: beforeRole.menus },
			afterData: { name: afterRole.name, menus: afterRole.menus },
			requiredFields: ['name'],
		});
		return updatedRole;
	} catch (error) {
		log.e(`[updatedRoleMenus] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const deleteRole = async (roleDto, settingHistoryDto) => {
	try {
		const { id } = roleDto;
		const beforeRole = await getRole({ id });

		const deletedRole = await roleModel.deleteRole(id);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: beforeRole?.workspace?.id || null,
			changeItem: '역할 삭제',
			tableName: 'ROLE',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeRole),
		});
		return deletedRole;
	} catch (error) {
		log.e(`[deleteRole] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default {
	initRole,
	getRoleList,
	getWorkspaceRoleList,
	getRole,
	createRole,
	updateRole,
	updatedRoleMenus,
	deleteRole,
};
