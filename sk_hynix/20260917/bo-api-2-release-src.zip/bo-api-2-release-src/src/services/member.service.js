import memberModel from '../models/member.model.js';
import roleService from './role.service.js';
import workspaceService from './workspace.service.js';
import { HttpError } from '../handlers/error.handler.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import historyService from './history.service.js';

const vaildFieldExtraction = member => {
	try {
		const { menuRole, user } = member;
		const { profile } = user;
		const { nickName } = profile;
		return {
			roleName: menuRole ? menuRole.name : '구성원',
			nickName,
		};
	} catch (error) {
		throw error;
	}
};

const findMemberAuthorities = async userDto => {
	try {
		const { workspaceId, workspaceName, memberId } = userDto;
		let result = {};

		const member = await getMember({ id: memberId });
		if (!member.menuRoleId) throw new HttpError(1303);

		const menuRole = await roleService.getRole({ id: member.menuRoleId, workspaceId });
		result.menus = menuRole.menus;

		if (menuRole.adminType === Enums.AdminType.GLOBAL || menuRole.adminType === Enums.AdminType.SYSTEM) {
			result.workspaces = await workspaceService.getWorkspaceList({});
			result.workspaces.forEach(workspace => {
				workspace.isDefault = workspace.id === workspaceId;
			});
		} else if (menuRole.adminType === Enums.AdminType.WORKSPACE) {
			result.workspaces = { id: workspaceId, name: workspaceName, isDefault: true };
		}

		return result;
	} catch (error) {
		log.e(`[findMemberAuthorities] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const findMembersForDelete = async memberDto => {
	try {
		const members = await memberModel.findMembersForDelete(memberDto);
		const contentIds = members.flatMap(member => member.creatorContent.map(content => content.contentId));
		return { members, contentIds };
	} catch (error) {
		log.e(`[findMembersForDelete] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getMemberList = async memberDto => {
	try {
		const [members, total] = await memberModel.getMemberList(memberDto);
		const roles = await roleService.getWorkspaceRoleList({
			workspaceId: memberDto.workspaceId,
			adminType: memberDto.isSystem ? null : Enums.AdminType.WORKSPACE,
		});

		const workspaceMap = new Map();
		roles.forEach(role => {
			const workspaceId = role.workspaceId;
			if (!workspaceMap.has(workspaceId)) {
				workspaceMap.set(workspaceId, {
					id: workspaceId,
					roles: [],
				});
			}
			workspaceMap.get(workspaceId).roles.push({
				id: role.id,
				name: role.name,
			});
		});

		const workspaces = Array.from(workspaceMap.values());

		return { members, total, workspaces };
	} catch (error) {
		log.e(`[getMemberList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getMember = async memberDto => {
	try {
		const { id } = memberDto;
		const member = await memberModel.getMember(id);
		if (!member) throw new HttpError(1304);
		return member;
	} catch (error) {
		log.e(`[getMember] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getStatisticsMemberList = async memberDto => {
	try {
		const memberList = await memberModel.getStatisticsMemberList(memberDto);
		return memberList;
	} catch (error) {
		log.e(`[getStatisticsMemberList] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const getWorkspaceMemberCount = async workspaceIds => {
	return await memberModel.getWorkspaceMemberCount(workspaceIds);
};

const createMember = async memberDto => {
	try {
		const member = await memberModel.createMember(memberDto);
		return member;
	} catch (error) {
		log.e(`[createMember] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

const updateMemberRole = async (memberDto, settingHistoryDto) => {
	try {
		const { id, roleId } = memberDto;
		const beforeMember = await getMember({ id });

		if (roleId) await roleService.getRole({ id: roleId });

		const updatedMember = await memberModel.updateMemberRole(memberDto);

		await historyService.createSettingHistory({
			...settingHistoryDto,
			workspaceId: updatedMember.workspaceId,
			changeItem: '사용자 역할 수정',
			tableName: 'MEMBER',
			tableKey: id,
			beforeData: vaildFieldExtraction(beforeMember),
			afterData: vaildFieldExtraction(updatedMember),
			requiredFields: ['nickName', 'roleName'],
		});
		return updatedMember;
	} catch (error) {
		log.e(`[updateMemberRole] error: ${JSON.stringify(error)}`);
		throw error;
	}
};

export default {
	findMemberAuthorities,
	findMembersForDelete,
	getMemberList,
	getMember,
	getStatisticsMemberList,
	getWorkspaceMemberCount,
	createMember,
	updateMemberRole,
};
