import fs from 'fs';
import 'dotenv/config';
import path from 'path';
import Consul from 'consul';

const envFilePath = path.join(process.cwd(), '.env');
const consul = new Consul({
	host: process.env.CONSUL_HOST || 'consul-discovery',
	port: process.env.CONSUL_PORT || 8500,
	secure: false,
});

console.log('envFilePath:', envFilePath);

const getConfigJson = async () => {
	let commonConfig = await consul.kv.get('timblo/common/env');
	if (!commonConfig) throw new Error('No config found in Consul common/env');
	const value2 = commonConfig.Value.replace(/,\s*}$/, '}');
	commonConfig = JSON.parse(value2);

	let immutableConfig = await consul.kv.get(`timblo/${process.env.APP_NAME}/immutable`);
	if (!immutableConfig) throw new Error(`No config found in Consul ${process.env.APP_NAME}/immutable`);
	const value = immutableConfig.Value.replace(/,\s*}$/, '}');
	immutableConfig = JSON.parse(value);

	return { ...immutableConfig, ...commonConfig };
};

try {
	const config = await getConfigJson();

	let envContent = '';
	Object.keys(config).forEach(key => {
		let value = config[key];
		if (isNaN(value) || typeof value === 'string') {
			value = `"${value}"`;
		}
		envContent += `${key}=${value}\n`;
	});

	fs.writeFileSync(envFilePath, envContent);
	console.log('.env file created successfully');
} catch (err) {
	console.error('Error generating .env file:', err.message);
	process.exit(1);
}
