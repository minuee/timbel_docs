import { security } from './index.js';
import { HttpError } from '../handlers/error.handler.js';
import { Client } from '@timbel-timblo-onpremise/minio-js';

const { env } = process;

let MinioClient = null;

const initializeMinioClient = () => {
	if (!MinioClient) {
		MinioClient = new Client({
			endPoint: env.END_POINT || 'timblo-minio',
			port: env.END_POINT_PORT ? Number(env.END_POINT_PORT) : 9000,
			accessKey: env.ACCESS_KEY_ID,
			secretKey: env.SECRET_ACCESS_KEY,
			region: env.REGION || 'ap-northeast-2',
			useSSL: env.USE_SSL === 'true',
		});
	}
};

process.on('storageChanged', () => {
	MinioClient = new Client({
		endPoint: env.END_POINT || 'timblo-minio',
		port: env.END_POINT_PORT ? Number(env.END_POINT_PORT) : 9000,
		accessKey: env.ACCESS_KEY_ID,
		secretKey: env.SECRET_ACCESS_KEY,
		region: env.REGION || 'ap-northeast-2',
		useSSL: env.USE_SSL === 'true',
	});
});

// 초기화 시점에 클라이언트 생성
initializeMinioClient();

export default class DriveUtil {
	constructor({ kms, config }) {
		this.kms = kms ?? null;
		this.isMobile = config?.isMobile ?? false;
		return this;
	}

	createPutParams() {
		const { originalname, size, mimetype } = this.file;
		return {
			'Content-Type': mimetype,
			'Content-Length': size,
			originalname: encodeURIComponent(originalname),
		};
	}

	async putThumbnailObject(workspaceId, type, file) {
		this.file = file;
		log.i('[DriveUtil : putThumbnail] Thumbnail Upload Start');
		const key = !type ? 'thumbnail' : type;
		const fullPath = `${workspaceId}/${key}`;
		const encryptPath = security.encryptECB(fullPath);
		const params = this.createPutParams();
		params['x-amz-acl'] = 'public-read';

		log.i('[DriveUtil : putThumbnail] 생성 경로 => ', encryptPath);
		const result = await MinioClient.putObject(env.PUB_BUCKET_NAME, encryptPath, this.file.buffer, params);

		if (result.err) {
			log.e('[DriveUtil : putThumbnail] Thumbnail Upload Fail ', result.err);
			throw new HttpError(500, '파일 업로드에 실패했습니다.');
		}

		const publicUrl = `https://${env.IMAGE_END_POINT}/${env.PUB_BUCKET_NAME}/${encodeURIComponent(encryptPath)}`;
		log.i('[DriveUtil : putThumbnail] Thumbnail Upload OK ', publicUrl);

		return publicUrl;
	}

	async removeThumbnailObject({ pid = null, workspaceId = null }, key = 'thumbnail') {
		log.i(`[DriveUtil : removeThumbnailObject] key => ${key}`);
		const fullPath = key === 'thumbnail' ? `${pid}/${key}` : `${workspaceId}/${key}`;
		log.i('[DriveUtil : removeThumbnail] fullPath => ', fullPath);
		const encryptPath = security.encryptECB(fullPath);
		log.i('[DriveUtil : removeThumbnail] removeObject Start => ', encryptPath);
		await MinioClient.removeObject(env.PUB_BUCKET_NAME, encryptPath);
		log.i('[DriveUtil : removeThumbnail] removeObject End');
	}

	async removeContents(directoryPath) {
		try {
			log.i('[DriveUtil : removeContents] Start => ', directoryPath);

			const objectsList = [];
			const listStream = MinioClient.listObjects(env.BUCKET_NAME, directoryPath, true);

			for await (const obj of listStream) {
				objectsList.push(obj.name);
			}

			if (objectsList.length === 0) {
				log.i('[DriveUtil : removeContents] 삭제할 객체가 없습니다 => ', directoryPath);
				return;
			}
			log.i('[DriveUtil : removeContents] 삭제할 객체 개수 => ', objectsList.length);

			await MinioClient.removeObjects(env.BUCKET_NAME, objectsList);

			log.i('[DriveUtil : removeContents] End => ', directoryPath, ' (삭제된 객체: ', objectsList.length, ')');
		} catch (err) {
			log.e('[DriveUtil : removeContents] Fail ', err);
			throw new HttpError(500, '파일 삭제에 실패했습니다.');
		}
	}
}
