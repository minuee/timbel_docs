class ConvertUtil {
	originalnameEncoding({ originalname }) {
		return Buffer.from(originalname, 'latin1').toString('utf8');
	}

	/**
	 * 배열 데이터를 CSV 형식으로 변환
	 * @param {Array} data - CSV로 변환할 데이터 배열
	 * @param {Array} headers - CSV 헤더 배열 (옵션)
	 * @param {Array} forceQuoteFields - 강제 따옴표가 필요한 필드 배열 (옵션)
	 * @returns {String} CSV 문자열
	 */
	arrayToCsv(data, headers = null, forceQuoteFields = []) {
		if (!data || data.length === 0) return '';

		const csvHeaders = headers || Object.keys(data[0]);

		const escapeCsvField = (field, headerName) => {
			if (field === null || field === undefined) return '';
			const str = String(field);

			const shouldForceQuote = forceQuoteFields.includes(headerName);
			if (shouldForceQuote) {
				return `"${str.replace(/"/g, '""')}"`;
			}
			return str;
		};

		const headerRow = csvHeaders.map(header => escapeCsvField(header, header)).join(',');

		const dataRows = data.map(row => {
			return csvHeaders.map(header => escapeCsvField(row[header], header)).join(',');
		});

		const BOM = '\uFEFF';
		return BOM + [headerRow, ...dataRows].join('\n');
	}
}

export default new ConvertUtil();
