import fs from 'fs';
import { HttpError } from '../handlers/error.handler.js';
import licenseManager from '@timbel-timblo-onpremise/license';

class LicenseMonitor {
	static instance = null;
	isInitialized = false;

	constructor() {
		if (LicenseMonitor.instance) {
			return LicenseMonitor.instance;
		}
		LicenseMonitor.instance = this;
	}

	static getInstance() {
		if (!LicenseMonitor.instance) {
			LicenseMonitor.instance = new LicenseMonitor();
		}
		return LicenseMonitor.instance;
	}

	getLicenseInfo() {
		try {
			const licenseId = licenseManager.getLicenseId();
			const productId = licenseManager.getProductId();
			const seats = licenseManager.getSeats();
			const isFileWatching = licenseManager.isFileWatching();
			const getLastVerification = licenseManager.getLastVerification();
			const verifiedAt = getLastVerification?.timestamp || null;

			return {
				licenseId,
				productId,
				seats,
				isFileWatching,
				verifiedAt,
			};
		} catch (error) {
			log.e('라이선스 정보 조회 실패:', error);
			return {
				licenseId: '',
				productId: '',
				seats: 0,
				isFileWatching: false,
				verifiedAt: null,
			};
		}
	}

	async initialize() {
		if (this.isInitialized) {
			log.w('========== 라이선스 모니터가 이미 초기화되었습니다. ==========');
			return this.getLicenseInfo();
		}

		try {
			await licenseManager.ready();
			this.isInitialized = true;
			return this.getLicenseInfo();
		} catch (error) {
			log.e('========== 라이선스 모니터 초기화 실패:', error);
			throw error;
		}
	}

	isVerified() {
		return licenseManager.isVerified();
	}

	isReady() {
		return this.isInitialized && licenseManager.isFileWatching();
	}

	reset() {
		this.isInitialized = false;
		log.i('라이선스 모니터가 강제 리셋되었습니다.');
	}

	validateNewLicenseFile(file, jwt) {
		if (!file.originalname.endsWith('.jwt')) {
			throw new HttpError(400, '라이선스 파일은 .jwt 확장자여야 합니다.');
		}

		const fileContent = file.buffer.toString('utf8');
		try {
			const decoded = jwt.decode(fileContent);
			if (!decoded) {
				throw new Error('JWT 디코딩 실패');
			}
		} catch {
			throw new HttpError(400, '유효하지 않은 JWT 형식의 라이선스 파일입니다.');
		}
	}

	async validateNewLicense() {
		try {
			log.i('새 라이선스 파일 검증을 처음부터 다시 시작합니다.');

			this.reset();
			log.d('라이선스 모니터가 완전히 리셋되었습니다.');

			await licenseManager.ready();
			log.d('라이선스 매니저가 준비되었습니다.');

			const isFileWatching = licenseManager.isFileWatching();
			log.d(`파일 감시 상태: ${isFileWatching}`);

			if (!isFileWatching) {
				const reason = '라이선스 파일 감시가 시작되지 않았습니다. 파일이 유효하지 않을 수 있습니다.';
				log.w('라이선스 검증 실패: 파일 감시 상태가 false');
				return { isValid: false, reason };
			}

			await this.waitForLicenseVerification();
			log.d('라이선스 검증이 완료되었습니다.');

			await new Promise(resolve => setTimeout(resolve, 1000));
			log.d('라이선스 매니저 완전 준비 완료');

			const licenseId = licenseManager.getLicenseId();
			const productId = licenseManager.getProductId();
			const seats = licenseManager.getSeats();
			const isVerified = licenseManager.isVerified();

			log.d(
				`라이선스 매니저 정보: ${JSON.stringify({ licenseId, productId, seats, isVerified, isFileWatching: licenseManager.isFileWatching() })}`
			);

			if (!isVerified) {
				const reason = '라이선스 검증에 실패했습니다. 라이선스 파일이 손상되었거나 만료되었을 수 있습니다.';
				log.w('라이선스 검증 실패: isVerified가 false');
				return { isValid: false, reason };
			}

			if (!licenseId || !productId) {
				const reason = '라이선스 파일에 필수 정보(라이선스 ID, 제품 ID)가 누락되었습니다.';
				log.w('라이선스 검증 실패: licenseId 또는 productId가 없음');
				return { isValid: false, reason };
			}

			if (seats < -1) {
				const reason = `라이선스 파일의 시트 수가 유효하지 않습니다. (현재 값: ${seats})`;
				log.w(`라이선스 검증 실패: seats 값이 유효하지 않음 (${seats})`);
				return { isValid: false, reason };
			}

			log.i('새 라이선스 파일 검증이 성공적으로 완료되었습니다.');
			return { isValid: true };
		} catch (error) {
			const reason = `라이선스 검증 중 오류가 발생했습니다: ${error.message}`;
			log.e(`라이선스 검증 실패: ${error}`);
			return { isValid: false, reason };
		}
	}

	async waitForLicenseVerification() {
		const maxWaitTime = 15000;
		const checkInterval = 500;
		let elapsedTime = 0;
		let lastVerificationResult = null;
		const verificationStartTime = Date.now();

		log.d('라이선스 검증 완료 대기 시작...');

		while (elapsedTime < maxWaitTime) {
			const isPending = licenseManager.isVerificationPending();
			const currentVerification = licenseManager.getLastVerification();

			log.d(`검증 상태: pending=${isPending}, lastVerification=${currentVerification ? 'exists' : 'null'}`);

			if (!isPending && currentVerification) {
				if (!lastVerificationResult || currentVerification.timestamp !== lastVerificationResult.timestamp) {
					const verificationElapsed = Date.now() - verificationStartTime;
					if (verificationElapsed >= 2000) {
						log.d(`라이선스 검증이 완료되었습니다. (${verificationElapsed}ms 소요)`);
						return;
					} else {
						log.d(`검증 완료되었지만 최소 대기 시간 미달 (${verificationElapsed}ms). 계속 대기...`);
					}
				}
			}

			lastVerificationResult = currentVerification;

			await new Promise(resolve => setTimeout(resolve, checkInterval));
			elapsedTime += checkInterval;
		}

		log.w(`라이선스 검증 대기 시간 초과 (${maxWaitTime / 1000}초)`);
		throw new Error(`라이선스 검증 대기 시간이 초과되었습니다. (${maxWaitTime / 1000}초)`);
	}

	createLicenseBackup(licensePath, tempLicensePath, currentLicenseInfo) {
		if (!fs.existsSync(licensePath)) {
			return false;
		}

		const oldLicenseFile = fs.readFileSync(licensePath, 'utf8');
		fs.writeFileSync(tempLicensePath, oldLicenseFile, { mode: 0o644 });

		log.i(`기존 라이선스 파일을 임시 백업했습니다: ${tempLicensePath}`);
		log.d(
			`백업된 라이선스 정보: ${JSON.stringify({ licenseId: currentLicenseInfo.licenseId, verifiedAt: currentLicenseInfo.verifiedAt })}`
		);

		return true;
	}

	async restoreLicenseFile(licensePath, tempLicensePath, isBackupCreated) {
		log.i('신규 라이선스 검증이 실패했습니다. 기존 라이선스 파일을 복원합니다.');

		if (!isBackupCreated || !fs.existsSync(tempLicensePath)) {
			throw new HttpError(400, '라이선스 파일이 유효하지 않습니다.');
		}

		try {
			const tempFileContent = fs.readFileSync(tempLicensePath, 'utf8');
			fs.writeFileSync(licensePath, tempFileContent, { mode: 0o644 });

			log.d('라이선스 파일을 복원했습니다. 검증을 시작합니다...');

			const validationResult = await this.validateNewLicense();
			if (!validationResult.isValid) {
				log.e(`복원된 라이선스 검증 실패: ${validationResult.reason}`);
				throw new Error('라이선스 복원 후 검증에 실패했습니다.');
			}

			log.d('복원된 라이선스 파일 검증이 성공했습니다.');
			log.i('기존 라이선스 파일 복원이 완료되었습니다.');

			throw new HttpError(400, '라이선스 파일이 유효하지 않습니다.');
		} catch (restoreError) {
			log.e(`라이선스 파일 복원 실패: ${restoreError}`);

			if (!(restoreError instanceof HttpError)) {
				throw new HttpError(400, '라이선스 파일이 유효하지 않습니다.');
			}
			throw restoreError;
		}
	}
}

export default new LicenseMonitor();
