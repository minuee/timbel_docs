import { HttpError } from '../handlers/error.handler.js';

const isUnsignedInt = value => {
	if (typeof value !== 'number') throw new HttpError(1000);
	if (isNaN(value)) throw new HttpError(1000);
	if (value < 0) throw new HttpError(1000);
};

// 허용된 필드 목록 검증
const isAllowedFilter = (filter, allowedFilterList) => {
	if (filter && !allowedFilterList.includes(filter)) throw new HttpError(1008);
};

// 허용된 정렬 필드 목록 검증
const isAllowedOrderByField = (orderByField, allowedOrderByFieldList) => {
	if (orderByField && !allowedOrderByFieldList.includes(orderByField)) throw new HttpError(1009);
};

// 허용된 정렬 방향 목록 검증
const isAllowedSortOrder = (sortOrder, allowedSortOrderList = ['asc', 'desc']) => {
	if (sortOrder && !allowedSortOrderList.includes(sortOrder)) throw new HttpError(1009);
};

const validatePeriodFormat = (periodType, startPeriod, endPeriod) => {
	if (periodType === 'MONTHLY') {
		const monthlyPattern = /^\d{4}\.\d{2}$/;
		if (!monthlyPattern.test(startPeriod)) throw new HttpError(1012);
		if (!monthlyPattern.test(endPeriod)) throw new HttpError(1012);
	} else if (periodType === 'YEARLY') {
		const yearlyPattern = /^\d{4}$/;
		if (!yearlyPattern.test(startPeriod)) throw new HttpError(1012);
		if (!yearlyPattern.test(endPeriod)) throw new HttpError(1012);
	} else if (periodType === 'YYYY-MM-DD') {
		const dailyPattern = /^\d{4}-\d{2}-\d{2}$/;
		if (startPeriod && !dailyPattern.test(startPeriod)) throw new HttpError(1012);
		if (endPeriod && !dailyPattern.test(endPeriod)) throw new HttpError(1012);
	}

	if (startPeriod > endPeriod) throw new HttpError(1010);
};

const validateEmail = email => {
	const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	if (!emailRegex.test(email)) throw new HttpError(1011);
};

// 쉼표로 구분된 문자열을 배열로 변환 (빈 값 제거)
const parseCommaSeparatedToArray = value => {
	if (!value) return undefined;
	if (typeof value !== 'string') return undefined;
	const result = value
		.split(',')
		.map(item => item.trim())
		.filter(item => item.length > 0);
	return result.length > 0 ? result : undefined;
};

const validateMagicByte = ({ buffer, mimetype }) => {
	if (!buffer || buffer.length < 4) return false;

	const magicBytes = buffer.slice(0, 4);
	log.i('mimetype', mimetype);

	// 각 이미지 타입별 매직 바이트 검증
	switch (mimetype) {
		case 'image/jpeg':
		case 'image/jpg':
			return magicBytes[0] === 0xff && magicBytes[1] === 0xd8;
		case 'image/png':
			return magicBytes[0] === 0x89 && magicBytes[1] === 0x50 && magicBytes[2] === 0x4e && magicBytes[3] === 0x47;
		case 'image/gif':
			return magicBytes[0] === 0x47 && magicBytes[1] === 0x49 && magicBytes[2] === 0x46 && magicBytes[3] === 0x38;
		case 'image/bmp':
			return magicBytes[0] === 0x42 && magicBytes[1] === 0x4d;
		default:
			return false;
	}
};

const validateDateRange = (fromDate, toDate) => {
	if (fromDate && toDate && new Date(fromDate) > new Date(toDate)) throw new HttpError(1010);
};

/**
 * 날짜 범위 검증
 * @param {string} fromDate - 시작일 (YYYY-MM-DD)
 * @param {string} toDate - 종료일 (YYYY-MM-DD)
 * @returns {object} 검증된 날짜 범위
 */
const validateFromToDate = (fromDate, toDate) => {
	if (!fromDate || !toDate) throw new HttpError(1000);

	const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
	if (!dateRegex.test(fromDate) || !dateRegex.test(toDate)) throw new HttpError(1012);

	const start = new Date(fromDate);
	const end = new Date(toDate);

	if (isNaN(start.getTime()) || isNaN(end.getTime())) throw new HttpError(1013);

	if (start > end) throw new HttpError(1010);

	const today = new Date();
	today.setHours(23, 59, 59, 999);
	if (end > today) throw new HttpError(1018);
};

export default {
	isUnsignedInt,
	isAllowedFilter,
	isAllowedOrderByField,
	isAllowedSortOrder,
	validatePeriodFormat,
	validateEmail,
	validateMagicByte,
	validateDateRange,
	parseCommaSeparatedToArray,
	validateFromToDate,
};
