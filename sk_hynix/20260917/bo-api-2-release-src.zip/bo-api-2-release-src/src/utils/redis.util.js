import common from './common.util.js';
import { createClient } from 'redis';

class redisUtil {
	constructor() {
		this.EXPIRE_TIME = process.env.CACHE_EXP || 3 * 60 * 60;

		const config = {
			socket: {
				port: process.env.REDIS_PORT,
				host: process.env.REDIS_HOST,
			},
			password: process.env.REDIS_PASS,
			legacyMode: false,
		};

		log.i('[RedisConfig]', config);
		this.client = createClient(config);

		this.client.on('error', err => {
			log.e('[RedisUtil] ❌ Client Error:', err.message);
		});

		this.connectWithRetry();
	}

	async connectWithRetry(retries = 5) {
		for (let i = 0; i < retries; i++) {
			try {
				await this.client.connect();
				log.i('[RedisUtil] ✅ Redis Connection Success');
				return;
			} catch (err) {
				log.e(`[RedisUtil] ❌ Redis connection failed (attempt ${i + 1}/${retries}):`, err.message);
				if (i < retries - 1) {
					await common.delayWithRandom('RedisUtil');
				} else {
					log.e('[RedisUtil] ❌ All retries exhausted. Redis connection failed permanently.');
				}
			}
		}
	}

	async get(key) {
		const result = await this.client.get(key);
		return JSON.parse(result);
	}

	set(key, value, ex = this.EXPIRE_TIME) {
		this.client.set(key, JSON.stringify(value), { EX: ex });
	}
}

export default new redisUtil();
