import multer from 'multer';

let uploadTimeout = 3 * 60 * 60 * 1000;
process.on('configChanged', () => {
	uploadTimeout = process.env.UPLOAD_TIMEOUT || 3 * 60 * 60 * 1000;
});

class multerUtil {
	uploadFile() {
		return multer({
			limits: {
				fileSize: 2 * 1024 * 1024 * 1024,
			},
		}).single('file');
	}

	uploadFileWithTimeout() {
		const upload = this.uploadFile();
		return (req, res, next) => {
			const timer = setTimeout(() => {
				log.i(`[multer] Upload timeout after ${uploadTimeout}ms`);
				if (!res.headersSent) {
					res.status(200).json({
						message: '업로드 시간이 초과되었습니다.',
						httpCode: 408,
					});
				}
			}, uploadTimeout);
			upload(req, res, err => {
				clearTimeout(timer);
				if (err) return next(err);
				next();
			});
		};
	}
}

export default new multerUtil();
