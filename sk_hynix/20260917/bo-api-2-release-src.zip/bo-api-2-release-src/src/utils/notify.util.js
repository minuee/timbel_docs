import notify from '@timbel-timblo-onpremise/notify';

await notify.connect();

export const featureSettingsUpdated = (workspaceId, data) => {
	if (!notify.isConnect()) {
		return false;
	}

	try {
		notify.web.workspace(workspaceId, {
			data,
			action: 'WORKSPACE_SETTINGS_UPDATED',
		});
		return true;
	} catch (error) {
		log.e('[notifyUtil] Error : ', error);
		return false;
	}
};

export default {
	featureSettingsUpdated,
};
