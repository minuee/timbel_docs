const formatCreatorOrUpdaterProfile = profile => {
	if (!profile) return {};
	return {
		pid: profile?.pid || null,
		nickName: profile?.nickName || null,
		email: profile?.email || null,
		thumbnailUrl: profile?.thumbnailUrl || null,
	};
};

const transformTemplateProfile = (template, deleteFields = []) => {
	if (Array.isArray(template)) {
		return template.map(item => transformTemplateProfile(item, deleteFields));
	}

	const { category, creator, editor, ...rest } = template;
	if (deleteFields.length > 0) {
		for (const field of deleteFields) {
			delete rest[field];
		}
	}
	return {
		...rest,
		category: category?.name ?? null,
		creator: creator?.user?.profile || undefined,
		editor: editor?.user?.profile || undefined,
	};
};

export default { formatCreatorOrUpdaterProfile, transformTemplateProfile };
