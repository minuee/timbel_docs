import crypto from 'crypto';
import generate from './generate.util.js';

const getInviteCode = domain => {
	const hash = crypto.createHash('sha256').update(domain).digest('hex');
	const inviteCode = hash.slice(0, 6);
	return inviteCode;
};

const encryptECB = data => {
	const SECRET_KEY = process.env.ENCRYPT_SECRET_KEY || undefined;
	const keyHex = generate.keyFromString(SECRET_KEY, 'hex');
	const keyBuffer = Buffer.from(keyHex, 'hex');
	const cipher = crypto.createCipheriv('aes-256-ecb', keyBuffer, '');
	let encrypted = cipher.update(data, 'utf8', 'hex');
	encrypted += cipher.final('hex');
	return encrypted;
};

export default { getInviteCode, encryptECB };
