import axios from 'axios';
import { Agent } from 'https';
import transform from './transform.util.js';
import { HttpError } from '../handlers/error.handler.js';

const AX_API_URL = process.env.AX_API_URL || 'https://3.35.96.235:29002/api/';
const TAG = '[TemplateUtil] ';

export const templateZipUpload = async file => {
	try {
		const fileName = file.originalname;
		log.i(TAG, `[templateZipUpload] fileName: ${fileName}`);
		const { data, status } = await axios.post(
			`${AX_API_URL}prompt`,
			{
				file_path: `prompt/${fileName}`,
			},
			{
				httpsAgent: new Agent({
					rejectUnauthorized: false,
				}),
			}
		);

		if (status !== 200) throw new HttpError(5400);
		return data;
	} catch (err) {
		throw new HttpError(5400);
	}
};

export const filterLatestTemplatesByKeyAndInputType = (templates, version = null) => {
	const latestTemplatesMap = new Map();
	if (version) {
		return templates.filter(template => template.version === version);
	} else {
		for (const template of templates) {
			const key = template.id;
			latestTemplatesMap.set(key, template);
		}
		return Array.from(latestTemplatesMap.values());
	}
};

export const filterTemplateVersions = (templates, latestTemplate) => {
	const versions = templates.filter(template => template.version !== latestTemplate.version);
	const deleteFields = ['name', 'preview', 'options', 'isUsed'];
	return transform.transformTemplateProfile(versions, deleteFields);
};

export default { templateZipUpload, filterLatestTemplatesByKeyAndInputType, filterTemplateVersions };
