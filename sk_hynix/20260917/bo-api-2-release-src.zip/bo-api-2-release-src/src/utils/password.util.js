import bcrypt from 'bcrypt';

const saltRounds = 15;
export const hashPassword = async (password, pid) => {
	try {
		return await bcrypt.hash(`${password}${pid}`, saltRounds);
	} catch (err) {
		log.e(err);
		return undefined;
	}
};

export default {
	hashPassword,
};
