import cryptoV1 from 'crypto';

const defaultBucketPath = process.env.DEFAULT_BUCKET_PATH || '';

class GenerateUtil {
	keyFromString(str, option = 'hex') {
		const hash = cryptoV1.createHash('sha256');
		hash.update(str);
		return defaultBucketPath + hash.digest(option);
	}

	templateId(key) {
		const splitKey = key.split('_');
		let resultKey = '';
		if (splitKey.length === 1) resultKey = `DEF-${splitKey[0]}`;
		else resultKey = `DEF-${splitKey.join('-')}`;
		return resultKey.toUpperCase();
	}
}

export default new GenerateUtil();
