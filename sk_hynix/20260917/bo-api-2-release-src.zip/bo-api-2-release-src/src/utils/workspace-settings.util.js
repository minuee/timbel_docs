import { HttpError } from '../handlers/error.handler.js';
import { DEFAULT_SETTING_ITEMS } from '../constants/workspace-settings.constants.js';

/**
 * 설정 키에서 부모 키를 추출하는 함수
 * @param {string} key - 설정 키 (예: "download_docs.txt_enabled")
 * @returns {string} - 부모 키 (예: "download_docs")
 */
const getParentKey = key => {
	const parts = key.split('.');
	return parts.length > 1 ? parts[0] : key;
};

/**
 * 설정값을 적절한 타입으로 파싱하는 함수
 * @param {string} value - 문자열 값
 * @param {string} valueType - 값 타입
 * @returns {boolean|string|number} - 파싱된 값
 */
const parseSettingValue = (value, valueType) => {
	switch (valueType) {
		case 'BOOLEAN':
			return value === 'true';
		case 'STRING':
			return value;
		case 'NUMBER': {
			const numValue = Number(value);
			if (isNaN(numValue)) {
				throw new Error(`숫자로 변환할 수 없는 값입니다: ${value}`);
			}
			if (numValue < 0) {
				throw new Error('number 타입은 0 이상의 정수 값이어야 합니다.');
			}
			return numValue;
		}
		default:
			return value;
	}
};

/**
 * 기능 설정값들을 계층 구조로 변환하는 함수
 * @param {Array} rawSettings - 원시 기능 설정 배열
 * @returns {Object} - { settings: Array, simpleSettings: Object }
 */
export const transformSettingsToHierarchy = rawSettings => {
	const settingsMap = new Map();

	// 공통 속성을 추출하는 헬퍼 함수
	const createCommonSettingProps = setting => {
		const { settingItem, value } = setting;
		return {
			group: settingItem.group,
			key: settingItem.key,
			name: settingItem.name,
			type: settingItem.valueType,
			uiType: settingItem.uiType,
			value: parseSettingValue(value, settingItem.valueType),
			options: settingItem.options ?? undefined,
			validation: settingItem.validation ?? undefined,
		};
	};

	// 먼저 부모 설정들을 처리
	rawSettings.forEach(setting => {
		const key = setting.settingItem.key;
		const parentKey = getParentKey(key);

		// 부모 설정 자체인 경우 (자식이 아닌 경우)
		if (parentKey === key) {
			if (!settingsMap.has(parentKey)) {
				const commonProps = createCommonSettingProps(setting);
				settingsMap.set(parentKey, {
					...commonProps,
					key: parentKey,
					description: setting.settingItem.description,
					items: [],
				});
			}
		}
	});

	// 그 다음 자식 설정들을 처리
	rawSettings.forEach(setting => {
		const key = setting.settingItem.key;
		const parentKey = getParentKey(key);

		// 자식 설정인 경우
		if (parentKey !== key) {
			// 부모가 없으면 생성 (자식 설정의 정보로)
			if (!settingsMap.has(parentKey)) {
				// 부모 설정을 찾기 위해 rawSettings에서 부모 키와 일치하는 설정 찾기
				const parentSetting = rawSettings.find(s => s.settingItem.key === parentKey);
				if (parentSetting) {
					const commonProps = createCommonSettingProps(parentSetting);
					settingsMap.set(parentKey, {
						...commonProps,
						key: parentKey,
						description: parentSetting.settingItem.description,
						items: [],
					});
				} else {
					// 부모 설정이 DB에 없으면 자식 설정의 정보로 생성
					const commonProps = createCommonSettingProps(setting);
					settingsMap.set(parentKey, {
						...commonProps,
						key: parentKey,
						description: setting.settingItem.description,
						items: [],
					});
				}
			}

			const parent = settingsMap.get(parentKey);
			if (parent) {
				const commonProps = createCommonSettingProps(setting);
				// 자식 설정은 description 제외
				const { description, ...childProps } = commonProps;
				parent.items.push({ ...childProps, key: key });
			}
		}
	});

	const transformedSettings = Array.from(settingsMap.values());
	const simpleSettings = transformSettingsToSimpleSettings(transformedSettings);

	return { settings: transformedSettings, simpleSettings };
};

/**
 * 변환된 설정 배열을 평면 구조로 변환
 * @param {Array} transformedSettings - 변환된 설정 배열
 * @returns {Object} - 평면 구조의 설정 객체
 */
const transformSettingsToSimpleSettings = transformedSettings => {
	const simpleSettings = {};

	transformedSettings.forEach(setting => {
		// EXPIRATION 그룹은 제외
		if (setting.group === 'EXPIRATION') {
			return;
		}

		simpleSettings[setting.key] = setting.value;

		if (setting.items && setting.items.length > 0) {
			setting.items.forEach(item => {
				simpleSettings[item.key] = item.value;
			});
		}
	});

	return simpleSettings;
};

/**
 * 기능 설정값 유효성 검증
 * @param {*} value - 검증할 값
 * @param {string} valueType - 값의 타입
 * @param {Object} validation - 유효성 검증 규칙
 */
export const validateSettingValue = ({ value, valueType, validation }) => {
	// 기본 타입 검증
	switch (valueType) {
		case 'BOOLEAN':
			if (typeof value === 'boolean') break;
			if (typeof value === 'string' && (value === 'true' || value === 'false')) break;
			throw new HttpError(1000, 'boolean 타입은 true 또는 false 값이어야 합니다.');

		case 'STRING':
			if (typeof value === 'string') break;
			throw new HttpError(1000, 'string 타입은 문자열 값이어야 합니다.');

		case 'NUMBER': {
			let numValue;
			if (typeof value === 'number') {
				numValue = value;
			} else if (typeof value === 'string') {
				numValue = Number(value);
				if (isNaN(numValue)) {
					throw new HttpError(1000, 'number 타입은 유효한 숫자 값이어야 합니다.');
				}
			} else {
				throw new HttpError(1000, 'number 타입은 숫자 값이어야 합니다.');
			}

			// 추가 숫자 검증
			if (validation) {
				if (validation.min !== undefined && numValue < validation.min) {
					throw new HttpError(1000, `값은 ${validation.min} 이상이어야 합니다.`);
				}
				if (validation.max !== undefined && numValue > validation.max) {
					throw new HttpError(1000, `값은 ${validation.max} 이하여야 합니다.`);
				}
			}
			break;
		}

		default:
			throw new HttpError(1000, '지원하지 않는 값 타입입니다.');
	}

	// 추가 검증 규칙 (옵션)
	if (validation) {
		// enum 검증
		if (validation.enum && !validation.enum.includes(value)) {
			throw new HttpError(1000, `허용되지 않는 값입니다. 허용값: ${validation.enum.join(', ')}`);
		}

		// pattern 검증 (정규식)
		if (validation.pattern && typeof value === 'string') {
			const regex = new RegExp(validation.pattern);
			if (!regex.test(value)) {
				throw new HttpError(1000, '값이 형식에 맞지 않습니다.');
			}
		}
	}
};

/**
 * 기능 설정을 우선순위에 따라 정렬
 * @param {Array} settings - 정렬할 기능 설정 배열
 * @returns {Array} - 정렬된 기능 설정 배열
 */
export const sortSettingsByHierarchy = settings => {
	return settings.sort((a, b) => {
		const aPriority = a.settingItem.priority || 0;
		const bPriority = b.settingItem.priority || 0;
		return aPriority - bPriority;
	});
};

/**
 * 동기화가 필요한지 확인
 * @param {Array<string>} expectedKeys - 예상되는 키 목록
 * @param {Array<string>} actualKeys - 실제 키 목록
 * @returns {boolean} - 동기화 필요 여부
 */
export const needsSync = (expectedKeys, actualKeys) => {
	const expectedSet = new Set(expectedKeys);
	const actualSet = new Set(actualKeys);

	// expectedKeys에 있지만 actualKeys에 없는 키가 있으면 동기화 필요
	for (const key of expectedKeys) {
		if (!actualSet.has(key)) {
			return true;
		}
	}

	// actualKeys에 있지만 expectedKeys에 없는 키가 있으면 동기화 필요
	for (const key of actualKeys) {
		if (!expectedSet.has(key)) {
			return true;
		}
	}

	return false;
};

/**
 * 워크스페이스 설정값 동기화
 * @param {Object} prisma - Prisma 클라이언트
 * @param {string} workspaceId - 워크스페이스 ID
 */
export const syncWorkspaceSettings = async (prisma, workspaceId) => {
	console.log(`🔧 워크스페이스 ${workspaceId} 기능 설정값 동기화 시작...`);

	// 1. 모든 설정 아이템 조회
	const settingItems = await prisma.workspaceSettingItem.findMany({
		select: {
			key: true,
			defaultValue: true,
		},
	});

	// 2. 현재 워크스페이스의 설정값들 조회
	const existingSettings = await prisma.workspaceSetting.findMany({
		where: { workspaceId },
		select: { key: true },
	});

	const existingKeys = new Set(existingSettings.map(s => s.key));
	const requiredKeys = new Set(settingItems.map(item => item.key));

	let addedCount = 0;
	let removedCount = 0;

	// 3. 누락된 설정값 추가
	for (const item of settingItems) {
		if (!existingKeys.has(item.key)) {
			await prisma.workspaceSetting.create({
				data: {
					workspaceId,
					key: item.key,
					value: item.defaultValue,
				},
			});
			addedCount++;
			console.log(`➕ 기능 설정값 추가: ${item.key} = ${item.defaultValue}`);
		}
	}

	// 4. 더 이상 존재하지 않는 설정값 제거
	for (const existingKey of existingKeys) {
		if (!requiredKeys.has(existingKey)) {
			await prisma.workspaceSetting.delete({
				where: {
					workspaceId_key: { workspaceId, key: existingKey },
				},
			});
			removedCount++;
			console.log(`➖ 기능 설정값 제거: ${existingKey}`);
		}
	}

	console.log(`✅ 워크스페이스 ${workspaceId} 기능 설정값 동기화 완료!`);
	console.log(`📊 추가: ${addedCount}개, 제거: ${removedCount}개`);

	return { addedCount, removedCount };
};

/**
 * 워크스페이스 설정 항목들을 동기화하고 누락된 항목을 추가합니다.
 * @param {Object} prisma - Prisma 클라이언트
 * @param {Array} settingItems - 설정 아이템 배열 (기본값 사용시 생략 가능)
 */
export const syncWorkspaceSettingItems = async (prisma, settingItems = DEFAULT_SETTING_ITEMS) => {
	console.log('🔄 워크스페이스 설정 항목 동기화 시작...');

	// 1단계: 부모 설정들을 먼저 동기화
	console.log('📝 1단계: 부모 설정 항목 동기화 중...');
	const parentItems = settingItems.filter(item => item.parentKey === null);

	for (const item of parentItems) {
		const commonFields = {
			group: item.group,
			name: item.name,
			description: item.description,
			valueType: item.valueType,
			uiType: item.uiType,
			defaultValue: item.defaultValue,
			validation: item.validation ?? undefined,
			priority: item.priority,
			options: item.options ?? undefined,
		};
		await prisma.workspaceSettingItem.upsert({
			where: { key: item.key },
			update: { ...commonFields },
			create: { ...commonFields, key: item.key },
		});
	}

	// 2단계: 자식 설정들을 동기화 (부모 ID 연결)
	console.log('📝 2단계: 자식 설정 항목 동기화 중...');
	const childItems = settingItems.filter(item => item.parentKey !== null);

	for (const item of childItems) {
		// 부모 설정을 찾아서 ID를 가져옴
		const parent = await prisma.workspaceSettingItem.findUnique({
			where: { key: item.parentKey },
			select: { id: true },
		});

		if (!parent) {
			console.warn(`⚠️ 부모 설정을 찾을 수 없습니다: ${item.parentKey}`);
			continue;
		}

		const commonFields = {
			group: item.group,
			name: item.name,
			description: item.description,
			valueType: item.valueType,
			uiType: item.uiType,
			defaultValue: item.defaultValue,
			validation: item.validation ?? undefined,
			priority: item.priority,
			parentId: parent.id,
			options: item.options ?? undefined,
		};

		await prisma.workspaceSettingItem.upsert({
			where: { key: item.key },
			update: { ...commonFields },
			create: { ...commonFields, key: item.key },
		});
	}

	// 3단계: 더 이상 존재하지 않는 설정 항목 제거
	console.log('📝 3단계: 불필요한 설정 항목 제거 중...');
	const allSettingItemKeys = new Set(settingItems.map(item => item.key));
	const dbSettingItems = await prisma.workspaceSettingItem.findMany({
		select: { key: true },
	});

	let removedCount = 0;
	for (const dbItem of dbSettingItems) {
		if (!allSettingItemKeys.has(dbItem.key)) {
			await prisma.workspaceSettingItem.delete({
				where: { key: dbItem.key },
			});
			removedCount++;
			console.log(`➖ 설정 항목 제거: ${dbItem.key}`);
		}
	}

	console.log('✅ 워크스페이스 설정 항목 동기화 완료!');
	console.log(`📊 총 ${settingItems.length}개의 설정 항목이 동기화되었습니다.`);
	console.log(`📊 제거된 설정 항목: ${removedCount}개`);
};
