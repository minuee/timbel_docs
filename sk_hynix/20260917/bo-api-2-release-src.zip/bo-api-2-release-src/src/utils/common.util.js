import { randomInt } from 'crypto';
class commonUtil {
	getRandomDelay(minMilliseconds, maxMilliseconds) {
		return randomInt(minMilliseconds, maxMilliseconds + 1);
	}

	delayWithRandom(engine = 'RTZ') {
		const delay = this.getRandomDelay(0, 1500);
		log.i('[delayWithRandom]', `${engine} 호출 무작위 지연 ${delay / 1000}초 이후 수행`);

		return new Promise(resolve => setTimeout(resolve, delay));
	}

	pagenation(page, limit) {
		if (!isNaN(page) && !isNaN(limit)) {
			const skip = (page - 1) * limit;
			const take = limit;
			return { skip, take };
		}
		return {};
	}

	getClientIp(req) {
		return req.headers['x-real-ip'] || 'unknown';
	}

	jsonBigintToInt(obj) {
		return JSON.parse(
			JSON.stringify(obj, (_, value) => (typeof value === 'bigint' ? Number(value.toString()) : value))
		);
	}
}

export default new commonUtil();
