import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import customParseFormat from 'dayjs/plugin/customParseFormat.js';
import isoWeek from 'dayjs/plugin/isoWeek.js';
import weekOfYear from 'dayjs/plugin/weekOfYear.js';
import { HttpError } from '../handlers/error.handler.js';

dayjs.extend(customParseFormat);
dayjs.extend(utc);
dayjs.extend(timezone);
dayjs.extend(isoWeek);
dayjs.extend(weekOfYear);

const isAfter = (date1, date2) => {
	if (!date1 || !date2) return false;
	return dayjs(date1).isAfter(date2);
};

const isSame = (date1, date2) => {
	if (!date1 || !date2) return false;
	return dayjs(date1).isSame(date2);
};

const isValid = (date, format = 'YYYYMMDDHHmmss') => {
	if (!date) return false;
	return dayjs(date, format, true).isValid();
};

const isDate = date => {
	if (!date) return false;
	return dayjs(date).isValid();
};

const parse = (dateString, format = 'HH:mm:ss') => {
	if (!dateString) return null;
	return dayjs(dateString, format).toDate();
};

const toDate = (format = 'YYYYMMDDHHmmss', ...matches) => {
	if (!matches) return false;
	return dayjs(matches.join(''), format).toDate();
};

const addDate = (date, amount, unit = 'day') => {
	return dayjs(date).add(amount, unit).toDate();
};

const getDate = (date, format = 'YYYY-MM-DD') => {
	return dayjs(date).format(format);
};

const getDateTime = (dateString, format = 'YYYY-MM-DD HH:mm:ss') => {
	if (!dateString) return null;
	return dayjs(dateString).format(format);
};

/**
 * MariaDB WEEK(date, 1) 호환 주차 계산
 * mode 1: 월요일 시작, 첫 주는 4일 이상 포함하는 주, 범위 0-53
 *
 * MariaDB WEEK() mode 1의 동작:
 * - 해당 연도의 1월 1일이 포함된 주부터 카운트
 * - 1월 1일이 월~목: 1주차에 포함
 * - 1월 1일이 금~일: 0주차, 다음 월요일부터 1주차
 * - 연도를 넘기지 않음
 */
const getWeekNumber = dateString => {
	if (!dateString) return null;
	const date = dayjs(dateString);
	const year = date.year();

	// 해당 연도 1월 1일
	const jan1 = dayjs(`${year}-01-01`);
	const jan1Day = jan1.day(); // 0(일) ~ 6(토)

	// 1월 1일부터 해당 날짜까지의 일수
	const dayOfYear = date.diff(jan1, 'day');

	// mode 1의 규칙에 따른 주차 계산
	if (jan1Day === 0) {
		// 일요일 시작인 경우
		return Math.floor((dayOfYear + 7) / 7);
	} else if (jan1Day >= 1 && jan1Day <= 4) {
		// 월~목 시작: 1월 1일이 1주차에 포함
		return Math.floor((dayOfYear + jan1Day) / 7) + 1;
	} else {
		// 금~토 시작: 1월 1일은 0주차
		const adjustedDay = dayOfYear - (7 - jan1Day) + 1;
		if (adjustedDay < 0) return 0;
		return Math.floor(adjustedDay / 7) + 1;
	}
};

const getSearchRange = type => {
	const today = dayjs().utc();
	let startDate, endDate;

	if (type === 'today') {
		return {
			startDate: today.startOf('day').subtract(9, 'hour').toISOString(),
			endDate: today.endOf('day').subtract(9, 'hour').toISOString(),
		};
	}

	const [number, unit] = type.match(/^(\d+)?(week|month)$/)?.slice(1) || [];
	const count = number ? parseInt(number) : 1;

	if (unit === 'week') {
		startDate = today.subtract(count * 7 - 1, 'day').startOf('day');
		endDate = today.endOf('day');
	} else if (unit === 'month') {
		startDate = today.subtract(count, 'month').startOf('day').add(1, 'day');
		endDate = today.endOf('day');
	}

	if (startDate && endDate) {
		return {
			startDate: startDate.add(15, 'hour').toISOString(),
			endDate: endDate.add(15, 'hour').toISOString(),
		};
	}
};

const getDelayUntil = (afterDays, hour) => {
	if (afterDays < 1) throw new Error('afterDays 값은 1 이상이어야 합니다.');
	if (hour < 0 || hour > 24) throw new Error('hour 값은 0부터 24 사이여야 합니다.');

	const zone = 'Asia/Seoul';

	const now = dayjs().tz(zone);
	const target = now.add(afterDays, 'day').startOf('day').add(hour, 'hour');

	return Math.max(0, target.valueOf() - now.valueOf());
};

export const isValidDate = (startDate, endDate) => {
	const regex = /^(\d{8}|\d{4}-\d{2}-\d{2})$/;
	const isValidDate = { startDate: regex.test(startDate), endDate: regex.test(endDate) };

	if (!isValidDate.startDate || !isValidDate.endDate) {
		throw new HttpError(1013);
	}

	return isValidDate;
};

export const formatDate = (dateString, addDays = 0) => {
	if (!dateString) return null;
	if (addDays) dateString = addDate(dateString, addDays, 'day');

	const date = getDate(dateString, 'YYYYMMDD');
	return dayjs(date).utc().toISOString();
};

export default {
	isAfter,
	isSame,
	isValid,
	isDate,
	parse,
	toDate,
	addDate,
	getDate,
	getDateTime,
	getWeekNumber,
	getSearchRange,
	getDelayUntil,
	isValidDate,
	formatDate,
};
