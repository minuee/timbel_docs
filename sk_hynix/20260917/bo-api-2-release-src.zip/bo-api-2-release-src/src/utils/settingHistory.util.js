import { Enums } from '@timbel-timblo-onpremise/prisma';
import { DEFAULT_SETTING_ITEMS } from '../constants/workspace-settings.constants.js';
import { LIFECYCLE_POLICY_SETTINGS } from '../constants/lifecycle-policy.constants.js';

const TABLE_LABELS = {
	WORKSPACE: {
		name: '워크스페이스명',
		domain: '도메인',
		description: '비고',
	},
	WORKSPACE_CONFIG: {
		memberMaxCount: '구성원 수',
	},
	MENU: {
		group: '메뉴 그룹',
		name: '메뉴명',
		urlPath: 'URL',
		isUsed: '사용여부',
	},
	USER: {
		workspaceName: '워크스페이스명',
		nickName: '사용자명',
		email: '이메일',
	},
	MEMBER: {
		workspaceName: '워크스페이스명',
		nickName: '사용자명',
		email: '이메일',
		roleName: '역할명',
	},
	ROLE: {
		adminType: '관리자 유형',
		name: '역할명',
		description: '설명',
	},
	_MENUTOROLE: {
		name: '역할명',
		menus: '메뉴 권한',
	},
	POLICY: {
		category: '약관 구분',
		status: '약관 상태',
		title: '약관 제목',
		version: '약관 버전',
		content: '약관 내용',
		publishedAt: '약관 실행일',
	},
	NOTICE: {
		title: '공지사항 제목',
		content: '공지사항 내용',
		postAt: '공지사항 게시시작일',
		withdrawalAt: '공지사항 게시종료일',
		ignoreDays: '공지사항 다시보지 않기 일수',
	},
	TERMS: {
		version: '동의서 버전',
		title: '동의서 제목',
		content: '동의서 내용',
		status: '동의서 상태',
		publishedAt: '동의서 실행일',
		archivedAt: '동의서 보관일',
		categoryName: '동의서 구분',
	},
	WORKSPACE_SETTING: {
		key: '기능',
		value: '사용 설정',
	},
	WORKSPACE_POLICY: {
		policyType: '기능',
		value: '사용 설정',
	},
	LICENSE: {
		seats: '라이선스 사용 인원',
	},
};

const formatValue = (field, value, tableName) => {
	if (value === null || value === undefined) return '없음';

	if (field === 'isUsed') return value ? '사용' : '미사용';
	if (field === 'adminType')
		return (
			value === Enums.AdminType.SYSTEM ? '시스템 관리자'
			: value === Enums.AdminType.WORKSPACE ? '워크스페이스 관리자'
			: '전역 관리자'
		);
	if (tableName === '_MENUTOROLE' && field === 'menus') {
		return `${value.isAllowed ? '권한 O' : '권한 X'}`;
	}

	if (tableName === 'MENU' && field === 'group') {
		const groupLabels = {
			SYSTEM_ADDON: '시스템 사용자 추가 메뉴',
			WORKSPACE_ADDON: '워크스페이스 사용자 추가 메뉴',
		};
		return groupLabels[value] || value;
	}

	if (tableName === 'TERMS' && field === 'status') {
		return (
			value === Enums.TermsStatus.PUBLISHED ? '게시됨'
			: value === Enums.TermsStatus.ARCHIVED ? '보관됨'
			: '초안'
		);
	}

	if (tableName === 'POLICY' && field === 'status') {
		return (
			value === Enums.PolicyStatus.PUBLISHED ? '게시됨'
			: value === Enums.PolicyStatus.ARCHIVED ? '보관됨'
			: '초안'
		);
	}

	if (tableName === 'POLICY' && field === 'category') {
		return value === Enums.PolicyCategory.TERMS ? '이용약관' : '개인정보';
	}

	if (tableName === 'WORKSPACE_SETTING' && field === 'key') {
		const settingItem = DEFAULT_SETTING_ITEMS.find(item => item.key === value);
		return settingItem ? settingItem.name : value;
	}

	if (tableName === 'WORKSPACE_POLICY' && field === 'policyType') {
		const policyItem = LIFECYCLE_POLICY_SETTINGS.find(item => item.key === value);
		return policyItem ? policyItem.name : value;
	}

	if (tableName === 'WORKSPACE_POLICY' && field === 'value') {
		return value === -1 ? '영구' : `${value}일`;
	}

	if (tableName === 'LICENSE' && field === 'seats') {
		return value === -1 ? '무제한' : `${value}`;
	}

	return String(value);
};

// 객체의 깊은 비교를 수행하는 함수
const deepEqual = (obj1, obj2) => {
	// 둘 다 null이거나 undefined인 경우
	if (obj1 === null || obj1 === undefined) {
		return obj2 === null || obj2 === undefined;
	}
	if (obj2 === null || obj2 === undefined) {
		return false;
	}

	// 타입이 다른 경우
	if (typeof obj1 !== typeof obj2) {
		return false;
	}

	// 원시 타입인 경우 직접 비교
	if (typeof obj1 !== 'object' || obj1 instanceof Date) {
		return obj1 === obj2;
	}

	// 배열인 경우
	if (Array.isArray(obj1) !== Array.isArray(obj2)) {
		return false;
	}
	if (Array.isArray(obj1)) {
		if (obj1.length !== obj2.length) {
			return false;
		}
		for (let i = 0; i < obj1.length; i++) {
			if (!deepEqual(obj1[i], obj2[i])) {
				return false;
			}
		}
		return true;
	}

	// 객체인 경우 - Set을 사용하여 O(1) 조회로 성능 개선
	const keys1 = Object.keys(obj1);
	const keys2Set = new Set(Object.keys(obj2));

	if (keys1.length !== keys2Set.size) {
		return false;
	}

	for (const key of keys1) {
		if (!keys2Set.has(key) || !deepEqual(obj1[key], obj2[key])) {
			return false;
		}
	}

	return true;
};

// menus 배열 필드를 개별 항목으로 처리하는 함수
const processMenusField = (field, label, beforeValue, afterValue, tableName, beforeDetails, afterDetails) => {
	const beforeMenusMap = new Map((beforeValue || []).map(menu => [menu.id, menu]));
	const afterMenusMap = new Map((afterValue || []).map(menu => [menu.id, menu]));
	const allMenuIds = new Set([...beforeMenusMap.keys(), ...afterMenusMap.keys()]);

	for (const menuId of allMenuIds) {
		const beforeMenu = beforeMenusMap.get(menuId);
		const afterMenu = afterMenusMap.get(menuId);

		// 메뉴가 추가되거나 삭제되었거나 isAllowed 값이 변경된 경우만 처리
		if (!beforeMenu || !afterMenu || beforeMenu.isAllowed !== afterMenu.isAllowed) {
			if (beforeMenu) {
				beforeDetails.push({
					field: `${field}.${menuId}`,
					label: `${label} - ${beforeMenu.name}`,
					value: formatValue(field, beforeMenu, tableName),
					rawValue: beforeMenu,
				});
			}

			if (afterMenu) {
				afterDetails.push({
					field: `${field}.${menuId}`,
					label: `${label} - ${afterMenu.name}`,
					value: formatValue(field, afterMenu, tableName),
					rawValue: afterMenu,
				});
			}
		}
	}
};

// 일반 필드를 처리하는 함수
const processRegularField = (
	field,
	label,
	beforeValue,
	afterValue,
	tableName,
	beforeData,
	afterData,
	beforeDetails,
	afterDetails
) => {
	if (beforeData) {
		beforeDetails.push({
			field,
			label,
			value: formatValue(field, beforeValue, tableName),
			rawValue: beforeValue,
		});
	}

	if (afterData) {
		afterDetails.push({
			field,
			label,
			value: formatValue(field, afterValue, tableName),
			rawValue: afterValue,
		});
	}
};

const formatHistoryComparison = history => {
	const { tableName, beforeData, afterData, requiredFields } = history;
	if (!beforeData && !afterData) {
		return {
			beforeDetails: [],
			afterDetails: [],
		};
	}

	const fieldLabels = TABLE_LABELS[tableName] || {};
	const beforeDetails = [];
	const afterDetails = [];

	const allFields = new Set([
		...(beforeData ? Object.keys(beforeData) : []),
		...(afterData ? Object.keys(afterData) : []),
	]);

	for (const field of allFields) {
		const beforeValue = beforeData?.[field];
		const afterValue = afterData?.[field];
		const label = fieldLabels[field] || field;

		const isMenusArray =
			tableName === '_MENUTOROLE' && field === 'menus' && Array.isArray(beforeValue) && Array.isArray(afterValue);

		if (isMenusArray) {
			processMenusField(field, label, beforeValue, afterValue, tableName, beforeDetails, afterDetails);
		} else if (!deepEqual(beforeValue, afterValue) || (requiredFields && requiredFields.includes(field))) {
			processRegularField(
				field,
				label,
				beforeValue,
				afterValue,
				tableName,
				beforeData,
				afterData,
				beforeDetails,
				afterDetails
			);
		}
	}

	return {
		beforeDetails,
		afterDetails,
	};
};

export default { formatHistoryComparison };
