import ExcelJS from 'exceljs';

// 필터된 키워드 부스팅 목록을 '키워드' 단일 열 XLSX로 내보낸다.
// 헤더('키워드(필수)')는 FO 일괄등록 양식과 동일하여 다운로드한 파일을 그대로 업로드에 사용할 수 있다.
class KeywordBoostingExportUtil {
	async generateKeywordXlsx(keywords = []) {
		const workbook = new ExcelJS.Workbook();
		const worksheet = workbook.addWorksheet('키워드 부스팅');

		const headerRow = worksheet.addRow(['키워드(필수)']);
		headerRow.eachCell(cell => {
			cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFF00' } };
			cell.font = { bold: true, size: 11 };
			cell.alignment = { horizontal: 'center', vertical: 'middle' };
			cell.border = {
				top: { style: 'medium' },
				left: { style: 'medium' },
				bottom: { style: 'medium' },
				right: { style: 'medium' },
			};
		});
		headerRow.height = 25;

		for (const keyword of keywords) {
			worksheet.addRow([keyword]);
		}

		const column = worksheet.getColumn(1);
		column.width = 30;
		column.numFmt = '@';
		worksheet.eachRow((row, rowNumber) => {
			if (rowNumber > 1) {
				row.eachCell({ includeEmpty: true }, cell => {
					cell.numFmt = '@';
					cell.alignment = { horizontal: 'center', vertical: 'middle' };
				});
			}
		});

		const buffer = await workbook.xlsx.writeBuffer();
		return Buffer.from(buffer);
	}
}

export default new KeywordBoostingExportUtil();
