import { userService } from '../services/index.js';
import authHandler from '../handlers/auth.handler.js';
import { HttpError } from '../handlers/error.handler.js';
import { common, validation } from '../utils/index.js';

class UserController {
	async createUser(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { member } = auth;
			const { workspace } = member;
			const { workspaceId, name, email, password, roleId = null } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S300' : 'W400';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!name || !email || !password) throw new HttpError(1000);
			if (menuCode === 'S300' && !workspaceId) throw new HttpError(1000);
			validation.validateEmail(email);

			const userDto = {
				workspaceId: menuCode === 'S300' ? workspaceId : workspace.id,
				name,
				email,
				password,
				roleId,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await userService.createUser(userDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateUserPassword(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { pid } = req.params;
			const { newPassword } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S300' : 'W400';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!newPassword) throw new HttpError(1000);

			const userDto = {
				pid,
				newPassword,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await userService.updateUserPassword(userDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deleteUsers(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { pids } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S300' : 'W400';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!pids || !Array.isArray(pids) || pids.length === 0) throw new HttpError(1000);

			const userDto = {
				pids,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await userService.deleteUsers(userDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new UserController();
