import { roleService } from '../services/index.js';
import authHandler from '../handlers/auth.handler.js';
import { validation, common } from '../utils/index.js';
import { HttpError } from '../handlers/error.handler.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';

class RoleController {
	async getRoleList(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				adminType = null,
				page: pageString = 1,
				limit: limitString = 10,
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S400' : 'W300';

			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedOrderByField(orderByField, [
				'workspaceName',
				'creator',
				'description',
				'createAt',
				'updateAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const roleDto = {
				workspaceId,
				adminType: isSystem ? adminType : Enums.AdminType.WORKSPACE,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await roleService.getRoleList(roleDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getRole(req, res, next) {
		try {
			const { auth, path } = req;
			const { id } = req.params;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S400' : 'W300';

			await authHandler.checkRolePermission(auth, menuCode);

			const roleDto = {
				id,
			};
			const result = await roleService.getRole(roleDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createRole(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { workspaceId, adminType, name, description } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S400' : 'W300';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId || !adminType || !name || !description) throw new HttpError(1000);

			const roleDto = {
				workspaceId,
				adminType,
				name,
				description,
				creatorId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await roleService.createRole(roleDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateRole(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { id } = req.params;
			const { adminType, name, description } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S400' : 'W300';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!adminType || !name || !description) throw new HttpError(1000);

			const roleDto = {
				id,
				adminType,
				name,
				description,
				updaterId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await roleService.updateRole(roleDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updatedRoleMenus(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { id } = req.params;
			const { menus } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S400' : 'W300';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!menus) throw new HttpError(1000);
			if (!Array.isArray(menus)) throw new HttpError(1000);

			const roleDto = {
				id,
				menus,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await roleService.updatedRoleMenus(roleDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deleteRole(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { id } = req.params;
			const menuCode = path.split('/').pop() === 'system' ? 'S400' : 'W300';

			await authHandler.checkRolePermission(auth, menuCode);

			const roleDto = { id };

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await roleService.deleteRole(roleDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new RoleController();
