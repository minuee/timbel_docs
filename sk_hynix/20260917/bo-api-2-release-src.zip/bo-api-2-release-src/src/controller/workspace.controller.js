import validator from 'validator';
import authHandler from '../handlers/auth.handler.js';
import { workspaceService } from '../services/index.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import { HttpError } from '../handlers/error.handler.js';
import { validation, common, convert } from '../utils/index.js';

class WorkspaceController {
	// 내 워크스페이스 기능 설정 간단 조회(FO)
	async getMyWorkspaceInfo(req, res, next) {
		try {
			const { member } = req.auth;
			const menuRoleId = member?.menuRole?.id;
			let workspaceId = member.workspace.id;

			const result = await workspaceService.getMyWorkspaceInfo(workspaceId);
			res.json({ message: 'Success', httpCode: 200, data: { menuRoleId, ...result } });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 기본 정보 조회
	async getWorkspaceInfo(req, res, next) {
		try {
			const { workspaceId } = req.params;
			if (!workspaceId) throw new HttpError(1000, '워크스페이스 ID는 필수입니다.');

			await authHandler.checkRolePermission(req.auth, 'W500');
			const result = await workspaceService.getWorkspaceInfo(workspaceId);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getWorkspaceList(req, res, next) {
		try {
			const { auth } = req;
			const {
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			await authHandler.checkRolePermission(auth, 'S100');

			validation.isAllowedFilter(filter, ['name', 'domain', 'owner']);
			validation.isAllowedOrderByField(orderByField, ['name', 'domain', 'owner', 'createAt', 'description']);
			validation.isAllowedSortOrder(sortOrder);

			const workspaceDto = {
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};
			const result = await workspaceService.findWorkspaceList(workspaceDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스별 구성원 인원 변경 API
	async updateWorkspaceMemberLimit(req, res, next) {
		try {
			const { auth } = req;
			const { workspaceId } = req.params;
			const { memberMaxCount } = req.body;

			await authHandler.checkRolePermission(auth, 'S100');

			if (memberMaxCount === undefined || memberMaxCount === null)
				throw new HttpError(1000, '최대 구성원 수는 필수입니다.');

			const parsedMemberMaxCount = Number(memberMaxCount);
			if (!Number.isInteger(parsedMemberMaxCount) || parsedMemberMaxCount < 0)
				throw new HttpError(1000, '최대 구성원 수는 0 이상의 정수여야 합니다.');

			const workspaceDto = { workspaceId, memberMaxCount: parsedMemberMaxCount };

			const result = await workspaceService.updateWorkspaceMemberLimit(workspaceDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createWorkspace(req, res, next) {
		try {
			const { auth, user } = req;
			const { name, domain, description } = req.body;
			const menuCode = 'S100';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!domain) throw new HttpError(1000);
			if (!validator.isFQDN(domain)) throw new HttpError(1102);

			const workspaceDto = {
				name,
				domain,
				description,
				ownerId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await workspaceService.createWorkspace(workspaceDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateWorkspace(req, res, next) {
		try {
			const { auth, user, path } = req;
			const { workspaceId } = req.params;
			const { name, description } = req.body;
			const menuCode = path.split('/').pop() === 'name' ? 'D500' : 'S100';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!name) throw new HttpError(1000);
			const workspaceDto = {
				id: workspaceId,
				name,
				description,
			};
			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await workspaceService.updateWorkspace(workspaceDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deleteWorkspace(req, res, next) {
		try {
			const { auth, user } = req;
			const { workspaceId } = req.params;
			const menuCode = 'S100';

			await authHandler.checkRolePermission(auth, menuCode);

			const workspaceDto = {
				id: workspaceId,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await workspaceService.deleteWorkspace(workspaceDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 기능 설정 조회
	async getWorkspaceFeatureSettings(req, res, next) {
		try {
			const { auth } = req;
			const { workspaceId } = req.params;
			const { group = null } = req.query;

			const menuCode = group === Enums.WorkspaceSettingGroup.CALENDAR ? 'D400' : 'W100';
			await authHandler.checkRolePermission(auth, menuCode);

			const groupList = group ? group.split(',') : null;
			if (groupList && !groupList.every(item => Object.values(Enums.WorkspaceSettingGroup).includes(item)))
				throw new HttpError(1111);

			const workspaceDto = { workspaceId, groupList };

			const result = await workspaceService.findFeatureSettings(workspaceDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 기능 설정 업데이트
	async updateWorkspaceFeatureSetting(req, res, next) {
		try {
			const { auth, user } = req;
			const { workspaceId } = req.params;
			const { key, value } = req.body;

			const menuCode = key.startsWith('use_calendar') ? 'D400' : 'W100';
			await authHandler.checkRolePermission(auth, menuCode);

			if (!key) throw new HttpError(1000, '기능 설정 키는 필수입니다.');
			if (value === undefined || value === null) throw new HttpError(1000, '기능 설정 값은 필수입니다.');

			const featureSettingDto = { workspaceId, key, value };
			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await workspaceService.updateFeatureSetting(featureSettingDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 라이선스 정보 조회
	async getLicenseInfo(req, res, next) {
		try {
			await authHandler.checkRolePermission(req.auth, 'S100');

			const result = await workspaceService.getLicenseInfo();
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 라이선스 파일 업로드
	async uploadLicenseFile(req, res, next) {
		try {
			const { file, auth, user } = req;
			if (!file) throw new HttpError(400, '라이선스 파일이 없습니다.');

			const menuCode = 'S100';
			await authHandler.checkRolePermission(auth, menuCode);

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await workspaceService.uploadLicenseFile(file, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 로고 업로드
	async uploadLogo(req, res, next) {
		try {
			const { workspaceId } = req.params;
			const { file, auth, user } = req;
			const menuCode = 'W500';
			if (!file) throw new HttpError(400, '파일이 없습니다.');

			await authHandler.checkRolePermission(auth, menuCode);

			file.originalname = convert.originalnameEncoding(file);
			if (!validation.validateMagicByte(file)) throw new HttpError(1014);

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await workspaceService.updateThumbnail(workspaceId, file, user.pid, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 로고 삭제
	async deleteLogo(req, res, next) {
		try {
			const { workspaceId } = req.params;
			const { auth, user } = req;
			const menuCode = 'W500';
			await authHandler.checkRolePermission(auth, menuCode);

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			await workspaceService.deleteThumbnail(workspaceId, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: {} });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 콘텐츠 보존 정책 조회
	async getLifecyclePolicy(req, res, next) {
		try {
			const { workspaceId } = req.params;

			await authHandler.checkRolePermission(req.auth, 'W200');

			const result = await workspaceService.getLifecyclePolicy(workspaceId);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 콘텐츠 보존 정책 개별 업데이트
	async updateEachLifecyclePolicy(req, res, next) {
		try {
			const { workspaceId } = req.params;
			const { key, value, unit } = req.body;
			const { auth, user } = req;

			const menuCode = 'W200';
			await authHandler.checkRolePermission(auth, menuCode);

			if (!key) throw new HttpError(400, '키는 필수입니다.');
			if (!value) throw new HttpError(400, '값은 필수입니다.');
			if (value && !validator.isInt(value, { min: -1, max: 9999 }))
				throw new HttpError(400, '값은 -1 이상 9999 이하의 정수값이어야 합니다.');
			if (unit && !validator.isIn(unit, [Enums.Unit.DAYS, Enums.Unit.HOURS]))
				throw new HttpError(400, '단위는 DAYS 또는 HOURS 중 하나여야 합니다.');

			const workspacePolicyDto = { key, value, unit };
			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};

			const result = await workspaceService.updateEachLifecyclePolicy(
				workspaceId,
				workspacePolicyDto,
				settingHistoryDto
			);

			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 워크스페이스 콘텐츠 보존 정책 생성/업데이트
	async createLifecyclePolicy(req, res, next) {
		try {
			const { workspaceId } = req.params;
			const { policyType, value, unit, description } = req.body;

			if (!policyType) throw new HttpError(400, '정책 타입은 필수입니다.');
			if (!value) throw new HttpError(400, '정책 값은 필수입니다.');
			if (value && !validator.isInt(value, { min: -1 }))
				throw new HttpError(400, '정책 값은 -1 이상의 정수값이어야 합니다.');
			if (unit && !validator.isIn(unit, [Enums.Unit.DAYS, Enums.Unit.HOURS]))
				throw new HttpError(400, '단위는 DAYS 또는 HOURS 중 하나여야 합니다.');

			await authHandler.checkRolePermission(req.auth, 'W200');

			const workspacePolicyDto = { policyType, value, unit, description };

			const result = await workspaceService.createLifecyclePolicy(workspaceId, workspacePolicyDto);

			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new WorkspaceController();
