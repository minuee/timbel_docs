import { validation, common } from '../utils/index.js';
import authHandler from '../handlers/auth.handler.js';
import { policyService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';

const menuCode = 'S500';

class PolicyController {
	async getPolicyList(req, res, next) {
		try {
			const { auth } = req;
			const {
				category,
				isUsed,
				filter = null,
				keyword = null,
				page: pageString = 1,
				limit: limitString = 10,
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(filter, ['title', 'creator']);
			validation.isAllowedFilter(category, Object.values(Enums.PolicyCategory));
			validation.isAllowedFilter(isUsed, ['true', 'false']);
			validation.isAllowedOrderByField(orderByField, [
				'category',
				'status',
				'title',
				'version',
				'createAt',
				'creator',
				'publishedAt',
				'isUsed',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const policyDto = {
				category,
				isUsed:
					isUsed === 'true' ? true
					: isUsed === 'false' ? false
					: null,
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await policyService.getPolicyList(policyDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getPolicy(req, res, next) {
		try {
			const { auth } = req;
			const { id } = req.params;

			await authHandler.checkRolePermission(auth, menuCode);

			const policyDto = { id };
			const result = await policyService.getPolicy(policyDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createPolicy(req, res, next) {
		try {
			const { auth, user } = req;
			const { category, title, content } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!category || !title || !content) throw new HttpError(1000);

			const policyDto = {
				category,
				title,
				content,
				creatorId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await policyService.createPolicy(policyDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updatePolicy(req, res, next) {
		try {
			const { auth, user } = req;
			const { id } = req.params;
			const { category, title, content } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!category || !title || !content) throw new HttpError(1000);

			validation.isAllowedFilter(category, Object.values(Enums.PolicyCategory));

			const policyDto = {
				id,
				category,
				title,
				content,
				updaterId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await policyService.updatePolicy(policyDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updatePolicyStatus(req, res, next) {
		try {
			const { auth, user } = req;
			const { id } = req.params;
			const { status } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(status, [Enums.PolicyStatus.PUBLISHED, Enums.PolicyStatus.ARCHIVED]);

			const policyDto = {
				id,
				status,
				updaterId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await policyService.updatePolicyStatus(policyDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deletePolicy(req, res, next) {
		try {
			const { auth, user } = req;
			const { id } = req.params;

			await authHandler.checkRolePermission(auth, menuCode);

			const policyDto = { id };

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await policyService.deletePolicy(policyDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new PolicyController();
