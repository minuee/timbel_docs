import { templateService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';
import authHandler from '../handlers/auth.handler.js';
import { validation } from '../utils/index.js';

const templateOptions = {
	speaker: false,
	keyword: false,
	summary: false,
};
const menuCode = 'D100';

class TemplateController {
	async uploadTemplate(req, res, next) {
		try {
			const { auth, file } = req;
			const { member } = auth;
			if (!file) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			const result = await templateService.uploadTemplate(file, member);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getTemplateCategories(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;

			await authHandler.checkRolePermission(auth, menuCode);

			const result = await templateService.getTemplateCategories(member);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createCategory(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { name } = req.body;
			if (!name) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			const result = await templateService.createCategory(name, member);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deleteCategory(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { id } = req.params;
			if (!id) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			await templateService.deleteCategory(id, member);
			res.json({ message: 'Success', httpCode: 204, data: {} });
		} catch (err) {
			next(err);
		}
	}

	async updateCategory(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { id } = req.params;
			const { name } = req.body;
			if (!id || !name) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			const result = await templateService.updateCategory(id, name, member);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createTemplate(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { inputType, key, name, preview, version, categoryId } = req.body;
			if (!inputType || !key || !name || !preview || !version || !categoryId) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			req.body.options = templateOptions;
			const result = await templateService.createTemplate(req.body, member);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getTemplates(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
			} = req.query;
			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(filter, ['creatorName', 'templateName']);

			if (!workspaceId) throw new HttpError(1000);

			const templateDto = {
				workspaceId,
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
			};

			if (fromDateString) templateDto.fromDate = new Date(fromDateString);
			if (toDateString) templateDto.toDate = new Date(toDateString);

			const result = await templateService.getTemplates(templateDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getTemplateDetail(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { id, version } = req.params;
			if (!id) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			const result = await templateService.getTemplateDetail(id, member, version);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateTemplate(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { id, version = null } = req.params;
			const { name, description, categoryId, options = {} } = req.body;
			if (!id || !version) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			const updateData = {
				name,
				description,
				categoryId,
				options: {
					...templateOptions,
					...options,
				},
			};

			const result = await templateService.updateTemplate(id, version, member, updateData);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateTemplateIsUsed(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { id, version = null } = req.params;
			if (!id || !version) throw new HttpError(1000);

			await authHandler.checkRolePermission(auth, menuCode);

			const result = await templateService.updateTemplateIsUsed(id, version, member);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new TemplateController();
