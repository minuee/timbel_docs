import keywordBoostingService from '../services/keywordBoosting.service.js';
import authHandler from '../handlers/auth.handler.js';
import { validation } from '../utils/index.js';
import { HttpError } from '../handlers/error.handler.js';

class KeywordBoostingController {
	async getKeywordBoostingList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				keyword = null,
				creator = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			const menuCode = 'D700';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId) throw new HttpError(1000);

			validation.isAllowedOrderByField(orderByField, ['keyword', 'creator', 'createAt', 'updateAt']);
			validation.isAllowedSortOrder(sortOrder);

			const keywordDto = {
				workspaceId,
				keyword,
				creator,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await keywordBoostingService.getKeywordBoostingList(keywordDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async exportKeywordBoostingList(req, res, next) {
		try {
			const { auth } = req;
			const { workspaceId, keyword = null, creator = null } = req.query;

			await authHandler.checkRolePermission(auth, 'D700');

			if (!workspaceId) throw new HttpError(1000);

			const keywordDto = { workspaceId, keyword, creator };
			const buffer = await keywordBoostingService.exportKeywordBoostingList(keywordDto);

			res.setHeader(
				'Content-Type',
				'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
			);
			res.setHeader('Content-Disposition', "attachment; filename*=UTF-8''keyword_boosting.xlsx");
			res.setHeader('Content-Length', buffer.length);
			res.send(buffer);
		} catch (err) {
			next(err);
		}
	}
}

export default new KeywordBoostingController();
