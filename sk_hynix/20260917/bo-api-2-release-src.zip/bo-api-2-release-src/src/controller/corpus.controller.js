import { corpusService } from '../services/index.js';
import authHandler from '../handlers/auth.handler.js';
import { validation } from '../utils/index.js';
import { HttpError } from '../handlers/error.handler.js';

class CorpusController {
	async getCorpusList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				source = null,
				target = null,
				creator = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			const menuCode = 'D500';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId) throw new HttpError(1000);

			validation.isAllowedOrderByField(orderByField, ['source', 'target', 'creator', 'createAt', 'updateAt']);
			validation.isAllowedSortOrder(sortOrder);

			const corpusDto = {
				workspaceId,
				source,
				target,
				creator,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await corpusService.getCorpusList(corpusDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new CorpusController();
