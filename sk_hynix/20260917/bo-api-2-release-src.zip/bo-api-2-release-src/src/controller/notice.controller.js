import { noticeService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';
import { common, date, validation } from '../utils/index.js';
import authHandler from '../handlers/auth.handler.js';

const menuCode = 'D600';

class NoticeController {
	async getNoticeList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId) throw new HttpError(1000);
			validation.validateDateRange(fromDateString, toDateString);

			validation.isAllowedFilter(filter, ['title', 'creatorName', 'status']);
			validation.isAllowedOrderByField(orderByField, [
				'title',
				'creatorName',
				'postAt',
				'withdrawalAt',
				'status',
				'createAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const noticeDto = {
				workspaceId,
				fromDate: date.formatDate(fromDateString),
				toDate: date.formatDate(toDateString, 1),
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};
			const result = await noticeService.getNoticeList(noticeDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getNotice(req, res, next) {
		try {
			const { auth } = req;
			const { id } = req.params;

			await authHandler.checkRolePermission(auth, menuCode);

			const noticeDto = {
				id,
			};
			const result = await noticeService.getNotice(noticeDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createNotice(req, res, next) {
		try {
			const { auth, user } = req;
			const { workspaceId, title, content, postAt, withdrawalAt, ignoreDays = 0 } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId || !title || !content || !postAt || !postAt) throw new HttpError(1000);
			validation.validateDateRange(postAt, postAt);

			const noticeDto = {
				workspaceId,
				title,
				content,
				postAt: date.formatDate(postAt),
				withdrawalAt: date.formatDate(withdrawalAt),
				ignoreDays,
				creatorId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await noticeService.createNotice(noticeDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateNotice(req, res, next) {
		try {
			const { auth, user } = req;
			const { id } = req.params;
			const { title, content, postAt, withdrawalAt, ignoreDays = 0 } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!title || !content || !postAt || !withdrawalAt) throw new HttpError(1000);
			validation.validateDateRange(postAt, withdrawalAt);

			const noticeDto = {
				id,
				title,
				content,
				ignoreDays,
				postAt: date.formatDate(postAt),
				withdrawalAt: date.formatDate(withdrawalAt),
				updaterId: user.pid,
			};
			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await noticeService.updateNotice(noticeDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateNoticesStatus(req, res, next) {
		try {
			const { auth, user } = req;
			const { ids, status } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!ids || !Array.isArray(ids)) throw new HttpError(1000);
			validation.isAllowedFilter(status, ['POST', 'WITHDRAWAL']);

			const noticeDto = {
				ids,
				status,
				updaterId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await noticeService.updateNoticesStatus(noticeDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deleteNotices(req, res, next) {
		try {
			const { auth, user } = req;
			const { ids } = req.body;

			await authHandler.checkRolePermission(auth, menuCode);

			if (!ids || !Array.isArray(ids)) throw new HttpError(1000);

			const noticeDto = {
				ids,
			};
			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await noticeService.deleteNotices(noticeDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new NoticeController();
