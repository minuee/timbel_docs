import { validation } from '../utils/index.js';
import authHandler from '../handlers/auth.handler.js';
import { termsService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

class TermsController {
	// 동의서 목록 조회
	async findTermsList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				categoryId,
				status,
				keyword,
				filter,
				startDate,
				endDate,
				orderByField = 'createAt',
				sortOrder = 'desc',
				page: pageString = '1',
				limit: limitString = '10',
			} = req.query;

			await authHandler.checkRolePermission(auth, 'D300');

			if (!workspaceId) throw new HttpError(1000);

			const categoryIdArray = validation.parseCommaSeparatedToArray(categoryId);
			const statusArray = validation.parseCommaSeparatedToArray(status);

			validation.isAllowedFilter(status, Object.values(Enums.TermsStatus));
			validation.isAllowedFilter(filter, ['title', 'content', 'creator']);
			validation.isAllowedOrderByField(orderByField, [
				'createAt',
				'updateAt',
				'publishedAt',
				'archivedAt',
				'title',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const findTermsDto = {
				workspaceId,
				categoryId: categoryIdArray,
				status: statusArray,
				keyword,
				filter,
				startDate: startDate ? new Date(startDate) : undefined,
				endDate: endDate ? new Date(endDate) : undefined,
				orderByField,
				sortOrder,
				page: parseInt(pageString),
				limit: parseInt(limitString),
			};

			const result = await termsService.findTermsList(findTermsDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 동의서 상세 조회
	async findTermsById(req, res, next) {
		try {
			const { id } = req.params;
			const { auth } = req;

			await authHandler.checkRolePermission(auth, 'D300');

			const result = await termsService.findTermsById(id);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 동의서 초안 생성
	async createTerms(req, res, next) {
		try {
			const { auth, user } = req;
			const { member } = auth;
			const { categoryId, title, content, isRequired } = req.body;

			const menuCode = 'D300';
			await authHandler.checkRolePermission(auth, menuCode);

			if (!categoryId) throw new HttpError(400, '동의서 카테고리 ID는 필수입니다.');
			if (!title) throw new HttpError(400, '동의서 제목은 필수입니다.');
			if (!content) throw new HttpError(400, '동의서 내용은 필수입니다.');

			const createTermsDto = {
				workspaceId: member.workspace.id,
				categoryId,
				title,
				content,
				isRequired: isRequired || false,
				creatorId: member.id,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await termsService.createTerms(createTermsDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 동의서 수정
	async updateTerms(req, res, next) {
		try {
			const { id } = req.params;
			const { auth, user } = req;
			const { member } = auth;
			const { categoryId, title, content, isRequired } = req.body;

			const menuCode = 'D300';
			await authHandler.checkRolePermission(auth, menuCode);

			if (!categoryId) throw new HttpError(400, '동의서 카테고리 ID는 필수입니다.');
			if (!title) throw new HttpError(400, '동의서 제목은 필수입니다.');
			if (!content) throw new HttpError(400, '동의서 내용은 필수입니다.');

			const updateTermsDto = {
				id,
				workspaceId: member.workspace.id,
				categoryId,
				title,
				content,
				isRequired,
				updaterId: member.id,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await termsService.updateTerms(updateTermsDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 동의서 상태 변경
	async updateTermsStatus(req, res, next) {
		try {
			const { id } = req.params;
			const { status } = req.query;
			const { auth, user } = req;
			const { member } = auth;
			const workspaceId = member.workspace.id;

			if (!status) throw new HttpError(5503, '상태는 필수 필드입니다.');
			const menuCode = 'D300';
			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(status, Object.values(Enums.TermsStatus));

			const updateTermsStatusDto = {
				workspaceId,
				status,
				id,
				updaterId: member.id,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await termsService.updateTermsStatus(updateTermsStatusDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 동의서 삭제
	async deleteTerms(req, res, next) {
		try {
			const { auth, user } = req;
			const { id } = req.params;

			const menuCode = 'D300';
			await authHandler.checkRolePermission(auth, menuCode);

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await termsService.deleteTerms(id, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: {} });
		} catch (err) {
			next(err);
		}
	}

	// 사용자 동의서 제출 이력 조회
	async findAgreementHistoryList(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const {
				termsId,
				termsCategoryId,
				keyword,
				filter,
				status,
				startDate,
				endDate,
				orderByField = 'createAt',
				sortOrder = 'desc',
				page: pageString = '1',
				limit: limitString = '10',
			} = req.query;

			validation.isAllowedFilter(filter, ['category', 'userName', 'email', 'title', 'version']);
			validation.isAllowedFilter(status, Object.values(Enums.AgreementStatus));
			validation.isAllowedOrderByField(orderByField, [
				'category',
				'userName',
				'email',
				'title',
				'version',
				'createAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const findAgreementHistoryListDto = {
				workspaceId: member.workspace.id,
				termsId,
				termsCategoryId,
				keyword,
				filter,
				status,
				startDate: startDate ? new Date(startDate) : undefined,
				endDate: endDate ? new Date(endDate) : undefined,
				orderByField,
				sortOrder,
				page: parseInt(pageString),
				limit: parseInt(limitString),
			};

			const result = await termsService.findAgreementHistoryList(findAgreementHistoryListDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	// 사용 가능한 동의서 카테고리 목록 조회
	async findEnabledTermsCategories(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const workspaceId = member.workspace.id;

			const result = await termsService.findEnabledTermsCategories(workspaceId);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new TermsController();
