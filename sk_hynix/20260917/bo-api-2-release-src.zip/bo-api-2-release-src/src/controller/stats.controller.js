import { statsService } from '../services/index.js';
import authHandler from '../handlers/auth.handler.js';
import { HttpError } from '../handlers/error.handler.js';
import { validation, date } from '../utils/index.js';

class StatsController {
	async getYears(req, res, next) {
		try {
			const result = await statsService.getYears();
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getWorkspaceStats(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				periodType,
				startPeriod,
				endPeriod,
				page: pageString = '1',
				limit: limitString = '1',
				orderByField = 'workspaceId',
				sortOrder = 'asc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S800' : 'H600';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!periodType || !startPeriod || !endPeriod) throw new HttpError(1000);

			validation.validatePeriodFormat(periodType, startPeriod, endPeriod);
			validation.isAllowedOrderByField(orderByField, ['workspaceId', 'workspaceName']);
			validation.isAllowedSortOrder(sortOrder);

			const statsDto = {
				workspaceId,
				periodType,
				startPeriod,
				endPeriod,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await statsService.findWorkspaceStats(statsDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async downloadWorkspaceStats(req, res, next) {
		try {
			const { auth, path } = req;
			const { workspaceId = null, periodType, startPeriod, endPeriod } = req.body;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S800' : 'H600';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!periodType || !startPeriod || !endPeriod) throw new HttpError(1000);

			validation.validatePeriodFormat(periodType, startPeriod, endPeriod);

			const statsDto = {
				workspaceId,
				periodType,
				startPeriod: String(startPeriod),
				endPeriod: String(endPeriod),
				orderByField: 'workspaceId',
				sortOrder: 'asc',
			};

			const csv = await statsService.downloadWorkspaceStats(statsDto);

			const filename = `workspace_stats_${startPeriod}_${endPeriod}.csv`;

			res.setHeader('Content-Type', 'text/csv; charset=utf-8');
			res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${filename}`);
			res.setHeader('Cache-Control', 'no-cache');
			res.send(Buffer.from(csv, 'utf8'));
		} catch (err) {
			next(err);
		}
	}

	async getMemberStats(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				filter = null,
				keyword = null,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'email',
				sortOrder = 'asc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S900' : 'H700';

			await authHandler.checkRolePermission(auth, menuCode);

			validation.validatePeriodFormat('YYYY-MM-DD', fromDateString, toDateString);
			validation.isAllowedFilter(filter, ['userName', 'email', 'workspaceName']);
			validation.isAllowedOrderByField(orderByField, [
				'workspaceName',
				'userName',
				'email',
				'totalContentCount',
				'totalContentDuration',
				'totalLLMToken',
				'totalLLMCount',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const statsDto = {
				workspaceId,
				filter,
				keyword,
				fromDate: fromDateString ? date.getDateTime(fromDateString, 'YYYY-MM-DDTHH:mm:ss.000Z') : null,
				toDate:
					toDateString ? date.getDateTime(date.addDate(toDateString, 1), 'YYYY-MM-DDTHH:mm:ss.000Z') : null,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await statsService.findMemberStats(statsDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async downloadMemberStats(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				filter = null,
				keyword = null,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
			} = req.body;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S900' : 'H700';

			await authHandler.checkRolePermission(auth, menuCode);

			validation.validatePeriodFormat('YYYY-MM-DD', fromDateString, toDateString);
			validation.isAllowedFilter(filter, ['userName', 'email', 'workspaceName']);

			const statsDto = {
				workspaceId,
				filter,
				keyword,
				fromDate: fromDateString ? date.getDateTime(fromDateString, 'YYYY-MM-DDTHH:mm:ss.000Z') : null,
				toDate:
					toDateString ? date.getDateTime(date.addDate(toDateString, 1), 'YYYY-MM-DDTHH:mm:ss.000Z') : null,
				orderByField: 'memberId',
				sortOrder: 'asc',
			};

			const csv = await statsService.downloadMemberStats(statsDto);

			res.setHeader('Content-Type', 'text/csv; charset=utf-8');
			res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''member_stats.csv`);
			res.setHeader('Cache-Control', 'no-cache');

			res.send(Buffer.from(csv, 'utf8'));
		} catch (err) {
			next(err);
		}
	}

	async createDailyStats(req, res, next) {
		try {
			const { statsDate } = req.body;

			if (!statsDate) throw new HttpError(1000);

			const today = date.getDate(new Date(), 'YYYY-MM-DD');
			if (statsDate <= today) throw new HttpError(1017);

			const dateDto = {
				fromDate: date.getDateTime(statsDate, 'YYYY-MM-DDTHH:mm:ss.000Z'),
				toDate: date.getDateTime(date.addDate(statsDate, 1), 'YYYY-MM-DDTHH:mm:ss.000Z'),
			};

			const result = await statsService.createDailyStats(dateDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new StatsController();
