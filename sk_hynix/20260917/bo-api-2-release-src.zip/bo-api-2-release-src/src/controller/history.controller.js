import { historyService } from '../services/index.js';
import authHandler from '../handlers/auth.handler.js';
import { validation, date } from '../utils/index.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';

class HistoryController {
	async getPolicyHistoryList(req, res, next) {
		try {
			const { auth } = req;
			const {
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;
			const menuCode = 'S600';

			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(filter, ['category', 'userName', 'email', 'title', 'version']);
			validation.isAllowedOrderByField(orderByField, [
				'userName',
				'email',
				'category',
				'title',
				'version',
				'createAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const policyHistoryDto = {
				fromDate: date.formatDate(fromDateString),
				toDate: date.formatDate(toDateString, 1),
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await historyService.getPolicyHistoryList(policyHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getLoginHistoryList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				device = null,
				isSuccess = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'loginAt',
				sortOrder = 'desc',
			} = req.query;
			const menuCode = 'H100';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId) throw new HttpError(1000);

			validation.isAllowedFilter(filter, ['ip', 'userName', 'email']);
			validation.isAllowedFilter(device, Object.values(Enums.LoginDevice));
			validation.isAllowedFilter(isSuccess, ['true', 'false']);
			validation.isAllowedOrderByField(orderByField, [
				'userName',
				'email',
				'ip',
				'device',
				'failureReason',
				'loginAt',
				'logoutAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const loginHistoryDto = {
				workspaceId,
				device,
				isSuccess:
					isSuccess === 'true' ? true
					: isSuccess === 'false' ? false
					: null,
				fromDate: date.formatDate(fromDateString),
				toDate: date.formatDate(toDateString, 1),
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await historyService.getLoginHistoryList(loginHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getDownloadHistoryList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				type = null,
				device = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'downloadAt',
				sortOrder = 'desc',
			} = req.query;

			const menuCode = 'H200';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId) throw new HttpError(1000);

			validation.isAllowedFilter(filter, ['contentTitle', 'fileName', 'userName', 'email']);
			validation.isAllowedFilter(device, Object.values(Enums.DownloadDevice));
			validation.isAllowedFilter(type, ['DOCS', 'MEDIA']);
			validation.isAllowedOrderByField(orderByField, [
				'type',
				'contentTitle',
				'fileName',
				'userName',
				'email',
				'size',
				'device',
				'downloadAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const downloadHistoryDto = {
				workspaceId,
				type,
				device,
				fromDate: date.formatDate(fromDateString),
				toDate: date.formatDate(toDateString, 1),
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await historyService.getDownloadHistoryList(downloadHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getSettingHistoryList(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S700' : 'H400';

			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(filter, ['userName', 'menuName', 'changeItem']);
			validation.isAllowedOrderByField(orderByField, [
				'id',
				'userName',
				'ip',
				'menuName',
				'changeItem',
				'createAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const settingHistoryDto = {
				workspaceId,
				fromDate: date.formatDate(fromDateString),
				toDate: date.formatDate(toDateString, 1),
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await historyService.getSettingHistoryList(settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getContentHistoryList(req, res, next) {
		try {
			const { auth } = req;
			const {
				workspaceId,
				fromDate: fromDateString = null,
				toDate: toDateString = null,
				contentType = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			const menuCode = 'H500';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!workspaceId) throw new HttpError(1000);

			validation.isAllowedFilter(filter, ['contentTitle', 'userName']);
			validation.isAllowedFilter(contentType, Object.values(Enums.ContentType));
			validation.isAllowedOrderByField(orderByField, [
				'contentType',
				'contentTitle',
				'userName',
				'meetingStartTime',
				'duration',
				'createAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const contentHistoryDto = {
				workspaceId,
				contentType,
				fromDate: date.formatDate(fromDateString),
				toDate: date.formatDate(toDateString, 1),
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await historyService.getContentHistoryList(contentHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new HistoryController();
