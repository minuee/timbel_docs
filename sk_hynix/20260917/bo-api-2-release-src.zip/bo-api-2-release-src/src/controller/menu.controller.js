import { menuService, roleService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';
import authHandler from '../handlers/auth.handler.js';
import { common } from '../utils/index.js';

class MenuController {
	async getMenuList(req, res, next) {
		try {
			const { auth } = req;
			const { group = null, workspaceId = null } = req.query;

			await authHandler.checkRolePermission(auth, 'S200');

			const menuDto = {
				group,
				workspaceId,
			};

			const result = await menuService.getMenuList(menuDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createAddonMenu(req, res, next) {
		try {
			const { auth, user } = req;
			const { workspaceId, group, name, urlPath, isUsed } = req.body;
			const menuCode = 'S200';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!group || !name || !urlPath) throw new HttpError(1000);
			if (typeof isUsed !== 'boolean') throw new HttpError(1000);

			const menuDto = {
				group,
				workspaceId,
				name,
				urlPath,
				isUsed,
				creatorId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await menuService.createAddonMenu(menuDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async createDefaultMenu(req, res, next) {
		try {
			const { auth, user } = req;
			const { group, code, name, urlPath, isUsed } = req.body;

			await authHandler.checkRolePermission(auth, 'S200');

			if (!group || !code || !name || !urlPath) throw new HttpError(1000);
			if (typeof isUsed !== 'boolean') throw new HttpError(1000);

			const menuDto = {
				group,
				code,
				name,
				urlPath,
				isUsed,
				creatorId: user.pid,
			};
			const result = await menuService.createDefaultMenu(menuDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateMenu(req, res, next) {
		try {
			const { user, auth } = req;
			const { id } = req.params;
			const { group, name, urlPath, isUsed } = req.body;
			const menuCode = 'S200';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!group || !name || !urlPath) throw new HttpError(1000);
			if (typeof isUsed !== 'boolean') throw new HttpError(1000);

			const menuDto = {
				id,
				group,
				name,
				urlPath,
				isUsed,
				updaterId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await menuService.updateMenu(menuDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateMenuIsUsed(req, res, next) {
		try {
			const { user, auth } = req;
			const { id } = req.params;
			const { isUsed } = req.body;
			const menuCode = 'S200';

			await authHandler.checkRolePermission(auth, menuCode);

			if (typeof isUsed !== 'boolean') throw new HttpError(1000);

			const menuDto = {
				id,
				isUsed,
				updaterId: user.pid,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await menuService.updateMenuIsUsed(menuDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async deleteMenu(req, res, next) {
		try {
			const { user, auth } = req;
			const { id } = req.params;
			const menuCode = 'S200';

			await authHandler.checkRolePermission(auth, menuCode);

			const menuDto = { id };

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await menuService.deleteMenu(menuDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 204, data: result });
		} catch (err) {
			next(err);
		}
	}

	async initMenuAndRole(req, res, next) {
		try {
			const result1 = await menuService.initMenu();
			const result2 = await roleService.initRole();
			res.json({ message: 'Success', httpCode: 200, data: { result1, result2 } });
		} catch (err) {
			next(err);
		}
	}
}

export default new MenuController();
