import { memberService } from '../services/index.js';
import authHandler from '../handlers/auth.handler.js';
import { validation, common } from '../utils/index.js';

class MemberController {
	async getMemberAuthorities(req, res, next) {
		try {
			const { auth } = req;
			const { member } = auth;
			const { workspace } = member;
			const { workspaceId = null } = req.query;

			const userDto = {
				workspaceId: workspaceId || workspace.id,
				workspaceName: workspace.name,
				memberId: member.id,
			};
			const result = await memberService.findMemberAuthorities(userDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getMemberList(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'createAt',
				sortOrder = 'desc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S300' : 'W400';

			await authHandler.checkRolePermission(auth, menuCode);

			validation.isAllowedFilter(filter, ['email', 'nickName']);
			validation.isAllowedOrderByField(orderByField, [
				'workspaceName',
				'nickName',
				'email',
				'roleName',
				'createAt',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const memberDto = {
				workspaceId,
				isSystem,
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await memberService.getMemberList(memberDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async updateMemberRole(req, res, next) {
		try {
			const { user, auth, path } = req;
			const { id } = req.params;
			const { roleId = null } = req.body;
			const menuCode = path.split('/').pop() === 'system' ? 'S300' : 'W400';

			await authHandler.checkRolePermission(auth, menuCode);

			const memberDto = {
				id,
				roleId,
			};

			const settingHistoryDto = {
				userName: user.nickName,
				email: user.email,
				ip: common.getClientIp(req),
				menuCode,
			};
			const result = await memberService.updateMemberRole(memberDto, settingHistoryDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new MemberController();
