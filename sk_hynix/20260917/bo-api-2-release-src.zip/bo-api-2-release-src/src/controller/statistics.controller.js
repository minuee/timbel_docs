import statisticsService from '../services/statistics.service.js';
import authHandler from '../handlers/auth.handler.js';
import { HttpError } from '../handlers/error.handler.js';
import { validation, date } from '../utils/index.js';

class StatisticsController {
	async getMemberStatistics(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				memberId,
				periodType,
				fromDate,
				toDate,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'totalSeconds',
				sortOrder = 'desc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S1000' : 'H800';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!periodType || !fromDate || !toDate) throw new HttpError(1000);

			validation.isAllowedFilter(periodType, ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']);
			validation.isAllowedFilter(filter, ['workspaceName', 'userName', 'email']);
			validation.validateFromToDate(fromDate, toDate);
			validation.isAllowedOrderByField(orderByField, [
				'period',
				'workspaceName',
				'userName',
				'email',
				'totalContentCount',
				'totalSeconds',
				'mobileContentCount',
				'mobileSeconds',
				'transcribeDoneCount',
				'transcribeErrorCount',
				'transcribeOtherCount',
				'duration0_1Min',
				'duration1_30Min',
				'duration30_60Min',
				'duration60_120Min',
				'duration120_180Min',
				'durationOver180Min',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const statisticsDto = {
				workspaceId,
				memberId,
				periodType,
				fromDate,
				toDate,
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await statisticsService.findMemberStatistics(statisticsDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async getWorkspaceStatistics(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				periodType,
				fromDate,
				toDate,
				filter = null,
				keyword = null,
				page: pageString = '1',
				limit: limitString = '10',
				orderByField = 'totalSeconds',
				sortOrder = 'desc',
			} = req.query;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S1000' : 'H800';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!periodType || !fromDate || !toDate) throw new HttpError(1000);

			validation.isAllowedFilter(periodType, ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']);
			validation.isAllowedFilter(filter, ['workspaceName', 'userName', 'email']);
			validation.validateFromToDate(fromDate, toDate);
			validation.isAllowedOrderByField(orderByField, [
				'period',
				'workspaceName',
				'totalContentCount',
				'totalSeconds',
				'mobileContentCount',
				'mobileSeconds',
				'transcribeDoneCount',
				'transcribeErrorCount',
				'transcribeOtherCount',
				'duration0_1Min',
				'duration1_30Min',
				'duration30_60Min',
				'duration60_120Min',
				'duration120_180Min',
				'durationOver180Min',
			]);
			validation.isAllowedSortOrder(sortOrder);

			const statisticsDto = {
				workspaceId,
				periodType,
				fromDate,
				toDate,
				filter,
				keyword,
				page: parseInt(pageString),
				limit: parseInt(limitString),
				orderByField,
				sortOrder,
			};

			const result = await statisticsService.findWorkspaceStatistics(statisticsDto);
			res.json({ message: 'Success', httpCode: 200, data: result });
		} catch (err) {
			next(err);
		}
	}

	async downloadMemberStatistics(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				memberId,
				periodType,
				fromDate,
				toDate,
				filter = null,
				keyword = null,
				orderByField = 'workspaceName',
				sortOrder = 'asc',
			} = req.body;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S1000' : 'H800';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!periodType || !fromDate || !toDate) throw new HttpError(1000);

			validation.isAllowedFilter(periodType, ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']);
			validation.isAllowedFilter(filter, ['workspaceName', 'userName', 'email']);
			validation.validateFromToDate(fromDate, toDate);

			const statisticsDto = {
				workspaceId,
				memberId,
				periodType,
				fromDate,
				toDate,
				filter,
				keyword,
				orderByField,
				sortOrder,
			};

			const csv = await statisticsService.downloadMemberStatistics(statisticsDto);
			const filename = `member_statistics_${fromDate}_${toDate}.csv`;

			res.setHeader('Content-Type', 'text/csv; charset=utf-8');
			res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${filename}`);
			res.setHeader('Cache-Control', 'no-cache');

			res.send(Buffer.from(csv, 'utf8'));
		} catch (err) {
			next(err);
		}
	}

	async downloadWorkspaceStatistics(req, res, next) {
		try {
			const { auth, path } = req;
			const {
				workspaceId = null,
				periodType,
				fromDate,
				toDate,
				filter = null,
				keyword = null,
				orderByField = 'workspaceName',
				sortOrder = 'asc',
			} = req.body;

			const isSystem = path.split('/').pop() === 'system';
			const menuCode = isSystem ? 'S1000' : 'H800';

			await authHandler.checkRolePermission(auth, menuCode);

			if (!periodType || !fromDate || !toDate) throw new HttpError(1000);

			validation.isAllowedFilter(periodType, ['DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY']);
			validation.isAllowedFilter(filter, ['workspaceName']);
			validation.validateFromToDate(fromDate, toDate);

			const statisticsDto = {
				workspaceId,
				periodType,
				fromDate,
				toDate,
				filter,
				keyword,
				orderByField,
				sortOrder,
			};

			const csv = await statisticsService.downloadWorkspaceStatistics(statisticsDto);
			const filename = `workspace_statistics_${fromDate}_${toDate}.csv`;

			res.setHeader('Content-Type', 'text/csv; charset=utf-8');
			res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${filename}`);
			res.setHeader('Cache-Control', 'no-cache');

			res.send(Buffer.from(csv, 'utf8'));
		} catch (err) {
			next(err);
		}
	}

	async createDailyStatistics(req, res, next) {
		try {
			const { statsDate } = req.body;

			if (!statsDate) throw new HttpError(1000);

			const dateDto = {
				fromDate: date.formatDate(statsDate),
				toDate: date.formatDate(statsDate, 1),
			};

			const result = await statisticsService.createDailyStatistics(dateDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new StatisticsController();
