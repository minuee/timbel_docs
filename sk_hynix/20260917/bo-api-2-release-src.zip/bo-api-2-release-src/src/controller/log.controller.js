import { logService } from '../services/index.js';
import { HttpError } from '../handlers/error.handler.js';

class LogController {
	async createErrorLog(req, res, next) {
		try {
			const { email, group, transaction } = req.body;

			if (!email || !group || !transaction) throw new HttpError(1000);

			const logDto = {
				email,
				group,
				transaction,
			};

			const result = await logService.createErrorLog(logDto);
			res.json({ message: 'Success', httpCode: 201, data: result });
		} catch (err) {
			next(err);
		}
	}
}

export default new LogController();
