import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class StatsModel extends BaseDatabase {
	constructor() {
		super('StatsModel');
	}

	async getYears() {
		return await this.mariaDB.dailyStats.groupBy({
			by: ['yyyy'],
			orderBy: { yyyy: 'asc' },
			select: {
				yyyy: true,
			},
		});
	}

	async getStatsWorkspaceIds(statsDto) {
		const { page = null, limit = null, orderByField, sortOrder } = statsDto;

		const pagenation = common.pagenation(page, limit);

		return await this.mariaDB.dailyStats.groupBy({
			by: ['workspaceId'],
			orderBy: { [orderByField]: sortOrder },
			...pagenation,
			select: {
				workspaceId: true,
			},
		});
	}

	async getWorkspaceYearlyStats(statsDto) {
		const { workspaceId, workspaceIds = null, startPeriod, endPeriod, orderByField, sortOrder } = statsDto;

		let where = {
			yyyy: { gte: startPeriod, lte: endPeriod },
		};
		if (workspaceIds) where.workspaceId = { in: workspaceIds };
		else if (workspaceId) where.workspaceId = workspaceId;

		return await this.mariaDB.workspaceYearlyStats.findMany({
			where,
			orderBy: [{ [orderByField]: sortOrder }, { yyyy: 'desc' }],
		});
	}

	async getWorkspaceMonthlyStats(statsDto) {
		const { workspaceId, workspaceIds = null, startPeriod, endPeriod, orderByField, sortOrder } = statsDto;

		let where = {
			yyyymm: { gte: startPeriod, lte: endPeriod },
		};
		if (workspaceIds) where.workspaceId = { in: workspaceIds };
		else if (workspaceId) where.workspaceId = workspaceId;

		return await this.mariaDB.workspaceMonthlyStats.findMany({
			where,
			orderBy: [{ [orderByField]: sortOrder }, { yyyymm: 'desc' }],
		});
	}

	async getMemberStats(statsDto) {
		const { workspaceId, filter, keyword, fromDate, toDate, page, limit, orderByField, sortOrder } = statsDto;

		let where = {};
		if (workspaceId) where.workspaceId = workspaceId;

		if (fromDate || toDate) {
			const createAtConditions = [];
			if (fromDate) {
				createAtConditions.push({ createDate: { gte: fromDate } });
			}
			if (toDate) {
				createAtConditions.push({ createDate: { lt: toDate } });
			}
			where.AND = createAtConditions;
		}

		if (keyword) {
			const searchConditions = [];
			const userNameSearchConditions = { userName: { contains: keyword } };
			const emailSearchConditions = { email: { contains: keyword } };
			const workspaceNameSearchConditions = { workspaceName: { contains: keyword } };
			if (!filter) {
				searchConditions.push(userNameSearchConditions, emailSearchConditions, workspaceNameSearchConditions);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'email') {
				searchConditions.push(emailSearchConditions);
			} else if (filter === 'workspaceName') {
				searchConditions.push(workspaceNameSearchConditions);
			}
			where.OR = searchConditions;
		}

		const groupBy = ['workspaceId', 'workspaceName', 'memberId', 'userName', 'email'];

		// 집계 필드로 정렬할 수 있는 필드 목록
		const aggregateFields = ['totalContentCount', 'totalContentDuration', 'totalLLMToken', 'totalLLMCount'];
		const isAggregateField = orderByField && aggregateFields.includes(orderByField);

		let orderBy = {};
		if (orderByField && !isAggregateField) {
			orderBy = { [orderByField]: sortOrder };
		}

		const pagenation = common.pagenation(page, limit);

		// 집계 필드로 정렬하는 경우, 전체 데이터를 가져와서 정렬 후 페이지네이션 적용
		if (isAggregateField) {
			const [allStats, countResult] = await Promise.all([
				this.mariaDB.memberStats.groupBy({
					by: groupBy,
					where,
					_sum: {
						totalContentCount: true,
						totalContentDuration: true,
						totalLLMToken: true,
						totalLLMCount: true,
					},
				}),
				this.mariaDB.memberStats.groupBy({
					by: groupBy,
					where,
				}),
			]);

			// 집계 필드로 정렬
			allStats.sort((a, b) => {
				const aValue = a._sum[orderByField] || 0;
				const bValue = b._sum[orderByField] || 0;
				if (sortOrder === 'asc') {
					return aValue - bValue;
				} else {
					return bValue - aValue;
				}
			});

			const total = countResult.length;
			const startIndex = pagenation.skip || 0;
			const endIndex = pagenation.take ? startIndex + pagenation.take : undefined;
			const stats = allStats.slice(startIndex, endIndex);

			return { stats, total };
		}

		// 일반 필드로 정렬하는 경우, 기존 방식 사용
		const [stats, countResult] = await Promise.all([
			this.mariaDB.memberStats.groupBy({
				by: groupBy,
				where,
				orderBy,
				...pagenation,
				_sum: {
					totalContentCount: true,
					totalContentDuration: true,
					totalLLMToken: true,
					totalLLMCount: true,
				},
			}),
			this.mariaDB.memberStats.groupBy({
				by: groupBy,
				where,
			}),
		]);
		const total = countResult.length;

		return { stats, total };
	}

	async getUsageStats(dateDto, usageType) {
		const { fromDate, toDate } = dateDto;
		return await this.mariaDB.usage.groupBy({
			by: ['contentId'],
			where: {
				createAt: {
					gte: fromDate,
					lt: toDate,
				},
				type: usageType,
			},
			_sum: {
				count: true,
			},
		});
	}

	async getDailyStats(createDate) {
		return await this.mariaDB.dailyStats.findMany({
			where: {
				createDate,
			},
		});
	}

	async createDailyStats(dailyStats) {
		return await this.mariaDB.dailyStats.createMany({
			data: dailyStats,
		});
	}
}

export default new StatsModel();
