import { common } from '../utils/index.js';
import BaseDatabase from '@timbel-timblo-onpremise/prisma';

class PolicyModel extends BaseDatabase {
	constructor() {
		super('PolicyModel');
	}

	policyInclude = {
		creator: {
			select: {
				pid: true,
				nickName: true,
				email: true,
			},
		},
		updater: {
			select: {
				pid: true,
				nickName: true,
				email: true,
			},
		},
	};

	async getPolicyList(params) {
		const { category, status, filter, keyword, orderByField, sortOrder, page, limit } = params;

		let where = {};

		if (category) where.category = category;
		if (status) where.status = { in: status };

		if (keyword) {
			const searchConditions = [];
			const titleSearchConditions = { title: { contains: keyword } };
			const creatorSearchConditions = { creator: { nickName: { contains: keyword } } };

			if (!filter) {
				searchConditions.push(titleSearchConditions, creatorSearchConditions);
			} else {
				if (filter === 'title') searchConditions.push(titleSearchConditions);
				if (filter === 'creator') searchConditions.push(creatorSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'creator') orderBy = { creator: { nickName: sortOrder } };
			else orderBy = { [orderByField]: sortOrder };
		}

		const { skip, take } = common.pagenation(page, limit);

		return await Promise.all([
			this.mariaDB.policy.findMany({
				where,
				orderBy,
				skip,
				take,
				include: this.policyInclude,
			}),
			this.mariaDB.policy.count({ where }),
		]);
	}

	async getPolicy(policyDto) {
		const { id, category, status, orderByField, sortOrder } = policyDto;

		let where = {};
		if (id) where.id = id;
		if (category) where.category = category;
		if (status) where.status = status;

		let orderBy = {};
		if (orderByField) {
			orderBy = { [orderByField]: sortOrder || 'asc' };
		}

		return await this.mariaDB.policy.findFirst({
			where,
			orderBy,
			include: this.policyInclude,
		});
	}

	async createPolicy(data) {
		const { category, title, content, creatorId } = data;
		return await this.mariaDB.policy.create({
			data: {
				category,
				title,
				content,
				creator: { connect: { pid: creatorId } },
			},
		});
	}

	async updatePolicy(policyDto) {
		const { id, category, title, content, updaterId } = policyDto;
		return await this.mariaDB.policy.update({
			where: { id },
			data: { category, title, content, updater: { connect: { pid: updaterId } } },
			select: {
				id: true,
				category: true,
				status: true,
				title: true,
				content: true,
				publishedAt: true,
				createAt: true,
				updateAt: true,
				...this.policyInclude,
			},
		});
	}

	async updatePolicyStatus(policyDto) {
		const { id, status, version, updaterId } = policyDto;
		let data = {
			status,
			version,
			updater: { connect: { pid: updaterId } },
		};
		if (status === this.Enums.PolicyStatus.PUBLISHED) data.publishedAt = new Date();
		if (status === this.Enums.PolicyStatus.ARCHIVED) data.archivedAt = new Date();
		return await this.mariaDB.policy.update({
			where: { id },
			data,
		});
	}

	async deletePolicy(id) {
		return await this.mariaDB.policy.delete({
			where: { id },
		});
	}
}

export default new PolicyModel();
