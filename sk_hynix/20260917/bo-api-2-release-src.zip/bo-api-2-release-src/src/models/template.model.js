import { common } from '../utils/index.js';
import BaseDatabase from '@timbel-timblo-onpremise/prisma';

export class TemplateModel extends BaseDatabase {
	constructor() {
		super('TemplateModel');

		this.memberSelect = {
			select: {
				user: {
					select: {
						profile: {
							select: {
								nickName: true,
								thumbnailUrl: true,
							},
						},
					},
				},
			},
		};

		this.templateSelect = {
			id: true,
			version: true,
			name: true,
			description: true,
			preview: true,
			category: {
				select: {
					id: true,
					name: true,
				},
			},
			options: true,
			isUsed: true,
			createAt: true,
			creator: this.memberSelect,
			updateAt: true,
			editor: this.memberSelect,
		};

		this.templateListSelect = {
			...this.templateSelect,
			description: false,
			preview: false,
			options: false,
			creator: false,
			createAt: false,
		};
	}

	async isTemplateCategoryExists(name, { workspace }) {
		return await this.mariaDB.templateCategory.findFirst({
			where: {
				name,
				workspaceId: workspace.id,
			},
		});
	}

	async isTemplateCategoryExistsById(id, { workspace }) {
		return await this.mariaDB.templateCategory.findFirst({
			where: {
				id,
				workspaceId: workspace.id,
			},
		});
	}

	async createTemplateCategory(name, { workspace }) {
		return await this.mariaDB.templateCategory.create({
			data: {
				name,
				workspace: {
					connect: {
						id: workspace.id,
					},
				},
			},
		});
	}

	async updateCategory(id, name, { workspace }) {
		return await this.mariaDB.templateCategory.update({
			where: {
				id,
				workspaceId: workspace.id,
			},
			data: {
				name,
			},
		});
	}

	async findAllTemplateCategories({ workspace }) {
		return await this.mariaDB.templateCategory.findMany({
			where: {
				workspaceId: workspace.id,
			},
			select: {
				id: true,
				name: true,
				createAt: true,
				updateAt: true,
			},
			orderBy: {
				createAt: 'desc',
			},
		});
	}

	async deleteCategory(id, { workspace }) {
		return await this.mariaDB.templateCategory.delete({
			where: {
				id,
				workspaceId: workspace.id,
			},
		});
	}

	async findTemplatesById(id, { workspace }) {
		return await this.mariaDB.template.findMany({
			where: {
				id,
				workspaceId: workspace.id,
			},
		});
	}

	async createTemplate(templateId, templateInfo, member) {
		const { workspace, id } = member;
		const { categoryId, ...rest } = templateInfo;
		return await this.mariaDB.template.create({
			data: {
				...rest,
				id: templateId,
				workspace: { connect: { id: workspace.id } },
				category: { connect: { id: categoryId } },
				creator: { connect: { id: id } },
				editor: { connect: { id: id } },
			},
			select: this.templateSelect,
		});
	}

	async findAllTemplates(templateDto) {
		const { workspaceId, fromDate, toDate, filter, keyword, page, limit } = templateDto;
		const where = {
			workspaceId,
			isDeleted: 'N',
		};
		if (fromDate) where.createAt = { gte: fromDate };
		if (toDate) where.createAt = { lte: toDate };

		if (keyword) {
			const searchConditions = [];
			const creatorNameSearchConditions = {
				creator: { user: { profile: { nickName: { contains: keyword.trim() } } } },
			};
			const templateNameSearchConditions = { name: { contains: keyword.trim() } };
			if (!filter) {
				searchConditions.push(creatorNameSearchConditions, templateNameSearchConditions);
			} else if (filter === 'creatorName') {
				searchConditions.push(creatorNameSearchConditions);
			} else if (filter === 'templateName') {
				searchConditions.push(templateNameSearchConditions);
			}
			where.OR = searchConditions;
		}

		const commonOptions = {
			orderBy: [{ updateAt: 'asc' }, { version: 'asc' }],
			...common.pagenation(page, limit),
		};

		const [templates, groupedTemplates = []] = await Promise.all([
			this.mariaDB.template.findMany({
				where,
				select: this.templateListSelect,
				...commonOptions,
			}),
			this.mariaDB.template.groupBy({ where, by: ['id'] }),
		]);

		return {
			templates,
			_count: groupedTemplates.length,
			currentPage: page,
			totalPage: Math.ceil(groupedTemplates.length / limit),
		};
	}

	async findTemplatesById(id, member) {
		const { workspace } = member;
		return await this.mariaDB.template.findMany({
			where: {
				id,
				workspaceId: workspace.id,
			},
			select: this.templateSelect,
			orderBy: [{ version: 'asc' }],
		});
	}

	async findTemplateByIdAndVersion(id, version, member) {
		const { workspace } = member;
		return await this.mariaDB.template.findUnique({
			where: {
				id_version: {
					id,
					version,
				},
				workspaceId: workspace.id,
			},
		});
	}

	async updateTemplate(id, version, member, updateData) {
		const { workspace } = member;

		const { categoryId, ...rest } = updateData;
		const data = {
			...rest,
			editor: { connect: { id: member.id } },
		};

		if (categoryId) {
			data.category = { connect: { id: categoryId } };
		}

		return await this.mariaDB.template.update({
			where: {
				id_version: {
					id,
					version,
				},
				workspaceId: workspace.id,
			},
			data,
			select: this.templateSelect,
		});
	}

	async updateTemplateIsUsed(id, version, member, isUsed) {
		const { workspace } = member;
		return await this.mariaDB.template.update({
			where: {
				id_version: { id, version },
				workspaceId: workspace.id,
			},
			data: {
				isUsed,
				editor: { connect: { id: member.id } },
			},
		});
	}
}

export default new TemplateModel();
