import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class HistoryModel extends BaseDatabase {
	constructor() {
		super('HistoryModel');
	}

	async getPolicyHistoryList(policyHistoryDto) {
		const { fromDate, toDate, filter, keyword, page, limit, orderByField, sortOrder } = policyHistoryDto;

		let where = {};
		if (fromDate || toDate) {
			const createAtConditions = [];
			if (fromDate) createAtConditions.push({ createAt: { gte: fromDate } });
			if (toDate) createAtConditions.push({ createAt: { lt: toDate } });
			where.AND = createAtConditions;
		}
		if (keyword) {
			const searchConditions = [];
			const categorySearchConditions = { policy: { category: { contains: keyword } } };
			const userNameSearchConditions = { userName: { contains: keyword } };
			const emailSearchConditions = { email: { contains: keyword } };
			const titleSearchConditions = { policy: { title: { contains: keyword } } };
			const versionSearchConditions = { policy: { version: { contains: keyword } } };

			if (!filter) {
				searchConditions.push(
					categorySearchConditions,
					userNameSearchConditions,
					emailSearchConditions,
					titleSearchConditions,
					versionSearchConditions
				);
			} else if (filter === 'category') {
				searchConditions.push(categorySearchConditions);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'email') {
				searchConditions.push(emailSearchConditions);
			} else if (filter === 'title') {
				searchConditions.push(titleSearchConditions);
			} else if (filter === 'version') {
				searchConditions.push(versionSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'category') orderBy = { policy: { category: sortOrder } };
			else if (orderByField === 'title') orderBy = { policy: { title: sortOrder } };
			else if (orderByField === 'version') orderBy = { policy: { version: sortOrder } };
			else orderBy = { [orderByField]: sortOrder };
		}

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.policyAgreement.findMany({
				where,
				orderBy,
				skip,
				take,
				select: {
					id: true,
					userName: true,
					email: true,
					policy: {
						select: {
							id: true,
							category: true,
							title: true,
							version: true,
						},
					},
					createAt: true,
				},
			}),
			await this.mariaDB.policyAgreement.count({ where }),
		]);
	}

	async getLoginHistoryList(loginHistoryDto) {
		const {
			workspaceId,
			fromDate,
			toDate,
			device,
			isSuccess,
			filter,
			keyword,
			page,
			limit,
			orderByField,
			sortOrder,
		} = loginHistoryDto;

		let where = {
			workspaceId,
		};
		if (fromDate || toDate) {
			const loginAtConditions = [];
			if (fromDate) loginAtConditions.push({ loginAt: { gte: fromDate } });
			if (toDate) loginAtConditions.push({ loginAt: { lt: toDate } });
			where.AND = loginAtConditions;
		}
		if (isSuccess !== null) where.failureReason = isSuccess ? null : { not: null };
		if (device) where.device = device;
		if (keyword) {
			const searchConditions = [];
			const ipSearchConditions = { ip: { contains: keyword } };
			const userNameSearchConditions = { userName: { contains: keyword } };
			const emailSearchConditions = { email: { contains: keyword } };

			if (!filter) {
				searchConditions.push(ipSearchConditions, userNameSearchConditions, emailSearchConditions);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'ip') {
				searchConditions.push(ipSearchConditions);
			} else if (filter === 'email') {
				searchConditions.push(emailSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) orderBy = { [orderByField]: sortOrder };

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.loginHistory.findMany({
				where,
				orderBy,
				skip,
				take,
			}),
			await this.mariaDB.loginHistory.count({ where }),
		]);
	}

	async getDownloadHistoryList(downloadHistoryDto) {
		const { workspaceId, fromDate, toDate, type, device, filter, keyword, page, limit, orderByField, sortOrder } =
			downloadHistoryDto;

		let where = {
			workspaceId,
		};
		if (fromDate || toDate) {
			const downloadAtConditions = [];
			if (fromDate) downloadAtConditions.push({ downloadAt: { gte: fromDate } });
			if (toDate) downloadAtConditions.push({ downloadAt: { lt: toDate } });
			where.AND = downloadAtConditions;
		}
		if (type) where.type = { in: type };
		if (device) where.device = device;
		if (keyword) {
			const searchConditions = [];
			const contentTitleSearchConditions = { contentTitle: { contains: keyword } };
			const fileNameSearchConditions = { fileName: { contains: keyword } };
			const userNameSearchConditions = { userName: { contains: keyword } };
			const emailSearchConditions = { email: { contains: keyword } };

			if (!filter) {
				searchConditions.push(
					contentTitleSearchConditions,
					fileNameSearchConditions,
					userNameSearchConditions,
					emailSearchConditions
				);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'contentTitle') {
				searchConditions.push(contentTitleSearchConditions);
			} else if (filter === 'fileName') {
				searchConditions.push(fileNameSearchConditions);
			} else if (filter === 'email') {
				searchConditions.push(emailSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) orderBy = { [orderByField]: sortOrder };

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.downloadHistory.findMany({
				where,
				orderBy,
				skip,
				take,
			}),
			await this.mariaDB.downloadHistory.count({ where }),
		]);
	}

	async getSettingHistoryList(settingHistoryDto) {
		const { workspaceId, fromDate, toDate, filter, keyword, page, limit, orderByField, sortOrder } =
			settingHistoryDto;

		let where = {};
		if (workspaceId) where.workspaceId = workspaceId;

		if (fromDate || toDate) {
			const createAtConditions = [];
			if (fromDate) createAtConditions.push({ createAt: { gte: fromDate } });
			if (toDate) createAtConditions.push({ createAt: { lt: toDate } });
			where.AND = createAtConditions;
		}
		if (keyword) {
			const searchConditions = [];
			const userNameSearchConditions = { userName: { contains: keyword } };
			const menuNameSearchConditions = { menuName: { contains: keyword } };
			const changeItemSearchConditions = { changeItem: { contains: keyword } };

			if (!filter) {
				searchConditions.push(userNameSearchConditions, menuNameSearchConditions, changeItemSearchConditions);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'menuName') {
				searchConditions.push(menuNameSearchConditions);
			} else if (filter === 'changeItem') {
				searchConditions.push(changeItemSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) {
			orderBy = { [orderByField]: sortOrder };
		}

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.settingHistory.findMany({
				where,
				orderBy,
				skip,
				take,
				select: {
					id: true,
					workspaceId: true,
					workspaceName: true,
					userName: true,
					ip: true,
					menuName: true,
					tableName: true,
					changeItem: true,
					createAt: true,
					beforeData: true,
					afterData: true,
					requiredFields: true,
				},
			}),
			await this.mariaDB.settingHistory.count({ where }),
		]);
	}

	async createSettingHistory(settingHistoryDto) {
		return await this.mariaDB.settingHistory.create({
			data: settingHistoryDto,
		});
	}

	async getContentHistoryList(contentHistoryDto) {
		const { workspaceId, fromDate, toDate, contentType, filter, keyword, page, limit, orderByField, sortOrder } =
			contentHistoryDto;

		let where = {
			workspaceId,
		};
		if (fromDate || toDate) {
			const createAtConditions = [];
			if (fromDate) createAtConditions.push({ createAt: { gte: fromDate } });
			if (toDate) createAtConditions.push({ createAt: { lt: toDate } });
			where.AND = createAtConditions;
		}
		if (contentType) where.contentType = contentType;
		if (keyword) {
			const searchConditions = [];
			const contentTitleSearchConditions = { contentTitle: { contains: keyword } };
			const userNameSearchConditions = { userName: { contains: keyword } };

			if (!filter) {
				searchConditions.push(contentTitleSearchConditions, userNameSearchConditions);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'contentTitle') {
				searchConditions.push(contentTitleSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) orderBy = { [orderByField]: sortOrder };

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.contentHistory.findMany({
				where,
				orderBy,
				skip,
				take,
			}),
			await this.mariaDB.contentHistory.count({ where }),
		]);
	}
}

export default new HistoryModel();
