import BaseDatabase from '@timbel-timblo-onpremise/prisma';

export class LogModel extends BaseDatabase {
	constructor() {
		super('LogModel');
	}

	async createErrorLog(logDto) {
		const { email, group, transaction } = logDto;
		return await this.mongoDB.clientErrorLog.create({
			data: { email, group, transaction },
		});
	}
}

export default new LogModel();
