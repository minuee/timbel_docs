import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class CorpusModel extends BaseDatabase {
	constructor() {
		super('CorpusModel');
	}

	async findCorpusList(corpusDto) {
		const { workspaceId, source, target, creator, page, limit, orderByField, sortOrder } = corpusDto;

		let where = {
			workspaceId,
		};
		if (source) where.source = { contains: source };
		if (target) where.target = { contains: target };
		if (creator) where.creator = { user: { profile: { nickName: { contains: creator } } } };

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'creator') orderBy = { creator: { user: { profile: { nickName: sortOrder } } } };
			else orderBy = { [orderByField]: sortOrder };
		}

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.corpus.findMany({
				where,
				orderBy,
				skip,
				take,
				select: {
					id: true,
					source: true,
					target: true,
					creator: {
						select: {
							user: {
								select: {
									profile: {
										select: {
											pid: true,
											name: true,
											nickName: true,
										},
									},
								},
							},
						},
					},
					createAt: true,
					updateAt: true,
				},
			}),
			await this.mariaDB.corpus.count({ where }),
		]);
	}
}

export default new CorpusModel();
