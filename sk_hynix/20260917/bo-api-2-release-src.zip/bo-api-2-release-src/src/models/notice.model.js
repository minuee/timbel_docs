import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class NoticeModel extends BaseDatabase {
	constructor() {
		super('NoticeModel');
	}

	async getNoticeList(noticeDto) {
		const { ids, workspaceId, fromDate, toDate, filter, keyword, page, limit, orderByField, sortOrder } = noticeDto;

		const where = {
			workspaceId,
		};

		if (ids) where.id = { in: ids };

		if (fromDate || toDate) {
			const createAtConditions = [];
			if (fromDate) createAtConditions.push({ createAt: { gte: fromDate } });
			if (toDate) createAtConditions.push({ createAt: { lt: toDate } });
			where.AND = createAtConditions;
		}
		if (keyword) {
			const searchConditions = [];
			const titleSearchConditions = { title: { contains: keyword } };
			const creatorNameSearchConditions = { creatorName: { contains: keyword } };
			const statusSearchConditions = { status: { contains: keyword } };

			if (!filter) {
				searchConditions.push(titleSearchConditions, creatorNameSearchConditions, statusSearchConditions);
			} else if (filter === 'title') {
				searchConditions.push(titleSearchConditions);
			} else if (filter === 'creatorName') {
				searchConditions.push(creatorNameSearchConditions);
			} else if (filter === 'status') {
				searchConditions.push(statusSearchConditions);
			}
			where.OR = searchConditions;
		}

		const { skip, take } = common.pagenation(page, limit);

		return await Promise.all([
			this.mariaDB.noticeView.findMany({
				where,
				orderBy: { [orderByField]: sortOrder },
				skip,
				take,
			}),
			this.mariaDB.noticeView.count({ where }),
		]);
	}

	async getNotice(noticeDto) {
		const { id } = noticeDto;
		return await this.mariaDB.noticeView.findFirst({
			where: { id },
		});
	}

	async createNotice(noticeDto) {
		const { workspaceId, title, content, postAt, withdrawalAt, ignoreDays, creatorId } = noticeDto;
		return await this.mariaDB.notice.create({
			data: {
				workspace: { connect: { id: workspaceId } },
				title,
				content,
				postAt,
				withdrawalAt,
				ignoreDays,
				creator: { connect: { pid: creatorId } },
			},
		});
	}

	async updateNotice(noticeDto) {
		const { id, title, content, ignoreDays, postAt, withdrawalAt, updaterId } = noticeDto;
		return await this.mariaDB.notice.update({
			where: { id },
			data: {
				title,
				content,
				ignoreDays,
				postAt,
				withdrawalAt,
				updater: { connect: { pid: updaterId } },
			},
		});
	}

	async updateNoticeStatus(noticeDto) {
		const { id, postAt, withdrawalAt, updaterId } = noticeDto;
		return await this.mariaDB.notice.update({
			where: { id },
			data: {
				postAt,
				withdrawalAt,
				updater: { connect: { pid: updaterId } },
			},
		});
	}

	async deleteNotices(ids) {
		return await this.mariaDB.notice.deleteMany({
			where: { id: { in: ids } },
		});
	}
}

export default new NoticeModel();
