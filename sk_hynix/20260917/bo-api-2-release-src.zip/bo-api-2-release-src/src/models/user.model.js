import BaseDatabase from '@timbel-timblo-onpremise/prisma';

export class UserModel extends BaseDatabase {
	constructor() {
		super('UserModel');
	}

	async getUserList() {
		return await this.mariaDB.user.findMany({
			where: {
				memberWorkspaces: {
					some: {
						workspace: {
							domain: { not: 'global' },
						},
					},
				},
			},
		});
	}

	async getUser(userDto) {
		const { pid, email } = userDto;
		let where = {};
		if (pid) where.pid = pid;
		if (email) where.profile = { email };

		return await this.mariaDB.user.findFirst({
			where,
			include: {
				profile: true,
				memberWorkspaces: {
					select: {
						workspace: true,
					},
				},
			},
		});
	}

	async createUser(userDto) {
		const { pid, domain, name, email, password } = userDto;

		return await this.mariaDB.user.create({
			data: {
				pid,
				domain,
				password,
				profile: { create: { nickName: name, email } },
				config: { create: {} },
			},
			include: {
				password: false,
			},
		});
	}

	async updateUserPassword(userDto) {
		const { pid, hashedPassword } = userDto;
		return await this.mariaDB.user.update({
			where: { pid },
			data: { password: hashedPassword },
		});
	}

	async deleteUsers(pids) {
		return await this.mariaDB.user.deleteMany({
			where: { pid: { in: pids } },
		});
	}

	async getUserCompanyByPids(pids) {
		return await this.mariaDB.userProfile.findMany({
			where: { pid: { in: pids } },
			select: {
				company: {
					select: {
						userId: true,
					},
				},
			},
		});
	}

	async deleteCompanyByUserIds(userIds) {
		return await this.mariaDB.company.deleteMany({
			where: { userId: { in: userIds } },
		});
	}
}

export default new UserModel();
