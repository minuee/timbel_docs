import BaseDatabase from '@timbel-timblo-onpremise/prisma';

export class MenuModel extends BaseDatabase {
	constructor() {
		super('MenuModel');
	}

	async getMenuList(menuDto) {
		const { group, workspaceId, isUsed } = menuDto;

		let where = {};
		if (group) where.group = { in: group };
		if (workspaceId) where.OR = [{ workspaceId }, { workspaceId: null }];
		if (isUsed) where.isUsed = isUsed;

		return await this.mariaDB.menu.findMany({
			where,
			orderBy: [{ group: 'asc' }, { code: 'asc' }],
		});
	}

	async getMenu(menuDto) {
		const { id, code, workspaceId } = menuDto;
		let where = {};
		if (id) where.id = id;
		if (code) where.code = code;
		if (workspaceId) where.OR = [{ workspaceId }, { workspaceId: null }];

		return await this.mariaDB.menu.findFirst({
			where,
		});
	}

	async createMenu(menuDto) {
		const { group, code, workspaceId, name, urlPath, isUsed, creatorId } = menuDto;
		let data = {
			group,
			code,
			name,
			urlPath,
			isUsed,
		};
		if (workspaceId) data.workspace = { connect: { id: workspaceId } };
		if (creatorId) data.creator = { connect: { pid: creatorId } };

		return await this.mariaDB.menu.create({
			data,
		});
	}

	async createMenus(menuDtoList) {
		return await this.mariaDB.menu.createMany({
			data: menuDtoList,
		});
	}

	async updateMenu(menuDto) {
		const { id, group, name, urlPath, isUsed, updaterId } = menuDto;

		const data = {
			group,
			name,
			urlPath,
			isUsed,
			updater: { connect: { pid: updaterId } },
		};

		return await this.mariaDB.menu.update({
			where: { id },
			data,
		});
	}

	async updateMenuIsUsed(menuDto) {
		const { id, isUsed, updaterId } = menuDto;
		let data = {
			isUsed,
			updater: { connect: { pid: updaterId } },
		};

		return await this.mariaDB.menu.update({
			where: { id },
			data,
		});
	}

	async deleteMenu(id) {
		return await this.mariaDB.menu.delete({
			where: { id },
		});
	}
}

export default new MenuModel();
