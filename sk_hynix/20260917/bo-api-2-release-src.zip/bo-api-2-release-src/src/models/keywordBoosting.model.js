import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class KeywordBoostingModel extends BaseDatabase {
	constructor() {
		super('KeywordBoostingModel');
	}

	async findKeywordBoostingList(keywordDto) {
		const { workspaceId, keyword, creator, page, limit, orderByField, sortOrder } = keywordDto;

		let where = {
			workspaceId,
		};
		if (keyword) where.keyword = { contains: keyword };
		if (creator) where.creator = { user: { profile: { nickName: { contains: creator } } } };

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'creator') orderBy = { creator: { user: { profile: { nickName: sortOrder } } } };
			else orderBy = { [orderByField]: sortOrder };
		}

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.keywordBoosting.findMany({
				where,
				orderBy,
				skip,
				take,
				select: {
					id: true,
					keyword: true,
					creator: {
						select: {
							user: {
								select: {
									profile: {
										select: {
											pid: true,
											name: true,
											nickName: true,
										},
									},
								},
							},
						},
					},
					createAt: true,
					updateAt: true,
				},
			}),
			await this.mariaDB.keywordBoosting.count({ where }),
		]);
	}

	// 내보내기용: 필터 동일, 페이지네이션 없이 전체 키워드 문자열 목록
	async findKeywordsForExport(keywordDto) {
		const { workspaceId, keyword, creator } = keywordDto;

		let where = { workspaceId };
		if (keyword) where.keyword = { contains: keyword };
		if (creator) where.creator = { user: { profile: { nickName: { contains: creator } } } };

		const rows = await this.mariaDB.keywordBoosting.findMany({
			where,
			orderBy: { createAt: 'desc' },
			select: { keyword: true },
		});
		return rows.map(row => row.keyword);
	}
}

export default new KeywordBoostingModel();
