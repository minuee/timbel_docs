import { HttpError } from '../handlers/error.handler.js';
import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class MemberModel extends BaseDatabase {
	constructor() {
		super('MemberModel');
	}

	async findMemberByPID(pid, select) {
		if (!pid) throw new HttpError(1301);
		const result = await this.mariaDB.member.findFirst({
			select,
			where: {
				user: { pid },
			},
		});

		if (result === null) throw new HttpError(1301);

		return result;
	}

	async findMembersForDelete(memberDto) {
		const { pids, workspaceId } = memberDto;
		let where = {};
		if (pids) where.pid = { in: pids };
		if (workspaceId) where.workspaceId = workspaceId;

		return await this.mariaDB.member.findMany({
			where,
			select: {
				id: true,
				pid: true,
				workspace: {
					select: {
						id: true,
					},
				},
				user: {
					select: {
						profile: {
							select: {
								nickName: true,
								email: true,
							},
						},
						ownedWorkspaces: {
							select: {
								id: true,
							},
						},
					},
				},
				creatorContent: {
					select: {
						contentId: true,
					},
				},
			},
		});
	}

	async getWorkspaceMemberCount(workspaceIds) {
		return await this.mariaDB.member.groupBy({
			where: {
				workspaceId: { in: workspaceIds },
			},
			by: ['workspaceId', 'role'],
			select: {
				workspaceId: true,
				role: true,
			},
			_count: true,
		});
	}

	async getMemberList(memberDto) {
		const { workspaceId, filter, keyword, page, limit, orderByField, sortOrder } = memberDto;

		let where = {
			workspace: {
				domain: { not: 'global' },
			},
		};
		if (workspaceId) where.workspace.id = workspaceId;
		if (keyword) {
			const searchConditions = [];
			const emailSearchConditions = { user: { profile: { email: { contains: keyword } } } };
			const nickNameSearchConditions = { user: { profile: { nickName: { contains: keyword } } } };

			if (!filter) {
				searchConditions.push(emailSearchConditions, nickNameSearchConditions);
			} else if (filter === 'email') {
				searchConditions.push(emailSearchConditions);
			} else if (filter === 'nickName') {
				searchConditions.push(nickNameSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'workspaceName') {
				orderBy = { workspace: { name: sortOrder } };
			} else if (orderByField === 'nickName') {
				orderBy = { user: { profile: { nickName: sortOrder } } };
			} else if (orderByField === 'email') {
				orderBy = { user: { profile: { email: sortOrder } } };
			} else if (orderByField === 'roleName') {
				orderBy = { menuRole: { name: sortOrder } };
			} else if (orderByField === 'createAt') {
				orderBy = { createAt: sortOrder };
			}
		}

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.member.findMany({
				where,
				orderBy,
				skip,
				take,
				select: {
					id: true,
					workspace: {
						select: {
							id: true,
							name: true,
							thumbnailUrl: true,
						},
					},
					user: {
						select: {
							profile: {
								select: {
									pid: true,
									name: true,
									nickName: true,
									email: true,
								},
							},
						},
					},
					menuRole: {
						select: {
							id: true,
							name: true,
							adminType: true,
						},
					},
					createAt: true,
				},
			}),
			await this.mariaDB.member.count({ where }),
		]);
	}

	async getMember(id) {
		return await this.mariaDB.member.findUnique({
			where: { id },
			select: {
				id: true,
				menuRole: {
					select: {
						name: true,
					},
				},
				menuRoleId: true,
				user: {
					select: {
						profile: {
							select: {
								nickName: true,
							},
						},
					},
				},
			},
		});
	}

	async getStatisticsMemberList(memberDto) {
		const { workspaceId, memberId } = memberDto;
		let where = {
			workspace: {
				domain: { not: 'global' },
			},
		};
		if (workspaceId) where.workspace.id = workspaceId;
		if (memberId) where.id = memberId;

		return await this.mariaDB.member.findMany({
			where,
			select: {
				id: true,
				user: {
					select: {
						profile: {
							select: {
								nickName: true,
								email: true,
							},
						},
					},
				},
			},
		});
	}

	async getStatsMembers(dateDto) {
		const { toDate } = dateDto;
		return await this.mariaDB.member.findMany({
			where: {
				workspace: {
					domain: { not: 'global' },
				},
				createAt: {
					lte: toDate,
				},
			},
			select: {
				id: true,
				workspaceId: true,
			},
		});
	}

	async createMember(memberDto) {
		const { pid, workspaceId, roleId } = memberDto;
		let data = {
			user: { connect: { pid } },
			workspace: { connect: { id: workspaceId } },
		};
		if (roleId) data.menuRole = { connect: { id: roleId } };

		return await this.mariaDB.member.create({
			data,
		});
	}

	async updateMemberRole(memberDto) {
		const { id, roleId } = memberDto;
		let data = {};

		data.menuRole = roleId ? { connect: { id: roleId } } : { disconnect: true };
		return await this.mariaDB.member.update({
			where: { id },
			data,
			select: {
				id: true,
				workspaceId: true,
				menuRoleId: true,
				menuRole: {
					select: {
						id: true,
						name: true,
					},
				},
				user: {
					select: {
						profile: {
							select: {
								nickName: true,
							},
						},
					},
				},
			},
		});
	}
}

export default new MemberModel();
