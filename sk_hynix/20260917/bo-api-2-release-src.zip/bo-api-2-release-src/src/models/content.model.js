import BaseDatabase from '@timbel-timblo-onpremise/prisma';

export class ContentModel extends BaseDatabase {
	constructor() {
		super('ContentModel');
	}

	async getFileListByContentIds(contentIds) {
		return await this.mongoDB.file.findMany({
			where: { contentId: { in: contentIds } },
			select: {
				id: true,
			},
		});
	}

	async getNoteListByContentIds(contentIds) {
		return await this.mongoDB.note.findMany({
			where: { contentId: { in: contentIds } },
			select: {
				id: true,
			},
		});
	}

	async getContentStatistics(dateDto) {
		const { fromDate, toDate } = dateDto;
		return await this.mariaDB.content.findMany({
			where: {
				workspace: {
					domain: {
						not: 'global',
					},
				},
				isDeleted: false,
				isRecycle: false,
				createAt: {
					gte: fromDate,
					lt: toDate,
				},
			},
			select: {
				contentId: true,
				workspaceId: true,
				creatorId: true,
				duration: true,
				isMobile: true,
				transcribeStatus: true,
				createAt: true,
			},
		});
	}

	async getContentStats(dateDto) {
		const { fromDate, toDate } = dateDto;
		return await this.mariaDB.content.groupBy({
			where: {
				createAt: {
					gte: fromDate,
					lt: toDate,
				},
			},
			by: ['creatorId', 'contentId'],
			_count: {
				creatorId: true,
			},
			_sum: {
				duration: true,
			},
		});
	}

	async getContentCaptureStats(fromDate, toDate, captureAction) {
		return await this.mariaDB.contentCapture.findMany({
			where: {
				captureAction: {
					in: captureAction,
				},
				createAt: {
					gte: fromDate,
					lt: toDate,
				},
			},
			select: {
				creatorId: true,
				contentId: true,
				captureAction: true,
				duration: true,
			},
		});
	}

	async deleteFile(contentIds) {
		return await this.mongoDB.file.deleteMany({
			where: { contentId: { in: contentIds } },
		});
	}

	async deleteNote(contentIds) {
		return await this.mongoDB.note.deleteMany({
			where: { contentId: { in: contentIds } },
		});
	}

	async deleteBookmark(contentIds) {
		return await this.mongoDB.bookmarks.deleteMany({
			where: { contentId: { in: contentIds } },
		});
	}

	async deleteTranscribeResult(fileIds) {
		return await this.mongoDB.transcribeResult.deleteMany({
			where: { fileId: { in: fileIds } },
		});
	}
}

export default new ContentModel();
