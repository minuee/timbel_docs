import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';
import { syncWorkspaceSettings } from '../utils/workspace-settings.util.js';
import { DEFAULT_MENU_ITEMS } from '../constants/workspace-menu.constants.js';

class WorkspaceModel extends BaseDatabase {
	constructor() {
		super('WorkspaceModel');
	}

	async findWorkspaceList(workspaceDto) {
		const { ids, filter, keyword, page, limit, orderByField, sortOrder } = workspaceDto;
		let where = {
			domain: { not: 'global' },
		};
		if (ids) where.id = { in: ids };
		if (keyword) {
			const searchConditions = [];
			const nameSearchConditions = { name: { contains: keyword } };
			const domainSearchConditions = { domain: { contains: keyword } };
			const ownerSearchConditions = { owner: { profile: { nickName: { contains: keyword } } } };
			if (!filter) {
				searchConditions.push(nameSearchConditions, domainSearchConditions, ownerSearchConditions);
			} else if (filter === 'name') {
				searchConditions.push(nameSearchConditions);
			} else if (filter === 'domain') {
				searchConditions.push(domainSearchConditions);
			} else if (filter === 'owner') {
				searchConditions.push(ownerSearchConditions);
			}
			where.OR = searchConditions;
		}

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'owner') {
				orderBy = { owner: { profile: { nickName: sortOrder } } };
			} else {
				orderBy = { [orderByField]: sortOrder };
			}
		}

		const { skip, take } = common.pagenation(page, limit);

		const workspaceList = await this.mariaDB.workspace.findMany({
			where,
			orderBy,
			skip,
			take,
			select: {
				id: true,
				name: true,
				thumbnailUrl: true,
				domain: true,
				description: true,
				owner: { select: { profile: true } },
				config: {
					select: {
						memberMaxCount: true,
					},
				},
				createAt: true,
			},
		});
		const workspaceCount = await this.mariaDB.workspace.count({ where });
		return { workspaceList, workspaceCount };
	}

	async getWorkspaceList(workspaceDto) {
		const { ids } = workspaceDto;
		let where = {
			domain: { not: 'global' },
		};
		if (ids) where.id = { in: ids };
		return await this.mariaDB.workspace.findMany({
			where,
			select: {
				id: true,
				name: true,
			},
		});
	}

	async getWorkspace(workspaceDto) {
		const { id, domain } = workspaceDto;
		let where = {};
		if (id) where.id = id;
		if (domain) where.domain = domain;
		return await this.mariaDB.workspace.findFirst({
			where,
		});
	}

	async getWorkspaceById(workspaceId) {
		return await this.mariaDB.workspace.findUnique({
			where: { id: workspaceId },
			select: {
				id: true,
				name: true,
				domain: true,
				description: true,
				thumbnailUrl: true,
				createAt: true,
				ownerId: true,
				config: {
					select: {
						memberMaxCount: true,
					},
				},
			},
		});
	}

	async getMemberCount(workspaceId) {
		return await this.mariaDB.member.count({
			where: { workspaceId },
		});
	}

	async updateWorkspaceMemberMaxCount(workspaceId, memberMaxCount) {
		return await this.mariaDB.workspaceConfig.update({
			where: { workspaceId },
			data: { memberMaxCount },
		});
	}

	async getTotalWorkspaceMemberMaxCount(excludeWorkspaceId = null) {
		const workspaceWhere = {
			domain: { not: 'global' },
		};

		if (excludeWorkspaceId) {
			workspaceWhere.id = { not: excludeWorkspaceId };
		}

		const result = await this.mariaDB.workspaceConfig.aggregate({
			where: {
				workspace: workspaceWhere,
			},
			_sum: {
				memberMaxCount: true,
			},
		});

		return result._sum.memberMaxCount || 0;
	}

	async createWorkspace(workspaceDto) {
		const { name, domain, description, inviteCode, ownerId } = workspaceDto;
		const menuItems = DEFAULT_MENU_ITEMS.filter(item => item.group !== 'SYSTEM');
		const result = await this.mariaDB.workspace.create({
			data: {
				name,
				domain,
				description,
				owner: { connect: { pid: ownerId } },
				inviteCode,
				config: {
					create: {
						inviteCode,
					},
				},
				menus: {
					createMany: {
						data: menuItems,
					},
				},
			},
		});
		return result;
	}

	async updateWorkspace(workspaceDto) {
		const { id, name, description } = workspaceDto;
		let data = {
			name,
		};
		if (description != undefined) data.description = description;

		const result = await this.mariaDB.workspace.update({
			where: { id },
			data,
		});
		return result;
	}

	async updateWorkspaceOwner(workspaceDto) {
		const { id } = workspaceDto;
		return await this.mariaDB.workspace.update({
			where: { id },
			data: { ownerId: null },
		});
	}

	async deleteWorkspace(id) {
		return await this.mariaDB.workspace.delete({
			where: { id },
		});
	}

	// 워크스페이스 썸네일 URL 업데이트
	async updateThumbnailUrl(workspaceId, thumbnailUrl) {
		return await this.mariaDB.workspace.update({
			where: { id: workspaceId },
			data: { thumbnailUrl },
		});
	}

	// 워크스페이스 썸네일 삭제
	async deleteThumbnail(workspaceId) {
		return await this.mariaDB.workspace.update({
			where: { id: workspaceId },
			data: { thumbnailUrl: null },
		});
	}

	async getWorkspaceSetting(workspaceId, key) {
		return await this.mariaDB.workspaceSetting.findFirst({
			where: { workspaceId, key },
		});
	}

	// 워크스페이스 기능 설정 조회
	async findFeatureSettings(workspaceId, groupList) {
		let where = { workspaceId };
		if (groupList) where.settingItem = { group: { in: groupList } };
		return await this.mariaDB.workspaceSetting.findMany({
			where,
			select: {
				id: true,
				value: true,
				workspace: {
					select: { id: true, name: true, domain: true, thumbnailUrl: true },
				},
				settingItem: true,
			},
		});
	}

	// 기능 설정 아이템을 키로 조회
	async findFeatureSettingItemByKey(key) {
		return await this.mariaDB.workspaceSettingItem.findFirst({
			where: { key },
		});
	}

	// 워크스페이스 기능 설정 업데이트
	async updateFeatureSetting({ workspaceId, value, key }) {
		return await this.mariaDB.workspaceSetting.update({
			where: { workspaceId_key: { workspaceId, key } },
			data: {
				value: value.toString(),
			},
		});
	}

	// 기능 설정 항목의 총 개수를 조회
	async getFeatureSettingItemCount() {
		return await this.mariaDB.workspaceSettingItem.count();
	}

	// 특정 워크스페이스의 기능 설정값 개수를 조회
	async getWorkspaceFeatureSettingCount(workspaceId) {
		return await this.mariaDB.workspaceSetting.count({
			where: { workspaceId },
		});
	}

	// 현재 DB에 있는 기능 설정 항목의 키 목록을 조회
	async getFeatureSettingItemKeys() {
		const items = await this.mariaDB.workspaceSettingItem.findMany({
			select: { key: true },
		});
		return items.map(item => item.key);
	}

	// 특정 워크스페이스의 기능 설정값 키 목록을 조회
	async getWorkspaceFeatureSettingKeys(workspaceId) {
		const settings = await this.mariaDB.workspaceSetting.findMany({
			where: { workspaceId },
			select: { key: true },
		});
		return settings.map(setting => setting.key);
	}

	// 워크스페이스 기능 설정값 동기화
	async syncWorkspaceFeatureSettings(workspaceId) {
		return await syncWorkspaceSettings(this.mariaDB, workspaceId);
	}

	// 사용 중인 라이선스 개수 조회
	async getUsingLicenseCount() {
		return await this.mariaDB.member.count({
			where: { workspace: { domain: { not: 'global' } } },
		});
	}

	// 워크스페이스 정책 생성/업데이트 (upsert)
	async upsertLifecyclePolicy(dto) {
		const { workspaceId, policyType, value, unit } = dto;
		return await this.mariaDB.workspacePolicy.upsert({
			where: {
				uniq_workspace_policy_type: {
					workspaceId,
					policyType,
				},
			},
			update: { value, unit },
			create: { workspaceId, policyType, value, unit },
		});
	}

	// 워크스페이스 보존 정책 조회(개별)
	async getLifecyclePolicyByWorkspaceIdAndPolicyType(workspaceId, policyType) {
		return await this.mariaDB.workspacePolicy.findFirst({
			where: {
				workspaceId,
				policyType,
			},
		});
	}
	// 워크스페이스 보존 정책 조회
	async getLifecyclePolicyByWorkspaceId(workspaceId) {
		return await this.mariaDB.workspacePolicy.findMany({
			where: {
				workspaceId,
			},
		});
	}

	// 워크스페이스 정책 전체 삭제
	async deleteWorkspaceLifecyclePolicy(workspaceId) {
		return await this.mariaDB.workspacePolicy.deleteMany({
			where: {
				workspaceId,
			},
		});
	}

	// 특정 정책 타입 삭제
	async deleteWorkspaceLifecyclePolicyByPolicyType(workspaceId, policyType) {
		return await this.mariaDB.workspacePolicy.delete({
			where: {
				uniq_workspace_policy_type: {
					workspaceId,
					policyType,
				},
			},
		});
	}
}

export default new WorkspaceModel();
