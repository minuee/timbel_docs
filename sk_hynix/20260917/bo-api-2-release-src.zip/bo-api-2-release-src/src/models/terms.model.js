import { common } from '../utils/index.js';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { TERMS_SELECT } from '../constants/terms-select.constant.js';

class TermsModel extends BaseDatabase {
	constructor() {
		super('TermsModel');
	}

	// 동의서 초안 생성
	async createTerms(data) {
		const { workspaceId, categoryId, title, content, isRequired, creatorId } = data;
		return await this.mariaDB.terms.create({
			data: {
				workspaceId,
				categoryId,
				version: null,
				title,
				content,
				isRequired: isRequired || false,
				creatorId,
				status: Enums.TermsStatus.DRAFT,
			},
			select: TERMS_SELECT.FULL,
		});
	}

	// 카테고리별 최신 동의서 조회
	async findLatestTermsByCategoryId(params) {
		const { workspaceId, categoryId } = params;
		return await this.mariaDB.terms.findFirst({
			where: {
				workspaceId,
				categoryId,
				status: { in: [Enums.TermsStatus.PUBLISHED, Enums.TermsStatus.ARCHIVED] },
			},
			orderBy: { version: 'desc' },
		});
	}

	// 동의서 목록 조회
	async findTermsList(params) {
		const {
			workspaceId,
			categoryId,
			filter,
			status,
			keyword,
			startDate,
			endDate,
			orderByField,
			sortOrder,
			page,
			limit,
		} = params;
		const where = {};

		if (workspaceId) where.workspaceId = workspaceId;
		if (categoryId && categoryId.length > 0) where.categoryId = { in: categoryId };
		if (status && status.length > 0) where.status = { in: status };

		if (keyword && keyword.trim()) {
			const trimmedKeyword = keyword.trim();
			const searchConditions = [];

			if (!filter) {
				searchConditions.push(
					{ title: { contains: trimmedKeyword } },
					{ content: { contains: trimmedKeyword } },
					{ creator: { user: { profile: { name: { contains: trimmedKeyword } } } } },
					{ creator: { user: { profile: { nickName: { contains: trimmedKeyword } } } } }
				);
			} else {
				if (filter === 'title') searchConditions.push({ title: { contains: trimmedKeyword } });
				if (filter === 'content') searchConditions.push({ content: { contains: trimmedKeyword } });
				if (filter === 'creator') {
					searchConditions.push(
						{ creator: { user: { profile: { name: { contains: trimmedKeyword } } } } },
						{ creator: { user: { profile: { nickName: { contains: trimmedKeyword } } } } }
					);
				}
			}
			if (searchConditions.length > 0) where.OR = searchConditions;
		}
		if (startDate && endDate) {
			where.createAt = { gte: startDate, lte: endDate };
		} else if (startDate) {
			where.createAt = { gte: startDate };
		} else if (endDate) {
			where.createAt = { lte: endDate };
		}
		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'creator') orderBy = { creator: { user: { profile: { nickName: sortOrder } } } };
			else orderBy = { [orderByField]: sortOrder };
		}

		const { skip, take } = common.pagenation(page, limit);

		const [terms, total] = await Promise.all([
			this.mariaDB.terms.findMany({
				where,
				orderBy,
				skip,
				take,
				select: TERMS_SELECT.FULL,
			}),
			this.mariaDB.terms.count({ where }),
		]);

		return {
			data: terms,
			total,
			page,
			limit,
			totalPages: Math.ceil(total / (limit || 10)),
		};
	}

	// 동의서 상세 조회
	async findTermsById(id) {
		return await this.mariaDB.terms.findUnique({
			where: { id },
			select: { ...TERMS_SELECT.FULL, content: true },
		});
	}

	// 동일 카테고리 동의서의 마지막 버전 조회
	async findLastVersion(categoryId, workspaceId) {
		return await this.mariaDB.terms.findFirst({
			where: { categoryId, workspaceId },
			orderBy: { version: 'desc' },
		});
	}

	// 동의서 초안 수정
	async updateTerms(data, updaterId = null) {
		const { id, title, content, isRequired, categoryId, status } = data;
		const updateData = {
			title,
			content,
			isRequired,
			updater: updaterId ? { connect: { id: updaterId } } : undefined,
		};

		if (status && status === Enums.TermsStatus.PUBLISHED) {
			updateData.publishedAt = new Date();
		}

		if (categoryId) updateData.category = { connect: { id: categoryId } };

		return await this.mariaDB.terms.update({
			where: { id },
			data: updateData,
			select: TERMS_SELECT.FULL,
		});
	}

	// 동의서 삭제
	async deleteTerms(id) {
		return await this.mariaDB.terms.delete({
			where: { id },
		});
	}

	// 동의서 시행
	async publishTerms(id, version, updaterId = null) {
		return await this.mariaDB.terms.update({
			where: { id },
			data: {
				status: Enums.TermsStatus.PUBLISHED,
				publishedAt: new Date(),
				version,
				updater: updaterId ? { connect: { id: updaterId } } : undefined,
			},
			select: TERMS_SELECT.FULL,
		});
	}

	// 동의서 보관
	async archiveTerms(id, updaterId = null) {
		return await this.mariaDB.terms.update({
			where: { id },
			data: {
				status: Enums.TermsStatus.ARCHIVED,
				archivedAt: new Date(),
				updater: updaterId ? { connect: { id: updaterId } } : undefined,
			},
			select: TERMS_SELECT.FULL,
		});
	}

	// PUBLISHED 상태인 동의서을 카테고리별로 조회
	async findPublishedInCategory(workspaceId, categoryId) {
		return await this.mariaDB.terms.findFirst({
			where: { workspaceId, categoryId, status: Enums.TermsStatus.PUBLISHED },
			orderBy: { version: 'desc' },
		});
	}

	// 동의서 제출 이력 목록 조회
	async findAgreementHistoryList(params) {
		const {
			workspaceId,
			termsId,
			termsCategoryId,
			filter,
			status,
			keyword,
			startDate,
			endDate,
			orderByField,
			sortOrder,
			page,
			limit,
		} = params;
		const where = {};

		if (workspaceId) where.workspaceId = workspaceId;
		if (termsId) where.termsId = termsId;
		if (termsCategoryId) where.terms = { categoryId: termsCategoryId };
		if (status) where.status = status;

		if (startDate && endDate) {
			where.createAt = { gte: startDate, lte: endDate };
		} else if (startDate) {
			where.createAt = { gte: startDate };
		} else if (endDate) {
			where.createAt = { lte: endDate };
		}

		const orderBy = [];

		if (orderByField) {
			if (orderByField === 'title') {
				orderBy.push({ terms: { title: sortOrder || 'desc' } });
			} else if (orderByField === 'version') {
				orderBy.push({ terms: { version: sortOrder || 'desc' } });
			} else if (orderByField === 'category') {
				orderBy.push({ terms: { category: { name: sortOrder || 'desc' } } });
			} else {
				orderBy.push({ [orderByField]: sortOrder || 'desc' });
			}
		} else {
			orderBy.push({ createAt: 'desc' });
		}

		if (keyword && keyword.trim()) {
			const trimmedKeyword = keyword.trim();
			const searchConditions = [];

			if (!filter) {
				searchConditions.push(
					{ userName: { contains: trimmedKeyword } },
					{ email: { contains: trimmedKeyword } },
					{ terms: { title: { contains: trimmedKeyword } } },
					{ terms: { version: { contains: trimmedKeyword } } }
				);
			} else {
				if (filter === 'userName') {
					searchConditions.push({ userName: { contains: trimmedKeyword } });
				}
				if (filter === 'email') {
					searchConditions.push({ email: { contains: trimmedKeyword } });
				}
				if (filter === 'title') {
					searchConditions.push({ terms: { title: { contains: trimmedKeyword } } });
				}
				if (filter === 'version') {
					searchConditions.push({ terms: { version: { contains: trimmedKeyword } } });
				}
				if (filter === 'category') {
					searchConditions.push({ terms: { category: { name: { contains: trimmedKeyword } } } });
				}
			}
			if (searchConditions.length > 0) where.OR = searchConditions;
		}

		const skip = ((page || 1) - 1) * (limit || 10);
		const take = limit || 10;

		const [agreements, total] = await Promise.all([
			this.mariaDB.agreement.findMany({
				where,
				orderBy,
				skip,
				take,
				include: {
					workspace: { select: { id: true, name: true } },
					terms: {
						select: {
							id: true,
							title: true,
							version: true,
							category: { select: { id: true, name: true } },
							creator: { select: { user: { select: { profile: true } } } },
						},
					},
				},
			}),
			this.mariaDB.agreement.count({ where }),
		]);

		return { items: agreements, total, page, limit };
	}

	// 사용 가능한 동의서 카테고리 목록 조회
	async findEnabledTermsCategories(workspaceId) {
		return await this.mariaDB.termsCategory.findMany({
			where: { workspaceId, isEnabled: true },
			select: { id: true, name: true, description: true },
		});
	}

	// 동의서 카테고리 조회
	async findTermsCategoryById(workspaceId, id) {
		return await this.mariaDB.termsCategory.findUnique({
			where: { id, workspaceId },
			include: { terms: true },
		});
	}

	// 동의서 카테고리 이름으로 조회
	async findTermsCategoryByName(workspaceId, name) {
		return await this.mariaDB.termsCategory.findFirst({
			where: { workspaceId, name },
		});
	}

	// 동의서 카테고리 생성
	async createTermsCategory(data) {
		const { workspaceId, name, description, isEnabled, priority } = data;
		return await this.mariaDB.termsCategory.create({
			data: {
				workspaceId,
				name,
				description: description ?? '',
				isEnabled: isEnabled ?? true,
				priority,
			},
		});
	}
}

export default new TermsModel();
