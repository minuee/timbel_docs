import BaseDatabase from '@timbel-timblo-onpremise/prisma';

export class StatisticsModel extends BaseDatabase {
	constructor() {
		super('StatisticsModel');
	}

	getGroupByFields(periodType) {
		switch (periodType) {
			case 'DAILY':
				return ['dateKst'];
			case 'WEEKLY':
				return ['yearKst', 'weekNumber'];
			case 'MONTHLY':
				return ['yearKst', 'monthKst'];
			case 'YEARLY':
				return ['yearKst'];
			default:
				return ['dateKst'];
		}
	}

	buildWhereClause(statisticsDto = {}) {
		const { workspaceId, creatorId, fromDate, toDate, filter, keyword } = statisticsDto;
		const where = {};

		if (fromDate || toDate) {
			where.dateKst = {};
			if (fromDate) where.dateKst.gte = fromDate;
			if (toDate) where.dateKst.lte = toDate;
		}

		if (keyword) {
			const searchConditions = [];
			const workspaceNameSearchConditions = { workspace: { name: { contains: keyword } } };
			const userNameSearchConditions = { creator: { user: { profile: { nickName: { contains: keyword } } } } };
			const emailSearchConditions = { creator: { user: { profile: { email: { contains: keyword } } } } };
			if (!filter) {
				searchConditions.push(workspaceNameSearchConditions, userNameSearchConditions, emailSearchConditions);
			} else if (filter === 'workspaceName') {
				searchConditions.push(workspaceNameSearchConditions);
			} else if (filter === 'userName') {
				searchConditions.push(userNameSearchConditions);
			} else if (filter === 'email') {
				searchConditions.push(emailSearchConditions);
			}
			where.OR = searchConditions;
			return where;
		}

		if (workspaceId) where.workspaceId = workspaceId;
		if (creatorId) where.creatorId = creatorId;

		return where;
	}

	async getMemberStats(statisticsDto = {}) {
		const { periodType = 'DAILY' } = statisticsDto;

		const groupByFields = [...this.getGroupByFields(periodType), 'workspaceId', 'creatorId'];

		const where = this.buildWhereClause(statisticsDto);

		return await this.mariaDB.statistics.groupBy({
			by: groupByFields,
			where,
			_sum: {
				totalContentCount: true,
				totalSeconds: true,
				mobileContentCount: true,
				mobileSeconds: true,
				transcribeDoneCount: true,
				transcribeErrorCount: true,
				transcribeOtherCount: true,
				duration0_1Min: true,
				duration1_30Min: true,
				duration30_60Min: true,
				duration60_120Min: true,
				duration120_180Min: true,
				durationOver180Min: true,
			},
		});
	}

	async getWorkspaceStats(statisticsDto = {}) {
		const { periodType = 'DAILY' } = statisticsDto;

		const groupByFields = [...this.getGroupByFields(periodType), 'workspaceId'];

		const where = this.buildWhereClause(statisticsDto);

		return await this.mariaDB.statistics.groupBy({
			by: groupByFields,
			where,
			_sum: {
				totalContentCount: true,
				totalSeconds: true,
				mobileContentCount: true,
				mobileSeconds: true,
				transcribeDoneCount: true,
				transcribeErrorCount: true,
				transcribeOtherCount: true,
				duration0_1Min: true,
				duration1_30Min: true,
				duration30_60Min: true,
				duration60_120Min: true,
				duration120_180Min: true,
				durationOver180Min: true,
			},
		});
	}

	async getDailyStatistics(dateKst) {
		return await this.mariaDB.statistics.findMany({
			where: {
				dateKst,
			},
		});
	}

	async createDailyStatistics(dailyStatistics) {
		return await this.mariaDB.statistics.createMany({
			data: dailyStatistics,
		});
	}
}

export default new StatisticsModel();
