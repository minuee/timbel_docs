import BaseDatabase from '@timbel-timblo-onpremise/prisma';
import { Enums } from '@timbel-timblo-onpremise/prisma';
import { common } from '../utils/index.js';

export class RoleModel extends BaseDatabase {
	constructor() {
		super('RoleModel');
	}

	async findRoleList(roleDto) {
		const { adminType, workspaceId, page, limit, orderByField, sortOrder } = roleDto;

		let where = {
			adminType: { not: Enums.AdminType.GLOBAL },
		};
		if (adminType) where.adminType = adminType;
		if (workspaceId) where.workspaceId = workspaceId;

		let orderBy = {};
		if (orderByField) {
			if (orderByField === 'workspaceName') {
				orderBy = { workspace: { name: sortOrder } };
			} else if (orderByField === 'creator') {
				orderBy = { creator: { nickName: sortOrder } };
			} else {
				orderBy = { [orderByField]: sortOrder };
			}
		}

		const { skip, take } = common.pagenation(page, limit);

		return Promise.all([
			await this.mariaDB.role.findMany({
				where,
				orderBy,
				skip,
				take,
				select: {
					id: true,
					workspace: {
						select: {
							id: true,
							name: true,
							thumbnailUrl: true,
						},
					},
					adminType: true,
					name: true,
					description: true,
					creator: {
						select: {
							pid: true,
							name: true,
							nickName: true,
						},
					},
					createAt: true,
					updateAt: true,
				},
			}),
			await this.mariaDB.role.count({ where }),
		]);
	}

	async getWorkspaceRoleList(roleDto) {
		const { workspaceId, adminType } = roleDto;

		let where = {
			adminType: { not: Enums.AdminType.GLOBAL },
		};

		if (adminType) where.adminType = adminType;
		if (workspaceId) where.workspaceId = workspaceId;

		return await this.mariaDB.role.findMany({
			where,
			select: {
				id: true,
				name: true,
				adminType: true,
				workspaceId: true,
			},
		});
	}

	async getRole(roleDto) {
		const { id } = roleDto;
		return await this.mariaDB.role.findUnique({
			where: {
				id,
			},
			select: {
				id: true,
				workspace: {
					select: {
						id: true,
						name: true,
						thumbnailUrl: true,
					},
				},
				adminType: true,
				name: true,
				description: true,
				creator: {
					select: {
						pid: true,
						name: true,
						nickName: true,
					},
				},
				createAt: true,
				updateAt: true,
				menus: {
					select: {
						id: true,
						group: true,
						code: true,
						name: true,
						urlPath: true,
					},
				},
			},
		});
	}

	// global workspace 역할 조회
	async getGlobalRole() {
		return await this.mariaDB.role.findFirst({
			where: { adminType: Enums.AdminType.GLOBAL },
		});
	}

	async createRole(roleDto) {
		const { workspaceId, adminType, name, description, creatorId } = roleDto;

		let data = {
			workspace: { connect: { id: workspaceId } },
			adminType,
			name,
			description,
		};
		if (creatorId) data.creator = { connect: { pid: creatorId } };

		return await this.mariaDB.role.create({
			data,
		});
	}

	async updateRole(roleDto) {
		const { id, adminType, name, description, updaterId } = roleDto;

		let data = {
			adminType,
			name,
			description,
			updater: { connect: { pid: updaterId } },
		};

		return await this.mariaDB.role.update({
			where: { id },
			data,
		});
	}

	async updatedRoleMenus(roleDto) {
		const { id, attachMenuIds, detachMenuIds } = roleDto;

		return await this.mariaDB.role.update({
			where: { id },
			data: {
				menus: {
					connect: attachMenuIds.map(id => ({ id })),
					disconnect: detachMenuIds.map(id => ({ id })),
				},
			},
		});
	}

	async deleteRole(id) {
		return await this.mariaDB.role.delete({
			where: { id },
		});
	}
}

export default new RoleModel();
