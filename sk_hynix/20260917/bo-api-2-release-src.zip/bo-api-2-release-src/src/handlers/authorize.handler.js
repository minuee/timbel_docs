import { HttpError } from './error.handler.js';
import { redis, generate } from '../utils/index.js';
import memberModel from '../models/member.model.js';

const TAG = '[authorizeMember] ';

const getDefaultMemberOptions = (isInit = false) => {
	let options = {
		id: true,
		workspace: {
			select: {
				id: true,
				name: true,
				domain: true,
			},
		},
	};

	if (!isInit) {
		options.menuRole = {
			select: {
				id: true,
				name: true,
				adminType: true,
				menus: {
					select: {
						id: true,
						group: true,
						code: true,
						name: true,
						urlPath: true,
					},
				},
			},
		};
	}
	return options;
};

const verifyTemporaryAccess = async req => {
	try {
		const { token } = req;
		if (token) {
			const { verify = null, isGuest = false } = await redis.get(`accessTokens:${token}`);
			if (verify && verify.isCert && isGuest) {
				req.auth = { isAuthorized: true };
				log.i(TAG, '-- authorization !isVerified');
				return true;
			}
		}
		return false;
	} catch (err) {
		throw new HttpError(401, '세션 상태를 확인할 수 없습니다.');
	}
};

const authorizeMember = async (req, res, next) => {
	try {
		const { user, headers, path } = req;
		const { 'x-timblo-mobi-gw': isMobile = 'FALSE' } = headers;
		if (await verifyTemporaryAccess(req)) return next();
		log.i(TAG, '-- 멤버 인증으로 진행');

		const options = getDefaultMemberOptions(path.includes('init'));
		const member = await memberModel.findMemberByPID(user.pid, options);
		const salt = `${member.id}${member.workspace.id}`;

		req.auth = {
			member,
			isAuthorized: true,
			config: {
				...user.config,
				isMobile: isMobile?.trim().toUpperCase() === 'TRUE',
			},
			kms: generate.keyFromString(salt),
		};
	} catch (err) {
		return next(err);
	}
	next();
};

export default authorizeMember;
