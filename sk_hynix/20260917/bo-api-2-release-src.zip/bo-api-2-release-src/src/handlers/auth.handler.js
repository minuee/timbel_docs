import { HttpError } from '../handlers/error.handler.js';

const checkRolePermission = async (auth, code) => {
	const { member } = auth;
	log.i(`[AuthHandler : checkRolePermission] code => ${code}`);
	log.i(`[AuthHandler : checkRolePermission] memberId => ${member.id}`);
	const { menuRole } = member;
	if (!menuRole) throw new HttpError(1303);
	const { menus } = menuRole;
	const menu = menus.find(menu => menu.code === code);
	if (!menu) throw new HttpError(1003);
	return true;
};

export default { checkRolePermission };
