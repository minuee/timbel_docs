const mappingError = {
	// Default Errors
	400: { code: 400, errorCode: 'BE0400', message: 'Bad Request' },
	401: { code: 401, errorCode: 'BE0401', message: 'Unauthorized' },
	403: { code: 403, errorCode: 'BE0403', message: 'Forbidden' },
	404: { code: 404, errorCode: 'BE0404', message: 'Not Found' },
	405: { code: 405, errorCode: 'BE0405', message: 'Method Not Allowed' },
	406: { code: 406, errorCode: 'BE0406', message: 'Not Acceptable' },
	408: { code: 408, errorCode: 'BE0408', message: 'Request Timeout' },
	414: { code: 414, errorCode: 'BE0414', message: 'URI Too Long' },
	415: { code: 415, errorCode: 'BE0415', message: 'Unsupported Media Type' },
	422: { code: 422, errorCode: 'BE0422', message: 'Unprocessable Content' },
	429: { code: 429, errorCode: 'BE0429', message: 'Too Many Requests' },
	500: { code: 500, errorCode: 'BE0500', message: 'Internal Server Error' },

	// Common Errors (E1xxx)
	1000: { code: 400, errorCode: 'BE1000', message: '필수 파라미터가 부족합니다.' },
	1003: { code: 403, errorCode: 'BE1003', message: '메뉴 권한이 없습니다.' },
	1008: { code: 400, errorCode: 'BE1008', message: '정의되지 않은 필터입니다.' },
	1009: { code: 400, errorCode: 'BE1009', message: '정의되지 않은 정렬 기준입니다.' },
	1010: { code: 400, errorCode: 'BE1010', message: '시작일이 종료일보다 이후일 수 없습니다.' },
	1011: { code: 400, errorCode: 'BE1011', message: '이메일 형식이 올바르지 않습니다.' },
	1012: { code: 400, errorCode: 'BE1012', message: '기간 형식이 올바르지 않습니다.' },
	1013: { code: 400, errorCode: 'BE1013', message: '날짜 형식이 올바르지 않습니다.' },
	1014: { code: 400, errorCode: 'BE1014', message: '파일 형식이 올바르지 않습니다.' },
	1015: { code: 400, errorCode: 'BE1015', message: '라이선스 정보가 유효하지 않습니다.' },
	1016: { code: 400, errorCode: 'BE1016', message: '라이선스 갯수가 부족하여 요청을 처리할 수 없습니다.' },
	1017: { code: 400, errorCode: 'BE1017', message: '오늘을 포함한 지난 날짜는 사용할 수 없습니다.' },
	1018: { code: 400, errorCode: 'BE1018', message: '종료일은 오늘 이후일 수 없습니다.' },

	// Workspace Errors (E11xx)
	1102: { code: 400, errorCode: 'BE1102', message: '유효하지 않은 도메인입니다.' },
	1104: { code: 404, errorCode: 'BE1104', message: '워크스페이스를 찾을 수 없습니다.' },
	1109: { code: 409, errorCode: 'BE1109', message: '이미 존재하는 워크스페이스입니다.' },
	1110: { code: 400, errorCode: 'BE1110', message: '최대 할당 인원수가 현재 활성화된 인원수보다 작을 수 없습니다.' },
	1111: { code: 400, errorCode: 'BE1111', message: '정의되지 않은 기능 설정 그룹입니다.' },

	// Menu Errors (E12xxx)
	1200: { code: 409, errorCode: 'BE1200', message: '이미 존재하는 메뉴입니다.' },
	1201: { code: 400, errorCode: 'BE1201', message: '정의되지 않은 그룹입니다.' },
	1202: { code: 400, errorCode: 'BE1202', message: '허용되지 않은 그룹입니다.' },
	1203: { code: 404, errorCode: 'BE1203', message: '메뉴를 찾을 수 없습니다.' },

	// Member Errors (E13xx)
	1301: { code: 401, errorCode: 'BE1301', message: '회원 정보가 없습니다.' },
	1303: { code: 403, errorCode: 'BE1303', message: '회원의 역할이 없습니다.' },
	1304: { code: 404, errorCode: 'BE1304', message: '회원을 찾을 수 없습니다.' },

	// Role Errors (E14xx)
	1401: { code: 400, errorCode: 'BE1401', message: '정의되지 않은 관리자 타입입니다.' },
	1402: {
		code: 400,
		errorCode: 'BE1402',
		message: '워크스페이스 관리자 유형은 SYSTEM 또는 SYSTEM_ADDON 그룹의 메뉴를 가질 수 없습니다.',
	},
	1404: { code: 404, errorCode: 'BE1404', message: '역할을 찾을 수 없습니다.' },
	1409: { code: 409, errorCode: 'BE1409', message: '이미 존재하는 역할입니다.' },

	// User Errors (E15xx)
	1504: { code: 404, errorCode: 'BE1504', message: '사용자를 찾을 수 없습니다.' },
	1505: { code: 400, errorCode: 'BE1505', message: '워크스페이스 소유자는 삭제할 수 없습니다.' },
	1509: { code: 409, errorCode: 'BE1509', message: '이미 존재하는 사용자입니다.' },

	// Policy Errors (E16xx)
	1600: { code: 400, errorCode: 'BE1600', message: '정의되지 않은 약관 구분입니다.' },
	1601: { code: 400, errorCode: 'BE1601', message: '약관 구분별 하나의 약관은 게시 상태로 유지해야 합니다.' },
	1602: { code: 400, errorCode: 'BE1602', message: '이미 보관된 약관은 변경할 수 없습니다.' },
	1603: { code: 400, errorCode: 'BE1603', message: '현재 약관 상태와 변경하려는 상태가 동일합니다.' },
	1604: { code: 404, errorCode: 'BE1604', message: '약관을 찾을 수 없습니다.' },
	1605: { code: 400, errorCode: 'BE1605', message: '초안을 제외한 약관은 수정/삭제 할 수 없습니다.' },

	// Notice Errors (E17xx)
	1704: { code: 404, errorCode: 'BE1704', message: '공지사항을 찾을 수 없습니다.' },

	// Stats Errors (E21xx)
	2100: { code: 400, errorCode: 'BE2100', message: '정의되지 않은 기간 타입입니다.' },
	2101: { code: 400, errorCode: 'BE2101', message: '조회 기간을 초과했습니다.' },
	2109: { code: 409, errorCode: 'BE2109', message: '이미 존재하는 일일 통계입니다.' },

	// History Errors (E22xx)
	2200: { code: 400, errorCode: 'BE2200', message: '정의되지 않은 파일 타입입니다.' },

	// Template Errors (E5xxx)
	5400: { code: 500, errorCode: 'BE5400', message: '템플릿 업로드에 실패했습니다.' },
	5401: { code: 400, errorCode: 'BE5401', message: '이미 존재하는 카테고리입니다.' },
	5402: { code: 400, errorCode: 'BE5402', message: '카테고리 생성에 실패했습니다.' },
	5403: { code: 400, errorCode: 'BE5403', message: '카테고리 ID가 필요합니다.' },
	5404: { code: 404, errorCode: 'BE5404', message: '카테고리를 찾을 수 없습니다.' },
	5405: { code: 400, errorCode: 'BE5405', message: '카테고리 수정에 실패했습니다.' },
	5406: { code: 400, errorCode: 'BE5406', message: '카테고리 이름이 변경되지 않았습니다.' },
	5407: { code: 400, errorCode: 'BE5407', message: '동일한 버전의 템플릿이 존재합니다.' },
	5408: { code: 400, errorCode: 'BE5408', message: '템플릿 생성에 실패했습니다.' },
	5409: { code: 404, errorCode: 'BE5409', message: '템플릿을 찾을 수 없습니다.' },
	5410: { code: 400, errorCode: 'BE5410', message: '템플릿 수정에 실패했습니다.' },

	// Terms Errors (E55xx)
	5500: { code: 404, errorCode: 'BE5500', message: '해당 동의서를 찾을 수 없습니다.' },
	5501: { code: 400, errorCode: 'BE5501', message: '유효하지 않은 상태에서 요청할 수 없습니다.' },
	5502: { code: 400, errorCode: 'BE5502', message: '해당 동의서 카테고리를 찾을 수 없습니다.' },
	5503: { code: 400, errorCode: 'BE5503', message: '필수 필드가 누락되었습니다.' },
};

class ErrorHandler {
	async exception(err, req, res, next) {
		const { code = 500, result = {} } = err;
		const errorResponse = errorDetails => {
			const { code: httpCode, errorCode, message } = errorDetails;
			log.e('[ErrorHandler : exception] error:', message);
			console.log(err);
			res.json({ httpCode, message, errorCode, result });
		};

		try {
			const errorDetails = mappingError[code] || mappingError[500];
			errorResponse(errorDetails);
		} catch (error) {
			const fallbackErrorDetails = mappingError[500];
			log.e('[ErrorHandler : exception] fallback error:', error.message);
			errorResponse(fallbackErrorDetails);
		}
	}
}

export const HttpError = class extends Error {
	constructor(httpCode, data) {
		super();
		this.code = httpCode;
		this.result = data;
	}
};

export const QueueError = (errorCode, errorInfo = null) => {
	const errorDetails = mappingError[errorCode] || mappingError[500];
	errorDetails.reason = typeof errorInfo === 'string' || errorInfo === null ? { message: errorInfo } : errorInfo;
	return errorDetails;
};

export default new ErrorHandler();
