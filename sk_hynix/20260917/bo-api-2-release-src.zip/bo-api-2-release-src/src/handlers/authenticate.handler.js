import jwt from 'jsonwebtoken';
import { HttpError } from './error.handler.js';

const TAG = '[sessionHandler] ';

const extractTimbloAuthToken = ({ headers, query }) => {
	let { 'x-timblo-token': token } = headers;

	// 개발 환경 인증 처리를 위한 코드 추가
	if (!token && process.env.NODE_ENV === 'development') {
		const { authorization = null } = headers;
		const { accessToken = null } = query;
		token = !authorization ? accessToken : authorization.split(' ')[1];
	}

	return token;
};

const withTimbloToken = async req => {
	log.i(TAG, '-- timbloTokenAuth Timblo 회원 인증으로 진행');

	const token = extractTimbloAuthToken(req);
	if (!token) throw new HttpError(401);
	log.i(TAG, '-- timbloTokenAuth Header Token 확인');

	log.d(TAG, '-- timbloTokenAuth Token:', token);
	const decoded = jwt.decode(token) ?? {};
	if (!decoded.hasOwnProperty('pid')) throw new HttpError(401, '토큰 정보가 올바르지 않습니다.');
	log.i(TAG, '-- timbloTokenAuth JWT decode 확인');

	req.user = decoded;
	req.token = token;
};

export const authenticateRequest = async (req, res, next) => {
	try {
		await withTimbloToken(req);

		next();
	} catch (err) {
		log.e(TAG, '-- authentication error => ', err.message);
		next(err);
	}
};

export default authenticateRequest;
