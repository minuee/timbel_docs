import 'dotenv/config';
import cors from 'cors';
import express from 'express';
import cookieParser from 'cookie-parser';
import { morganMiddleware } from '@baronote/logger';
import discovery from './configs/discovery-config.js';
import prometheus from './configs/metrics.config.js';
import telemetry from '@timbel-timblo-onpremise/tracely';
export { cookieParser, cors, discovery, prometheus, express, morganMiddleware, telemetry };
