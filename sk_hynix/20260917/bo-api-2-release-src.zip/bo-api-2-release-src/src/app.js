// prettier-ignore
import { 
    cors, 
    express, 
    discovery,
	telemetry,
	prometheus,
	cookieParser, 
	morganMiddleware,
} from './app.module.js';
import './app.handle.js';
import authorizeMember from './handlers/authorize.handler.js';
import authenticateRequest from './handlers/authenticate.handler.js';
import ErrorHandler from './handlers/error.handler.js';
import corpusRouter from './routes/corpus.router.js';
import keywordBoostingRouter from './routes/keywordBoosting.router.js';
import historyRouter from './routes/history.router.js';
import logRouter from './routes/log.router.js';
import memberRouter from './routes/member.router.js';
import menuRouter from './routes/menu.router.js';
import noticeRouter from './routes/notice.router.js';
import policyRouter from './routes/policy.router.js';
import roleRouter from './routes/role.router.js';
import statsRouter from './routes/stats.router.js';
import statisticsRouter from './routes/statistics.router.js';
import templateRouter from './routes/template.router.js';
import userRouter from './routes/user.router.js';
import termsRouter from './routes/terms.router.js';
import workspaceRouter from './routes/workspace.router.js';
import licenseMonitor from './utils/license-monitor.util.js';
import { swaggerUi, specs, uiOptions } from './configs/swagger.config.js';
import mariaDBConnectionPromise from './configs/initialization.config.js';
import { addDailyStatisticsJob, dailyStatisticsQueue } from './queues/statistics.queue.js';
import dailyStatisticsWorker from './workers/statistics.worker.js';

const app = express();

app.use(telemetry.traceMiddleware());

app.use('/health', discovery.healthChecker);
app.use('/metrics', prometheus.metricsHandler);

if (process.env.NODE_ENV === 'development') {
	app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs, uiOptions));
}

app.use(
	express.json({
		limit: '1gb',
	})
);

app.use(
	express.urlencoded({
		limit: '1gb',
		extended: false,
	})
);

// set middleware
app.use(cookieParser());
app.use(morganMiddleware(app));
app.use(cors({ origin: true, credentials: true }));
app.use(prometheus.httpMetricsMiddleware);

app.listen(process.env.PORT ?? 9010, '0.0.0.0', async () => {
	log.i(`Listening on ${process.env.PORT}`);
	// MariaDB 연결 완료 후 Consul 등록 (순서 보장)
	await mariaDBConnectionPromise;

	// Register Batch Jobs
	await addDailyStatisticsJob();

	await discovery.registerService();
});

app.use(authenticateRequest);
app.use(authorizeMember);

const router = express.Router();
router.use('/corpus', corpusRouter);
router.use('/keyword-boosting', keywordBoostingRouter);
router.use('/history', historyRouter);
router.use('/log', logRouter);
router.use('/member', memberRouter);
router.use('/menu', menuRouter);
router.use('/notice', noticeRouter);
router.use('/policy', policyRouter);
router.use('/role', roleRouter);
router.use('/stats', statsRouter);
router.use('/statistics', statisticsRouter);
router.use('/template', templateRouter);
router.use('/user', userRouter);
router.use('/workspace', workspaceRouter);
router.use('/terms', termsRouter);

app.use('/', router);

app.use(ErrorHandler.exception);

await licenseMonitor.initialize();

process.once('SIGINT', async () => {
	await discovery.deregisterService();

	// Graceful shutdown for BullMQ
	await dailyStatisticsQueue.close();
	await dailyStatisticsWorker.close();

	log.i(`${process.env.SYS_NAME} is stopped`);
	process.exit(0);
});

export default app;
