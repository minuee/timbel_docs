import express from 'express';
import statisticsController from '../controller/statistics.controller.js';

const router = express.Router();

router.get(['/members', '/members/system'], statisticsController.getMemberStatistics);
router.get(['/workspaces', '/workspaces/system'], statisticsController.getWorkspaceStatistics);
router.post(['/members/download', '/members/download/system'], statisticsController.downloadMemberStatistics);
router.post(['/workspaces/download', '/workspaces/download/system'], statisticsController.downloadWorkspaceStatistics);
router.post('/', statisticsController.createDailyStatistics);

export default router;
