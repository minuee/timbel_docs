import express from 'express';
import { multer } from '../utils/index.js';
import workspaceController from '../controller/workspace.controller.js';

const router = express.Router();

router.get('/me', workspaceController.getMyWorkspaceInfo);

router.get('/license', workspaceController.getLicenseInfo);
router.post('/license', multer.uploadFile(), workspaceController.uploadLicenseFile);

router.get('/', workspaceController.getWorkspaceList);
router.post('/', workspaceController.createWorkspace);
router.get('/:workspaceId', workspaceController.getWorkspaceInfo); // 특정워크스페이스 기본 정보 조회
router.patch(['/:workspaceId', '/:workspaceId/name'], workspaceController.updateWorkspace);
router.delete('/:workspaceId', workspaceController.deleteWorkspace);

// 워크스페이스 콘텐츠 보존 정책 관리
router.get('/:workspaceId/policy', workspaceController.getLifecyclePolicy);
router.patch('/:workspaceId/policy', workspaceController.updateEachLifecyclePolicy);
router.post('/:workspaceId/policy', workspaceController.createLifecyclePolicy);

router.get('/:workspaceId/setting', workspaceController.getWorkspaceFeatureSettings);
router.patch('/:workspaceId/setting', workspaceController.updateWorkspaceFeatureSetting);

router.put('/:workspaceId/member', workspaceController.updateWorkspaceMemberLimit);

// 로고 관리
router.put('/:workspaceId/logo', multer.uploadFile(), workspaceController.uploadLogo);
router.delete('/:workspaceId/logo', workspaceController.deleteLogo);

export default router;
