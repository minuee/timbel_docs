import express from 'express';
import historyController from '../controller/history.controller.js';

const router = express.Router();

router.get('/policy', historyController.getPolicyHistoryList);
router.get('/login', historyController.getLoginHistoryList);
router.get('/download', historyController.getDownloadHistoryList);
router.get(['/setting', '/setting/system'], historyController.getSettingHistoryList);
router.get('/content', historyController.getContentHistoryList);

export default router;
