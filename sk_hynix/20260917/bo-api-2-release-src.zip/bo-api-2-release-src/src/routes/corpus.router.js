import express from 'express';
import corpusController from '../controller/corpus.controller.js';

const router = express.Router();

router.get('/', corpusController.getCorpusList);

export default router;
