import express from 'express';
import policyController from '../controller/policy.controller.js';

const router = express.Router();

router.get('/', policyController.getPolicyList);
router.get('/:id', policyController.getPolicy);
router.post('/', policyController.createPolicy);
router.put('/:id', policyController.updatePolicy);
router.patch('/:id/status', policyController.updatePolicyStatus);
router.delete('/:id', policyController.deletePolicy);

export default router;
