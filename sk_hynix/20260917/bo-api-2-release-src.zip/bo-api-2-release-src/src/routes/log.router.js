import express from 'express';
import logController from '../controller/log.controller.js';

const router = express.Router();

router.post('/error', logController.createErrorLog);

export default router;
