import express from 'express';
import keywordBoostingController from '../controller/keywordBoosting.controller.js';

const router = express.Router();

router.get('/', keywordBoostingController.getKeywordBoostingList);
router.get('/export', keywordBoostingController.exportKeywordBoostingList);

export default router;
