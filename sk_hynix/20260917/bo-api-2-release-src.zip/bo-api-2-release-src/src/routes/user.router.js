import express from 'express';
import userController from '../controller/user.controller.js';

const router = express.Router();

router.post(['/', '/system'], userController.createUser);
router.patch(['/:pid/password', '/:pid/password/system'], userController.updateUserPassword);
router.delete(['/', '/system'], userController.deleteUsers);

export default router;
