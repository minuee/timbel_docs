import express from 'express';
import statsController from '../controller/stats.controller.js';

const router = express.Router();

router.get('/years', statsController.getYears);
router.get(['/workspace', '/workspace/system'], statsController.getWorkspaceStats);
router.post(['/workspace/download', '/workspace/download/system'], statsController.downloadWorkspaceStats);
router.get(['/member', '/member/system'], statsController.getMemberStats);
router.post(['/member/download', '/member/download/system'], statsController.downloadMemberStats);

router.post('/', statsController.createDailyStats);

export default router;
