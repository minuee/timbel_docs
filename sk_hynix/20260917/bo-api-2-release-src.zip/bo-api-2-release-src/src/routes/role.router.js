import express from 'express';
import roleController from '../controller/role.controller.js';

const router = express.Router();

router.get(['/', '/system'], roleController.getRoleList);
router.get(['/:id', '/:id/system'], roleController.getRole);
router.post(['/', '/system'], roleController.createRole);
router.post(['/:id/menus', '/:id/menus/system'], roleController.updatedRoleMenus);
router.patch(['/:id', '/:id/system'], roleController.updateRole);
router.delete(['/:id', '/:id/system'], roleController.deleteRole);

export default router;
