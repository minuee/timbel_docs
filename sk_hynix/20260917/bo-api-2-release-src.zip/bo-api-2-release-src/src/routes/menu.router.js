import express from 'express';
import menuController from '../controller/menu.controller.js';

const router = express.Router();

router.post('/init', menuController.initMenuAndRole);

router.get('/', menuController.getMenuList);
router.post('/', menuController.createAddonMenu);
router.post('/default', menuController.createDefaultMenu);
router.put('/:id', menuController.updateMenu);
router.patch('/:id/status', menuController.updateMenuIsUsed);
router.delete('/:id', menuController.deleteMenu);

export default router;
