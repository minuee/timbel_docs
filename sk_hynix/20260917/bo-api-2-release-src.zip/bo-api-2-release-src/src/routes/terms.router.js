import express from 'express';
import termsController from '../controller/terms.controller.js';

const router = express.Router();

// 동의서 목록 조회
router.get('/', termsController.findTermsList);

// 사용자 동의서 제출 이력 조회
router.get('/agreement', termsController.findAgreementHistoryList);

// 사용 가능한 동의서 카테고리 목록 조회
router.get('/category/enabled', termsController.findEnabledTermsCategories);

// 동의서 초안 생성
router.post('/', termsController.createTerms);

router.get('/:id', termsController.findTermsById);
router.put('/:id', termsController.updateTerms);
router.patch('/:id', termsController.updateTermsStatus);
router.delete('/:id', termsController.deleteTerms);

export default router;
