import express from 'express';
import noticeController from '../controller/notice.controller.js';

const router = express.Router();

router.get('/', noticeController.getNoticeList);
router.get('/:id', noticeController.getNotice);
router.post('/', noticeController.createNotice);
router.put('/:id', noticeController.updateNotice);
router.patch('/status', noticeController.updateNoticesStatus);
router.delete('/', noticeController.deleteNotices);

export default router;
