import express from 'express';
import memberController from '../controller/member.controller.js';

const router = express.Router();

router.get('/authorities', memberController.getMemberAuthorities);
router.get(['/', '/system'], memberController.getMemberList);
router.patch(['/:id/role', '/:id/role/system'], memberController.updateMemberRole);

export default router;
