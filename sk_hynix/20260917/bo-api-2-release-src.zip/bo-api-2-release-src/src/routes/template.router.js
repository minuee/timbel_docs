import express from 'express';
import { multer } from '../utils/index.js';
import templateController from '../controller/template.controller.js';

const router = express.Router();

router.post('/upload', multer.uploadFileWithTimeout(), templateController.uploadTemplate);

router.post('/category', templateController.createCategory);
router.get('/categories', templateController.getTemplateCategories);
router.delete('/category/:id', templateController.deleteCategory);
router.put('/category/:id', templateController.updateCategory);

router.get(['/:id', '/:id/:version'], templateController.getTemplateDetail);
router.put(['/:id', '/:id/:version'], templateController.updateTemplate);
router.patch(['/:id', '/:id/:version'], templateController.updateTemplateIsUsed);

router.get('/', templateController.getTemplates);
router.post('/', templateController.createTemplate);

export default router;
