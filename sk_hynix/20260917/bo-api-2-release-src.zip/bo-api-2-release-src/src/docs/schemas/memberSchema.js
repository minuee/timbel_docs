/**
 * @swagger
 * components:
 *   schemas:
 *     MenuAuthority:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '메뉴 고유 식별자'
 *           description: '메뉴 ID'
 *         group:
 *           type: string
 *           example: 'SYSTEM'
 *           description: '메뉴 그룹'
 *         code:
 *           type: string
 *           example: 'S200'
 *           description: '메뉴 코드'
 *         name:
 *           type: string
 *           example: '전체 메뉴 관리'
 *           description: '메뉴 이름'
 *         urlPath:
 *           type: string
 *           example: '/workspace'
 *           description: '메뉴 URL 경로'
 *         isAllowed:
 *           type: boolean
 *           example: true
 *           description: '메뉴 권한 여부'
 *
 *     WorkspaceInfo:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: 'alibizgroup'
 *           description: '워크스페이스 이름'
 *         isDefault:
 *           type: boolean
 *           example: true
 *           description: '기본 워크스페이스 여부'
 *
 *     MemberAuthoritiesResponse:
 *       type: object
 *       properties:
 *         menus:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/MenuAuthority'
 *           description: '메뉴 권한 목록'
 *         workspaces:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/WorkspaceInfo'
 *           description: '워크스페이스 목록'
 *
 *     WorkspaceDetail:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: 'alibizgroup'
 *           description: '워크스페이스 이름'
 *         thumbnailUrl:
 *           type: string
 *           example: 'https://example.com/thumbnail.jpg'
 *           description: '워크스페이스 썸네일 URL'
 *
 *     UserProfile:
 *       type: object
 *       properties:
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         name:
 *           type: string
 *           example: '홍길동'
 *           description: '사용자 이름'
 *         nickName:
 *           type: string
 *           example: '닉네임'
 *           description: '사용자 닉네임'
 *         email:
 *           type: string
 *           example: 'user@example.com'
 *           description: '사용자 이메일'
 *
 *     MenuRoleInfo:
 *       type: object
 *       nullable: true
 *       properties:
 *         id:
 *           type: string
 *           example: '역할 고유 식별자'
 *           description: '역할 ID'
 *         name:
 *           type: string
 *           example: '시스템 관리자(Global)'
 *           description: '역할 이름'
 *         adminType:
 *           type: string
 *           example: 'SYSTEM'
 *           description: '역할 관리자 타입'
 *
 *     MemberListItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '회원 고유 식별자'
 *           description: '회원 ID'
 *         workspace:
 *           $ref: '#/components/schemas/WorkspaceDetail'
 *         user:
 *           type: object
 *           properties:
 *             profile:
 *               $ref: '#/components/schemas/UserProfile'
 *         menuRole:
 *           $ref: '#/components/schemas/MenuRoleInfo'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '생성 일시'
 *
 *     WorkspaceRoleInfo:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '역할 고유 식별자'
 *           description: '역할 ID'
 *         name:
 *           type: string
 *           example: '시스템 관리자'
 *
 *     MemberListResponse:
 *       type: object
 *       properties:
 *         members:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/MemberListItem'
 *           description: '회원 목록'
 *         total:
 *           type: integer
 *           example: 3
 *           description: '전체 회원 수'
 *         workspaces:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/WorkspaceInfo'
 *           description: '워크스페이스 목록'
 *
 *     MemberRoleUpdateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '회원 고유 식별자'
 *           description: '회원 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         role:
 *           type: string
 *           example: 'ADMIN'
 *           description: '회원 역할'
 *         menuRoleId:
 *           type: string
 *           example: '역할 고유 식별자'
 *           description: '메뉴 역할 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-02-20T02:04:01.341Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T08:31:47.777Z'
 *           description: '수정 일시'
 */
