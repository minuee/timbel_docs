/**
 * @swagger
 * components:
 *   schemas:
 *     NoticeItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '공지사항 고유 식별자'
 *           description: '공지사항 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         title:
 *           type: string
 *           example: '테스트'
 *           description: '공지사항 제목'
 *         content:
 *           type: string
 *           example: '<p>공지사항 내용</p>'
 *           description: '공지사항 내용 (HTML)'
 *         status:
 *           type: string
 *           enum: [POST, WITHDRAWAL]
 *           example: 'WITHDRAWAL'
 *           description: '공지사항 상태 (POST: 게시, WITHDRAWAL: 철회)'
 *         postAt:
 *           type: string
 *           format: date-time
 *           example: '2025-09-16T15:00:00.000Z'
 *           description: '게시 일시'
 *         withdrawalAt:
 *           type: string
 *           format: date-time
 *           example: '2025-09-26T15:00:00.000Z'
 *           description: '철회 일시'
 *         ignoreDays:
 *           type: integer
 *           example: 0
 *           description: '무시 일수'
 *         creatorName:
 *           type: string
 *           example: 'Timblo'
 *           description: '생성자 이름'
 *         updaterName:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '수정자 이름'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-09-19T01:17:04.000Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-09-22T00:25:12.000Z'
 *           description: '수정 일시'
 *
 *     NoticeListResponse:
 *       type: object
 *       properties:
 *         notices:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/NoticeItem'
 *           description: '공지사항 목록'
 *         total:
 *           type: integer
 *           example: 10
 *           description: '전체 공지사항 수'
 *
 *     NoticeCreateRequest:
 *       type: object
 *       required:
 *         - workspaceId
 *         - title
 *         - content
 *         - postAt
 *         - withdrawalAt
 *         - ignoreDays
 *       properties:
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         title:
 *           type: string
 *           example: '공지사항'
 *           description: '공지사항 제목'
 *         content:
 *           type: string
 *           example: '테스트'
 *           description: '공지사항 내용'
 *         postAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-19T23:00:00.000Z'
 *           description: '게시 일시'
 *         withdrawalAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-27T09:00:00.000Z'
 *           description: '철회 일시'
 *         ignoreDays:
 *           type: integer
 *           example: 7
 *           description: '무시 일수'
 *
 *     NoticeCreateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '공지사항 고유 식별자'
 *           description: '공지사항 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         title:
 *           type: string
 *           example: '공지사항'
 *           description: '공지사항 제목'
 *         content:
 *           type: string
 *           example: '테스트'
 *           description: '공지사항 내용'
 *         postAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-19T23:00:00.000Z'
 *           description: '게시 일시'
 *         withdrawalAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-27T09:00:00.000Z'
 *           description: '철회 일시'
 *         ignoreDays:
 *           type: integer
 *           example: 7
 *           description: '무시 일수'
 *         creatorId:
 *           type: string
 *           example: '생성자 고유 식별자'
 *           description: '생성자 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-21T06:44:21.000Z'
 *           description: '생성 일시'
 *         updaterId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '수정자 ID'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-21T06:44:21.000Z'
 *           description: '수정 일시'
 *
 *     NoticeUpdateRequest:
 *       type: object
 *       required:
 *         - title
 *         - content
 *         - postAt
 *         - withdrawalAt
 *       properties:
 *         title:
 *           type: string
 *           example: '공지사항'
 *           description: '공지사항 제목'
 *         content:
 *           type: string
 *           example: '테스트'
 *           description: '공지사항 내용'
 *         postAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-21T23:00:00.000Z'
 *           description: '게시 일시'
 *         withdrawalAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-26T09:00:00.000Z'
 *           description: '철회 일시'
 *         ignoreDays:
 *           type: integer
 *           default: 0
 *           example: 0
 *           description: '무시 일수'
 *
 *     NoticeUpdateResponse:
 *       $ref: '#/components/schemas/NoticeCreateResponse'
 *
 *     NoticeStatusUpdateRequest:
 *       type: object
 *       required:
 *         - ids
 *         - status
 *       properties:
 *         ids:
 *           type: array
 *           items:
 *             type: string
 *           example: ['공지사항 고유 식별자1', '공지사항 고유 식별자2']
 *           description: '공지사항 ID 배열'
 *         status:
 *           type: string
 *           enum: [POST, WITHDRAWAL]
 *           example: 'POST'
 *           description: '공지사항 상태 (POST: 게시, WITHDRAWAL: 철회)'
 *
 *     NoticeStatusUpdateResponse:
 *       type: array
 *       items:
 *         $ref: '#/components/schemas/NoticeCreateResponse'
 *       description: '상태가 수정된 공지사항 목록'
 *
 *     NoticeDeleteRequest:
 *       type: object
 *       required:
 *         - ids
 *       properties:
 *         ids:
 *           type: array
 *           items:
 *             type: string
 *           example: ['공지사항 고유 식별자1', '공지사항 고유 식별자2']
 *           description: '공지사항 ID 배열'
 *
 *     NoticeDeleteResponse:
 *       type: object
 *       properties:
 *         count:
 *           type: integer
 *           example: 1
 *           description: '삭제된 공지사항 수'
 *
 *     NoticeDetailResponse:
 *       $ref: '#/components/schemas/NoticeItem'
 */
