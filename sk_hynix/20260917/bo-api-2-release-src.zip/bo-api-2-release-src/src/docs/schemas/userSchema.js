/**
 * @swagger
 * components:
 *   schemas:
 *     UserInfo:
 *       type: object
 *       properties:
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         domain:
 *           type: string
 *           example: 'timbel.net'
 *           description: '도메인'
 *         provider:
 *           type: string
 *           example: 'timblo'
 *           description: '인증 제공자'
 *         lastLogin:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: null
 *           description: '마지막 로그인 일시'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-10T02:49:17.047Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-10T02:49:17.047Z'
 *           description: '수정 일시'
 *
 *     UserCreateMemberInfo:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '회원 고유 식별자'
 *           description: '회원 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         role:
 *           type: string
 *           example: 'MEMBER'
 *           description: '회원 역할'
 *         menuRoleId:
 *           type: string
 *           example: '메뉴 역할 고유 식별자'
 *           description: '메뉴 역할 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-10T02:49:17.060Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-10T02:49:17.060Z'
 *           description: '수정 일시'
 *
 *     UserCreateResponse:
 *       type: object
 *       properties:
 *         user:
 *           $ref: '#/components/schemas/UserInfo'
 *           description: '생성된 사용자 정보'
 *         member:
 *           $ref: '#/components/schemas/UserCreateMemberInfo'
 *           description: '생성된 회원 정보'
 *
 *     UserPasswordUpdateResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/UserInfo'
 *         - type: object
 *           properties:
 *             password:
 *               type: string
 *               example: '$2b$15$XIXwUmsAeAmFHLyOrWucBOlcK67cGiXEaHpLHj1bPfzxYA3GS622S'
 *               description: '해시된 비밀번호'
 *
 *     UserDeleteRequest:
 *       type: object
 *       required:
 *         - pids
 *       properties:
 *         pids:
 *           type: array
 *           items:
 *             type: string
 *           example: ['사용자 고유 식별자1', '사용자 고유 식별자2']
 *           description: '사용자 PID 배열'
 *
 *     UserDeleteResponse:
 *       type: object
 *       properties:
 *         count:
 *           type: integer
 *           example: 1
 *           description: '삭제된 사용자 수'
 */
