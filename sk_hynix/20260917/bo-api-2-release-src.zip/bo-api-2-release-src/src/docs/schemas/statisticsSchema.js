/**
 * @swagger
 * components:
 *   schemas:
 *     MemberStatisticsItem:
 *       type: object
 *       properties:
 *         period:
 *           type: string
 *           example: '2025-01-15'
 *           description: '기간 레이블 (DAILY: YYYY-MM-DD, WEEKLY: YYYY-WNN, MONTHLY: YYYY-MM, YEARLY: YYYY)'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         workspaceName:
 *           type: string
 *           nullable: true
 *           example: '워크스페이스 이름'
 *           description: '워크스페이스 이름'
 *         memberId:
 *           type: string
 *           example: '멤버 고유 식별자'
 *           description: '멤버 ID'
 *         userName:
 *           type: string
 *           nullable: true
 *           example: '사용자 닉네임'
 *           description: '멤버 닉네임'
 *         email:
 *           type: string
 *           nullable: true
 *           example: '사용자 이메일'
 *           description: '멤버 이메일'
 *         totalContentCount:
 *           type: integer
 *           example: 10
 *           description: '전체 콘텐츠 수'
 *         totalSeconds:
 *           type: integer
 *           example: 3600
 *           description: '전체 초 (재생 시간)'
 *         mobileContentCount:
 *           type: integer
 *           example: 5
 *           description: '모바일 콘텐츠 수'
 *         mobileSeconds:
 *           type: integer
 *           example: 1800
 *           description: '모바일 초 (재생 시간)'
 *         transcribeDoneCount:
 *           type: integer
 *           example: 8
 *           description: '전사 완료 수'
 *         transcribeErrorCount:
 *           type: integer
 *           example: 1
 *           description: '전사 오류 수'
 *         transcribeOtherCount:
 *           type: integer
 *           example: 1
 *           description: '전사 기타 수'
 *         duration0_1Min:
 *           type: integer
 *           example: 2
 *           description: '0-1분 구간 콘텐츠 수'
 *         duration1_30Min:
 *           type: integer
 *           example: 5
 *           description: '1-30분 구간 콘텐츠 수'
 *         duration30_60Min:
 *           type: integer
 *           example: 2
 *           description: '30-60분 구간 콘텐츠 수'
 *         duration60_120Min:
 *           type: integer
 *           example: 1
 *           description: '60-120분 구간 콘텐츠 수'
 *         duration120_180Min:
 *           type: integer
 *           example: 0
 *           description: '120-180분 구간 콘텐츠 수'
 *         durationOver180Min:
 *           type: integer
 *           example: 0
 *           description: '180분 초과 구간 콘텐츠 수'
 *
 *     MemberStatisticsData:
 *       type: object
 *       properties:
 *         statistics:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/MemberStatisticsItem'
 *           description: '멤버별 통계 목록'
 *         total:
 *           type: integer
 *           example: 158
 *           description: '전체 통계 항목 수'
 *
 *     MemberStatisticsResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/MemberStatisticsData'
 *               description: '멤버별 통계 데이터'
 *
 *     WorkspaceStatisticsItem:
 *       type: object
 *       properties:
 *         period:
 *           type: string
 *           example: '2025-01-15'
 *           description: '기간 레이블 (DAILY: YYYY-MM-DD, WEEKLY: YYYY-WNN, MONTHLY: YYYY-MM, YEARLY: YYYY)'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         workspaceName:
 *           type: string
 *           nullable: true
 *           example: '워크스페이스 이름'
 *           description: '워크스페이스 이름'
 *         totalContentCount:
 *           type: integer
 *           example: 20
 *           description: '전체 콘텐츠 수'
 *         totalSeconds:
 *           type: integer
 *           example: 7200
 *           description: '전체 초 (재생 시간)'
 *         mobileContentCount:
 *           type: integer
 *           example: 10
 *           description: '모바일 콘텐츠 수'
 *         mobileSeconds:
 *           type: integer
 *           example: 3600
 *           description: '모바일 초 (재생 시간)'
 *         transcribeDoneCount:
 *           type: integer
 *           example: 15
 *           description: '전사 완료 수'
 *         transcribeErrorCount:
 *           type: integer
 *           example: 3
 *           description: '전사 오류 수'
 *         transcribeOtherCount:
 *           type: integer
 *           example: 2
 *           description: '전사 기타 수'
 *         duration0_1Min:
 *           type: integer
 *           example: 5
 *           description: '0-1분 구간 콘텐츠 수'
 *         duration1_30Min:
 *           type: integer
 *           example: 10
 *           description: '1-30분 구간 콘텐츠 수'
 *         duration30_60Min:
 *           type: integer
 *           example: 3
 *           description: '30-60분 구간 콘텐츠 수'
 *         duration60_120Min:
 *           type: integer
 *           example: 2
 *           description: '60-120분 구간 콘텐츠 수'
 *         duration120_180Min:
 *           type: integer
 *           example: 0
 *           description: '120-180분 구간 콘텐츠 수'
 *         durationOver180Min:
 *           type: integer
 *           example: 0
 *           description: '180분 초과 구간 콘텐츠 수'
 *
 *     WorkspaceStatisticsData:
 *       type: object
 *       properties:
 *         statistics:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/WorkspaceStatisticsItem'
 *           description: '워크스페이스별 통계 목록'
 *         total:
 *           type: integer
 *           example: 69
 *           description: '전체 통계 항목 수'
 *
 *     WorkspaceStatisticsResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/WorkspaceStatisticsData'
 *               description: '워크스페이스별 통계 데이터'
 */
