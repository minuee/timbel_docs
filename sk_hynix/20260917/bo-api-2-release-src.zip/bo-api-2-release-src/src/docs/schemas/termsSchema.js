/**
 * @swagger
 * components:
 *   schemas:
 *     TermsCategory:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '동의서 카테고리 고유 식별자'
 *           description: '동의서 카테고리 ID'
 *         name:
 *           type: string
 *           example: '개인정보'
 *           description: '동의서 카테고리 이름'
 *
 *     TermsCreatorOrUpdater:
 *       type: object
 *       nullable: true
 *       properties:
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         name:
 *           type: string
 *           example: '홍길동'
 *           description: '사용자 이름'
 *         nickName:
 *           type: string
 *           example: '닉네임'
 *           description: '사용자 닉네임'
 *         email:
 *           type: string
 *           example: 'user@example.com'
 *           description: '사용자 이메일'
 *         thumbnailUrl:
 *           type: string
 *           example: 'https://example.com/thumbnail.jpg'
 *           description: '사용자 썸네일 URL'
 *
 *     TermsItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '동의서 고유 식별자'
 *           description: '동의서 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         title:
 *           type: string
 *           example: '동의서 제목'
 *           description: '동의서 제목'
 *         version:
 *           type: string
 *           nullable: true
 *           example: '1.0'
 *           description: '동의서 버전'
 *         status:
 *           type: string
 *           enum: [DRAFT, PUBLISHED, ARCHIVED]
 *           example: 'DRAFT'
 *           description: '동의서 상태'
 *         isRequired:
 *           type: boolean
 *           example: true
 *           description: '필수 동의서 여부'
 *         publishedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '시행 일시'
 *         archivedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '보관 일시'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '수정 일시'
 *         category:
 *           $ref: '#/components/schemas/TermsCategory'
 *           description: '동의서 카테고리'
 *         creator:
 *           $ref: '#/components/schemas/TermsCreatorOrUpdater'
 *           nullable: true
 *           description: '생성자 정보'
 *         updater:
 *           $ref: '#/components/schemas/TermsCreatorOrUpdater'
 *           nullable: true
 *           description: '수정자 정보'
 *
 *     TermsDetail:
 *       allOf:
 *         - $ref: '#/components/schemas/TermsItem'
 *         - type: object
 *           properties:
 *             content:
 *               type: string
 *               example: '동의서 내용'
 *               description: '동의서 내용'
 *
 *     TermsListResponse:
 *       type: object
 *       properties:
 *         items:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/TermsItem'
 *           description: '동의서 목록'
 *         total:
 *           type: integer
 *           example: 10
 *           description: '전체 동의서 수'
 *         page:
 *           type: integer
 *           example: 1
 *           description: '현재 페이지'
 *         limit:
 *           type: integer
 *           example: 10
 *           description: '페이지당 항목 수'
 *         totalPages:
 *           type: integer
 *           example: 1
 *           description: '전체 페이지 수'
 *
 *     TermsDetailResponse:
 *       $ref: '#/components/schemas/TermsDetail'
 *
 *     TermsCreateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '동의서 고유 식별자'
 *           description: '동의서 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         title:
 *           type: string
 *           example: '동의서 제목'
 *           description: '동의서 제목'
 *         status:
 *           type: string
 *           enum: [DRAFT, PUBLISHED, ARCHIVED]
 *           example: 'DRAFT'
 *           description: '동의서 상태'
 *         category:
 *           $ref: '#/components/schemas/TermsCategory'
 *           description: '동의서 카테고리'
 *
 *     TermsUpdateResponse:
 *       $ref: '#/components/schemas/TermsItem'
 *
 *     TermsStatusUpdateResponse:
 *       $ref: '#/components/schemas/TermsItem'
 *
 *     AgreementWorkspace:
 *       type: object
 *       nullable: true
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: '워크스페이스 이름'
 *           description: '워크스페이스 이름'
 *
 *     AgreementTerms:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '동의서 고유 식별자'
 *           description: '동의서 ID'
 *         title:
 *           type: string
 *           example: '동의서 제목'
 *           description: '동의서 제목'
 *         version:
 *           type: string
 *           nullable: true
 *           example: '1.0'
 *           description: '동의서 버전'
 *         category:
 *           $ref: '#/components/schemas/TermsCategory'
 *           nullable: true
 *           description: '동의서 카테고리'
 *
 *     AgreementItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '동의서 고유 식별자'
 *           description: '동의서 ID'
 *         workspace:
 *           $ref: '#/components/schemas/AgreementWorkspace'
 *           nullable: true
 *           description: '워크스페이스 정보'
 *         status:
 *           type: string
 *           enum: [CONSENTED, DECLINED]
 *           example: 'CONSENTED'
 *           description: '동의 상태'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '제출 일시'
 *         userName:
 *           type: string
 *           example: '홍길동'
 *           description: '제출자 이름'
 *         email:
 *           type: string
 *           example: 'user@example.com'
 *           description: '제출자 이메일'
 *         ipAddress:
 *           type: string
 *           example: '192.168.1.1'
 *           description: '제출자 IP 주소'
 *         userAgent:
 *           type: string
 *           example: 'Mozilla/5.0...'
 *           description: '제출자 User Agent'
 *         terms:
 *           $ref: '#/components/schemas/AgreementTerms'
 *           description: '동의서 정보'
 *
 *     AgreementListResponse:
 *       type: object
 *       properties:
 *         items:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/AgreementItem'
 *           description: '동의서 목록'
 *         total:
 *           type: integer
 *           example: 10
 *           description: '전체 동의서 수'
 *         page:
 *           type: integer
 *           example: 1
 *           description: '현재 페이지'
 *         limit:
 *           type: integer
 *           example: 10
 *           description: '페이지당 항목 수'
 *
 *     TermsCategoryItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '동의서 카테고리 고유 식별자'
 *           description: '동의서 카테고리 ID'
 *         name:
 *           type: string
 *           example: '개인정보'
 *           description: '동의서 카테고리 이름'
 *         description:
 *           type: string
 *           example: '동의서 카테고리 설명'
 *           description: '동의서 카테고리 설명'
 *
 *     TermsCategoryListResponse:
 *       type: array
 *       items:
 *         $ref: '#/components/schemas/TermsCategoryItem'
 *       description: '사용 가능한 동의서 카테고리 목록'
 */
