/**
 * @swagger
 * components:
 *   schemas:
 *     RoleItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '역할 고유 식별자'
 *           description: '역할 ID'
 *         workspaceId:
 *           type: string
 *           nullable: true
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         adminType:
 *           type: string
 *           example: 'WORKSPACE'
 *           description: '관리자 타입'
 *         name:
 *           type: string
 *           example: 'WORKSPACE 권한'
 *           description: '역할 이름'
 *         description:
 *           type: string
 *           example: '권한 테스트입니다.'
 *           description: '역할 설명'
 *         creatorId:
 *           type: string
 *           nullable: true
 *           example: '생성자 고유 식별자'
 *           description: '생성자 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-30T08:29:06.738Z'
 *           description: '생성 일시'
 *         updaterId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '수정자 ID'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-30T08:29:06.738Z'
 *           description: '수정 일시'
 *
 *     RoleCreateResponse:
 *       $ref: '#/components/schemas/RoleItem'
 *
 *     RoleCreator:
 *       type: object
 *       properties:
 *         pid:
 *           type: string
 *           example: '생성자 고유 식별자'
 *           description: '생성자 PID'
 *         name:
 *           type: string
 *           example: ''
 *           description: '생성자 이름'
 *         nickName:
 *           type: string
 *           example: '심승종1'
 *           description: '생성자 닉네임'
 *
 *     RoleDetailResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '역할 고유 식별자'
 *           description: '역할 ID'
 *         workspace:
 *           $ref: '#/components/schemas/WorkspaceDetail'
 *         adminType:
 *           type: string
 *           example: 'SYSTEM'
 *           description: '관리자 타입'
 *         name:
 *           type: string
 *           example: '테스트 권한'
 *           description: '역할 이름'
 *         description:
 *           type: string
 *           example: '권한 테스트입니다.'
 *           description: '역할 설명'
 *         creator:
 *           $ref: '#/components/schemas/RoleCreator'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-30T06:57:36.889Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-30T06:57:36.889Z'
 *           description: '수정 일시'
 *         menus:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/MenuAuthority'
 *           description: '메뉴 권한 목록'
 *
 *     RoleListItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '역할 고유 식별자'
 *           description: '역할 ID'
 *         workspace:
 *           $ref: '#/components/schemas/WorkspaceDetail'
 *         adminType:
 *           type: string
 *           example: 'SYSTEM'
 *           description: '관리자 타입'
 *         name:
 *           type: string
 *           example: '테스트 권한123'
 *           description: '역할 이름'
 *         description:
 *           type: string
 *           example: '권한 테스트입니다221.'
 *           description: '역할 설명'
 *         creator:
 *           $ref: '#/components/schemas/RoleCreator'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-30T06:57:36.889Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-30T07:40:38.924Z'
 *           description: '수정 일시'
 *
 *     RoleListResponse:
 *       type: object
 *       properties:
 *         roles:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/RoleListItem'
 *           description: '역할 목록'
 *         total:
 *           type: integer
 *           example: 2
 *           description: '전체 역할 수'
 */
