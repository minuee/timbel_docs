/**
 * @swagger
 * components:
 *   schemas:
 *     TemplateCategory:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 카테고리 고유 식별자'
 *           description: '템플릿 카테고리 ID'
 *         name:
 *           type: string
 *           example: '템플릿 카테고리명'
 *           description: '템플릿 카테고리명'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T01:46:43.793Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T01:46:43.793Z'
 *           description: '수정 일시'
 *
 *     TemplateCategoryCreateRequest:
 *       type: object
 *       required:
 *         - name
 *       properties:
 *         name:
 *           type: string
 *           example: '템플릿 카테고리명'
 *           description: '템플릿 카테고리명'
 *
 *     TemplateCreateRequest:
 *       type: object
 *       required:
 *         - categoryId
 *         - inputType
 *         - key
 *         - name
 *         - version
 *       properties:
 *         categoryId:
 *           type: string
 *           example: '템플릿 카테고리 고유 식별자'
 *           description: '템플릿 카테고리 ID'
 *         inputType:
 *           type: string
 *           example: 'timbel_stt'
 *           description: '입력 타입'
 *         description:
 *           type: string
 *           example: '템플릿 설명'
 *           description: '템플릿 설명'
 *         key:
 *           type: string
 *           example: 'medical_consulting'
 *           description: '템플릿 키'
 *         name:
 *           type: string
 *           example: '의료 컨설팅'
 *           description: '템플릿 이름'
 *         preview:
 *           type: string
 *           example: '템플릿 미리보기 내용'
 *           description: '템플릿 미리보기'
 *         version:
 *           type: string
 *           example: '2025.10.6'
 *           description: '템플릿 버전'
 *
 *     TemplateCategoriesResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/TemplateCategory'
 *               description: '템플릿 카테고리 목록'
 *
 *     TemplateEditor:
 *       type: object
 *       properties:
 *         nickName:
 *           type: string
 *           example: 'jwpark1234'
 *           description: '편집자 닉네임'
 *         thumbnailUrl:
 *           type: string
 *           example: '프로필 이미지 URL'
 *           description: '편집자 프로필 이미지 URL'
 *
 *     TemplateItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 고유 식별자'
 *           description: '템플릿 ID'
 *         version:
 *           type: string
 *           example: '2025.10.6'
 *           description: '템플릿 버전'
 *         name:
 *           type: string
 *           example: '의료가 뭐인가요'
 *           description: '템플릿 이름'
 *         isUsed:
 *           type: string
 *           example: 'N'
 *           description: '사용 여부'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T06:33:58.007Z'
 *           description: '수정 일시'
 *         category:
 *           type: string
 *           example: '변경할 이름을 입력'
 *           description: '템플릿 카테고리'
 *         editor:
 *           $ref: '#/components/schemas/TemplateEditor'
 *
 *     TemplateListData:
 *       type: object
 *       properties:
 *         templates:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/TemplateItem'
 *           description: '템플릿 목록'
 *         _count:
 *           type: integer
 *           example: 2
 *           description: '템플릿 총 개수'
 *         currentPage:
 *           type: integer
 *           example: 1
 *           description: '현재 페이지 번호'
 *         totalPage:
 *           type: integer
 *           example: 1
 *           description: '전체 페이지 수'
 *
 *     TemplateListResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/TemplateListData'
 *
 *     TemplateVersionItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 고유 식별자'
 *           description: '템플릿 ID'
 *         version:
 *           type: string
 *           example: '2025.10.2'
 *           description: '템플릿 버전'
 *         description:
 *           type: string
 *           example: '의료 컨설팅 요약용 템플릿 입니다.'
 *           description: '템플릿 설명'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T05:16:34.070Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T05:16:34.070Z'
 *           description: '수정 일시'
 *         category:
 *           type: string
 *           example: 'asbb'
 *           description: '템플릿 카테고리'
 *         creator:
 *           $ref: '#/components/schemas/TemplateEditor'
 *         editor:
 *           $ref: '#/components/schemas/TemplateEditor'
 *
 *     TemplateDetailData:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 고유 식별자'
 *           description: '템플릿 ID'
 *         version:
 *           type: string
 *           example: '2025.10.1'
 *           description: '템플릿 버전'
 *         name:
 *           type: string
 *           example: '의료 컨설팅'
 *           description: '템플릿 이름'
 *         description:
 *           type: string
 *           example: '의료 컨설팅 요약용 템플릿 입니다.'
 *           description: '템플릿 설명'
 *         preview:
 *           type: string
 *           example: '템플릿 미리보기 내용'
 *           description: '템플릿 미리보기'
 *         options:
 *           type: object
 *           nullable: true
 *           example: null
 *           description: '템플릿 옵션'
 *         isUsed:
 *           type: string
 *           example: 'N'
 *           description: '사용 여부'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T05:16:35.428Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T05:16:35.428Z'
 *           description: '수정 일시'
 *         category:
 *           type: string
 *           example: 'asbb'
 *           description: '템플릿 카테고리'
 *         creator:
 *           $ref: '#/components/schemas/TemplateEditor'
 *         editor:
 *           $ref: '#/components/schemas/TemplateEditor'
 *         versions:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/TemplateVersionItem'
 *           description: '템플릿 버전 목록'
 *
 *     TemplateDetailResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/TemplateDetailData'
 *
 *     TemplateCategoryInfo:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 카테고리 고유 식별자'
 *           description: '템플릿 카테고리 ID'
 *         name:
 *           type: string
 *           example: '템플릿 카테고리명'
 *           description: '템플릿 카테고리명'
 *
 *     TemplateOptions:
 *       type: object
 *       properties:
 *         speaker:
 *           type: boolean
 *           example: false
 *           description: '화자 옵션 사용 여부'
 *         keyword:
 *           type: boolean
 *           example: false
 *           description: '키워드 옵션 사용 여부'
 *         summary:
 *           type: boolean
 *           example: false
 *           description: '요약 옵션 사용 여부'
 *
 *     TemplateCreateData:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 고유 식별자'
 *           description: '템플릿 ID'
 *         version:
 *           type: string
 *           example: '2025.10.6'
 *           description: '템플릿 버전'
 *         name:
 *           type: string
 *           example: '의료 컨설팅'
 *           description: '템플릿 이름'
 *         description:
 *           type: string
 *           example: '템플릿 설명'
 *           description: '템플릿 설명'
 *         preview:
 *           type: string
 *           example: '템플릿 미리보기 내용'
 *           description: '템플릿 미리보기'
 *         category:
 *           $ref: '#/components/schemas/TemplateCategoryInfo'
 *         options:
 *           $ref: '#/components/schemas/TemplateOptions'
 *         isUsed:
 *           type: string
 *           example: 'N'
 *           description: '사용 여부'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T06:13:39.569Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T06:13:39.569Z'
 *           description: '수정 일시'
 *         creator:
 *           $ref: '#/components/schemas/TemplateEditor'
 *         editor:
 *           $ref: '#/components/schemas/TemplateEditor'
 *
 *     TemplateCreateResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/TemplateCreateData'
 *
 *     TemplateUploadData:
 *       type: object
 *       properties:
 *         inputType:
 *           type: string
 *           example: 'timbel_stt'
 *           description: '입력 타입'
 *         description:
 *           type: string
 *           example: '일반 회의록 템플릿 입니다.'
 *           description: '템플릿 설명'
 *         key:
 *           type: string
 *           example: 'basic'
 *           description: '템플릿 키'
 *         name:
 *           type: string
 *           example: '일반 회의록'
 *           description: '템플릿 이름'
 *         preview:
 *           type: string
 *           example: '## 📑 운영형 회의록 (샘플)\n \n- 키워드: 사무실 정수기, 회의실 예약, 간식 비치\n\n### 주제\n\n- 사무실 정수기 교체 및 관리 방안 - [00:01:02 ~ 00:06:15]\n- 회의실 예약 시스템 개선 및 간식 비치 논의 - [00:07:20 ~ 00:12:40]\n\n### 구간별 요약\n\n**사무실 정수기 교체 및 관리 방안**\n- 기존 정수기에서 잦은 고장 발생, 필터 교체 주기 불규칙 문제 제기 [00:01:02]\n- 렌탈 업체 변경 여부 검토, 월 비용 증가 예상 [00:03:15]\n- 시설팀은 업체 견적 비교, 관리팀은 필터 교체 주기 체크 담당 [00:05:20]\n- [이슈] 교체 시기와 기존 계약 위약금 여부 확인 필요 [00:06:15]\n\n**회의실 예약 시스템 개선 및 간식 비치 논의**\n- 예약 중복 문제로 회의 지연 사례 발생 [00:07:20]\n- 캘린더와 연동된 예약 시스템 도입 검토 [00:08:40]\n- 직원 만족도 향상을 위해 스낵바에 간식 종류 확대(견과류·과일 등) 제안 [00:10:50]\n- [할일] 예약 시스템 개선안 조사 및 간식 구입 품목 리스트 작성 (담당자: 참석자 1, 완료예상일: 차주 월요일) [00:12:40]'
 *           description: '템플릿 미리보기'
 *         version:
 *           type: string
 *           example: '2025.10.2'
 *           description: '템플릿 버전'
 *
 *     TemplateUploadResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/TemplateUploadData'
 *
 *     TemplateUpdateRequest:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           example: '의료가 뭐인가요'
 *           description: '템플릿 이름'
 *         description:
 *           type: string
 *           example: '설명문을 수정합니다.'
 *           description: '템플릿 설명'
 *         categoryId:
 *           type: string
 *           example: '템플릿 카테고리 고유 식별자'
 *           description: '템플릿 카테고리 ID'
 *         options:
 *           $ref: '#/components/schemas/TemplateOptions'
 *
 *     TemplateUpdateData:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '템플릿 고유 식별자'
 *           description: '템플릿 ID'
 *         version:
 *           type: string
 *           example: '2025.10.6'
 *           description: '템플릿 버전'
 *         name:
 *           type: string
 *           example: '의료가 뭐인가요'
 *           description: '템플릿 이름'
 *         description:
 *           type: string
 *           example: '설명문을 수정합니다.'
 *           description: '템플릿 설명'
 *         preview:
 *           type: string
 *           example: '템플릿 미리보기 내용'
 *           description: '템플릿 미리보기'
 *         options:
 *           $ref: '#/components/schemas/TemplateOptions'
 *         isUsed:
 *           type: string
 *           example: 'Y'
 *           description: '사용 여부'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T06:13:39.569Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-03T06:33:55.002Z'
 *           description: '수정 일시'
 *         category:
 *           type: string
 *           example: 'asbb'
 *           description: '템플릿 카테고리'
 *         creator:
 *           $ref: '#/components/schemas/TemplateEditor'
 *         editor:
 *           $ref: '#/components/schemas/TemplateEditor'
 *
 *     TemplateUpdateResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/TemplateUpdateData'
 */
