/**
 * @swagger
 * components:
 *   schemas:
 *     PolicyCreateRequest:
 *       type: object
 *       required:
 *         - category
 *         - title
 *         - content
 *       properties:
 *         category:
 *           type: string
 *           enum: [TERMS, PRIVACY]
 *           example: 'TERMS'
 *           description: '약관 카테고리'
 *         title:
 *           type: string
 *           example: '약관 테스트'
 *           description: '약관 제목'
 *         content:
 *           type: string
 *           example: '테스트 약관입니다.'
 *           description: '약관 내용'
 *
 *     PolicyItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '약관 고유 식별자'
 *           description: '약관 ID'
 *         category:
 *           type: string
 *           enum: [TERMS, PRIVACY]
 *           example: 'TERMS'
 *           description: '약관 카테고리'
 *         status:
 *           type: string
 *           enum: [DRAFT, PUBLISHED, ARCHIVED]
 *           example: 'DRAFT'
 *           description: '약관 상태'
 *         title:
 *           type: string
 *           example: '약관 테스트'
 *           description: '약관 제목'
 *         version:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '약관 버전'
 *         content:
 *           type: string
 *           example: '테스트 약관입니다.'
 *           description: '약관 내용'
 *         publishedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: null
 *           description: '시행 일시'
 *         archivedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: null
 *           description: '보관 일시'
 *         creatorId:
 *           type: string
 *           example: '생성자 고유 식별자'
 *           description: '생성자 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-18T09:05:50.205Z'
 *           description: '생성 일시'
 *         updaterId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '수정자 ID'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-18T09:05:50.205Z'
 *           description: '수정 일시'
 *         creator:
 *           type: object
 *           nullable: true
 *           properties:
 *             pid:
 *               type: string
 *               example: '생성자 고유 식별자'
 *               description: '생성자 PID'
 *             nickName:
 *               type: string
 *               example: '사용자 닉네임'
 *               description: '생성자 닉네임'
 *             email:
 *               type: string
 *               example: 'user@example.com'
 *               description: '생성자 이메일'
 *           description: '생성자 정보'
 *         updater:
 *           type: object
 *           nullable: true
 *           properties:
 *             pid:
 *               type: string
 *               example: '수정자 고유 식별자'
 *               description: '수정자 PID'
 *             nickName:
 *               type: string
 *               example: '사용자 닉네임'
 *               description: '수정자 닉네임'
 *             email:
 *               type: string
 *               example: 'user@example.com'
 *               description: '수정자 이메일'
 *           description: '수정자 정보'
 *
 *     PolicyListResponse:
 *       type: object
 *       properties:
 *         policies:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/PolicyItem'
 *           description: '약관 목록'
 *         total:
 *           type: integer
 *           example: 97
 *           description: '전체 약관 수'
 *
 *     PolicyDetailResponse:
 *       $ref: '#/components/schemas/PolicyItem'
 *
 *     PolicyStatusUpdateRequest:
 *       type: object
 *       required:
 *         - status
 *       properties:
 *         status:
 *           type: string
 *           enum: [PUBLISHED, ARCHIVED]
 *           example: 'PUBLISHED'
 *           description: '약관 상태 (PUBLISHED: 시행, ARCHIVED: 보관)'
 *
 *     PolicyStatusUpdateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '약관 고유 식별자'
 *           description: '약관 ID'
 *         category:
 *           type: string
 *           enum: [TERMS, PRIVACY]
 *           example: 'TERMS'
 *           description: '약관 카테고리'
 *         status:
 *           type: string
 *           enum: [DRAFT, PUBLISHED, ARCHIVED]
 *           example: 'PUBLISHED'
 *           description: '약관 상태'
 *         title:
 *           type: string
 *           example: '약관 제목'
 *           description: '약관 제목'
 *         version:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '약관 버전'
 *         content:
 *           type: string
 *           example: '약관 내용'
 *           description: '약관 내용'
 *         publishedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-04-23T02:20:00.000Z'
 *           description: '시행 일시'
 *         archivedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-05-07T17:13:42.000Z'
 *           description: '보관 일시'
 *         creatorId:
 *           type: string
 *           example: '생성자 고유 식별자'
 *           description: '생성자 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-04-23T15:16:19.805Z'
 *           description: '생성 일시'
 *         updaterId:
 *           type: string
 *           nullable: true
 *           example: '수정자 고유 식별자'
 *           description: '수정자 ID'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-19T01:42:04.821Z'
 *           description: '수정 일시'
 *
 *     PolicyUpdateRequest:
 *       type: object
 *       required:
 *         - title
 *         - content
 *       properties:
 *         title:
 *           type: string
 *           example: '수정된 약관'
 *           description: '약관 제목'
 *         content:
 *           type: string
 *           example: '수정수정'
 *           description: '약관 내용'
 *
 *     PolicyUpdateResponse:
 *       $ref: '#/components/schemas/PolicyStatusUpdateResponse'
 *
 *     PolicyDeleteResponse:
 *       $ref: '#/components/schemas/PolicyStatusUpdateResponse'
 *
 *     PolicyCreateResponse:
 *       $ref: '#/components/schemas/PolicyItem'
 */
