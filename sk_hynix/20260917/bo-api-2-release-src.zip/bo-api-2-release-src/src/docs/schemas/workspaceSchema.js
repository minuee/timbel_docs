/**
 * @swagger
 * components:
 *   schemas:
 *     WorkspaceConfig:
 *       type: object
 *       properties:
 *         memberMaxCount:
 *           type: integer
 *           example: 100
 *           description: '최대 멤버 수'
 *
 *     UpdateWorkspaceMemberLimitRequest:
 *       type: object
 *       required:
 *         - memberMaxCount
 *       properties:
 *         memberMaxCount:
 *           type: integer
 *           minimum: 0
 *           example: 120
 *           description: '설정할 최대 구성원 수'
 *
 *     WorkspaceMemberLimitResponse:
 *       type: object
 *       properties:
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         memberMaxCount:
 *           type: integer
 *           example: 120
 *           description: '적용된 최대 구성원 수'
 *
 *     WorkspaceBasicInfo:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: 'alibizgroup'
 *           description: '워크스페이스 이름'
 *         domain:
 *           type: string
 *           example: 'example.com'
 *           description: '워크스페이스 도메인'
 *         description:
 *           type: string
 *           nullable: true
 *           example: '워크스페이스 설명'
 *           description: '워크스페이스 설명'
 *         thumbnailUrl:
 *           type: string
 *           nullable: true
 *           example: 'https://example.com/thumbnail.jpg'
 *           description: '워크스페이스 썸네일 URL'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '생성 일시'
 *         ownerId:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '소유자 ID'
 *         config:
 *           $ref: '#/components/schemas/WorkspaceConfig'
 *
 *     WorkspaceFeatureSettingItem:
 *       type: object
 *       properties:
 *         key:
 *           type: string
 *           example: 'global_page_title'
 *           description: '기능 설정 키'
 *         name:
 *           type: string
 *           example: '브라우저 제목바 제목'
 *           description: '기능 설정 이름'
 *         description:
 *           type: string
 *           example: '브라우저 탭 제목바에 표시되는 제목을 설정합니다.'
 *           description: '기능 설정 설명'
 *         value:
 *           oneOf:
 *             - type: string
 *             - type: boolean
 *             - type: number
 *           example: 'AI 회의록'
 *           description: '기능 설정 값'
 *         type:
 *           type: string
 *           example: 'STRING'
 *           description: '값 타입'
 *         uiType:
 *           type: string
 *           example: 'TEXT_INPUT'
 *           description: 'UI 타입'
 *         group:
 *           type: string
 *           example: 'GENERAL'
 *           description: '설정 그룹'
 *         items:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/WorkspaceFeatureSettingItem'
 *           description: '자식 설정 항목 목록'
 *
 *     WorkspaceFeatureSettings:
 *       type: object
 *       description: '기능 설정 계층 구조 (그룹별로 구성)'
 *       additionalProperties:
 *         type: object
 *         additionalProperties:
 *           oneOf:
 *             - $ref: '#/components/schemas/WorkspaceFeatureSettingItem'
 *             - type: object
 *               additionalProperties:
 *                 $ref: '#/components/schemas/WorkspaceFeatureSettingItem'
 *
 *     WorkspaceSimpleSettings:
 *       type: object
 *       description: '기능 설정 평면 구조 (키-값 쌍)'
 *       additionalProperties:
 *         oneOf:
 *           - type: string
 *           - type: boolean
 *           - type: number
 *       example:
 *         global_page_title: 'AI 회의록'
 *         enforce_agreement: false
 *         upload_thumbnail: true
 *
 *     MyWorkspaceInfoResponse:
 *       type: object
 *       properties:
 *         role:
 *           type: string
 *           example: 'OWNER'
 *           description: '멤버 역할'
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: 'alibizgroup'
 *           description: '워크스페이스 이름'
 *         domain:
 *           type: string
 *           example: 'example.com'
 *           description: '워크스페이스 도메인'
 *         description:
 *           type: string
 *           nullable: true
 *           example: '워크스페이스 설명'
 *           description: '워크스페이스 설명'
 *         thumbnailUrl:
 *           type: string
 *           nullable: true
 *           example: 'https://example.com/thumbnail.jpg'
 *           description: '워크스페이스 썸네일 URL'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '생성 일시'
 *         ownerId:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '소유자 ID'
 *         config:
 *           $ref: '#/components/schemas/WorkspaceConfig'
 *
 *     WorkspaceFeatureSettingsResponse:
 *       type: object
 *       properties:
 *         settings:
 *           $ref: '#/components/schemas/WorkspaceFeatureSettings'
 *           description: '기능 설정 계층 구조'
 *         simpleSettings:
 *           $ref: '#/components/schemas/WorkspaceSimpleSettings'
 *           description: '기능 설정 평면 구조'
 *
 *     WorkspaceFeatureSettingUpdateRequest:
 *       type: object
 *       required:
 *         - key
 *         - value
 *       properties:
 *         key:
 *           type: string
 *           example: 'global_page_title'
 *           description: '기능 설정 키'
 *         value:
 *           oneOf:
 *             - type: string
 *               example: 'AI 회의록'
 *             - type: boolean
 *               example: true
 *             - type: number
 *               example: 180
 *           description: '설정할 값'
 *
 *     LicenseInfo:
 *       type: object
 *       properties:
 *         isFileWatching:
 *           type: boolean
 *           example: true
 *           description: '라이선스 파일 모니터링 활성화 여부'
 *         verifiedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '라이선스 검증 일시'
 *         seats:
 *           type: integer
 *           example: 100
 *           description: '총 라이선스 시트 수 (-1은 무제한)'
 *         usingSeats:
 *           type: integer
 *           example: 45
 *           description: '사용 중인 라이선스 시트 수'
 *         leftSeats:
 *           type: integer
 *           example: 55
 *           description: '남은 라이선스 시트 수 (-1은 무제한)'
 *
 *     LicenseUploadResponse:
 *       type: object
 *       properties:
 *         seats:
 *           type: integer
 *           example: 100
 *           description: '총 라이선스 시트 수 (-1은 무제한)'
 *         verifiedAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '라이선스 검증 일시'
 *
 *     WorkspaceLogoUploadResponse:
 *       type: object
 *       properties:
 *         thumbnailUrl:
 *           type: string
 *           example: 'https://example.com/thumbnail.jpg'
 *           description: '업로드된 로고 URL'
 *
 *     WorkspaceLogoDeleteResponse:
 *       type: object
 *       description: '빈 객체 (204 No Content)'
 *
 *     WorkspaceCreateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: '테스트'
 *           description: '워크스페이스 이름'
 *         thumbnailUrl:
 *           type: string
 *           example: ''
 *           description: '워크스페이스 썸네일 URL'
 *         domain:
 *           type: string
 *           example: 'test4.test.com'
 *           description: '워크스페이스 도메인'
 *         description:
 *           type: string
 *           example: ''
 *           description: '워크스페이스 설명'
 *         ownerId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '소유자 ID'
 *         inviteCode:
 *           type: string
 *           example: '88c295'
 *           description: '초대 코드'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-10T06:52:10.393Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-10T06:52:10.393Z'
 *           description: '수정 일시'
 *
 *     WorkspaceOwnerProfile:
 *       type: object
 *       properties:
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         empno:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '사원번호'
 *         companyCode:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '회사 코드'
 *         name:
 *           type: string
 *           example: ''
 *           description: '사용자 이름'
 *         nickName:
 *           type: string
 *           example: 'sefek86255@ckuer.com'
 *           description: '사용자 닉네임'
 *         email:
 *           type: string
 *           example: 'sefek86255@ckuer.com'
 *           description: '사용자 이메일'
 *         thumbnailUrl:
 *           type: string
 *           example: ''
 *           description: '사용자 썸네일 URL'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2024-12-13T00:52:51.998Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2024-12-13T00:52:51.998Z'
 *           description: '수정 일시'
 *
 *     WorkspaceOwner:
 *       type: object
 *       properties:
 *         profile:
 *           $ref: '#/components/schemas/WorkspaceOwnerProfile'
 *           description: '소유자 프로필 정보'
 *
 *     WorkspaceListItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: 'ckuer'
 *           description: '워크스페이스 이름'
 *         thumbnailUrl:
 *           type: string
 *           nullable: true
 *           example: ''
 *           description: '워크스페이스 썸네일 URL'
 *         domain:
 *           type: string
 *           example: 'ckuer.com'
 *           description: '워크스페이스 도메인'
 *         description:
 *           type: string
 *           example: ''
 *           description: '워크스페이스 설명'
 *         owner:
 *           $ref: '#/components/schemas/WorkspaceOwner'
 *           description: '소유자 정보'
 *         config:
 *           $ref: '#/components/schemas/WorkspaceConfig'
 *           description: '워크스페이스 설정'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2024-12-13T00:52:52.306Z'
 *           description: '생성 일시'
 *         adminCount:
 *           type: integer
 *           example: 1
 *           description: '관리자 수'
 *         memberCount:
 *           type: integer
 *           example: 0
 *           description: '일반 멤버 수'
 *         totalCount:
 *           type: integer
 *           example: 1
 *           description: '전체 멤버 수'
 *
 *     WorkspaceListResponse:
 *       type: object
 *       properties:
 *         workspaceCount:
 *           type: integer
 *           example: 15
 *           description: '전체 워크스페이스 수'
 *         workspaces:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/WorkspaceListItem'
 *           description: '워크스페이스 목록'
 *
 *     WorkspacePolicy:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '워크스페이스 정책 고유 식별자'
 *           description: '정책 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         policyType:
 *           type: string
 *           enum: [ALL, SEGMENT, META, SUMMARY, FILE, NOTE]
 *           example: 'ALL'
 *           description: '정책 타입'
 *         value:
 *           type: string
 *           example: '-1'
 *           description: '정책 값 (-1은 무제한)'
 *         unit:
 *           type: string
 *           enum: [DAYS, HOURS]
 *           example: 'DAYS'
 *           description: '단위'
 *         description:
 *           type: string
 *           nullable: true
 *           example: '콘텐츠 보존 기간 설정'
 *           description: '정책 설명'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-01-07T07:12:03.034Z'
 *           description: '수정 일시'
 *
 *     WorkspacePolicyRequest:
 *       type: object
 *       required:
 *         - policyType
 *         - value
 *       properties:
 *         policyType:
 *           type: string
 *           enum: [ALL, SEGMENT, META, SUMMARY, FILE, NOTE]
 *           example: 'ALL'
 *           description: '정책 타입'
 *         value:
 *           type: string
 *           example: '-1'
 *           description: '정책 값 (-1은 무제한, -1 이상의 정수값이어야 함)'
 *           pattern: '^-?[0-9]+$'
 *           minimum: -1
 *         unit:
 *           type: string
 *           enum: [DAYS, HOURS]
 *           default: DAYS
 *           example: 'DAYS'
 *           description: '단위 (DAYS 또는 HOURS 중 하나)'
 *         description:
 *           type: string
 *           nullable: true
 *           example: '콘텐츠 보존 기간 설정'
 *           description: '정책 설명'
 *
 *     ExpirationPolicyOption:
 *       type: object
 *       properties:
 *         value:
 *           type: string
 *           nullable: true
 *           example: '-1'
 *           description: '옵션 값 (null인 경우 직접 입력)'
 *         unit:
 *           type: string
 *           nullable: true
 *           enum: [DAYS, HOURS]
 *           example: 'DAYS'
 *           description: '단위 (null인 경우 직접 입력)'
 *         label:
 *           type: string
 *           example: '영구'
 *           description: '옵션 라벨'
 *         unitOptions:
 *           type: array
 *           nullable: true
 *           items:
 *             type: string
 *             enum: [DAYS, HOURS]
 *           example: [DAYS, HOURS]
 *           description: '직접 입력 시 선택 가능한 단위 옵션'
 *
 *     ExpirationPolicyItem:
 *       type: object
 *       properties:
 *         key:
 *           type: string
 *           enum: [FILE, SEGMENT]
 *           example: 'FILE'
 *           description: '정책 키'
 *         policyType:
 *           type: string
 *           nullable: true
 *           enum: [FILE, SEGMENT]
 *           example: 'FILE'
 *           description: '정책 타입 (DB에 저장된 정책이 있으면 값, 없으면 null)'
 *         name:
 *           type: string
 *           example: '원본 파일 보존 기간'
 *           description: '정책 이름'
 *         description:
 *           type: string
 *           example: '업로드된 미디어 원본 파일의 보존 기간을 설정합니다.'
 *           description: '정책 설명'
 *         valueType:
 *           type: string
 *           example: 'STRING'
 *           description: '값 타입'
 *         uiType:
 *           type: string
 *           example: 'SELECT'
 *           description: 'UI 타입'
 *         options:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ExpirationPolicyOption'
 *           description: '선택 가능한 옵션 목록'
 *         value:
 *           type: string
 *           example: '-1'
 *           description: '정책 값 (DB에 저장된 정책이 있으면 값, 없으면 기본값)'
 *         unit:
 *           type: string
 *           enum: [DAYS, HOURS]
 *           example: 'DAYS'
 *           description: '단위 (DB에 저장된 정책이 있으면 값, 없으면 DAYS)'
 *
 *     ExpirationPolicyResponse:
 *       type: array
 *       items:
 *         $ref: '#/components/schemas/ExpirationPolicyItem'
 *       description: '콘텐츠 보존 정책 목록'
 *
 *     ExpirationPolicyUpdateRequest:
 *       type: object
 *       required:
 *         - key
 *         - value
 *       properties:
 *         key:
 *           type: string
 *           enum: [FILE, SEGMENT]
 *           example: 'FILE'
 *           description: '정책 키'
 *         value:
 *           type: string
 *           example: '30'
 *           description: '정책 값 (-1 이상 9999 이하의 정수값)'
 *           pattern: '^-?[0-9]+$'
 *           minimum: -1
 *           maximum: 9999
 *         unit:
 *           type: string
 *           enum: [DAYS, HOURS]
 *           example: 'DAYS'
 *           description: '단위 (DAYS 또는 HOURS 중 하나)'
 *
 *     ExpirationPolicyCreateResponse:
 *       type: object
 *       properties:
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         policyType:
 *           type: string
 *           enum: [ALL, SEGMENT, META, SUMMARY, FILE, NOTE]
 *           example: 'FILE'
 *           description: '정책 타입'
 *         value:
 *           type: string
 *           example: '-1'
 *           description: '정책 값'
 *         unit:
 *           type: string
 *           enum: [DAYS, HOURS]
 *           example: 'DAYS'
 *           description: '단위'
 *
 *     WorkspaceDeleteResponse:
 *       $ref: '#/components/schemas/WorkspaceCreateResponse'
 */
