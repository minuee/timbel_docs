/**
 * @swagger
 * components:
 *   schemas:
 *     MenuItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '메뉴 고유 식별자'
 *           description: '메뉴 ID'
 *         group:
 *           type: string
 *           example: 'WORKSPACE'
 *           description: '메뉴 그룹'
 *         code:
 *           type: string
 *           example: 'W400'
 *           description: '메뉴 코드'
 *         workspaceId:
 *           type: string
 *           nullable: true
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: '사용자 관리'
 *           description: '메뉴 이름'
 *         urlPath:
 *           type: string
 *           example: '/user'
 *           description: '메뉴 URL 경로'
 *         isUsed:
 *           type: boolean
 *           example: true
 *           description: '사용 여부'
 *         creatorId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '생성자 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-29T08:05:31.173Z'
 *           description: '생성 일시'
 *         updaterId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '수정자 ID'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-29T08:05:31.173Z'
 *           description: '수정 일시'
 *
 *     MenuListResponse:
 *       type: array
 *       items:
 *         $ref: '#/components/schemas/MenuItem'
 *
 *     MenuCreateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '메뉴 고유 식별자'
 *           description: '메뉴 ID'
 *         group:
 *           type: string
 *           example: 'SYSTEM_ADDON'
 *           description: '메뉴 그룹'
 *         code:
 *           type: string
 *           example: '메뉴 코드 고유 식별자'
 *           description: '메뉴 코드'
 *         workspaceId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '워크스페이스 ID'
 *         name:
 *           type: string
 *           example: '서킷브레이커2'
 *           description: '메뉴 이름'
 *         urlPath:
 *           type: string
 *           example: '/circuit/breaker2'
 *           description: '메뉴 URL 경로'
 *         isUsed:
 *           type: boolean
 *           example: true
 *           description: '사용 여부'
 *         creatorId:
 *           type: string
 *           example: '생성자 고유 식별자'
 *           description: '생성자 ID'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-28T08:20:42.328Z'
 *           description: '생성 일시'
 *         updaterId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '수정자 ID'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-10-28T08:20:42.328Z'
 *           description: '수정 일시'
 */
