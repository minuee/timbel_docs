/**
 * @swagger
 * components:
 *   schemas:
 *     # 기본 HTTP 에러 (4xx, 5xx)
 *     BadRequestError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "Bad Request"
 *         errorCode:
 *           type: string
 *           example: "E0400"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         badRequest:
 *           summary: 잘못된 요청
 *           value:
 *             httpCode: 400
 *             message: "Bad Request"
 *             errorCode: "E0400"
 *             result: {}
 *
 *     UnauthorizedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "Unauthorized"
 *         errorCode:
 *           type: string
 *           example: "E0401"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         unauthorized:
 *           summary: 인증 실패
 *           value:
 *             httpCode: 401
 *             message: "Unauthorized"
 *             errorCode: "E0401"
 *             result: {}
 *
 *     ForbiddenError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 403
 *         message:
 *           type: string
 *           example: "Forbidden"
 *         errorCode:
 *           type: string
 *           example: "E0403"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         forbidden:
 *           summary: 권한 없음
 *           value:
 *             httpCode: 403
 *             message: "Forbidden"
 *             errorCode: "E0403"
 *             result: {}
 *
 *     NotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "Not Found"
 *         errorCode:
 *           type: string
 *           example: "E0404"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         notFound:
 *           summary: 리소스를 찾을 수 없음
 *           value:
 *             httpCode: 404
 *             message: "Not Found"
 *             errorCode: "E0404"
 *             result: {}
 *
 *     MethodNotAllowedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 405
 *         message:
 *           type: string
 *           example: "Method Not Allowed"
 *         errorCode:
 *           type: string
 *           example: "E0405"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     NotAcceptableError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 406
 *         message:
 *           type: string
 *           example: "Not Acceptable"
 *         errorCode:
 *           type: string
 *           example: "E0406"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     RequestTimeoutError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 408
 *         message:
 *           type: string
 *           example: "Request Timeout"
 *         errorCode:
 *           type: string
 *           example: "E0408"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     URITooLongError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 414
 *         message:
 *           type: string
 *           example: "URI Too Long"
 *         errorCode:
 *           type: string
 *           example: "E0414"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     UnsupportedMediaTypeError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 415
 *         message:
 *           type: string
 *           example: "Unsupported Media Type"
 *         errorCode:
 *           type: string
 *           example: "E0415"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     UnprocessableContentError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 422
 *         message:
 *           type: string
 *           example: "Unprocessable Content"
 *         errorCode:
 *           type: string
 *           example: "E0422"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     TooManyRequestsError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 429
 *         message:
 *           type: string
 *           example: "Too Many Requests"
 *         errorCode:
 *           type: string
 *           example: "E0429"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *
 *     InternalServerError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 500
 *         message:
 *           type: string
 *           example: "Internal Server Error"
 *         errorCode:
 *           type: string
 *           example: "E0500"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         internalServerError:
 *           summary: 서버 내부 오류
 *           value:
 *             httpCode: 500
 *             message: "Internal Server Error"
 *             errorCode: "E0500"
 *             result: {}
 *
 *     # 공통 에러 (E1xxx)
 *     CommonMissingRequiredParameterError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "필수 파라미터가 부족합니다."
 *         errorCode:
 *           type: string
 *           example: "E1000"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         missingParameter:
 *           summary: 필수 파라미터 누락
 *           value:
 *             httpCode: 400
 *             message: "필수 파라미터가 부족합니다."
 *             errorCode: "E1000"
 *             result: {}
 *
 *     CommonViewerHigherPermissionRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "뷰어 이상의 권한이 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E1001"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         viewerPermissionRequired:
 *           summary: 뷰어 이상 권한 필요
 *           value:
 *             httpCode: 401
 *             message: "뷰어 이상의 권한이 필요합니다."
 *             errorCode: "E1001"
 *             result: {}
 *
 *     CommonEditorHigherPermissionRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "편집자 이상의 권한이 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E1002"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         editorPermissionRequired:
 *           summary: 편집자 이상 권한 필요
 *           value:
 *             httpCode: 401
 *             message: "편집자 이상의 권한이 필요합니다."
 *             errorCode: "E1002"
 *             result: {}
 *
 *     CommonMenuPermissionError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 403
 *         message:
 *           type: string
 *           example: "메뉴 권한이 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1003"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         menuPermissionError:
 *           summary: 메뉴 권한 없음
 *           value:
 *             httpCode: 403
 *             message: "메뉴 권한이 없습니다."
 *             errorCode: "BE1003"
 *             result: {}
 *
 *     CommonOwnerPermissionRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "소유자 권한이 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E1003"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         ownerPermissionRequired:
 *           summary: 소유자 권한 필요
 *           value:
 *             httpCode: 401
 *             message: "소유자 권한이 필요합니다."
 *             errorCode: "E1003"
 *             result: {}
 *
 *     CommonInvalidFilterError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "정의되지 않은 필터입니다."
 *         errorCode:
 *           type: string
 *           example: "BE1008"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         invalidFilter:
 *           summary: 정의되지 않은 필터
 *           value:
 *             httpCode: 400
 *             message: "정의되지 않은 필터입니다."
 *             errorCode: "BE1008"
 *             result: {}
 *
 *     CommonInvalidSortOrderError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "정의되지 않은 정렬 기준입니다."
 *         errorCode:
 *           type: string
 *           example: "BE1009"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         invalidSortOrder:
 *           summary: 정의되지 않은 정렬 기준
 *           value:
 *             httpCode: 400
 *             message: "정의되지 않은 정렬 기준입니다."
 *             errorCode: "BE1009"
 *             result: {}
 *
 *     CommonInvalidDateError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "오늘을 포함한 지난 날짜는 사용할 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1017"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         invalidDate:
 *           summary: 잘못된 날짜
 *           value:
 *             httpCode: 400
 *             message: "오늘을 포함한 지난 날짜는 사용할 수 없습니다."
 *             errorCode: "BE1017"
 *             result: {}
 *
 *     CommonGuestPermissionNotAllowedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "게스트 권한으로 할 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E1004"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         guestPermissionNotAllowed:
 *           summary: 게스트 권한 불가
 *           value:
 *             httpCode: 401
 *             message: "게스트 권한으로 할 수 없습니다."
 *             errorCode: "E1004"
 *             result: {}
 *
 *     CommonDownloadHigherPermissionRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "다운로드 이상의 권한이 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E1005"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         downloadPermissionRequired:
 *           summary: 다운로드 이상 권한 필요
 *           value:
 *             httpCode: 401
 *             message: "다운로드 이상의 권한이 필요합니다."
 *             errorCode: "E1005"
 *             result: {}
 *
 *     CommonOwnerHigherPermissionRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "소유자 이상의 권한이 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E1006"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         ownerHigherPermissionRequired:
 *           summary: 소유자 이상 권한 필요
 *           value:
 *             httpCode: 401
 *             message: "소유자 이상의 권한이 필요합니다."
 *             errorCode: "E1006"
 *             result: {}
 *
 *     CommonAdminHigherPermissionRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "관리자 권한이 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E1007"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         adminPermissionRequired:
 *           summary: 관리자 권한 필요
 *           value:
 *             httpCode: 401
 *             message: "관리자 권한이 필요합니다."
 *             errorCode: "E1007"
 *             result: {}
 *
 *     # 워크스페이스 에러 (E2xxx)
 *
 *     # 메뉴 에러 (E12xx)
 *     MenuAlreadyExistsError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 409
 *         message:
 *           type: string
 *           example: "이미 존재하는 메뉴입니다."
 *         errorCode:
 *           type: string
 *           example: "BE1200"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         menuAlreadyExists:
 *           summary: 메뉴 중복
 *           value:
 *             httpCode: 409
 *             message: "이미 존재하는 메뉴입니다."
 *             errorCode: "BE1200"
 *             result: {}
 *
 *     MenuGroupUndefinedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "정의되지 않은 그룹입니다."
 *         errorCode:
 *           type: string
 *           example: "BE1201"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         menuGroupUndefined:
 *           summary: 정의되지 않은 그룹
 *           value:
 *             httpCode: 400
 *             message: "정의되지 않은 그룹입니다."
 *             errorCode: "BE1201"
 *             result: {}
 *
 *     MenuGroupNotAllowedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "허용되지 않은 그룹입니다."
 *         errorCode:
 *           type: string
 *           example: "BE1202"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         menuGroupNotAllowed:
 *           summary: 허용되지 않은 그룹
 *           value:
 *             httpCode: 400
 *             message: "허용되지 않은 그룹입니다."
 *             errorCode: "BE1202"
 *             result: {}
 *
 *     MenuNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "메뉴를 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1203"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         menuNotFound:
 *           summary: 메뉴 없음
 *           value:
 *             httpCode: 404
 *             message: "메뉴를 찾을 수 없습니다."
 *             errorCode: "BE1203"
 *             result: {}
 *
 *     # 회원 에러 (E3xxx)
 *     MemberInfoNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 401
 *         message:
 *           type: string
 *           example: "회원 정보가 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1301"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         memberInfoNotFound:
 *           summary: 회원 정보 없음
 *           value:
 *             httpCode: 401
 *             message: "회원 정보가 없습니다."
 *             errorCode: "BE1301"
 *             result: {}
 *
 *     MemberNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "회원을 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1304"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         memberNotFound:
 *           summary: 회원 없음
 *           value:
 *             httpCode: 404
 *             message: "회원을 찾을 수 없습니다."
 *             errorCode: "BE1304"
 *             result: {}
 *
 *     # 역할 에러 (E14xx)
 *     RoleRestrictedMenuGroupError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "워크스페이스 관리자 유형은 SYSTEM 또는 SYSTEM_ADDON 그룹의 메뉴를 가질 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1402"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         restrictedMenuGroup:
 *           summary: 워크스페이스 관리자 유형의 제한된 메뉴 그룹
 *           value:
 *             httpCode: 400
 *             message: "워크스페이스 관리자 유형은 SYSTEM 또는 SYSTEM_ADDON 그룹의 메뉴를 가질 수 없습니다."
 *             errorCode: "BE1402"
 *             result: {}
 *
 *     RoleNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "역할을 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1404"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         roleNotFound:
 *           summary: 역할 없음
 *           value:
 *             httpCode: 404
 *             message: "역할을 찾을 수 없습니다."
 *             errorCode: "BE1404"
 *             result: {}
 *
 *     # 사용자 에러 (E15xx)
 *     MemberRoleNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "회원의 역할을 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "BE1303"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         memberRoleNotFound:
 *           summary: 회원 역할 없음
 *           value:
 *             httpCode: 404
 *             message: "회원의 역할을 찾을 수 없습니다."
 *             errorCode: "BE1303"
 *             result: {}
 *
 *     # 공지사항 에러 (E4xxx)
 *     NoticeLevelUndefinedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "정의되지 않은 레벨입니다."
 *         errorCode:
 *           type: string
 *           example: "E4300"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         noticeLevelUndefined:
 *           summary: 잘못된 noticeLevel 값
 *           value:
 *             httpCode: 400
 *             message: "정의되지 않은 레벨입니다."
 *             errorCode: "E4300"
 *             result: {}
 *
 *     NoticeStartEndDateError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "시작일이 종료일보다 이후일 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E4301"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         startEndDateError:
 *           summary: 시작일/종료일 오류
 *           value:
 *             httpCode: 400
 *             message: "시작일이 종료일보다 이후일 수 없습니다."
 *             errorCode: "E4301"
 *             result: {}
 *
 *     NoticeWorkspaceAccessPermissionError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 403
 *         message:
 *           type: string
 *           example: "해당 워크스페이스에 접근 권한이 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E4302"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         workspaceAccessPermissionError:
 *           summary: 워크스페이스 접근 권한 없음
 *           value:
 *             httpCode: 403
 *             message: "해당 워크스페이스에 접근 권한이 없습니다."
 *             errorCode: "E4302"
 *             result: {}
 *
 *     NoticeSystemAccessPermissionError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 403
 *         message:
 *           type: string
 *           example: "시스템 공지사항 접근 권한이 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E4303"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         systemAccessPermissionError:
 *           summary: 시스템 공지사항 접근 권한 없음
 *           value:
 *             httpCode: 403
 *             message: "시스템 공지사항 접근 권한이 없습니다."
 *             errorCode: "E4303"
 *             result: {}
 *
 *     NoticeNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "공지사항을 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E4304"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         noticeNotFound:
 *           summary: 공지사항 없음
 *           value:
 *             httpCode: 404
 *             message: "공지사항을 찾을 수 없습니다."
 *             errorCode: "E4304"
 *             result: {}
 *
 *     # 템플릿 에러 (E5xxx)
 *     TemplateUploadFailedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 500
 *         message:
 *           type: string
 *           example: "템플릿 업로드에 실패했습니다."
 *         errorCode:
 *           type: string
 *           example: "E5400"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         templateUploadFailed:
 *           summary: 템플릿 업로드 실패
 *           value:
 *             httpCode: 500
 *             message: "템플릿 업로드에 실패했습니다."
 *             errorCode: "E5400"
 *             result: {}
 *
 *     TemplateCategoryAlreadyExistsError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "이미 존재하는 카테고리입니다."
 *         errorCode:
 *           type: string
 *           example: "E5401"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         categoryAlreadyExists:
 *           summary: 카테고리 중복
 *           value:
 *             httpCode: 400
 *             message: "이미 존재하는 카테고리입니다."
 *             errorCode: "E5401"
 *             result: {}
 *
 *     TemplateCategoryCreateFailedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "카테고리 생성에 실패했습니다."
 *         errorCode:
 *           type: string
 *           example: "E5402"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         categoryCreateFailed:
 *           summary: 카테고리 생성 실패
 *           value:
 *             httpCode: 400
 *             message: "카테고리 생성에 실패했습니다."
 *             errorCode: "E5402"
 *             result: {}
 *
 *     TemplateCategoryIdRequiredError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "카테고리 ID가 필요합니다."
 *         errorCode:
 *           type: string
 *           example: "E5403"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         categoryIdRequired:
 *           summary: 카테고리 ID 필요
 *           value:
 *             httpCode: 400
 *             message: "카테고리 ID가 필요합니다."
 *             errorCode: "E5403"
 *             result: {}
 *
 *     TemplateCategoryNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "카테고리를 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E5404"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         categoryNotFound:
 *           summary: 카테고리 없음
 *           value:
 *             httpCode: 404
 *             message: "카테고리를 찾을 수 없습니다."
 *             errorCode: "E5404"
 *             result: {}
 *
 *     TemplateCategoryUpdateFailedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "카테고리 수정에 실패했습니다."
 *         errorCode:
 *           type: string
 *           example: "E5405"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         categoryUpdateFailed:
 *           summary: 카테고리 수정 실패
 *           value:
 *             httpCode: 400
 *             message: "카테고리 수정에 실패했습니다."
 *             errorCode: "E5405"
 *             result: {}
 *
 *     TemplateCategoryNameNotChangedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "카테고리 이름이 변경되지 않았습니다."
 *         errorCode:
 *           type: string
 *           example: "E5406"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         categoryNameNotChanged:
 *           summary: 카테고리 이름 미변경
 *           value:
 *             httpCode: 400
 *             message: "카테고리 이름이 변경되지 않았습니다."
 *             errorCode: "E5406"
 *             result: {}
 *
 *     TemplateVersionAlreadyExistsError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "동일한 버전의 템플릿이 존재합니다."
 *         errorCode:
 *           type: string
 *           example: "E5407"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         templateVersionExists:
 *           summary: 템플릿 버전 중복
 *           value:
 *             httpCode: 400
 *             message: "동일한 버전의 템플릿이 존재합니다."
 *             errorCode: "E5407"
 *             result: {}
 *
 *     TemplateCreateFailedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "템플릿 생성에 실패했습니다."
 *         errorCode:
 *           type: string
 *           example: "E5408"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         templateCreateFailed:
 *           summary: 템플릿 생성 실패
 *           value:
 *             httpCode: 400
 *             message: "템플릿 생성에 실패했습니다."
 *             errorCode: "E5408"
 *             result: {}
 *
 *     TemplateNotFoundError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 404
 *         message:
 *           type: string
 *           example: "템플릿을 찾을 수 없습니다."
 *         errorCode:
 *           type: string
 *           example: "E5409"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         templateNotFound:
 *           summary: 템플릿 없음
 *           value:
 *             httpCode: 404
 *             message: "템플릿을 찾을 수 없습니다."
 *             errorCode: "E5409"
 *             result: {}
 *
 *     TemplateUpdateFailedError:
 *       type: object
 *       properties:
 *         httpCode:
 *           type: integer
 *           example: 400
 *         message:
 *           type: string
 *           example: "템플릿 수정에 실패했습니다."
 *         errorCode:
 *           type: string
 *           example: "E5410"
 *         result:
 *           type: object
 *           description: 추가 에러 정보
 *       examples:
 *         templateUpdateFailed:
 *           summary: 템플릿 수정 실패
 *           value:
 *             httpCode: 400
 *             message: "템플릿 수정에 실패했습니다."
 *             errorCode: "E5410"
 *             result: {}
 *
 */
