/**
 * @swagger
 * components:
 *   schemas:
 *     ErrorLogTransactionItem:
 *       type: object
 *       properties:
 *         date:
 *           type: string
 *           example: '오전 11:29:33'
 *           description: '로그 발생 시간'
 *         message:
 *           type: string
 *           example: '[마이크 리스트] 마이크를 찾을 수 없습니다.'
 *           description: '에러 메시지'
 *
 *     ErrorLogCreateRequest:
 *       type: object
 *       required:
 *         - email
 *         - group
 *         - transaction
 *       properties:
 *         email:
 *           type: string
 *           example: 'shimsj@timbel.net'
 *           description: '사용자 이메일'
 *         group:
 *           type: string
 *           example: 'Recorder'
 *           description: '에러 그룹'
 *         transaction:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ErrorLogTransactionItem'
 *           example:
 *             - date: '오전 11:29:33'
 *               message: '[공지사항 체크 확인] true'
 *             - date: '오전 11:29:33'
 *               message: '[마이크 리스트] 실패 NotFoundError: Requested device not found'
 *           description: '에러 트랜잭션 목록'
 *
 *     ErrorLogCreateResponse:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '6923ce86a24bb57a435b11d4'
 *           description: '에러 로그 ID'
 *         email:
 *           type: string
 *           example: 'shimsj@timbel.net'
 *           description: '사용자 이메일'
 *         group:
 *           type: string
 *           example: 'Recorder'
 *           description: '에러 그룹'
 *         transaction:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ErrorLogTransactionItem'
 *           description: '에러 트랜잭션 목록'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-24T03:18:30.263Z'
 *           description: '생성 일시'
 */
