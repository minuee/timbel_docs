/**
 * @swagger
 * components:
 *   schemas:
 *     CorpusCreatorProfile:
 *       type: object
 *       properties:
 *         pid:
 *           type: string
 *           example: '사용자 고유 식별자'
 *           description: '사용자 PID'
 *         name:
 *           type: string
 *           example: ''
 *           description: '사용자 이름'
 *         nickName:
 *           type: string
 *           example: '팀벨입니다 asd'
 *           description: '사용자 닉네임'
 *
 *     CorpusCreator:
 *       type: object
 *       properties:
 *         user:
 *           type: object
 *           properties:
 *             profile:
 *               $ref: '#/components/schemas/CorpusCreatorProfile'
 *               description: '생성자 프로필 정보'
 *
 *     CorpusItem:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           example: 71
 *           description: '사전 항목 ID'
 *         source:
 *           type: string
 *           example: '사전'
 *           description: '원문'
 *         target:
 *           type: string
 *           example: '등록'
 *           description: '번역문'
 *         creator:
 *           $ref: '#/components/schemas/CorpusCreator'
 *           description: '생성자 정보'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-03-27T04:57:17.908Z'
 *           description: '생성 일시'
 *         updateAt:
 *           type: string
 *           format: date-time
 *           example: '2025-03-27T04:57:17.908Z'
 *           description: '수정 일시'
 *
 *     CorpusListResponse:
 *       type: array
 *       minItems: 2
 *       maxItems: 2
 *       items:
 *         oneOf:
 *           - type: array
 *             items:
 *               $ref: '#/components/schemas/CorpusItem'
 *             description: '사전 항목 목록 (첫 번째 요소)'
 *           - type: integer
 *             example: 2
 *             description: '전체 항목 수 (두 번째 요소)'
 *       description: '사전 목록과 전체 개수 [items[], total] 형태의 배열'
 *       example:
 *         - - id: 71
 *             source: '사전'
 *             target: '등록'
 *             creator:
 *               user:
 *                 profile:
 *                   pid: '사용자 고유 식별자'
 *                   name: ''
 *                   nickName: '팀벨입니다 asd'
 *             createAt: '2025-03-27T04:57:17.908Z'
 *             updateAt: '2025-03-27T04:57:17.908Z'
 *         - 2
 */
