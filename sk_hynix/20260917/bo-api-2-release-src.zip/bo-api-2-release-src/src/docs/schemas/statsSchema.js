/**
 * @swagger
 * components:
 *   schemas:
 *     WorkspaceStatsItem:
 *       type: object
 *       properties:
 *         workspaceId:
 *           type: string
 *           example: '212bfd54-5d07-4d91-9500-e614c4b9f59f'
 *           description: '워크스페이스 고유 식별자'
 *         workspaceName:
 *           type: string
 *           example: 'alibizgroup'
 *           description: '워크스페이스 이름'
 *         yyyymm:
 *           type: string
 *           example: '2025.07'
 *           description: '연월 (YYYY.MM 형식 또는 "TOTAL")'
 *         totalSTTCount:
 *           type: integer
 *           example: 452
 *           description: '전체 STT 처리 수'
 *         totalSTTDuration:
 *           type: integer
 *           example: 218080171
 *           description: '전체 STT 처리 시간 (밀리초)'
 *         successSTTCount:
 *           type: integer
 *           example: 241
 *           description: '성공한 STT 처리 수'
 *         successSTTDuration:
 *           type: integer
 *           example: 193541671
 *           description: '성공한 STT 처리 시간 (밀리초)'
 *         failSTTCount:
 *           type: integer
 *           example: 211
 *           description: '실패한 STT 처리 수'
 *         failSTTDuration:
 *           type: integer
 *           example: 24538500
 *           description: '실패한 STT 처리 시간 (밀리초)'
 *         totalLLMCount:
 *           type: integer
 *           example: 457
 *           description: '전체 LLM 요청 수'
 *         totalLLMToken:
 *           type: integer
 *           example: 5602833
 *           description: '전체 LLM 토큰 수'
 *         successLLMCount:
 *           type: integer
 *           example: 240
 *           description: '성공한 LLM 요청 수'
 *         failLLMCount:
 *           type: integer
 *           example: 0
 *           description: '실패한 LLM 요청 수'
 *
 *     WorkspaceStatsResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/WorkspaceStatsItem'
 *               description: '워크스페이스 통계 목록'
 *
 *     MemberStatsSum:
 *       type: object
 *       properties:
 *         totalContentCount:
 *           type: integer
 *           example: 0
 *           description: '전체 콘텐츠 수'
 *         totalContentDuration:
 *           type: integer
 *           example: 0
 *           description: '전체 콘텐츠 재생 시간 (밀리초)'
 *         totalLLMToken:
 *           type: integer
 *           example: 0
 *           description: '전체 LLM 토큰 수'
 *         totalLLMCount:
 *           type: integer
 *           example: 0
 *           description: '전체 LLM 요청 수'
 *
 *     MemberStatsItem:
 *       type: object
 *       properties:
 *         workspaceId:
 *           type: string
 *           example: '0aacac42-5808-4e33-b2e5-5c07ec362618'
 *           description: '워크스페이스 고유 식별자'
 *         workspaceName:
 *           type: string
 *           example: 'timbel-dev'
 *           description: '워크스페이스 이름'
 *         memberId:
 *           type: string
 *           example: 'a48f7331-3599-4c85-a57c-9d6ec4c8a7ce'
 *           description: '멤버 고유 식별자'
 *         userName:
 *           type: string
 *           example: 'abc'
 *           description: '사용자 이름'
 *         email:
 *           type: string
 *           example: 'abc@timbel.net'
 *           description: '이메일'
 *         totalContentCount:
 *           type: integer
 *           example: 3
 *           description: '전체 콘텐츠 수'
 *         totalContentDuration:
 *           type: integer
 *           example: 301874
 *           description: '전체 콘텐츠 재생 시간 (밀리초)'
 *         totalLLMToken:
 *           type: integer
 *           example: 13862
 *           description: '전체 LLM 토큰 수'
 *         totalLLMCount:
 *           type: integer
 *           example: 3
 *           description: '전체 LLM 요청 수'
 *
 *     MemberStatsData:
 *       type: object
 *       properties:
 *         stats:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/MemberStatsItem'
 *           description: '멤버 통계 목록'
 *         total:
 *           type: integer
 *           example: 72
 *           description: '전체 멤버 수'
 *
 *     MemberStatsResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               $ref: '#/components/schemas/MemberStatsData'
 *               description: '멤버 통계 데이터'
 *
 *     YearItem:
 *       type: object
 *       properties:
 *         yyyy:
 *           type: string
 *           example: '2024'
 *           description: '연도 (YYYY 형식)'
 *
 *     YearsResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/YearItem'
 *               description: '연도 목록'
 *
 *     StatsCountResponse:
 *       allOf:
 *         - $ref: '#/components/schemas/Success'
 *         - type: object
 *           properties:
 *             data:
 *               type: object
 *               properties:
 *                 count:
 *                   type: integer
 *                   example: 89
 *                   description: '통계 카운트'
 *               description: '통계 카운트 데이터'
 */
