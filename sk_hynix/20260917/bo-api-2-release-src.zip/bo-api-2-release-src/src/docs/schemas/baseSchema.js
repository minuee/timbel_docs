/**
 * @swagger
 * components:
 *   schemas:
 *     Success:
 *       type: 'object'
 *       properties:
 *         message:
 *           type: 'string'
 *           description: 'Success message'
 *         httpCode:
 *           type: 'integer'
 *           description: 'HTTP status code'
 *         data:
 *           type: 'object'
 *           description: 'Response data'
 *
 *     CreatorOrUpdater:
 *       type: 'object'
 *       properties:
 *         pid:
 *           type: 'string'
 *           description: 'Creator pid'
 *         nickName:
 *           type: 'string'
 *           description: 'Creator nick name'
 *         email:
 *           type: 'string'
 *           description: 'Creator email'
 *         thumbnailUrl:
 *           type: 'string'
 *           description: 'Creator thumbnail URL'
 */
