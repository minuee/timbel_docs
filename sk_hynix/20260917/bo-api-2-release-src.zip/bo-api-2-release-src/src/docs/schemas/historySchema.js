/**
 * @swagger
 * components:
 *   schemas:
 *     SettingHistoryItem:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           example: 1
 *           description: '설정 이력 ID'
 *         workspaceId:
 *           type: string
 *           nullable: true
 *           example: null
 *           description: '워크스페이스 ID'
 *         workspaceName:
 *           type: string
 *           nullable: true
 *           example: 'Global'
 *           description: '워크스페이스 이름'
 *         userName:
 *           type: string
 *           example: '심승종1'
 *           description: '사용자 이름'
 *         ip:
 *           type: string
 *           example: 'unknown'
 *           description: 'IP 주소'
 *         menuName:
 *           type: string
 *           example: '전체 메뉴 관리'
 *           description: '메뉴 이름'
 *         changeItem:
 *           type: string
 *           example: '메뉴 수정'
 *           description: '변경 항목'
 *         beforeData:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *                 example: 'field'
 *               label:
 *                 type: string
 *                 example: '명칭'
 *               value:
 *                 type: string
 *                 example: '값'
 *               rawValue:
 *                 type: string
 *                 example: '실제 값'
 *           description: '변경 전 데이터'
 *         afterData:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               field:
 *                 type: string
 *                 example: 'field'
 *               label:
 *                 type: string
 *                 example: '명칭'
 *               value:
 *                 type: string
 *                 example: '값'
 *               rawValue:
 *                 type: string
 *                 example: '실제 값'
 *           description: '변경 후 데이터'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-06T02:31:14.717Z'
 *           description: '생성 일시'
 *
 *     SettingHistoryListResponse:
 *       type: object
 *       properties:
 *         histories:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/SettingHistoryItem'
 *           description: '설정 이력 목록'
 *         total:
 *           type: integer
 *           example: 2
 *           description: '전체 이력 수'
 *
 *     DownloadHistoryItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '다운로드 이력 고유 식별자'
 *           description: '다운로드 이력 ID'
 *         type:
 *           type: string
 *           enum: [DOCUMENT_PDF, DOCUMENT_TXT, DOCUMENT_HWP, DOCUMENT_DOCX, MEDIA_FILE]
 *           example: 'DOCUMENT_PDF'
 *           description: '다운로드 파일 타입'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         contentId:
 *           type: string
 *           example: '콘텐츠 고유 식별자'
 *           description: '콘텐츠 ID'
 *         contentTitle:
 *           type: string
 *           example: '콘텐츠 제목'
 *           description: '콘텐츠 제목'
 *         fileName:
 *           type: string
 *           example: '파일명.mp3'
 *           description: '다운로드한 파일명'
 *         userName:
 *           type: string
 *           example: '사용자 이름'
 *           description: '사용자 이름'
 *         email:
 *           type: string
 *           example: 'user@example.com'
 *           description: '사용자 이메일'
 *         device:
 *           type: string
 *           example: 'PC'
 *           description: '다운로드 디바이스'
 *         size:
 *           type: integer
 *           example: 2324558
 *           description: '파일 크기 (바이트)'
 *         downloadAt:
 *           type: string
 *           format: date-time
 *           example: '2025-04-07T06:58:11.165Z'
 *           description: '다운로드 일시'
 *
 *     DownloadHistoryListResponse:
 *       type: object
 *       properties:
 *         histories:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/DownloadHistoryItem'
 *           description: '다운로드 이력 목록'
 *         total:
 *           type: integer
 *           example: 606
 *           description: '전체 다운로드 이력 수'
 *
 *     ContentHistoryItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '콘텐츠 이력 고유 식별자'
 *           description: '콘텐츠 이력 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         contentId:
 *           type: string
 *           example: '콘텐츠 고유 식별자'
 *           description: '콘텐츠 ID'
 *         contentType:
 *           type: string
 *           enum: [AUDIO, VIDEO]
 *           example: 'AUDIO'
 *           description: '콘텐츠 타입'
 *         contentTitle:
 *           type: string
 *           example: '콘텐츠 제목'
 *           description: '콘텐츠 제목'
 *         meetingStartTime:
 *           type: string
 *           format: date-time
 *           example: '2025-11-18T01:01:34.461Z'
 *           description: '회의 시작 시간'
 *         meetingEndTime:
 *           type: string
 *           format: date-time
 *           example: '2025-11-18T01:13:48.139Z'
 *           description: '회의 종료 시간'
 *         duration:
 *           type: integer
 *           example: 733680
 *           description: '재생 시간 (밀리초)'
 *         transcribeStatus:
 *           type: string
 *           enum: [DONE, PROCESSING, FAILED, PENDING]
 *           example: 'DONE'
 *           description: '전사 상태'
 *         userName:
 *           type: string
 *           example: '사용자 이름'
 *           description: '사용자 이름'
 *         email:
 *           type: string
 *           example: 'user@example.com'
 *           description: '사용자 이메일'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-18T01:08:10.720Z'
 *           description: '생성 일시'
 *
 *     ContentHistoryListResponse:
 *       type: array
 *       minItems: 2
 *       maxItems: 2
 *       items:
 *         oneOf:
 *           - type: array
 *             items:
 *               $ref: '#/components/schemas/ContentHistoryItem'
 *           - type: integer
 *       description: '콘텐츠 이력 목록과 전체 수 (튜플 형태: [histories[], total])'
 *       example:
 *         - - id: '콘텐츠 이력 고유 식별자'
 *             workspaceId: '워크스페이스 고유 식별자'
 *             contentId: '콘텐츠 고유 식별자'
 *             contentType: 'AUDIO'
 *             contentTitle: '콘텐츠 제목'
 *             meetingStartTime: '2025-11-18T01:01:34.461Z'
 *             meetingEndTime: '2025-11-18T01:13:48.139Z'
 *             duration: 733680
 *             transcribeStatus: 'DONE'
 *             userName: '사용자 이름'
 *             email: 'user@example.com'
 *             createAt: '2025-11-18T01:08:10.720Z'
 *         - 2
 *
 *     LoginHistoryItem:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           example: 1
 *           description: '로그인 이력 ID'
 *         workspaceId:
 *           type: string
 *           example: '워크스페이스 고유 식별자'
 *           description: '워크스페이스 ID'
 *         userName:
 *           type: string
 *           example: '사용자 이름'
 *           description: '사용자 이름'
 *         email:
 *           type: string
 *           example: 'user@example.com'
 *           description: '사용자 이메일'
 *         ip:
 *           type: string
 *           example: '123.123.123.123'
 *           description: 'IP 주소'
 *         device:
 *           type: string
 *           enum: [PC, Mobile]
 *           example: 'PC'
 *           description: '로그인 디바이스'
 *         loginAt:
 *           type: string
 *           format: date-time
 *           example: '2025-04-14T06:07:11.393Z'
 *           description: '로그인 일시'
 *         logoutAt:
 *           type: string
 *           format: date-time
 *           nullable: true
 *           example: '2025-04-14T06:23:53.653Z'
 *           description: '로그아웃 일시'
 *         failureReason:
 *           type: string
 *           nullable: true
 *           example: '"Invalid password error"'
 *           description: '실패 사유 (로그인 실패 시)'
 *
 *     LoginHistoryListResponse:
 *       type: object
 *       properties:
 *         histories:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/LoginHistoryItem'
 *           description: '로그인 이력 목록'
 *         total:
 *           type: integer
 *           example: 3511
 *           description: '전체 로그인 이력 수'
 *
 *     PolicyInfo:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '약관 고유 식별자'
 *           description: '약관 ID'
 *         category:
 *           type: string
 *           enum: [TERMS, PRIVACY]
 *           example: 'TERMS'
 *           description: '약관 카테고리'
 *         title:
 *           type: string
 *           example: '테스트 이용약관'
 *           description: '약관 제목'
 *         version:
 *           type: string
 *           nullable: true
 *           example: '1.2'
 *           description: '약관 버전'
 *
 *     PolicyHistoryItem:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           example: '정책 이력 고유 식별자'
 *           description: '정책 이력 ID'
 *         userName:
 *           type: string
 *           example: '테스트2'
 *           description: '사용자 이름'
 *         email:
 *           type: string
 *           example: 'test2@test.com'
 *           description: '사용자 이메일'
 *         policy:
 *           $ref: '#/components/schemas/PolicyInfo'
 *         createAt:
 *           type: string
 *           format: date-time
 *           example: '2025-11-20T05:24:56.000Z'
 *           description: '생성 일시'
 *
 *     PolicyHistoryListResponse:
 *       type: object
 *       properties:
 *         histories:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/PolicyHistoryItem'
 *           description: '정책 이력 목록'
 *         total:
 *           type: integer
 *           example: 6
 *           description: '전체 정책 이력 수'
 */
