/**
 * @swagger
 * /history/policy:
 *   get:
 *     summary: 약관 동의 이력 목록 조회
 *     description: 약관 동의 이력 목록을 조회합니다.
 *     tags: [History]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 시작 날짜
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 종료 날짜
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [category, userName, email, title, version]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [userName, email, category, title, version, createAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 정책 이력 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/PolicyHistoryListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UnauthorizedError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /history/login:
 *   get:
 *     summary: 로그인 이력 목록 조회
 *     description: 워크스페이스의 로그인 이력 목록을 조회합니다.
 *     tags: [History]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 시작 날짜
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 종료 날짜
 *       - in: query
 *         name: device
 *         schema:
 *           type: string
 *           enum: [PC, Mobile]
 *         description: 디바이스 필터
 *       - in: query
 *         name: isSuccess
 *         schema:
 *           type: string
 *           enum: [true, false]
 *         description: 로그인 성공 여부 필터 (성공 -> true, 실패 -> false)
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [ip, userName, email]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [userName, email, ip, device, failureReason, loginAt, logoutAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 로그인 이력 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/LoginHistoryListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UnauthorizedError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /history/download:
 *   get:
 *     summary: 다운로드 이력 목록 조회
 *     description: 워크스페이스의 다운로드 이력 목록을 조회합니다.
 *     tags: [History]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 시작 날짜
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 종료 날짜
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *           enum: [DOCS, MEDIA]
 *         description: 파일 타입 필터 (DOCS -> DOCUMENT_TXT, DOCUMENT_PDF, DOCUMENT_DOCX, DOCUMENT_HWP, MEDIA -> MEDIA_FILE)
 *       - in: query
 *         name: device
 *         schema:
 *           type: string
 *           enum: [PC, Mobile]
 *         description: 디바이스 필터
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [contentTitle, fileName, userName, email]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [type, contentTitle, fileName, userName, email, size, device, downloadAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 다운로드 이력 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/DownloadHistoryListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UnauthorizedError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /history/content:
 *   get:
 *     summary: 콘텐츠 이력 목록 조회
 *     description: 워크스페이스의 콘텐츠 이력 목록을 조회합니다.
 *     tags: [History]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 시작 날짜
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 종료 날짜
 *       - in: query
 *         name: contentType
 *         schema:
 *           type: string
 *           enum: [AUDIO, RECORD, VIDEO, MERGED_CONTENT]
 *         description: 콘텐츠 타입 필터
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [contentTitle, userName]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [contentType, contentTitle, userName, meetingStartTime, duration, createAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 콘텐츠 이력 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/ContentHistoryListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UnauthorizedError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /history/setting:
 *   get:
 *     summary: 설정 이력 목록 조회
 *     description: 워크스페이스의 설정 변경 이력 목록을 조회합니다.
 *     tags: [History]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 시작 날짜
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 종료 날짜
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [userName, menuName, changeItem]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [id, userName, ip, menuName, changeItem, createAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 설정 이력 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/SettingHistoryListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UnauthorizedError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /history/setting/system:
 *   get:
 *     summary: 시스템 설정 이력 목록 조회
 *     description: 시스템 전체 설정 변경 이력 목록을 조회합니다.
 *     tags: [History]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 시작 날짜
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: YYYY-MM-DD
 *         description: 종료 날짜
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [userName, menuName, changeItem]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [id, userName, ip, menuName, changeItem, createAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 시스템 설정 이력 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/SettingHistoryListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/UnauthorizedError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
