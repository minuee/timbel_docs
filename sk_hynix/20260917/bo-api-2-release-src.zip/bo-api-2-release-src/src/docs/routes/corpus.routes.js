/**
 * @swagger
 * /corpus:
 *   get:
 *     summary: 사전 목록 조회
 *     description: 워크스페이스의 사전 목록을 조회합니다.
 *     tags: [Corpus]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: source
 *         schema:
 *           type: string
 *         description: 원문 검색어
 *       - in: query
 *         name: target
 *         schema:
 *           type: string
 *         description: 번역문 검색어
 *       - in: query
 *         name: creator
 *         schema:
 *           type: string
 *         description: 생성자 검색어
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [source, target, creator, createAt, updateAt]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 사전 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/CorpusListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
