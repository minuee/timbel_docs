/**
 * @swagger
 * /stats:
 *   post:
 *     summary: 일일 통계 생성
 *     description: 일일 통계를 생성합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - statsDate
 *             properties:
 *               statsDate:
 *                 type: string
 *                 example: '2025-12-16'
 *                 description: '생성할 통계일'
 *     responses:
 *       200:
 *         description: 통계 생성 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/StatsCountResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidDateError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidDate:
 *                 $ref: '#/components/schemas/CommonInvalidDateError/examples/invalidDate'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/years:
 *   get:
 *     summary: 연도 목록 조회
 *     description: 사용 가능한 연도 목록을 조회합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: 연도 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/YearsResponse'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/workspace:
 *   get:
 *     summary: 워크스페이스 통계 조회
 *     description: 워크스페이스의 통계 정보를 조회합니다. 기간별(MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: periodType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [MONTHLY, YEARLY]
 *         description: '기간 타입 (MONTHLY: 월별, YEARLY: 연별)'
 *       - in: query
 *         name: startPeriod
 *         required: true
 *         schema:
 *           type: string
 *         description: '시작 기간 (MONTHLY: YYYYMM 형식, YEARLY: YYYY 형식)'
 *       - in: query
 *         name: endPeriod
 *         required: true
 *         schema:
 *           type: string
 *         description: '종료 기간 (MONTHLY: YYYYMM 형식, YEARLY: YYYY 형식)'
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [workspaceName]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 워크스페이스 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/WorkspaceStatsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/workspace/system:
 *   get:
 *     summary: 시스템 워크스페이스 통계 조회
 *     description: 시스템 전체 워크스페이스의 통계 정보를 조회합니다. 기간별(MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *       - in: query
 *         name: periodType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [MONTHLY, YEARLY]
 *         description: '기간 타입 (MONTHLY: 월별, YEARLY: 연별)'
 *       - in: query
 *         name: startPeriod
 *         required: true
 *         schema:
 *           type: string
 *         description: '시작 기간 (MONTHLY: YYYY.MM 형식, YEARLY: YYYY 형식)'
 *       - in: query
 *         name: endPeriod
 *         required: true
 *         schema:
 *           type: string
 *         description: '종료 기간 (MONTHLY: YYYY.MM 형식, YEARLY: YYYY 형식)'
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 3
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [workspaceName]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 시스템 워크스페이스 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/WorkspaceStatsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/workspace/download:
 *   post:
 *     summary: 워크스페이스 통계 CSV 다운로드
 *     description: 워크스페이스의 통계 정보를 CSV 파일로 다운로드합니다. 기간별(MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - periodType
 *               - startPeriod
 *               - endPeriod
 *             properties:
 *               periodType:
 *                 type: string
 *                 enum: [MONTHLY, YEARLY]
 *                 description: '기간 타입 (MONTHLY: 월별, YEARLY: 연별)'
 *               startPeriod:
 *                 type: string
 *                 description: '시작 기간 (MONTHLY: YYYYMM 형식, YEARLY: YYYY 형식)'
 *               endPeriod:
 *                 type: string
 *                 description: '종료 기간 (MONTHLY: YYYYMM 형식, YEARLY: YYYY 형식)'
 *     responses:
 *       200:
 *         description: 워크스페이스 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *             description: CSV 파일
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/workspace/download/system:
 *   post:
 *     summary: 시스템 워크스페이스 통계 CSV 다운로드
 *     description: 시스템 전체 워크스페이스의 통계 정보를 CSV 파일로 다운로드합니다. 기간별(MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - periodType
 *               - startPeriod
 *               - endPeriod
 *             properties:
 *               workspaceId:
 *                 type: string
 *                 description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *               periodType:
 *                 type: string
 *                 enum: [MONTHLY, YEARLY]
 *                 description: '기간 타입 (MONTHLY: 월별, YEARLY: 연별)'
 *               startPeriod:
 *                 type: string
 *                 description: '시작 기간 (MONTHLY: YYYY.MM 형식, YEARLY: YYYY 형식)'
 *               endPeriod:
 *                 type: string
 *                 description: '종료 기간 (MONTHLY: YYYY.MM 형식, YEARLY: YYYY 형식)'
 *     responses:
 *       200:
 *         description: 시스템 워크스페이스 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *             description: CSV 파일
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/member:
 *   get:
 *     summary: 멤버 통계 조회
 *     description: 워크스페이스의 멤버별 통계 정보를 조회합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [userName, email, workspaceName]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: 시작 날짜 (YYYY-MM-DD 형식)
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: date
 *         description: 종료 날짜 (YYYY-MM-DD 형식)
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [workspaceName, userName, email, contentCount, contentDuration, llmToken, llmCount]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 멤버 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MemberStatsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/member/system:
 *   get:
 *     summary: 시스템 멤버 통계 조회
 *     description: 시스템 전체 멤버의 통계 정보를 조회합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: workspaceId
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [userName, email, workspaceName]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: fromDate
 *         schema:
 *           type: string
 *           format: date
 *         description: 시작 날짜 (YYYY-MM-DD 형식)
 *       - in: query
 *         name: toDate
 *         schema:
 *           type: string
 *           format: date
 *         description: 종료 날짜 (YYYY-MM-DD 형식)
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [workspaceName, userName, email, totalContentCount, totalContentDuration, totalLLMToken, totalLLMCount]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 시스템 멤버 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MemberStatsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/member/download:
 *   post:
 *     summary: 멤버 통계 CSV 다운로드
 *     description: 워크스페이스의 멤버별 통계 정보를 CSV 파일로 다운로드합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               filter:
 *                 type: string
 *                 enum: [userName, email, workspaceName]
 *                 description: 검색 필터
 *               keyword:
 *                 type: string
 *                 description: 검색 키워드
 *               fromDate:
 *                 type: string
 *                 format: date
 *                 description: 시작 날짜 (YYYY-MM-DD 형식)
 *               toDate:
 *                 type: string
 *                 format: date
 *                 description: 종료 날짜 (YYYY-MM-DD 형식)
 *     responses:
 *       200:
 *         description: 멤버 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *             description: CSV 파일
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /stats/member/download/system:
 *   post:
 *     summary: 시스템 멤버 통계 CSV 다운로드
 *     description: 시스템 전체 멤버의 통계 정보를 CSV 파일로 다운로드합니다.
 *     tags: [Stats]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               workspaceId:
 *                 type: string
 *                 description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *               filter:
 *                 type: string
 *                 enum: [userName, email, workspaceName]
 *                 description: 검색 필터
 *               keyword:
 *                 type: string
 *                 description: 검색 키워드
 *               fromDate:
 *                 type: string
 *                 format: date
 *                 description: 시작 날짜 (YYYY-MM-DD 형식)
 *               toDate:
 *                 type: string
 *                 format: date
 *                 description: 종료 날짜 (YYYY-MM-DD 형식)
 *     responses:
 *       200:
 *         description: 시스템 멤버 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *             description: CSV 파일
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
