/**
 * @swagger
 * /user:
 *   post:
 *     summary: 사용자 생성
 *     description: 워크스페이스에 새로운 사용자를 생성합니다.
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - workspaceId
 *               - name
 *               - email
 *               - password
 *             properties:
 *               workspaceId:
 *                 type: string
 *                 example: '워크스페이스 고유 식별자'
 *                 description: '워크스페이스 ID'
 *               name:
 *                 type: string
 *                 example: '홍길동'
 *                 description: '사용자 이름'
 *               email:
 *                 type: string
 *                 example: 'user@example.com'
 *                 description: '사용자 이메일'
 *               password:
 *                 type: string
 *                 example: 'password123'
 *                 description: '사용자 비밀번호'
 *               roleId:
 *                 type: string
 *                 nullable: true
 *                 example: '역할 고유 식별자'
 *                 description: '역할 ID (선택사항)'
 *     responses:
 *       201:
 *         description: 사용자 생성 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /user/system:
 *   post:
 *     summary: 시스템 사용자 생성
 *     description: 시스템 전체에 새로운 사용자를 생성합니다.
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - workspaceId
 *               - name
 *               - email
 *               - password
 *             properties:
 *               workspaceId:
 *                 type: string
 *                 example: '워크스페이스 고유 식별자'
 *                 description: '워크스페이스 ID'
 *               name:
 *                 type: string
 *                 example: '홍길동'
 *                 description: '사용자 이름'
 *               email:
 *                 type: string
 *                 example: 'user@example.com'
 *                 description: '사용자 이메일'
 *               password:
 *                 type: string
 *                 example: 'password123'
 *                 description: '사용자 비밀번호'
 *               roleId:
 *                 type: string
 *                 nullable: true
 *                 example: '역할 고유 식별자'
 *                 description: '역할 ID (선택사항)'
 *     responses:
 *       201:
 *         description: 시스템 사용자 생성 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /user/{pid}/password:
 *   patch:
 *     summary: 사용자 비밀번호 수정
 *     description: 워크스페이스 사용자의 비밀번호를 수정합니다.
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: pid
 *         required: true
 *         schema:
 *           type: string
 *         description: 사용자 PID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - newPassword
 *             properties:
 *               newPassword:
 *                 type: string
 *                 example: 'newPassword123'
 *                 description: '새 비밀번호'
 *     responses:
 *       200:
 *         description: 비밀번호 수정 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserPasswordUpdateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /user/{pid}/password/system:
 *   patch:
 *     summary: 시스템 사용자 비밀번호 수정
 *     description: 시스템 전체 사용자의 비밀번호를 수정합니다.
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: pid
 *         required: true
 *         schema:
 *           type: string
 *         description: 사용자 PID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - newPassword
 *             properties:
 *               newPassword:
 *                 type: string
 *                 example: 'newPassword123'
 *                 description: '새 비밀번호'
 *     responses:
 *       200:
 *         description: 비밀번호 수정 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserPasswordUpdateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /user:
 *   delete:
 *     summary: 사용자 일괄 삭제
 *     description: 워크스페이스의 여러 사용자를 일괄로 삭제합니다.
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UserDeleteRequest'
 *     responses:
 *       204:
 *         description: 사용자 삭제 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserDeleteResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               workspaceOwnerCannotDelete:
 *                 summary: 워크스페이스 소유자는 삭제할 수 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '워크스페이스 소유자는 삭제할 수 없습니다.'
 *                   errorCode: 'BE1505'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /user/system:
 *   delete:
 *     summary: 시스템 사용자 일괄 삭제
 *     description: 시스템 전체의 여러 사용자를 일괄로 삭제합니다.
 *     tags: [User]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UserDeleteRequest'
 *     responses:
 *       204:
 *         description: 사용자 삭제 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserDeleteResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               workspaceOwnerCannotDelete:
 *                 summary: 워크스페이스 소유자는 삭제할 수 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '워크스페이스 소유자는 삭제할 수 없습니다.'
 *                   errorCode: 'BE1505'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
