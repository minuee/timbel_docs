/**
 * @swagger
 * /menu:
 *   get:
 *     summary: 메뉴 목록 조회
 *     description: 워크스페이스의 메뉴 목록을 조회합니다.
 *     tags: [Menu]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: group
 *         required: false
 *         schema:
 *           type: string
 *         description: '메뉴 그룹 필터 (쉼표로 구분된 여러 그룹 지정 가능, 예: SYSTEM,SYSTEM_ADDON,WORKSPACE,WORKSPACE_ADDON,DETAIL,HISTORY)'
 *       - in: query
 *         name: workspaceId
 *         required: false
 *         schema:
 *           type: string
 *         description: '워크스페이스 ID'
 *     responses:
 *       200:
 *         description: 메뉴 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/MenuListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/MenuGroupUndefinedError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               menuGroupUndefined:
 *                 $ref: '#/components/schemas/MenuGroupUndefinedError/examples/menuGroupUndefined'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 *  */

/**
 * @swagger
 * /menu:
 *   post:
 *     summary: 메뉴 생성
 *     description: 애드온 메뉴를 생성합니다. (SYSTEM_ADDON, WORKSPACE_ADDON 그룹만 허용)
 *     tags: [Menu]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - group
 *               - name
 *               - urlPath
 *               - isUsed
 *             properties:
 *               workspaceId:
 *                 type: string
 *                 example: '워크스페이스 고유 식별자'
 *                 description: '워크스페이스 ID'
 *               group:
 *                 type: string
 *                 enum: [SYSTEM_ADDON, WORKSPACE_ADDON]
 *                 example: 'SYSTEM_ADDON'
 *                 description: '메뉴 그룹'
 *               name:
 *                 type: string
 *                 example: '서킷브레이커2'
 *                 description: '메뉴 이름'
 *               urlPath:
 *                 type: string
 *                 example: '/circuit/breaker2'
 *                 description: '메뉴 URL 경로'
 *               isUsed:
 *                 type: boolean
 *                 example: true
 *                 description: '사용 여부'
 *     responses:
 *       201:
 *         description: 메뉴 생성 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/MenuCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/MenuGroupUndefinedError'
 *                 - $ref: '#/components/schemas/MenuGroupNotAllowedError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               menuGroupUndefined:
 *                 $ref: '#/components/schemas/MenuGroupUndefinedError/examples/menuGroupUndefined'
 *               menuGroupNotAllowed:
 *                 $ref: '#/components/schemas/MenuGroupNotAllowedError/examples/menuGroupNotAllowed'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       409:
 *         description: 메뉴 중복
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MenuAlreadyExistsError'
 *             examples:
 *               menuAlreadyExists:
 *                 $ref: '#/components/schemas/MenuAlreadyExistsError/examples/menuAlreadyExists'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /menu/{menuId}:
 *   put:
 *     summary: 메뉴 수정
 *     description: 애드온 메뉴를 수정합니다. (SYSTEM_ADDON, WORKSPACE_ADDON 그룹만 허용)
 *     tags: [Menu]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: menuId
 *         required: true
 *         schema:
 *           type: string
 *         description: '메뉴 ID'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - group
 *               - name
 *               - urlPath
 *               - isUsed
 *             properties:
 *               group:
 *                 type: string
 *                 enum: [SYSTEM_ADDON, WORKSPACE_ADDON]
 *                 example: 'SYSTEM_ADDON'
 *                 description: '메뉴 그룹'
 *               name:
 *                 type: string
 *                 example: '서킷'
 *                 description: '메뉴 이름'
 *               urlPath:
 *                 type: string
 *                 example: '/test'
 *                 description: '메뉴 URL 경로'
 *               isUsed:
 *                 type: boolean
 *                 example: true
 *                 description: '사용 여부'
 *     responses:
 *       200:
 *         description: 메뉴 수정 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/MenuItem'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *                 - $ref: '#/components/schemas/MenuGroupUndefinedError'
 *                 - $ref: '#/components/schemas/MenuGroupNotAllowedError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               menuGroupUndefined:
 *                 $ref: '#/components/schemas/MenuGroupUndefinedError/examples/menuGroupUndefined'
 *               menuGroupNotAllowed:
 *                 $ref: '#/components/schemas/MenuGroupNotAllowedError/examples/menuGroupNotAllowed'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /menu/{menuId}/status:
 *   patch:
 *     summary: 메뉴 사용 여부 수정
 *     description: 메뉴의 사용 여부(isUsed)를 수정합니다.
 *     tags: [Menu]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: menuId
 *         required: true
 *         schema:
 *           type: string
 *         description: '메뉴 ID'
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - isUsed
 *             properties:
 *               isUsed:
 *                 type: boolean
 *                 example: true
 *                 description: '사용 여부'
 *     responses:
 *       200:
 *         description: 메뉴 사용 여부 수정 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/MenuItem'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /menu/{menuId}:
 *   delete:
 *     summary: 메뉴 삭제
 *     description: 메뉴를 삭제합니다.
 *     tags: [Menu]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: menuId
 *         required: true
 *         schema:
 *           type: string
 *         description: '메뉴 ID'
 *     responses:
 *       204:
 *         description: 메뉴 삭제 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/MenuItem'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /menu/default:
 *   post:
 *     summary: 기본 메뉴 생성
 *     description: 기본 메뉴를 생성합니다.
 *     tags: [Menu]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - group
 *               - code
 *               - name
 *               - urlPath
 *               - isUsed
 *             properties:
 *               group:
 *                 type: string
 *                 enum: [SYSTEM, WORKSPACE, DETAIL, HISTORY]
 *                 example: 'SYSTEM'
 *                 description: '메뉴 그룹'
 *               code:
 *                 type: string
 *                 example: 'S1000'
 *                 description: '메뉴 코드'
 *               name:
 *                 type: string
 *                 example: '통계 대시보드'
 *                 description: '메뉴 이름'
 *               urlPath:
 *                 type: string
 *                 example: '/system-new-statistic'
 *                 description: '메뉴 URL 경로'
 *               isUsed:
 *                 type: boolean
 *                 example: true
 *                 description: '사용 여부'
 *     responses:
 *       201:
 *         description: 기본 메뉴 생성 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/MenuItem'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
