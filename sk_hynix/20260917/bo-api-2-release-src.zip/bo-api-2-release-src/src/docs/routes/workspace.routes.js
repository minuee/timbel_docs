/**
 * @swagger
 * /workspace:
 *   get:
 *     summary: 워크스페이스 목록 조회
 *     description: 시스템의 워크스페이스 목록을 조회합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: filter
 *         schema:
 *           type: string
 *           enum: [name, domain, owner]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: 페이지당 항목 수
 *       - in: query
 *         name: orderByField
 *         schema:
 *           type: string
 *           enum: [name, domain, owner, createAt, description]
 *         description: 정렬 기준 필드
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: 정렬 순서
 *     responses:
 *       200:
 *         description: 워크스페이스 목록 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceListResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonInvalidFilterError'
 *                 - $ref: '#/components/schemas/CommonInvalidSortOrderError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               invalidFilter:
 *                 $ref: '#/components/schemas/CommonInvalidFilterError/examples/invalidFilter'
 *               invalidSortOrder:
 *                 $ref: '#/components/schemas/CommonInvalidSortOrderError/examples/invalidSortOrder'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 *   post:
 *     summary: 워크스페이스 생성
 *     description: 새로운 워크스페이스를 생성합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - domain
 *             properties:
 *               name:
 *                 type: string
 *                 example: '테스트'
 *                 description: '워크스페이스 이름'
 *               domain:
 *                 type: string
 *                 example: 'test4.test.com'
 *                 description: '워크스페이스 도메인 (FQDN 형식 필수)'
 *               description:
 *                 type: string
 *                 example: ''
 *                 description: '워크스페이스 설명'
 *     responses:
 *       201:
 *         description: 워크스페이스 생성 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *               invalidDomain:
 *                 summary: 유효하지 않은 도메인 형식
 *                 value:
 *                   httpCode: 400
 *                   message: '유효하지 않은 도메인 형식입니다.'
 *                   errorCode: 'E1102'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       409:
 *         description: 워크스페이스 중복
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               workspaceAlreadyExists:
 *                 summary: 이미 존재하는 워크스페이스
 *                 value:
 *                   httpCode: 409
 *                   message: '이미 존재하는 워크스페이스입니다.'
 *                   errorCode: 'BE1109'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/me:
 *   get:
 *     summary: 내 워크스페이스 기능 설정 간단 조회(FO)
 *     description: 현재 사용자의 워크스페이스 기본 정보와 기능 설정을 간단하게 조회합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: 워크스페이스 정보 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                           example: '워크스페이스 고유 식별자'
 *                           description: '워크스페이스 ID'
 *                         name:
 *                           type: string
 *                           example: 'alibizgroup'
 *                           description: '워크스페이스 이름'
 *                         domain:
 *                           type: string
 *                           example: 'example.com'
 *                           description: '워크스페이스 도메인'
 *                         thumbnailUrl:
 *                           type: string
 *                           nullable: true
 *                           example: 'https://example.com/thumbnail.jpg'
 *                           description: '워크스페이스 썸네일 URL'
 *                         createAt:
 *                           type: string
 *                           format: date-time
 *                           example: '2025-01-07T07:12:03.034Z'
 *                           description: '생성 일시'
 *                         simpleSettings:
 *                           $ref: '#/components/schemas/WorkspaceSimpleSettings'
 *                           description: '기능 설정 평면 구조'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}:
 *   get:
 *     summary: 워크스페이스 기본 정보 조회
 *     description: 특정 워크스페이스의 기본 정보를 조회합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     responses:
 *       200:
 *         description: 워크스페이스 기본 정보 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                           example: '워크스페이스 고유 식별자'
 *                           description: '워크스페이스 ID'
 *                         name:
 *                           type: string
 *                           example: 'alibizgroup'
 *                           description: '워크스페이스 이름'
 *                         domain:
 *                           type: string
 *                           example: 'example.com'
 *                           description: '워크스페이스 도메인'
 *                         thumbnailUrl:
 *                           type: string
 *                           nullable: true
 *                           example: 'https://example.com/thumbnail.jpg'
 *                           description: '워크스페이스 썸네일 URL'
 *                         createAt:
 *                           type: string
 *                           format: date-time
 *                           example: '2025-01-07T07:12:03.034Z'
 *                           description: '생성 일시'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 summary: 워크스페이스 ID 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '워크스페이스 ID는 필수입니다.'
 *                   errorCode: 'E1000'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 *   patch:
 *     summary: 워크스페이스 수정
 *     description: 워크스페이스 정보를 수정합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               name:
 *                 type: string
 *                 example: '123'
 *                 description: '워크스페이스 이름'
 *               description:
 *                 type: string
 *                 nullable: true
 *                 example: ''
 *                 description: '워크스페이스 설명'
 *     responses:
 *       200:
 *         description: 워크스페이스 수정 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 *   delete:
 *     summary: 워크스페이스 삭제
 *     description: 워크스페이스를 삭제합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     responses:
 *       204:
 *         description: 워크스페이스 삭제 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceDeleteResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}/name:
 *   patch:
 *     summary: 워크스페이스 이름 수정
 *     description: 워크스페이스 이름을 수정합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *             properties:
 *               name:
 *                 type: string
 *                 example: '123'
 *                 description: '워크스페이스 이름'
 *     responses:
 *       200:
 *         description: 워크스페이스 수정 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
/**
 * @swagger
 * /workspace/{workspaceId}/setting:
 *   get:
 *     summary: 워크스페이스 기능 설정 조회
 *     description: 워크스페이스의 기능 설정을 조회합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *       - in: query
 *         name: group
 *         required: false
 *         schema:
 *           type: string
 *         description: 기능 설정 그룹
 *     responses:
 *       200:
 *         description: 기능 설정 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceFeatureSettingsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}/member:
 *   put:
 *     summary: 워크스페이스 최대 구성원 수 업데이트
 *     description: 라이선스 좌석 수를 고려하여 워크스페이스의 최대 구성원 수를 변경합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateWorkspaceMemberLimitRequest'
 *     responses:
 *       200:
 *         description: 최대 구성원 수 업데이트 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceMemberLimitResponse'
 *       400:
 *         description: 잘못된 요청 또는 라이선스 좌석 부족
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               invalidValue:
 *                 summary: 잘못된 구성원 수
 *                 value:
 *                   httpCode: 400
 *                   message: '최대 구성원 수는 0 이상의 정수여야 합니다.'
 *                   errorCode: 'BE1000'
 *               lowerThanCurrentMembers:
 *                 summary: 현재 인원보다 낮은 값을 요청
 *                 value:
 *                   httpCode: 400
 *                   message: '최대 할당 인원수가 현재 활성화된 인원수보다 작을 수 없습니다.'
 *                   errorCode: 'BE1110'
 *               invalidLicenseInfo:
 *                 summary: 라이선스 정보가 유효하지 않음
 *                 value:
 *                   httpCode: 400
 *                   message: '라이선스 정보가 유효하지 않습니다.'
 *                   errorCode: 'BE1015'
 *               licenseShortage:
 *                 summary: 라이선스 부족
 *                 value:
 *                   httpCode: 400
 *                   message: '라이선스 갯수가 부족하여 요청을 처리할 수 없습니다.'
 *                   errorCode: 'BE1016'
 *                   result:
 *                     seats: 1000
 *                     currentTotalMemberMaxCount: 13971
 *                     requestedTotalMemberSeats: 14111
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *       404:
 *         description: 워크스페이스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/license:
 *   get:
 *     summary: 라이선스 정보 조회
 *     description: 현재 시스템의 라이선스 정보를 조회합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: 라이선스 정보 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/LicenseInfo'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               notWatching:
 *                 summary: 라이선스 파일 모니터링 비활성화
 *                 value:
 *                   httpCode: 400
 *                   message: '라이선스 파일 모니터링이 활성화되지 않았습니다.'
 *                   errorCode: 'E0400'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/license:
 *   post:
 *     summary: 라이선스 파일 업로드
 *     description: 새로운 라이선스 파일을 업로드합니다. 기존 라이선스 파일이 유효한 경우에만 업로드가 가능합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - file
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: 라이선스 파일 (.jwt 확장자)
 *     responses:
 *       200:
 *         description: 라이선스 파일 업로드 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/LicenseUploadResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               fileNotFound:
 *                 summary: 파일 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '라이선스 파일이 없습니다.'
 *                   errorCode: 'E0400'
 *               invalidLicense:
 *                 summary: 유효하지 않은 라이선스
 *                 value:
 *                   httpCode: 400
 *                   message: '기존 라이선스 파일이 유효하지 않습니다. 유효한 라이선스 파일을 업로드해주세요.'
 *                   errorCode: 'E0400'
 *               invalidFile:
 *                 summary: 유효하지 않은 파일 형식
 *                 value:
 *                   httpCode: 400
 *                   message: '라이선스 파일은 .jwt 확장자여야 합니다.'
 *                   errorCode: 'E0400'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}/logo:
 *   put:
 *     summary: 워크스페이스 로고 업로드
 *     description: 워크스페이스의 로고를 업로드합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - file
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: 로고 이미지 파일
 *     responses:
 *       200:
 *         description: 로고 업로드 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceLogoUploadResponse'
 *             example:
 *               message: 'Success'
 *               httpCode: 200
 *               data:
 *                 thumbnailUrl: 'https://example.com/thumbnail.jpg'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               fileNotFound:
 *                 summary: 파일 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '파일이 없습니다.'
 *                   errorCode: 'E0400'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}/logo:
 *   delete:
 *     summary: 워크스페이스 로고 삭제
 *     description: 워크스페이스의 로고를 삭제합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     responses:
 *       204:
 *         description: 로고 삭제 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceLogoDeleteResponse'
 *             example:
 *               message: 'Success'
 *               httpCode: 204
 *               data: {}
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/logo/{anything}:
 *   get:
 *     summary: 워크스페이스 로고 조회 (Public)
 *     description: 워크스페이스의 로고를 조회합니다. 인증이 필요하지 않습니다.
 *     tags: [Workspace]
 *     parameters:
 *       - in: path
 *         name: anything
 *         required: true
 *         schema:
 *           type: string
 *         description: 경로 파라미터 (사용되지 않음)
 *       - in: query
 *         name: src
 *         required: true
 *         schema:
 *           type: string
 *         description: 로고 이미지 URL
 *     responses:
 *       200:
 *         description: 로고 이미지 조회 성공
 *         content:
 *           image/png:
 *             schema:
 *               type: string
 *               format: binary
 *           image/jpeg:
 *             schema:
 *               type: string
 *               format: binary
 *           image/gif:
 *             schema:
 *               type: string
 *               format: binary
 *         headers:
 *           x-anything:
 *             schema:
 *               type: string
 *             description: 경로 파라미터 값
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               srcMissing:
 *                 summary: src 파라미터 없음
 *                 value:
 *                   httpCode: 400
 *                   message: 'src 쿼리 파라미터가 필요합니다.'
 *                   errorCode: 'E0400'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}/policy:
 *   get:
 *     summary: 워크스페이스 콘텐츠 보존 정책 조회
 *     description: 워크스페이스의 콘텐츠 보존 정책 목록을 조회합니다. 각 정책의 설정 정보와 현재 값을 반환합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     responses:
 *       200:
 *         description: 정책 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/ExpirationPolicyResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 *   patch:
 *     summary: 워크스페이스 콘텐츠 보존 정책 개별 업데이트
 *     description: 워크스페이스의 특정 콘텐츠 보존 정책을 개별적으로 업데이트합니다. (upsert 방식)
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ExpirationPolicyUpdateRequest'
 *     responses:
 *       200:
 *         description: 정책 업데이트 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       description: '빈 객체'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               missingKey:
 *                 summary: 키 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '키는 필수입니다.'
 *                   errorCode: 'E0400'
 *               missingValue:
 *                 summary: 값 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '값은 필수입니다.'
 *                   errorCode: 'E0400'
 *               invalidValue:
 *                 summary: 유효하지 않은 값
 *                 value:
 *                   httpCode: 400
 *                   message: '값은 -1 이상 9999 이하의 정수값이어야 합니다.'
 *                   errorCode: 'E0400'
 *               invalidUnit:
 *                 summary: 유효하지 않은 단위
 *                 value:
 *                   httpCode: 400
 *                   message: '단위는 DAYS 또는 HOURS 중 하나여야 합니다.'
 *                   errorCode: 'E0400'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 *   post:
 *     summary: 워크스페이스 콘텐츠 보존 정책 생성/업데이트
 *     description: 워크스페이스의 콘텐츠 보존 정책을 생성하거나 업데이트합니다. (upsert 방식) PolicyType이 ALL인 경우 기존 정책을 모두 삭제하고 새로 생성합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/WorkspacePolicyRequest'
 *     responses:
 *       201:
 *         description: 정책 생성/업데이트 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/ExpirationPolicyCreateResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               missingPolicyType:
 *                 summary: 정책 타입 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '정책 타입은 필수입니다.'
 *                   errorCode: 'E0400'
 *               missingValue:
 *                 summary: 정책 값 없음
 *                 value:
 *                   httpCode: 400
 *                   message: '정책 값은 필수입니다.'
 *                   errorCode: 'E0400'
 *               invalidValue:
 *                 summary: 유효하지 않은 정책 값
 *                 value:
 *                   httpCode: 400
 *                   message: '정책 값은 -1 이상의 정수값이어야 합니다.'
 *                   errorCode: 'E0400'
 *               invalidUnit:
 *                 summary: 유효하지 않은 단위
 *                 value:
 *                   httpCode: 400
 *                   message: '단위는 DAYS 또는 HOURS 중 하나여야 합니다.'
 *                   errorCode: 'E0400'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */

/**
 * @swagger
 * /workspace/{workspaceId}/setting:
 *   patch:
 *     summary: 워크스페이스 기능 설정 업데이트
 *     description: 워크스페이스의 특정 기능 설정을 업데이트합니다.
 *     tags: [Workspace]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/WorkspaceFeatureSettingUpdateRequest'
 *     responses:
 *       200:
 *         description: 기능 설정 업데이트 성공
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/Success'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/WorkspaceFeatureSettingsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/BadRequestError'
 *             examples:
 *               badRequest:
 *                 summary: 필수 파라미터 부족
 *                 value:
 *                   httpCode: 400
 *                   message: '기능 설정 키는 필수입니다.'
 *                   errorCode: 'E0400'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       404:
 *         description: 리소스를 찾을 수 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/NotFoundError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
