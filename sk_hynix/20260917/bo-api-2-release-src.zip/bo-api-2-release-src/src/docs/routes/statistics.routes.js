/**
 * @swagger
 * /statistics/members:
 *   get:
 *     summary: 멤버별 통계 조회
 *     description: 멤버별 통계 정보를 조회합니다. 기간별(DAILY/WEEKLY/MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: periodType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *         description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *       - in: query
 *         name: fromDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: toDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: memberId
 *         required: false
 *         schema:
 *           type: string
 *         description: 멤버 ID (선택사항, 특정 멤버만 조회 시 사용)
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *       - in: query
 *         name: filter
 *         required: false
 *         schema:
 *           type: string
 *           enum: [workspaceName, userName, email]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *       - in: query
 *         name: page
 *         required: false
 *         schema:
 *           type: number
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         required: false
 *         schema:
 *           type: number
 *           default: 10
 *         description: 페이지 당 아이템 수
 *       - in: query
 *         name: orderByField
 *         required: false
 *         schema:
 *           type: string
 *           enum: [period, workspaceName, creatorNickName, totalContentCount, totalSeconds, mobileContentCount, mobileSeconds, transcribeDoneCount, transcribeErrorCount, transcribeOtherCount, duration0_1Min, duration1_30Min, duration30_60Min, duration60_120Min, duration120_180Min, durationOver180Min]
 *           default: totalSeconds
 *         description: '정렬 필드'
 *       - in: query
 *         name: sortOrder
 *         required: false
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: '정렬 순서 (asc: 오름차순, desc: 내림차순)'
 *     responses:
 *       200:
 *         description: 멤버별 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MemberStatisticsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/members/system:
 *   get:
 *     summary: 멤버별 통계 조회 (시스템)
 *     description: 시스템 관리자용 멤버별 통계 정보를 조회합니다. 기간별(DAILY/WEEKLY/MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: periodType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *         description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *       - in: query
 *         name: fromDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: toDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: memberId
 *         required: false
 *         schema:
 *           type: string
 *         description: 멤버 ID (선택사항, 특정 멤버만 조회 시 사용)
 *       - in: query
 *         name: workspaceId
 *         required: false
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *       - in: query
 *         name: filter
 *         required: false
 *         schema:
 *           type: string
 *           enum: [workspaceName, userName, email]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         required: false
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         required: false
 *         schema:
 *           type: number
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         required: false
 *         schema:
 *           type: number
 *           default: 10
 *         description: 페이지 당 아이템 수
 *       - in: query
 *         name: orderByField
 *         required: false
 *         schema:
 *           type: string
 *           enum: [period, workspaceName, creatorNickName, totalContentCount, totalSeconds, mobileContentCount, mobileSeconds, transcribeDoneCount, transcribeErrorCount, transcribeOtherCount, duration0_1Min, duration1_30Min, duration30_60Min, duration60_120Min, duration120_180Min, durationOver180Min]
 *           default: totalSeconds
 *         description: '정렬 필드'
 *       - in: query
 *         name: sortOrder
 *         required: false
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: '정렬 순서 (asc: 오름차순, desc: 내림차순)'
 *     responses:
 *       200:
 *         description: 멤버별 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/MemberStatisticsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/workspaces:
 *   get:
 *     summary: 워크스페이스별 통계 조회
 *     description: 워크스페이스별 통계 정보를 조회합니다. 기간별(DAILY/WEEKLY/MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: periodType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *         description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *       - in: query
 *         name: fromDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: toDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: workspaceId
 *         required: true
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *       - in: query
 *         name: filter
 *         required: false
 *         schema:
 *           type: string
 *           enum: [workspaceName]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *       - in: query
 *         name: page
 *         required: false
 *         schema:
 *           type: number
 *           default: 1
 *         description: 페이지 번호
 *       - in: query
 *         name: limit
 *         required: false
 *         schema:
 *           type: number
 *           default: 10
 *         description: 페이지 당 아이템 수
 *       - in: query
 *         name: orderByField
 *         required: false
 *         schema:
 *           type: string
 *           enum: [period, workspaceName, totalContentCount, totalSeconds, mobileContentCount, mobileSeconds, transcribeDoneCount, transcribeErrorCount, transcribeOtherCount, duration0_1Min, duration1_30Min, duration30_60Min, duration60_120Min, duration120_180Min, durationOver180Min]
 *           default: totalSeconds
 *         description: '정렬 필드'
 *       - in: query
 *         name: sortOrder
 *         required: false
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: '정렬 순서 (asc: 오름차순, desc: 내림차순)'
 *     responses:
 *       200:
 *         description: 워크스페이스별 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/WorkspaceStatisticsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/workspaces/system:
 *   get:
 *     summary: 워크스페이스별 통계 조회 (시스템)
 *     description: 시스템 관리자용 워크스페이스별 통계 정보를 조회합니다. 기간별(DAILY/WEEKLY/MONTHLY/YEARLY) 통계를 제공합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: periodType
 *         required: true
 *         schema:
 *           type: string
 *           enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *         description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *       - in: query
 *         name: fromDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: toDate
 *         required: true
 *         schema:
 *           type: string
 *           format: date
 *         description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *       - in: query
 *         name: workspaceId
 *         required: false
 *         schema:
 *           type: string
 *         description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *       - in: query
 *         name: filter
 *         required: false
 *         schema:
 *           type: string
 *           enum: [workspaceName]
 *         description: 검색 필터
 *       - in: query
 *         name: keyword
 *         required: false
 *         schema:
 *           type: string
 *         description: 검색 키워드
 *       - in: query
 *         name: page
 *         required: false
 *         schema:
 *       - in: query
 *         name: limit
 *         required: false
 *         schema:
 *           type: number
 *           default: 10
 *         description: 페이지 당 아이템 수
 *       - in: query
 *         name: orderByField
 *         required: false
 *         schema:
 *           type: string
 *           enum: [period, workspaceName, totalContentCount, totalSeconds, transcribeDoneCount, transcribeErrorCount, transcribeOtherCount, mobileContentCount, mobileSeconds, duration0_1Min, duration1_30Min, duration30_60Min, duration60_120Min, duration120_180Min, durationOver180Min]
 *           default: totalSeconds
 *         description: '정렬 필드'
 *       - in: query
 *         name: sortOrder
 *         required: false
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: '정렬 순서 (asc: 오름차순, desc: 내림차순)'
 *     responses:
 *       200:
 *         description: 워크스페이스별 통계 조회 성공
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/WorkspaceStatisticsResponse'
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/members/download:
 *   post:
 *     summary: 멤버별 통계 다운로드
 *     description: 멤버별 통계 정보를 CSV 파일로 다운로드합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - periodType
 *               - fromDate
 *               - toDate
 *               - workspaceId
 *             properties:
 *               periodType:
 *                 type: string
 *                 enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *                 description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *               fromDate:
 *                 type: string
 *                 format: date
 *                 description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *               toDate:
 *                 type: string
 *                 format: date
 *                 description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *               memberId:
 *                 type: string
 *                 description: 멤버 ID (선택사항, 특정 멤버만 조회 시 사용)
 *               workspaceId:
 *                 type: string
 *                 description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *               filter:
 *                 type: string
 *                 enum: [workspaceName, userName, email]
 *                 description: 검색 필터
 *               keyword:
 *                 type: string
 *                 description: 검색 키워드
 *     responses:
 *       200:
 *         description: 멤버별 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/members/download/system:
 *   post:
 *     summary: 멤버별 통계 다운로드 (시스템)
 *     description: 시스템 관리자용 멤버별 통계 정보를 CSV 파일로 다운로드합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - periodType
 *               - fromDate
 *               - toDate
 *             properties:
 *               periodType:
 *                 type: string
 *                 enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *                 description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *               fromDate:
 *                 type: string
 *                 format: date
 *                 description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *               toDate:
 *                 type: string
 *                 format: date
 *                 description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *               memberId:
 *                 type: string
 *                 description: 멤버 ID (선택사항, 특정 멤버만 조회 시 사용)
 *               workspaceId:
 *                 type: string
 *                 description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *               filter:
 *                 type: string
 *                 enum: [workspaceName, userName, email]
 *                 description: 검색 필터
 *               keyword:
 *                 type: string
 *                 description: 검색 키워드
 *     responses:
 *       200:
 *         description: 멤버별 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/workspaces/download:
 *   post:
 *     summary: 워크스페이스별 통계 다운로드
 *     description: 워크스페이스별 통계 정보를 CSV 파일로 다운로드합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - periodType
 *               - fromDate
 *               - toDate
 *               - workspaceId
 *             properties:
 *               periodType:
 *                 type: string
 *                 enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *                 description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *               fromDate:
 *                 type: string
 *                 format: date
 *                 description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *               toDate:
 *                 type: string
 *                 format: date
 *                 description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *               workspaceId:
 *                 type: string
 *                 description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *               filter:
 *                 type: string
 *                 enum: [workspaceName]
 *                 description: 검색 필터
 *               keyword:
 *                 type: string
 *                 description: 검색 키워드
 *     responses:
 *       200:
 *         description: 워크스페이스별 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 *
 * /statistics/workspaces/download/system:
 *   post:
 *     summary: 워크스페이스별 통계 다운로드 (시스템)
 *     description: 시스템 관리자용 워크스페이스별 통계 정보를 CSV 파일로 다운로드합니다.
 *     tags: [Statistics]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - periodType
 *               - fromDate
 *               - toDate
 *             properties:
 *               periodType:
 *                 type: string
 *                 enum: [DAILY, WEEKLY, MONTHLY, YEARLY]
 *                 description: '기간 타입 (DAILY: 일별, WEEKLY: 주별, MONTHLY: 월별, YEARLY: 연별)'
 *               fromDate:
 *                 type: string
 *                 format: date
 *                 description: 시작 날짜 (YYYY-MM-DD 형식, 필수)
 *               toDate:
 *                 type: string
 *                 format: date
 *                 description: 종료 날짜 (YYYY-MM-DD 형식, 필수)
 *               workspaceId:
 *                 type: string
 *                 description: 워크스페이스 ID (선택사항, 특정 워크스페이스만 조회 시 사용)
 *               filter:
 *                 type: string
 *                 enum: [workspaceName]
 *                 description: 검색 필터
 *               keyword:
 *                 type: string
 *                 description: 검색 키워드
 *     responses:
 *       200:
 *         description: 워크스페이스별 통계 CSV 다운로드 성공
 *         content:
 *           text/csv:
 *             schema:
 *               type: string
 *               format: binary
 *             description: CSV 파일
 *       400:
 *         description: 잘못된 요청
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/BadRequestError'
 *                 - $ref: '#/components/schemas/CommonMissingRequiredParameterError'
 *             examples:
 *               badRequest:
 *                 $ref: '#/components/schemas/BadRequestError/examples/badRequest'
 *               missingParameter:
 *                 $ref: '#/components/schemas/CommonMissingRequiredParameterError/examples/missingParameter'
 *       401:
 *         description: 인증 실패
 *         content:
 *           application/json:
 *             schema:
 *               oneOf:
 *                 - $ref: '#/components/schemas/UnauthorizedError'
 *                 - $ref: '#/components/schemas/MemberInfoNotFoundError'
 *             examples:
 *               unauthorized:
 *                 $ref: '#/components/schemas/UnauthorizedError/examples/unauthorized'
 *               memberInfoNotFound:
 *                 $ref: '#/components/schemas/MemberInfoNotFoundError/examples/memberInfoNotFound'
 *       403:
 *         description: 권한 없음
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CommonMenuPermissionError'
 *             examples:
 *               menuPermissionError:
 *                 $ref: '#/components/schemas/CommonMenuPermissionError/examples/menuPermissionError'
 *       500:
 *         description: 서버 오류
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/InternalServerError'
 */
