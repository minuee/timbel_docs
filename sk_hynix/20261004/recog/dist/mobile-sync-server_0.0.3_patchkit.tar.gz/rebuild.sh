#!/usr/bin/env bash
#
# rebuild.sh — 망분리 서버에서 실행한다. 소스만 바꾼 새 이미지를 만들고 갈아끼운다.
#
# 네트워크를 전혀 타지 않는다. 지금 돌고 있는 이미지(.env 의 IMAGE_VERSION)를
# 베이스로 삼아 src/ 만 교체한다. python / ffmpeg 는 베이스에 이미 들어 있다.
#
# 이 디렉터리에 있어야 하는 것:
#   rebuild.sh  Dockerfile.patch  smoke_test.py  VERSION  src/
#
# 사용법:
#   ./rebuild.sh <새 버전>                 # 예: ./rebuild.sh 0.0.4
#   INSTALL_DIR=/경로 ./rebuild.sh 0.0.4   # 설치 위치가 이 디렉터리의 부모가 아닐 때
#
#   INSTALL_DIR  install.sh 로 설치한 곳 (docker-compose.yml 과 .env 가 있는 곳).
#                생략하면 이 디렉터리의 부모로 본다.
#
# 하는 일:
#   1. 지금 쓰는 이미지 확인 (= 베이스)
#   2. 소스 문법 검사                         ← 실패하면 여기서 중단
#   3. 새 이미지 빌드
#   4. 새 이미지로 임시 컨테이너를 띄워 병합을 한 번 돌려본다  ← 실패하면 여기서 중단
#   5. .env 의 IMAGE_VERSION 을 바꾸고 재기동
#   6. /health 확인. 안 뜨면 이전 버전으로 자동 롤백
#
# 4번까지는 서비스에 손대지 않는다. 지금 돌고 있는 컨테이너는 그대로다.
#
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="$(cd "${INSTALL_DIR:-${HERE}/..}" && pwd)"
ENV_FILE="${INSTALL_DIR}/.env"
NEW_VERSION="${1:-}"
TEST_CONTAINER="mobile-sync-server-patch-smoke"

log()  { printf '\033[1;34m[rebuild]\033[0m %s\n' "$*"; }
ok()   { printf '\033[1;32m[rebuild]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[rebuild] 주의:\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[rebuild] 중단:\033[0m %s\n' "$*" >&2; exit 1; }

cleanup() { docker rm -f "$TEST_CONTAINER" >/dev/null 2>&1 || true; }
trap cleanup EXIT

env_get() { grep -E "^$1=" "$ENV_FILE" | tail -1 | cut -d= -f2- | tr -d '[:space:]'; }
env_set() {
    sed "s|^$1=.*|$1=$2|" "$ENV_FILE" > "${ENV_FILE}.tmp" && mv "${ENV_FILE}.tmp" "$ENV_FILE"
}

# --------------------------------------------------------------- 사전 확인
[[ -n "$NEW_VERSION" ]] || die "새 버전을 지정할 것.  예: ./rebuild.sh 0.0.4"
command -v docker >/dev/null 2>&1 || die "docker 가 없다."
docker version >/dev/null 2>&1 || die "docker 데몬이 응답하지 않는다."

if docker compose version >/dev/null 2>&1; then
    COMPOSE=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
    COMPOSE=(docker-compose)
else
    die "docker compose 도 docker-compose 도 없다."
fi

for f in Dockerfile.patch smoke_test.py; do
    [[ -f "${HERE}/${f}" ]] || die "${f} 이 없다. 이 디렉터리(${HERE})에 같이 두어야 한다."
done
[[ -d "${HERE}/src/recog" ]] || die "src/recog 가 없다. 수정한 소스를 ${HERE}/src 에 두어야 한다."
[[ -f "$ENV_FILE" && -f "${INSTALL_DIR}/docker-compose.yml" ]] \
    || die "${INSTALL_DIR} 에 .env / docker-compose.yml 이 없다. INSTALL_DIR=/설치경로 로 지정할 것."

IMAGE_NAME="$(env_get IMAGE_NAME)"
OLD_VERSION="$(env_get IMAGE_VERSION)"
BASE_IMAGE="${IMAGE_NAME}:${OLD_VERSION}"
NEW_IMAGE="${IMAGE_NAME}:${NEW_VERSION}"
RUN_UID="$(env_get RUN_UID)"; RUN_UID="${RUN_UID:-10001}"
RUN_GID="$(env_get RUN_GID)"; RUN_GID="${RUN_GID:-10001}"
HOST_PORT="$(env_get HOST_PORT)"; HOST_PORT="${HOST_PORT:-9995}"

[[ "$NEW_VERSION" != "$OLD_VERSION" ]] || die "지금 쓰는 버전(${OLD_VERSION})과 같다. 다른 번호를 줄 것."
# 같은 태그를 덮어쓰면 롤백할 이미지가 사라진다.
if docker image inspect "$NEW_IMAGE" >/dev/null 2>&1; then
    die "${NEW_IMAGE} 이 이미 있다. 다른 번호를 줄 것.  (있는 것: docker images ${IMAGE_NAME})"
fi

log "설치 위치 : ${INSTALL_DIR}"
log "베이스    : ${BASE_IMAGE}  (지금 쓰는 이미지)"
log "새 이미지 : ${NEW_IMAGE}"
echo

# ------------------------------------------------------------- 1. 베이스
log "1/6 베이스 이미지 확인"
docker image inspect "$BASE_IMAGE" >/dev/null 2>&1 \
    || die "${BASE_IMAGE} 이 서버에 없다. docker images ${IMAGE_NAME} 로 확인할 것."
ok "있음"
echo

# --------------------------------------------------------- 2. 문법 검사
# 이미지 안의 python 으로 검사한다. 서버에 python 이 없어도 된다.
# 읽기 전용으로 붙이므로 __pycache__ 가 생기지 않는다.
log "2/6 소스 문법 검사"
docker run --rm --entrypoint python --user "${RUN_UID}:${RUN_GID}" \
    -v "${HERE}/src:/chk:ro" "$BASE_IMAGE" -c '
import pathlib, sys
bad = 0
for p in sorted(pathlib.Path("/chk").rglob("*.py")):
    try:
        compile(p.read_bytes(), str(p).replace("/chk/", "src/"), "exec")
    except SyntaxError as e:
        bad += 1
        print(f"  {e.filename}:{e.lineno}: {e.msg}", file=sys.stderr)
sys.exit(1 if bad else 0)
' || die "문법 오류가 있다. 위 파일:줄 을 고친 뒤 다시 실행할 것."
ok "통과"
echo

# --------------------------------------------------------------- 3. 빌드
log "3/6 이미지 빌드"
printf '%s\n' "$NEW_VERSION" > "${HERE}/VERSION"
build() {
    docker build --build-arg "BASE_IMAGE=${BASE_IMAGE}" \
        --tag "$NEW_IMAGE" --file "${HERE}/Dockerfile.patch" "$HERE"
}
if ! build; then
    # BuildKit 설정에 따라 로컬에 있는 베이스를 두고 레지스트리를 조회하려다
    # 실패하는 경우가 있다. 구형 빌더는 로컬 이미지만 보므로 그걸로 한 번 더.
    warn "빌드 실패 — 구형 빌더(DOCKER_BUILDKIT=0)로 다시 시도한다."
    DOCKER_BUILDKIT=0 build || die "빌드 실패. 위 메시지를 확인할 것."
fi
ok "빌드 완료"
echo

# ------------------------------------------------------- 4. 동작 검증
log "4/6 새 이미지 동작 검증 (임시 컨테이너, 서비스에는 영향 없음)"
cleanup
docker run -d --name "$TEST_CONTAINER" --user "${RUN_UID}:${RUN_GID}" "$NEW_IMAGE" >/dev/null \
    || die "임시 컨테이너가 기동하지 않는다."
sleep 2
if [[ "$(docker inspect -f '{{.State.Running}}' "$TEST_CONTAINER" 2>/dev/null)" != "true" ]]; then
    docker logs --tail 60 "$TEST_CONTAINER" >&2 2>&1 || true
    die "새 이미지가 기동 직후 죽었다. 위 로그 확인. (서비스는 그대로 ${OLD_VERSION} 로 돌고 있다)"
fi
docker cp "${HERE}/smoke_test.py" "${TEST_CONTAINER}:/tmp/smoke_test.py" >/dev/null
if ! docker exec "$TEST_CONTAINER" python /tmp/smoke_test.py; then
    docker logs --tail 60 "$TEST_CONTAINER" >&2 2>&1 || true
    die "검증 실패. (서비스는 그대로 ${OLD_VERSION} 로 돌고 있다)"
fi
cleanup
ok "검증 통과"
echo

# ------------------------------------------------------------ 5. 교체
log "5/6 서비스 교체 (${OLD_VERSION} → ${NEW_VERSION})"
cp "$ENV_FILE" "${ENV_FILE}.bak.$(date +%Y%m%d-%H%M%S)"
env_set IMAGE_VERSION "$NEW_VERSION"
( cd "$INSTALL_DIR" && "${COMPOSE[@]}" --env-file .env up -d )
echo

# ------------------------------------------------------- 6. 기동 확인
HEALTH="http://127.0.0.1:${HOST_PORT}/health"
log "6/6 기동 확인 (${HEALTH})"
for attempt in $(seq 1 30); do
    if curl -fsS --max-time 3 "$HEALTH" >/dev/null 2>&1; then
        ok "정상 기동 — 이제 ${NEW_IMAGE} 로 돌고 있다"
        echo
        echo "  로그    : docker logs -f mobile-sync-server"
        echo "  되돌리기: .env 의 IMAGE_VERSION=${OLD_VERSION} 로 바꾸고"
        echo "            cd ${INSTALL_DIR} && ${COMPOSE[*]} --env-file .env up -d"
        exit 0
    fi
    sleep 2
done

warn "60초 안에 /health 가 응답하지 않았다. 최근 로그:"
docker logs --tail 60 mobile-sync-server 2>&1 || true
warn "이전 버전(${OLD_VERSION})으로 되돌린다."
env_set IMAGE_VERSION "$OLD_VERSION"
( cd "$INSTALL_DIR" && "${COMPOSE[@]}" --env-file .env up -d )
die "${NEW_VERSION} 기동 실패 — ${OLD_VERSION} 로 롤백했다."
