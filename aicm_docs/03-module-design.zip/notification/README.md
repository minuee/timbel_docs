# Notification 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | NotificationModule |
| 문서 코드 | MS-NTF |
| 상태 | `미착수` |
| 기능정의서 | [FD-NTF-알림](../../01-requirements/features/FD-NTF-알림.md) |
| 데이터 모델 | [notification-module.md](./data.md) |
| 프로세스 흐름 | [flows/notification/](../../01-requirements/flows/notification/) |

---

## 모듈 책임

<!-- TODO: 인앱 알림, 이메일 알림, 알림 설정, 구독 관리 -->

---

## 핵심 엔티티

| 엔티티 | 설명 |
|--------|------|
| Notification | |
| Subscription | |
| NotificationSetting | |

---

## 의존 관계

<!-- TODO: Notification → Document (읽기). EventBus에서 document.published, approval.approved, community.comment_created 등 소비 -->

```mermaid
graph LR
    %% TODO: 의존 관계 다이어그램 작성
```

---

## 인프라 사용 요약

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | | |
| Redis / BullMQ | | |
| Elasticsearch | | |
| MinIO | | |
| EventBus | | |
| 외부 서비스 클라이언트 | | |
