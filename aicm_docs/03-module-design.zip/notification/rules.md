# Notification 비즈니스 규칙

> 기능정의서: [FD-NTF-알림](../../01-requirements/features/FD-NTF-알림.md)
> API 스펙: [api.md](api.md)

---

## 상태 전이

<!-- TODO: 알림 읽음/안읽음 상태 전이 -->

```mermaid
stateDiagram-v2
    %% TODO: 상태 전이 다이어그램 작성
```

---

## 규칙 카탈로그

<!-- TODO: 18종 알림 유형, 채널별 분기, 사용자 설정 우선순위, 묶음 처리 등 -->

### BR-NTF-001: {규칙 이름}

- **트리거**:
- **조건**:
- **동작**:
- **위반 시**:
- **근거**:
