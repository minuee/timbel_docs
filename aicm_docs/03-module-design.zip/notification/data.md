# NotificationModule — RDB 엔티티

> 인앱 알림, 구독 관리, 알림 설정

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    %% Notification, Subscription, NotificationSetting은 서로 FK 없이 독립적이다.
    %% user_id(외부 UserService UUID)로 논리적으로 연결된다.

    Notification {
        UUID id PK
        UUID user_id
        VARCHAR type
        VARCHAR title
        TEXT body
        VARCHAR resource_type
        UUID resource_id
        BOOLEAN is_read
        TIMESTAMPTZ read_at
    }

    Subscription {
        UUID id PK
        UUID user_id
        VARCHAR target_type
        UUID target_id
    }

    NotificationSetting {
        UUID id PK
        UUID user_id
        JSONB settings
    }
```

---

## 2. 엔티티 필드

### 2.1 Notification

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID | 수신자 (외부 UserService의 userId, FK 없음) |
| type | VARCHAR(50) | 알림 유형 |
| title | VARCHAR(500) | 알림 제목 |
| body | TEXT (nullable) | 알림 본문 |
| resource_type | VARCHAR(30) (nullable) | 관련 리소스 타입: `document`, `approval`, `shared_content` |
| resource_id | UUID (nullable) | 관련 리소스 ID (클릭 시 이동 대상) |
| is_read | BOOLEAN (default false) | 읽음 여부 |
| read_at | TIMESTAMPTZ (nullable) | 읽은 시각 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `type`은 앱 레벨에서 검증 — 알림 유형이 지속적으로 확장될 수 있으므로 CHECK 제약 대신 앱 레벨 검증
- `resource_type`과 `resource_id`는 함께 null이거나 함께 값이 있어야 한다 (앱 레벨 검증)
- `is_read = true`이면 `read_at`에 값이 있어야 한다 (앱 레벨 검증)

#### 설계 결정

**알림 유형 (type)**
— 현재 정의된 유형: `comment_on_my_doc`, `reply_to_comment`, `approval_requested`, `approval_approved`, `approval_rejected`, `approval_withdrawn`, `approval_step_approved`, `approval_step_rejected`, `approval_next_step`, `approval_bypassed`, `scheduled_publish_done`, `scheduled_publish_failed`, `shared_content_modified`, `embedding_completed`, `embedding_failed`, `draft_stale`, `ai_summary_completed`, `notice_published`, `notice_updated`, `notice_confirmation_due`. CHECK 제약 대신 앱 레벨 검증을 사용하여 유형 추가 시 마이그레이션 없이 확장 가능하다.

다단계 승인 관련 알림 유형:
- `approval_step_approved`: 다단계 승인에서 현재 단계 통과 알림 (요청자에게). "N단계 승인이 완료되었습니다"
- `approval_step_rejected`: 다단계 승인에서 단계 반려 알림 (요청자에게). "N단계에서 반려되었습니다"
- `approval_next_step`: 다음 단계 승인권자에게 승인 요청 도착 알림. "OO 문서의 N단계 승인 요청이 도착했습니다"
- `approval_bypassed`: 긴급 발행 시 관리자 전원에게 알림. "OO 문서가 승인 우회로 긴급 발행되었습니다" (감사 목적)

**EventBus + BullMQ 기반 발송**
— 도메인 이벤트(EventBus, Best-effort)로 트리거되고, 내부 BullMQ `notification` 큐에서 실제 발송한다. 인앱 알림은 필수이며, 이메일 발송은 NotificationSetting에 따라 선택적으로 수행한다.

**임베딩 완료 묶음 알림**
— 임베딩 완료 알림은 개별 건이 아닌 "N건 검색 반영 완료" 형태의 요약 알림으로 묶어 발송한다. 대량 임베딩 시 알림 폭주를 방지한다.

**인앱 알림 전용 테이블**
— 이 테이블은 인앱 알림만 저장한다. 이메일 발송 이력은 별도로 관리하지 않으며, 발송 실패는 BullMQ 큐 레벨에서 재시도한다.

**강제 발송 패턴**
— 공지 알림(`notice_*`)은 Subscription 테이블과 무관하게 `Document.notice_options.notification_target_type/ids`에 따라 대상을 산출하여 발송한다. NotificationSetting에서 사용자가 비활성화하더라도 인앱 알림은 항상 발송된다. [FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md) §5.2 [BR-NTC-038] 참조.

**updated_at 없음**
— 알림은 생성 후 `is_read`/`read_at`만 변경되는 단순 갱신이므로 `updated_at`을 별도로 관리하지 않는다.

---

### 2.2 Subscription

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID | 구독자 (외부 UserService의 userId, FK 없음) |
| target_type | VARCHAR(20) | 구독 대상 유형: `board` |
| target_id | UUID | 구독 대상 ID |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(user_id, target_type, target_id)` — 동일 대상 중복 구독 방지
- `CHECK (target_type IN ('board'))` — 허용된 구독 대상 유형만

#### 설계 결정

**게시판 구독**
— 사용자가 관심 게시판을 구독하면 새 문서 등록 시 알림을 받는다. 게시판은 재귀 트리 구조이므로, 상위 게시판을 구독하면 해당 게시판의 직접 문서에 대한 알림을 받는다. 피드 페이지에서 구독 대상의 최신 문서를 통합 표시한다.

**updated_at 없음**
— 구독은 추가/삭제만 존재하며 수정 개념이 없다.

---

### 2.3 NotificationSetting

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID (UNIQUE) | 사용자당 1건 (외부 UserService의 userId, FK 없음) |
| settings | JSONB (default '{}') | 알림 유형별 on/off 설정 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(user_id)` — 사용자당 설정 레코드 1건

#### 설계 결정

**JSONB 단일 필드 방식**
— 모든 알림 설정을 JSONB 단일 필드에 저장한다. 알림 유형이 추가되어도 스키마 변경 없이 확장 가능하다. 설정이 없는 유형은 시스템 기본값(`inapp: true, email: false`)을 적용한다.

**설정 구조 예시**

```json
{
  "comment_on_my_doc": { "inapp": true, "email": false },
  "approval_requested": { "inapp": true, "email": true }
}
```

---

## 3. DDL 및 인덱스

### 3.1 Notification

```sql
CREATE TABLE notification (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       UUID NOT NULL,
  type          VARCHAR(50) NOT NULL,
  title         VARCHAR(500) NOT NULL,
  body          TEXT,
  resource_type VARCHAR(30),
  resource_id   UUID,
  is_read       BOOLEAN NOT NULL DEFAULT false,
  read_at       TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 안 읽은 알림 목록: 배지 카운트 + 드롭다운
CREATE INDEX idx_notification_user_unread
  ON notification (user_id, created_at DESC)
  WHERE is_read = false;

-- 전체 알림 목록: 알림 센터 페이지네이션
CREATE INDEX idx_notification_user_created
  ON notification (user_id, created_at DESC);
```

### 3.2 Subscription

```sql
CREATE TABLE subscription (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL,
  target_type VARCHAR(20) NOT NULL,
  target_id   UUID NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_subscription UNIQUE (user_id, target_type, target_id),
  CONSTRAINT chk_subscription_target_type CHECK (target_type IN ('board'))
);

-- 대상별 구독자 목록: 새 문서 등록 시 구독자에게 알림 발송
CREATE INDEX idx_subscription_target
  ON subscription (target_type, target_id);
```

### 3.3 NotificationSetting

```sql
CREATE TABLE notification_setting (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL,
  settings   JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_notification_setting_user UNIQUE (user_id)
);
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [community.md](../community/data.md) — Comment, Like (알림 트리거 발생원)
- [aggregation.md](../aggregation/data.md) — AggregationCache (독립 모듈)
- [approval.md](../approval/data.md) — Approval (승인 알림 트리거)
- [document.md](../document/data.md) — Document (문서 관련 알림)
- [Redis 전략](../../02-architecture/data/aicm/redis.md) — BullMQ 큐 (notification)
