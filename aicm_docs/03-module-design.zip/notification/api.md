# Notification API 스펙

> 기능정의서: [FD-NTF-알림](../../01-requirements/features/FD-NTF-알림.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 엔드포인트 요약

<!-- TODO: 알림 목록 조회, 읽음 처리, 알림 설정, 구독 관리 -->

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| | | | |

---

## 상세 API

### `{METHOD}` /api/notifications/{path}

**설명**:

**권한**:

**Request**:

- Path params:
- Query params:
- Body:

```typescript
// TODO: Request DTO
```

**Response** (`200`):

```typescript
// TODO: Response DTO
```

**에러 코드**:

| HTTP | 코드 | 설명 |
|------|------|------|
| | | |

**비즈니스 규칙 참조**: BR-NTF-xxx
