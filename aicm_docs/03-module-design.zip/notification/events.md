# Notification 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [04-async-event-architecture.md](../../02-architecture/04-async-event-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 발행 이벤트

<!-- TODO: NotificationModule은 주로 소비 전용이지만 notification BullMQ 큐를 내부적으로 사용 -->

### {event.name}

- **티어**:
- **채널**:
- **트리거**:
- **페이로드**:

```typescript
// TODO: 이벤트 페이로드 인터페이스
```

- **소비자**:

---

## 소비 이벤트

<!-- TODO: document.published, document.deleted, document.expired, approval.approved, approval.delete_approved, community.comment_created -->

| 이벤트 | 발행자 | 채널 | 처리 내용 |
|--------|--------|------|----------|
| | | | |

---

## 외부 서비스 호출

<!-- TODO: 이메일 발송 서비스 등 -->

| 클라이언트 | 호출 시점 | 요청 페이로드 | 응답 |
|-----------|----------|-------------|------|
| | | | |
