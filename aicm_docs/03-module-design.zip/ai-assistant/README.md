# AI Assistant 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | AI AssistantModule |
| 문서 코드 | MS-AIA |
| 상태 | `draft` |
| 기능정의서 | [FD-AI-AI어시스턴트](../../01-requirements/features/FD-AI-AI어시스턴트.md) (§1~6 AI 기능, §3 프롬프트 관리), [FD-EMB-임베딩파이프라인](../../01-requirements/features/FD-EMB-임베딩파이프라인.md) |
| 데이터 모델 | [data.md](./data.md) |

---

## 모듈 책임

AI AssistantModule은 AICM의 **AI 기능 오케스트레이션 허브**로, LLM Orchestrator와 retrieval-service를 경유하여 AI 기능을 조율한다.

| 영역 | 설명 |
|------|------|
| 문서 요약 (자동) | 문서 `published` 전환 시 `ai-summary` 큐를 통해 자동 요약 생성. Document.auto_summary/summary_status 갱신 [BR-AIA-001] |
| 문서 요약 (수동) | 사용자 요청 시 실시간 SSE 스트리밍으로 요약 생성. AiSummaryCache에 결과 캐싱 [BR-AIA-004] |
| AI 글쓰기 개선 | 에디터 내 블록/문서 단위 텍스트 개선. SSE 스트리밍 응답, LlmOrchestratorClient 경유 [BR-AIA-009] |
| AI 태그 추천 | 문서 본문 분석 → 기존 태그 풀에서 적합 태그 추천. 새 태그 제안은 별도 분리 [BR-AIA-024] |
| 프롬프트 슬롯/버전 관리 | 기능별 PromptSlot 관리, 버전 이력(append-only), 롤백, 테스트 [BR-AIA-012] |
| 임베딩 파이프라인 오케스트레이션 | `embedding` 큐 관리(관리자 수동 재처리, DLQ 재투입, 일괄 재임베딩), embedding_status 갱신 [BR-EMB-001] |
| AI 사용 이력/통계 | AiUsageLog 비동기 기록, AiFeedback 수집, 관리자 통계 대시보드 [BR-AIA-017] |
| Hallucination 탐지 | RAG 답변의 출처 검증(grounding check), 신뢰도 점수, 면책 문구 [BR-AIA-020] |

### 현재 범위 참고

| 항목 | 설명 |
|------|------|
| 글쓰기 개선 호출 주체 | 에디터 내 실시간 호출은 DocumentModule이 LlmOrchestratorClient를 직접 호출 (단순 프록시 패턴). AI AssistantModule은 프롬프트 슬롯 제공 + 사용 이력 기록을 담당 |
| RAG 답변 | RAG 검색/답변 자체는 SearchModule 소관. AI AssistantModule은 Hallucination 탐지 로직과 grounding 정보 제공을 담당 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — data.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **PromptSlot** | 기능별 프롬프트 슬롯. slot_key(UNIQUE)로 식별, feature_group(summary/writing/tag) 분류, active_version_id로 현재 활성 버전 추적 |
| **PromptVersion** | 프롬프트 버전 이력. append-only(불변), 롤백은 PromptSlot.active_version_id 변경으로 구현 |
| **AiUsageLog** | AI 기능 호출 이력. feature_type별 분류, 입력 해시(원문 미저장), 토큰 수/응답 시간 기록 |
| **AiFeedback** | AI 결과 피드백(positive/negative). AiUsageLog에 종속, 부정 피드백 시 사유 기록 |
| **AiSummaryCache** | 수동 요약 캐시. document_id + document_version_id + summary_type + content_hash 조합으로 캐시 히트 판단 |
| **EmbeddingTask** | 임베딩 Job 실행 이력. 문서 수준 embedding_status와 별도로 Job별 상태/진행률/에러 추적 |
| **EmbeddingChunk** | 청크별 임베딩 상태. block_ids로 블록↔청크 역추적, content_hash로 변경 감지, partial 재시도 지원 |

> 7개 엔티티 모두 data.md에 정의되어 있다. PromptSlot, PromptVersion은 FD-AI §8.1~8.2, AiUsageLog, AiFeedback, AiSummaryCache는 FD-AI §8.3~8.5, EmbeddingTask, EmbeddingChunk는 FD-EMB §3.1~3.2가 원천이다.

---

## 의존 관계

```mermaid
graph LR
    AIA["<b>AI AssistantModule</b>"]

    Doc["DocumentModule"]

    AIA -->|"읽기"| Doc

    Admin["AdminModule"] -->|"읽기"| AIA

    LLM["LlmOrchestratorClient<br/>(외부)"]
    Retrieval["RetrievalServiceClient<br/>(외부)"]

    AIA -->|"AI 기능 호출"| LLM
    AIA -->|"임베딩 요청"| Retrieval

    classDef hub fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef consumer fill:#f3f4f6,stroke:#6b7280
    classDef external fill:#fef3c7,stroke:#d97706

    class AIA hub
    class Doc provider
    class Admin consumer
    class LLM,Retrieval external
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| AIA → Document | DocumentModule | 읽기 | AI 기능 대상 문서·블록 조회, Document.auto_summary/summary_status 갱신, embedding_status 갱신 |
| Admin → AIA | AdminModule | 읽기 | 관리자 대시보드에서 프롬프트 통계, 임베딩 대시보드, AI 사용 통계 조회 |
| AIA → LlmOrchestratorClient | 외부 서비스 | HTTP | AI 요약, 글쓰기 개선, 태그 추천, 프롬프트 테스트 |
| AIA → RetrievalServiceClient | 외부 서비스 | HTTP | 임베딩 상태 확인, 벡터 삭제, 임베딩 요청 |

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | PromptSlot, PromptVersion, AiUsageLog, AiFeedback, AiSummaryCache, EmbeddingTask, EmbeddingChunk |
| Redis / BullMQ | ● | `ai-summary` 큐(자동 요약), `embedding` 큐(관리자 수동 재임베딩/DLQ 재투입), 서킷브레이커 상태 |
| Elasticsearch | — | — |
| MinIO | — | — |
| EventBus | ● 발행/소비 | **발행**: `ai.summary.completed`, `ai.summary.failed`, `ai.cache.invalidated`, `ai.usage.logged`, `prompt.updated`, `embedding.completed`, `embedding.failed`, `embedding.progress`. **소비**: `document.published`, `document.content-updated`, `document.deleted`, `document.suspended`, `document.unsuspended`, `shared-content.updated` |
| 외부 서비스 클라이언트 | ● | LlmOrchestratorClient (AI 기능 + 프롬프트 테스트), RetrievalServiceClient (임베딩) |

---

## 외부 서비스 미연동 시 Graceful Degradation

LLM Orchestrator 또는 retrieval-service가 부재하거나 조직에서 AI 기능을 끈 경우에도 문서 관리·키워드 검색 등 핵심 기능이 정상 동작하도록 방어 코드를 적용한다.

| 구분 | 비활성 시 영향 | 핵심 기능 영향 |
|------|--------------|--------------|
| 자동 요약 | 자동 요약 미생성, 수동 요약 API `403 AI_FEATURE_DISABLED` | **없음** — 문서 발행/조회 정상 |
| 글쓰기 개선 | 글쓰기 개선 API `403 AI_FEATURE_DISABLED` | **없음** — 에디터 기능 정상 |
| 태그 추천 | 태그 추천 API `403 AI_FEATURE_DISABLED` | **없음** — 수동 태그 입력 정상 |

> **원칙**: AI 기능은 모두 부가 기능이다. 비활성이면 해당 API에서 `403`을 반환하고, 프론트엔드는 운영 설정에 따라 해당 UI를 숨긴다.

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `ai.summary.queue_lag` | ai-summary 큐 대기 Job 수 | BullMQ Dashboard |
| `ai.summary.failure_rate` | 자동 요약 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `ai.summary.latency_ms` | 자동 요약 평균 처리 시간 | Worker 메트릭 |
| `embedding.queue_lag` | embedding 큐 대기 Job 수 | BullMQ Dashboard |
| `embedding.failure_rate` | 임베딩 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `ai.usage.daily_count` | 일간 AI 기능 호출 수 | AiUsageLog 집계 |
| `ai.quota.usage_percent` | 일일 AI 쿼터 사용률 | AiUsageLog 카운트 / `lm:ai.daily_quota` |
| `circuit.llm.state_change` | LlmOrchestratorClient 서킷 상태 전이 | Redis 키 변경 감지 |
| `circuit.retrieval.state_change` | RetrievalServiceClient 서킷 상태 전이 | Redis 키 변경 감지 |

---

## 외부 설정값 카탈로그

| 설정 키 | 기본값 | 용도 | 참조 |
|---------|--------|------|------|
| `lm:ai.daily_quota` | 1000 | 조직 일일 AI 호출 횟수 제한 | BR-AIA-031 |
| `lm:ai.concurrent_requests` | 10 | 테넌트당 동시 AI 요청 수 | BR-AIA-030 |
| `lm:ai.summary_max_input_tokens` | 32000 | 요약 최대 입력 토큰 | BR-AIA-032 |
| `lm:ai.writing_max_input_tokens` | 8000 | 글쓰기 개선 최대 입력 토큰 | BR-AIA-032 |
| `lm:ai.max_regeneration_count` | 5 | 동일 블록 재생성 최대 횟수 | BR-AIA-036 |
| `pm:ai.tag_recommend_min_length` | 100 | 태그 추천 최소 본문 길이 (자) | BR-AIA-029 |
| `pm:ai.summary_max_retries` | 3 | 자동 요약 최대 재시도 횟수 | BR-AIA-002 |
| `pm:ai.confidence_threshold_high` | 0.8 | 신뢰도 상한 임계값 | BR-AIA-022 |
| `pm:ai.confidence_threshold_low` | 0.5 | 신뢰도 하한 임계값 | BR-AIA-022 |
| `pm:ai.usage_log_retention_years` | 1 | AI 사용 이력 보관 기간 (년) | schedule.md §2.3 |
| `sc:ai.summary_recon_cron` | `*/30 * * * *` | 요약 보정 배치 주기 | schedule.md §2.2 |
| `sc:ai.embedding_recon_cron` | `*/30 * * * *` | 임베딩 보정 배치 주기 | schedule.md §2.1 |
| `sc:ai.usage_archive_cron` | `0 2 1 * *` | 사용 이력 아카이빙 주기 | schedule.md §2.3 |
| `sc:ai.partial_timeout_cron` | `*/10 * * * *` | partial 상태 타임아웃 체크 주기 | schedule.md §2.4 |
| `pm:embedding.partial_max_duration_min` | 60 | partial 상태 최대 체류 시간 (분) | BR-EMB-002 |
| `pm:embedding.max_retries` | 3 | 임베딩 최대 재시도 횟수 | BR-EMB-010 |
| `pm:embedding.concurrency` | 3 | 임베딩 큐 동시 처리 워커 수 | events.md |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-AI-AI어시스턴트](../../01-requirements/features/FD-AI-AI어시스턴트.md) | 기능정의서 — AI 기능 원천 (§1~6, §7 규칙, §10 에러) |
| [FD-EMB-임베딩파이프라인](../../01-requirements/features/FD-EMB-임베딩파이프라인.md) | 기능정의서 — 임베딩 파이프라인 원천 |
| [data.md](./data.md) | RDB 엔티티 — PromptSlot, PromptVersion, AiUsageLog, AiFeedback, AiSummaryCache, EmbeddingTask, EmbeddingChunk |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 엔드포인트 권한 (manage_prompts, manage_embedding) |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 이벤트 신뢰성 티어 |
| [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md) | BullMQ/EventBus 규칙 |
