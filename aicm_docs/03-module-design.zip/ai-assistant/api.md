# AI Assistant API 스펙

> 기능정의서: [FD-AI-AI어시스턴트](../../01-requirements/features/FD-AI-AI어시스턴트.md), [FD-EMB-임베딩파이프라인](../../01-requirements/features/FD-EMB-임베딩파이프라인.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 엔드포인트 요약

### AI 기능 (일반 사용자)

| # | 메서드 | 경로 | 설명 | 권한 |
|---|--------|------|------|------|
| 1 | GET | `/api/documents/:documentId/auto-summary` | 자동 요약 조회 | `VIEW` — 문서 읽기 권한 |
| 2 | POST | `/api/documents/:documentId/summary` | 수동 요약 요청 (SSE) | `VIEW` — 문서 읽기 권한 |
| 3 | POST | `/api/documents/:documentId/writing-improve` | 글쓰기 개선 (SSE) | `EDIT` — 문서 편집 권한 |
| 4 | POST | `/api/documents/:documentId/tag-recommend` | AI 태그 추천 | `EDIT` — 문서 편집 권한 |
| 5 | POST | `/api/documents/:documentId/ai-feedback` | AI 피드백 등록 | `VIEW` — 문서 읽기 권한 |

### 프롬프트 관리 (관리자)

| # | 메서드 | 경로 | 설명 | 권한 |
|---|--------|------|------|------|
| 6 | GET | `/api/admin/prompt-slots` | 프롬프트 슬롯 목록 | `manage_prompts` |
| 7 | GET | `/api/admin/prompt-slots/:slotId` | 슬롯 상세 + 버전 이력 | `manage_prompts` |
| 8 | POST | `/api/admin/prompt-slots/:slotId/versions` | 새 버전 생성 | `manage_prompts` |
| 9 | POST | `/api/admin/prompt-slots/:slotId/rollback` | 프롬프트 롤백 | `manage_prompts` |
| 10 | POST | `/api/admin/prompt-slots/:slotId/test` | 프롬프트 테스트 | `manage_prompts` |

### 임베딩 관리 (관리자)

| # | 메서드 | 경로 | 설명 | 권한 |
|---|--------|------|------|------|
| 11 | GET | `/api/admin/embedding/dashboard` | 임베딩 대시보드 | `manage_embedding` |
| 12 | POST | `/api/admin/embedding/retry` | 임베딩 수동 재처리 | `manage_embedding` |
| 13 | POST | `/api/admin/embedding/dlq/requeue` | DLQ 재투입 | `manage_embedding` |
| 14 | POST | `/api/admin/embedding/re-embed` | 일괄 재임베딩 | `manage_embedding` |

### AI 사용 통계 (관리자)

| # | 메서드 | 경로 | 설명 | 권한 |
|---|--------|------|------|------|
| 15 | GET | `/api/admin/ai/usage-stats` | AI 사용 통계 대시보드 | `manage_prompts` |

---

## 상세 API — AI 기능

### 1. `GET` /api/documents/:documentId/auto-summary

**설명**: 문서의 자동 생성 요약을 조회한다. `published` 전환 시 비동기로 생성된 요약 결과를 반환한다.

**권한**: `VIEW` — 해당 문서 읽기 권한

**Request**:

- Path params: `documentId` (UUID) — 대상 문서 ID

**Response** (`200`):

```typescript
interface GetAutoSummaryResponse {
  documentId: string;
  summaryStatus: 'none' | 'pending' | 'processing' | 'completed' | 'failed';
  autoSummary: string | null;
  contentHash: string;
  updatedAt: string;  // ISO 8601
}
```

| 필드 | 설명 |
|------|------|
| `summaryStatus` | `none`: 요약 미요청, `pending`: 큐 대기, `processing`: 처리 중, `completed`: 완료, `failed`: 최종 실패 |
| `autoSummary` | `completed`일 때만 값 존재. 나머지 상태에서는 `null` |

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 403 | `AIA_FEATURE_DISABLED` | 자동 요약 비활성 | BR-AIA-033 |
| 404 | `DOC_NOT_FOUND` | 문서 미존재 | — |

**비즈니스 규칙 참조**: BR-AIA-001, BR-AIA-003, BR-AIA-033

---

### 2. `POST` /api/documents/:documentId/summary

**설명**: 수동 요약을 요청한다. 캐시 히트 시 JSON, 미스 시 SSE 스트리밍으로 응답한다.

**권한**: `VIEW` — 해당 문서 읽기 권한

**Request**:

- Path params: `documentId` (UUID) — 대상 문서 ID
- Body:

```typescript
interface RequestManualSummaryDto {
  summaryType: 'oneline' | 'keypoints' | 'section' | 'custom';
  customInstruction?: string;  // summaryType='custom'일 때 필수
  forceRegenerate?: boolean;   // true면 캐시 무시, 재요약 [BR-AIA-005]
}
```

**Response — 캐시 히트** (`200`, `Content-Type: application/json`):

```typescript
interface CachedSummaryResponse {
  cached: true;
  summaryId: string;
  summaryText: string;
  summaryType: string;
  createdAt: string;  // ISO 8601
}
```

**Response — 캐시 미스 / 재생성** (`200`, `Content-Type: text/event-stream`):

```
event: chunk
data: {"content":"요약 텍스트 일부..."}

event: done
data: {"summaryId":"<uuid>","summaryType":"oneline","modelName":"gpt-4o","tokenCount":512}

event: error
data: {"errorCode":"AI_SERVICE_TIMEOUT","message":"AI 서비스 응답 시간 초과"}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `AIA_CONTENT_TOO_LONG` | 입력 토큰 > `lm:ai.summary_max_input_tokens` | BR-AIA-032 |
| 400 | `AIA_CONTENT_TOO_SHORT` | 본문 분량 미달 | BR-AIA-029 |
| 403 | `AIA_FEATURE_DISABLED` | 자동 요약 비활성 | BR-AIA-033 |
| 403 | `AIA_SENSITIVE_RESTRICTED` | 민감 등급 문서 | BR-AIA-034 |
| 429 | `AIA_QUOTA_EXCEEDED` | 일일 AI 사용 한도 초과 | BR-AIA-031 |
| 503 | `AIA_SERVICE_UNAVAILABLE` | LLM Orchestrator 연결 불가 | BR-AIA-030 |
| 504 | `AIA_SERVICE_TIMEOUT` | LLM Orchestrator 응답 시간 초과 | BR-AIA-030 |

**비즈니스 규칙 참조**: BR-AIA-004, BR-AIA-005, BR-AIA-006, BR-AIA-029~034

---

### 3. `POST` /api/documents/:documentId/writing-improve

**설명**: AI 글쓰기 개선을 요청한다. SSE 스트리밍으로 개선 결과를 반환한다.

**권한**: `EDIT` — 해당 문서 편집 권한

**Request**:

- Path params: `documentId` (UUID) — 대상 문서 ID
- Body:

```typescript
interface RequestWritingImproveDto {
  blockIds: string[];
  scope: 'block' | 'document';
  improveType: 'polish' | 'tone_formal' | 'tone_casual'
             | 'concise' | 'elaborate' | 'translate' | 'freeform';
  targetLanguage?: string;       // improveType='translate'일 때 (예: 'en', 'ko')
  freeformInstruction?: string;  // improveType='freeform'일 때 필수
}
```

**Response** (`200`, `Content-Type: text/event-stream`):

```
event: chunk
data: {"blockId":"<block-uuid>","content":"개선된 텍스트 일부..."}

event: done
data: {"blockId":"<block-uuid>","originalText":"원본","improvedText":"전체 개선 결과","modelName":"gpt-4o"}

// 전체 문서 개선(scope='document') 시:
event: section-start
data: {"sectionIndex":0,"sectionTitle":"서론"}

event: chunk
data: {"content":"개선된 텍스트..."}

event: section-done
data: {"sectionIndex":0}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `AIA_CONTENT_TOO_LONG` | 입력 토큰 > `lm:ai.writing_max_input_tokens` | BR-AIA-032 |
| 403 | `AIA_FEATURE_DISABLED` | 글쓰기 개선 비활성 | BR-AIA-033 |
| 403 | `AIA_SENSITIVE_RESTRICTED` | 민감 등급 문서 | BR-AIA-034 |
| 409 | `AIA_CONCURRENT_CONFLICT` | 다른 사용자 동시 편집 중 | BR-AIA-035 |
| 429 | `AIA_QUOTA_EXCEEDED` | 일일 AI 사용 한도 초과 | BR-AIA-031 |
| 429 | `AIA_REGENERATION_LIMIT` | 동일 블록 재생성 횟수 초과 | BR-AIA-036 |
| 503 | `AIA_SERVICE_UNAVAILABLE` | LLM Orchestrator 연결 불가 | BR-AIA-030 |
| 504 | `AIA_SERVICE_TIMEOUT` | LLM Orchestrator 응답 시간 초과 | BR-AIA-030 |

**비즈니스 규칙 참조**: BR-AIA-009, BR-AIA-010, BR-AIA-011, BR-AIA-030~036

---

### 4. `POST` /api/documents/:documentId/tag-recommend

**설명**: 문서 본문을 분석하여 기존 태그 풀에서 적합한 태그를 추천한다.

**권한**: `EDIT` — 해당 문서 편집 권한

**Request**:

- Path params: `documentId` (UUID) — 대상 문서 ID
- Body:

```typescript
interface RequestTagRecommendDto {
  maxCount?: number;  // 추천 최대 수 (기본 5) [BR-AIA-025]
}
```

**Response** (`200`):

```typescript
interface TagRecommendResponse {
  existingTags: {
    tagId: string;
    name: string;
    reason: string;     // 추천 사유
  }[];
  newTagSuggestions: {
    name: string;
    reason: string;     // 제안 사유
  }[];
  modelName: string;
  inputTokens: number;
  outputTokens: number;
}
```

| 필드 | 설명 |
|------|------|
| `existingTags` | 기존 태그 풀에서 매칭된 태그 목록 (우선 표시) |
| `newTagSuggestions` | 기존 태그에 적합한 것이 없을 때 새 태그 제안. 별도 영역에 표시 [BR-AIA-024] |

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `AIA_CONTENT_TOO_SHORT` | 본문 길이 < `pm:ai.tag_recommend_min_length` | BR-AIA-029 |
| 403 | `AIA_FEATURE_DISABLED` | 태그 추천 비활성 | BR-AIA-033 |
| 403 | `AIA_SENSITIVE_RESTRICTED` | 민감 등급 문서 | BR-AIA-034 |
| 429 | `AIA_QUOTA_EXCEEDED` | 일일 AI 사용 한도 초과 | BR-AIA-031 |
| 503 | `AIA_SERVICE_UNAVAILABLE` | LLM Orchestrator 연결 불가 | BR-AIA-030 |

**비즈니스 규칙 참조**: BR-AIA-024, BR-AIA-025, BR-AIA-026, BR-AIA-029~034

---

### 5. `POST` /api/documents/:documentId/ai-feedback

**설명**: AI 기능 결과에 대한 사용자 피드백을 등록한다.

**권한**: `VIEW` — 해당 문서 읽기 권한

**Request**:

- Path params: `documentId` (UUID) — 대상 문서 ID
- Body:

```typescript
interface CreateAiFeedbackDto {
  usageLogId: string;                       // AiUsageLog.id — 피드백 대상 AI 호출
  feedbackType: 'positive' | 'negative';
  reason?: 'inaccurate' | 'nonexistent_content' | 'context_error'
         | 'meaning_changed' | 'unnecessary_change' | 'other';
  comment?: string;                         // 추가 의견
}
```

**Response** (`201`):

```typescript
interface AiFeedbackResponse {
  feedbackId: string;
  usageLogId: string;
  feedbackType: string;
  createdAt: string;  // ISO 8601
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 404 | `AIA_USAGE_LOG_NOT_FOUND` | 대상 AiUsageLog 미존재 | — |
| 409 | `AIA_FEEDBACK_DUPLICATE` | 동일 usageLogId에 이미 피드백 존재 | BR-AIA-019 |

**비즈니스 규칙 참조**: BR-AIA-017, BR-AIA-018, BR-AIA-019

---

## 상세 API — 프롬프트 관리 (관리자)

### 6. `GET` /api/admin/prompt-slots

**설명**: 전체 프롬프트 슬롯 목록을 조회한다.

**권한**: `manage_prompts`

**Request**:

- Query params:
  - `featureGroup?`: `'summary' | 'writing' | 'tag'` — 기능 그룹 필터
  - `page?`: number (기본 1)
  - `limit?`: number (기본 20)

**Response** (`200`):

```typescript
interface PromptSlotListResponse {
  slots: PromptSlotSummaryDto[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
}

interface PromptSlotSummaryDto {
  id: string;
  slotKey: string;
  name: string;
  featureGroup: 'summary' | 'writing' | 'tag';
  description: string | null;
  activeVersion: {
    id: string;
    versionNumber: number;
    status: 'active' | 'archived';
    createdBy: string;
    createdAt: string;    // ISO 8601
    changeNote: string | null;
  } | null;
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 403 | `AUTH_FORBIDDEN` | `manage_prompts` 권한 없음 | BR-AIA-012 |

---

### 7. `GET` /api/admin/prompt-slots/:slotId

**설명**: 프롬프트 슬롯 상세 정보와 버전 이력을 조회한다.

**권한**: `manage_prompts`

**Request**:

- Path params: `slotId` (UUID)
- Query params:
  - `versionPage?`: number (기본 1)
  - `versionLimit?`: number (기본 20)

**Response** (`200`):

```typescript
interface PromptSlotDetailResponse {
  id: string;
  slotKey: string;
  name: string;
  featureGroup: 'summary' | 'writing' | 'tag';
  description: string | null;
  activeVersionId: string | null;
  versions: PromptVersionDto[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
  };
}

interface PromptVersionDto {
  id: string;
  versionNumber: number;
  promptBody: string;
  status: 'active' | 'archived';
  createdBy: string;
  createdAt: string;    // ISO 8601
  changeNote: string | null;
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 403 | `AUTH_FORBIDDEN` | `manage_prompts` 권한 없음 | BR-AIA-012 |
| 404 | `AIA_SLOT_NOT_FOUND` | 슬롯 미존재 | — |

---

### 8. `POST` /api/admin/prompt-slots/:slotId/versions

**설명**: 새 프롬프트 버전을 생성한다. 기존 버전은 `archived`로 전환되고, 새 버전이 `active`가 된다.

**권한**: `manage_prompts`

**Request**:

- Path params: `slotId` (UUID)
- Body:

```typescript
interface CreatePromptVersionDto {
  promptBody: string;       // 프롬프트 본문 (빈 문자열 불가)
  changeNote?: string;      // 변경 사유
}
```

**Response** (`201`):

```typescript
interface CreatePromptVersionResponse {
  versionId: string;
  versionNumber: number;
  slotId: string;
  status: 'active';
  createdAt: string;  // ISO 8601
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `AIA_PROMPT_BODY_EMPTY` | `promptBody`가 빈 문자열 | BR-AIA-014 |
| 403 | `AUTH_FORBIDDEN` | `manage_prompts` 권한 없음 | BR-AIA-012 |
| 404 | `AIA_SLOT_NOT_FOUND` | 슬롯 미존재 | — |

**부수 효과**:
- 이전 활성 버전 → `archived` 전환
- `prompt.updated` 이벤트 발행 (감사 로그 연동)

**비즈니스 규칙 참조**: BR-AIA-012, BR-AIA-013, BR-AIA-014

---

### 9. `POST` /api/admin/prompt-slots/:slotId/rollback

**설명**: 특정 이전 버전으로 롤백한다. 실제로는 해당 버전의 `promptBody`를 복사하여 새 버전을 생성하는 copy-forward 방식이다.

**권한**: `manage_prompts`

**Request**:

- Path params: `slotId` (UUID)
- Body:

```typescript
interface RollbackPromptDto {
  targetVersionId: string;  // 롤백 대상 버전 ID
  changeNote?: string;      // 롤백 사유
}
```

**Response** (`201`):

```typescript
interface RollbackPromptResponse {
  newVersionId: string;
  newVersionNumber: number;
  rolledBackFromVersionId: string;
  slotId: string;
  createdAt: string;  // ISO 8601
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 403 | `AUTH_FORBIDDEN` | `manage_prompts` 권한 없음 | BR-AIA-012 |
| 404 | `AIA_SLOT_NOT_FOUND` | 슬롯 미존재 | — |
| 404 | `AIA_VERSION_NOT_FOUND` | 대상 버전 미존재 | — |

**부수 효과**:
- 새 버전 생성 (copy-forward) + 이전 활성 버전 `archived` 전환
- `prompt.updated` 이벤트 발행 (`action: 'rollback'`)

**비즈니스 규칙 참조**: BR-AIA-015, BR-AIA-016

---

### 10. `POST` /api/admin/prompt-slots/:slotId/test

**설명**: 프롬프트를 실제 LLM에 테스트 호출한다. 결과를 확인한 후 버전으로 저장 여부를 결정할 수 있다.

**권한**: `manage_prompts`

**Request**:

- Path params: `slotId` (UUID)
- Body:

```typescript
interface TestPromptDto {
  promptBody: string;          // 테스트할 프롬프트 본문
  sampleDocumentId?: string;   // 샘플 문서 ID (실제 문서로 테스트)
  sampleText?: string;         // 직접 입력 텍스트 (sampleDocumentId 미사용 시)
}
```

**Response** (`200`):

```typescript
interface TestPromptResponse {
  result: string;              // LLM 출력 결과
  modelName: string;
  inputTokens: number;
  outputTokens: number;
  responseTimeMs: number;
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `AIA_PROMPT_BODY_EMPTY` | `promptBody`가 빈 문자열 | BR-AIA-014 |
| 403 | `AUTH_FORBIDDEN` | `manage_prompts` 권한 없음 | BR-AIA-012 |
| 404 | `AIA_SLOT_NOT_FOUND` | 슬롯 미존재 | — |
| 500 | `AIA_PROMPT_TEST_FAILED` | LLM 호출 실패 | BR-AIA-015 |

**비즈니스 규칙 참조**: BR-AIA-012, BR-AIA-014, BR-AIA-015

---

## 상세 API — 임베딩 관리 (관리자)

### 11. `GET` /api/admin/embedding/dashboard

**설명**: 임베딩 파이프라인 현황 대시보드를 조회한다.

**권한**: `manage_embedding`

**Request**:

- Query params:
  - `period?`: `'1h' | '6h' | '24h' | '7d'` (기본 `'24h'`) — 통계 기간

**Response** (`200`):

```typescript
interface EmbeddingDashboardResponse {
  queueStatus: {
    waiting: number;      // 대기 중 Job 수
    active: number;       // 처리 중 Job 수
    completed: number;    // 완료 (기간 내)
    failed: number;       // 실패 (기간 내)
    dlq: number;          // DLQ 적재 Job 수
  };
  avgProcessingTimeMs: number;  // 평균 처리 시간 (기간 내)
  recentFailures: EmbeddingTaskSummaryDto[];
  documentStatusSummary: {
    documentId: string;
    title: string;
    embeddingStatus: string;
    totalChunks: number;
    completedChunks: number;
    failedChunks: number;
  }[];
  recentTasks: EmbeddingTaskDto[];
}

interface EmbeddingTaskSummaryDto {
  taskId: string;
  documentId: string;
  documentTitle: string;
  errorCode: string;
  errorMessage: string;
  failedAt: string;       // ISO 8601
  retryCount: number;
}

interface EmbeddingTaskDto {
  taskId: string;
  documentId: string;
  versionId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  totalChunks: number;
  processedChunks: number;
  failedChunks: number;
  errorCode: string | null;
  errorMessage: string | null;
  startedAt: string | null;
  completedAt: string | null;
  durationMs: number | null;
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 403 | `AUTH_FORBIDDEN` | `manage_embedding` 권한 없음 | — |

---

### 12. `POST` /api/admin/embedding/retry

**설명**: 실패한 문서의 임베딩을 수동으로 재처리한다.

**권한**: `manage_embedding`

**Request**:

```typescript
interface EmbeddingRetryDto {
  documentIds: string[];  // 재처리 대상 문서 ID 목록
  priority?: number;      // 우선순위 오버라이드 (기본: 2)
}
```

**Response** (`200`):

```typescript
interface EmbeddingRetryResponse {
  enqueuedCount: number;
  skippedCount: number;
  skippedReasons: {
    documentId: string;
    reason: string;       // 예: 'already_processing', 'document_deleted'
  }[];
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `EMB_EMPTY_DOCUMENT_LIST` | `documentIds` 비어있음 | — |
| 403 | `AUTH_FORBIDDEN` | `manage_embedding` 권한 없음 | — |

**비즈니스 규칙 참조**: BR-EMB-012 (멱등성), BR-EMB-009 (우선순위)

---

### 13. `POST` /api/admin/embedding/dlq/requeue

**설명**: DLQ에 적재된 실패 Job을 `embedding` 큐에 재투입한다.

**권한**: `manage_embedding`

**Request**:

```typescript
interface DlqRequeueDto {
  taskIds: string[];  // DLQ에서 재투입할 Task ID 목록
}
```

**Response** (`200`):

```typescript
interface DlqRequeueResponse {
  requeuedCount: number;
  failedCount: number;
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `EMB_EMPTY_TASK_LIST` | `taskIds` 비어있음 | — |
| 403 | `AUTH_FORBIDDEN` | `manage_embedding` 권한 없음 | — |

**비즈니스 규칙 참조**: BR-EMB-011 (DLQ 정책)

---

### 14. `POST` /api/admin/embedding/re-embed

**설명**: 조건 기반 일괄 재임베딩을 요청한다. 대량 처리이므로 비동기로 실행되며, `embedding.progress` 이벤트로 진행률을 통지한다.

**권한**: `manage_embedding`

**Request**:

```typescript
interface BulkReEmbedDto {
  scope: 'all' | 'board' | 'template' | 'failed';
  boardId?: string;      // scope='board'일 때 필수
  templateId?: string;   // scope='template'일 때 필수
  priority?: number;     // 우선순위 (기본: 3 — 대량 처리 수준)
  reason: string;        // 재임베딩 사유 (감사 로그 기록용)
}
```

**Response** (`202`):

```typescript
interface BulkReEmbedResponse {
  jobId: string;          // 일괄 처리 Job 추적 ID
  estimatedCount: number; // 예상 대상 문서 수
  status: 'queued';
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 400 | `EMB_INVALID_SCOPE` | scope에 맞는 필수 파라미터 누락 | — |
| 403 | `AUTH_FORBIDDEN` | `manage_embedding` 권한 없음 | — |
| 409 | `EMB_BULK_JOB_IN_PROGRESS` | 이미 일괄 재임베딩이 진행 중 | BR-EMB-012 |

**비즈니스 규칙 참조**: BR-EMB-009 (우선순위), BR-EMB-012 (멱등성)

---

## 상세 API — AI 사용 통계 (관리자)

### 15. `GET` /api/admin/ai/usage-stats

**설명**: AI 기능 사용 통계 대시보드를 조회한다.

**권한**: `manage_prompts`

**Request**:

- Query params:
  - `period`: `'1d' | '7d' | '30d'` (기본 `'7d'`) — 통계 기간
  - `featureType?`: `'summary' | 'writing' | 'tag'` — 기능 유형 필터

**Response** (`200`):

```typescript
interface AiUsageStatsResponse {
  period: string;
  totalCalls: number;
  quotaUsage: {
    used: number;
    limit: number;      // lm:ai.daily_quota
    usagePercent: number;
  };
  byFeature: {
    featureType: string;
    callCount: number;
    avgResponseTimeMs: number;
    errorRate: number;   // 0~1
    totalInputTokens: number;
    totalOutputTokens: number;
  }[];
  feedback: {
    totalCount: number;
    positiveCount: number;
    negativeCount: number;
    positiveRate: number;  // 0~1
  };
  dailyTrend: {
    date: string;        // YYYY-MM-DD
    callCount: number;
    errorCount: number;
  }[];
}
```

**에러 코드**:

| HTTP | 코드 | 조건 | 규칙 |
|------|------|------|------|
| 403 | `AUTH_FORBIDDEN` | `manage_prompts` 권한 없음 | — |

---

## §4. 에러 코드 카탈로그

> AI Assistant 모듈의 도메인 에러 코드 SSoT. 전역 에러는 [횡단 관심사 §8.2](../../02-architecture/07-cross-cutting-concerns.md) 참조.

### AI 기능 에러 (AIA_ 접두사)

| 에러 코드 | HTTP | 설명 | 관련 규칙 |
|-----------|------|------|-----------|
| `AIA_SERVICE_UNAVAILABLE` | 503 | AI 서비스(LLM Orchestrator)에 연결할 수 없음 | BR-AIA-030 |
| `AIA_SERVICE_TIMEOUT` | 504 | AI 서비스 응답 시간 초과 | BR-AIA-030 |
| `AIA_QUOTA_EXCEEDED` | 429 | 조직의 일일 AI 사용 한도 초과 | BR-AIA-031 |
| `AIA_CONTENT_TOO_LONG` | 400 | 입력 텍스트가 기능별 최대 토큰 한도 초과 | BR-AIA-032 |
| `AIA_CONTENT_TOO_SHORT` | 400 | 입력 텍스트가 최소 분량 미달 | BR-AIA-029 |
| `AIA_FEATURE_DISABLED` | 403 | 해당 AI 기능이 조직 설정에서 비활성화됨 | BR-AIA-033 |
| `AIA_SENSITIVE_RESTRICTED` | 403 | 민감 정보 AI 처리 제한 등급에 의해 차단 | BR-AIA-034 |
| `AIA_CONCURRENT_CONFLICT` | 409 | 동시 편집 충돌 — 다른 사용자가 동일 블록을 수정 중 | BR-AIA-035 |
| `AIA_REGENERATION_LIMIT` | 429 | 동일 블록에 대한 재생성 횟수 초과 | BR-AIA-036 |
| `AIA_SUMMARY_FAILED` | 500 | 자동 요약 생성 실패 (재시도 소진) | BR-AIA-002 |
| `AIA_PROMPT_TEST_FAILED` | 500 | 프롬프트 테스트 실행 실패 | BR-AIA-015 |
| `AIA_PROMPT_BODY_EMPTY` | 400 | 프롬프트 본문이 빈 문자열 | BR-AIA-014 |
| `AIA_SLOT_NOT_FOUND` | 404 | 프롬프트 슬롯 미존재 | — |
| `AIA_VERSION_NOT_FOUND` | 404 | 프롬프트 버전 미존재 | — |
| `AIA_USAGE_LOG_NOT_FOUND` | 404 | AI 사용 이력 미존재 | — |
| `AIA_FEEDBACK_DUPLICATE` | 409 | 동일 사용 이력에 중복 피드백 | BR-AIA-019 |

### 임베딩 에러 (EMB_ 접두사)

| 에러 코드 | HTTP/Worker | 설명 | 재시도 가능 | DLQ 이동 조건 | 관련 규칙 |
|-----------|-------------|------|-----------|-------------|-----------|
| `EMB_E001` | Worker | 외부 임베딩 API 호출 실패 (타임아웃, rate limit) | O | 3회 재시도 소진 | BR-EMB-010 |
| `EMB_E002` | Worker | 벡터 DB 쓰기 실패 (Milvus 연결 실패, 용량 초과) | O | 3회 재시도 소진 | BR-EMB-010 |
| `EMB_E003` | Worker | 청킹 실패 (비정상 블록 데이터, 토큰 초과) | X | 즉시 DLQ 이동 | BR-EMB-013 |
| `EMB_E004` | Worker | 원본 문서 조회 실패 (삭제됨, 권한 변경) | X | Job 폐기 (DLQ 미적재) | BR-EMB-013 |
| `EMB_E005` | Worker | content_hash 비교 실패 (기존 벡터 메타데이터 손상) | O | 3회 재시도 소진 | BR-EMB-010 |
| `EMB_E006` | Worker | Bull 큐 연결 실패 (Redis 장애) | O (인프라 복구 후) | 자동 복구 대기 | BR-EMB-010 |
| `EMB_EMPTY_DOCUMENT_LIST` | 400 | 재처리 요청 시 문서 목록 비어있음 | — | — | — |
| `EMB_EMPTY_TASK_LIST` | 400 | DLQ 재투입 시 Task 목록 비어있음 | — | — | — |
| `EMB_INVALID_SCOPE` | 400 | 일괄 재임베딩 scope 파라미터 오류 | — | — | — |
| `EMB_BULK_JOB_IN_PROGRESS` | 409 | 이미 일괄 재임베딩 진행 중 | — | — | BR-EMB-012 |

---

## 공통 SSE 이벤트 규격

> 수동 요약, 글쓰기 개선 등 SSE 스트리밍 API에 공통 적용.

| 이벤트 타입 | 용도 | 데이터 필드 |
|-------------|------|-------------|
| `chunk` | 스트리밍 텍스트 청크 | `content: string` (+ 선택: `blockId`) |
| `done` | 스트리밍 완료 신호 | 기능별 메타데이터 (`summaryId`, `modelName` 등) |
| `error` | 스트리밍 중 에러 | `errorCode: string, message: string` |
| `section-start` | 전체 문서 개선 시 섹션 시작 | `sectionIndex: number, sectionTitle: string` |
| `section-done` | 전체 문서 개선 시 섹션 완료 | `sectionIndex: number` |

> 클라이언트는 `text/event-stream` 응답을 EventSource 또는 fetch + ReadableStream으로 소비한다. 연결 끊김 시 자동 재연결하지 않으며 사용자에게 재시도를 안내한다.
