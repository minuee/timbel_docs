# AI AssistantModule — RDB 엔티티

> AI 기능별 프롬프트 슬롯 관리, 버전 이력/롤백, 관리자 편집 권한, 감사 연계

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    PromptSlot ||--o{ PromptVersion : "1:N (버전 이력)"
    PromptSlot ||--o| PromptVersion : "active_version_id"

    User ||--o{ AiUsageLog : "1:N"
    Document |o--o{ AiUsageLog : "0..1:N"
    PromptVersion |o--o{ AiUsageLog : "0..1:N"

    AiUsageLog ||--o{ AiFeedback : "1:N"

    Document ||--o{ AiSummaryCache : "1:N"

    Document ||--o{ EmbeddingTask : "1:N"
    EmbeddingTask ||--o{ EmbeddingChunk : "1:N"
    Document ||--o{ EmbeddingChunk : "1:N"
```

> User, Document는 외부 모듈 엔티티이다 — FK 대신 앱 레벨에서 유효성을 확인한다.

---

## 2. 엔티티 필드

### 2.1 PromptSlot

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| slot_key | VARCHAR(100) (UNIQUE) | 기능별 슬롯 식별자 (예: `doc_summary_oneline`, `writing_polish`) |
| name | VARCHAR(200) | 슬롯 표시명 (관리자 UI용) |
| description | TEXT (nullable) | 슬롯 설명 — 이 프롬프트가 어떤 AI 기능에 사용되는지 |
| feature_group | VARCHAR(50) | 기능 그룹: `summary`, `writing`, `tag` |
| active_version_id | UUID (FK → PromptVersion, nullable) | 현재 활성 버전. null이면 시스템 기본 프롬프트 사용 |
| is_active | BOOLEAN (default true) | 슬롯 활성 여부. false이면 해당 AI 기능에서 사용 불가 |
| created_by | UUID | 생성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(slot_key)` — 슬롯 키 중복 방지
- `feature_group`은 앱 레벨에서 검증 — 그룹이 확장될 수 있으므로 CHECK 제약 대신 앱 검증

#### 설계 결정

**슬롯 단위 관리**
— AICM은 프롬프트를 기능별 슬롯 단위로 관리한다 ([FD-AI](../../01-requirements/features/FD-AI-AI어시스턴트.md) §3.3). 슬롯 키는 AI 기능과 1:1 대응하며, 기능 추가 시 슬롯도 확장 가능하다.

**active_version_id (현재 활성 버전)**
— 저장 시 최신 프롬프트 버전이 즉시 활성화된다 (FD-AI §3.4). PromptVersion을 새로 생성한 뒤 이 FK를 갱신하면 즉시 반영된다. 롤백 시에도 이전 버전의 ID로 갱신한다.

**슬롯 비활성화**
— `is_active = false`이면 해당 슬롯의 프롬프트가 무시되어 시스템 기본 프롬프트로 폴백한다. 물리 삭제 대신 비활성화를 사용하여 이력을 보존한다.

---

### 2.2 PromptVersion

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| prompt_slot_id | UUID (FK → PromptSlot) | 소속 슬롯 |
| version_number | INT | 슬롯 내 버전 번호 (1부터 순증) |
| prompt_body | TEXT NOT NULL | 프롬프트 본문 |
| status | VARCHAR(10) NOT NULL DEFAULT 'active' | 상태: `active`, `archived` |
| change_note | VARCHAR(500) (nullable) | 변경 사유/메모 |
| created_by | UUID | 작성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(prompt_slot_id, version_number)` — 슬롯 내 버전 번호 중복 방지
- `prompt_body NOT NULL` — 빈 프롬프트는 허용하지 않음

#### 설계 결정

**불변 버전 (append-only)**
— PromptVersion은 생성 후 수정 불가. 변경이 필요하면 새 버전을 생성한다. `updated_at`이 없는 이유이다. 이를 통해 "누가 언제 어떤 프롬프트를 어떻게 변경했는지" 전체 이력을 추적한다 (FD-AI §3.6).

**롤백 메커니즘**
— 롤백은 별도 엔티티가 아니라 `PromptSlot.active_version_id`를 이전 버전 ID로 변경하는 것으로 구현한다. 롤백 자체도 감사 로그(`prompt.updated`)에 기록된다.

**감사 연계**
— 프롬프트 변경(버전 생성 + 활성 버전 전환)은 AuditLogModule에 `prompt.updated` 액션으로 기록된다 ([FD-AUD](../../01-requirements/features/FD-AUD-감사로그.md) §2.4). details에 `slot_key`, `before`(이전 활성 버전 content), `after`(새 활성 버전 content)를 포함한다.

**관리 권한**
— 프롬프트 조회/편집/테스트는 관리자급 사용자(AICM 관리자, 운영 관리자)만 가능하다 (FD-AI §3.2). 앱 레벨에서 AdminPermission(`manage_prompts`)을 검증한다.

---

## 3. DDL 및 인덱스

### 3.1 PromptSlot

```sql
CREATE TABLE prompt_slot (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slot_key          VARCHAR(100) NOT NULL,
  name              VARCHAR(200) NOT NULL,
  description       TEXT,
  feature_group     VARCHAR(50) NOT NULL,
  active_version_id UUID,
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_by        UUID NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_prompt_slot_key UNIQUE (slot_key)
);

CREATE INDEX idx_prompt_slot_feature_group
  ON prompt_slot (feature_group);

CREATE INDEX idx_prompt_slot_active
  ON prompt_slot (is_active)
  WHERE is_active = true;
```

### 3.2 PromptVersion

```sql
CREATE TABLE prompt_version (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  prompt_slot_id   UUID NOT NULL REFERENCES prompt_slot(id) ON DELETE CASCADE,
  version_number   INT NOT NULL,
  prompt_body      TEXT NOT NULL,
  status           VARCHAR(10) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'archived')),
  change_note      VARCHAR(500),
  created_by       UUID NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_prompt_version UNIQUE (prompt_slot_id, version_number)
);

CREATE INDEX idx_prompt_version_slot
  ON prompt_version (prompt_slot_id, version_number DESC);

-- PromptSlot.active_version_id FK (deferred — PromptVersion이 먼저 생성되어야 하므로)
ALTER TABLE prompt_slot
  ADD CONSTRAINT fk_prompt_slot_active_version
  FOREIGN KEY (active_version_id) REFERENCES prompt_version(id)
  ON DELETE SET NULL;
```

---

## 4. AiUsageLog — AI 사용 이력

> FD-AI §8.3

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID PK | |
| tenant_id | UUID NOT NULL | 테넌트 식별자 |
| user_id | UUID NOT NULL | 사용자 (외부 UserService, FK 없음) |
| feature_type | VARCHAR(30) NOT NULL | `summary_auto`, `summary_manual`, `writing_improve`, `tag_recommend`, `rag_answer` |
| document_id | UUID (nullable) | 대상 문서 (외부 DocumentModule, FK 없음) |
| input_hash | VARCHAR(64) NOT NULL | 입력 텍스트 SHA-256 해시 (원문 미저장) |
| output_preview | VARCHAR(500) (nullable) | 출력 앞부분 미리보기 |
| model_name | VARCHAR(100) NOT NULL | 사용 모델명 |
| input_tokens | INTEGER NOT NULL | 입력 토큰 수 |
| output_tokens | INTEGER NOT NULL | 출력 토큰 수 |
| response_time_ms | INTEGER NOT NULL | 응답 시간 (밀리초) |
| prompt_slot_key | VARCHAR(100) (nullable) | 사용된 프롬프트 슬롯 키 |
| prompt_version_id | UUID (nullable) | FK(prompt_version) — 사용된 프롬프트 버전 |
| created_at | TIMESTAMPTZ NOT NULL | |

### DDL

```sql
CREATE TABLE ai_usage_log (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         UUID NOT NULL,
  user_id           UUID NOT NULL,
  feature_type      VARCHAR(30) NOT NULL,
  document_id       UUID,
  input_hash        VARCHAR(64) NOT NULL,
  output_preview    VARCHAR(500),
  model_name        VARCHAR(100) NOT NULL,
  input_tokens      INTEGER NOT NULL,
  output_tokens     INTEGER NOT NULL,
  response_time_ms  INTEGER NOT NULL,
  prompt_slot_key   VARCHAR(100),
  prompt_version_id UUID REFERENCES prompt_version(id) ON DELETE SET NULL,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_usage_log_tenant_feature
  ON ai_usage_log (tenant_id, feature_type, created_at DESC);
```

### 설계 메모

- `user_id`, `document_id`는 외부 모듈 엔티티 — FK 대신 앱 레벨에서 유효성 확인
- `input_hash`로 원문 대신 해시만 저장하여 민감 데이터 최소화
- `feature_type`은 앱 레벨에서 검증 — 확장 가능성 고려

---

## 5. AiFeedback — AI 피드백

> FD-AI §8.4

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID PK | |
| usage_log_id | UUID NOT NULL | FK(ai_usage_log) — 대상 사용 이력 |
| feedback_type | VARCHAR(10) NOT NULL | `positive`, `negative` |
| reason | VARCHAR(30) (nullable) | 부정 피드백 사유 |
| comment | VARCHAR(500) (nullable) | 추가 의견 |
| user_id | UUID NOT NULL | 피드백 작성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ NOT NULL | |

### DDL

```sql
CREATE TABLE ai_feedback (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  usage_log_id   UUID NOT NULL REFERENCES ai_usage_log(id) ON DELETE CASCADE,
  feedback_type  VARCHAR(10) NOT NULL CHECK (feedback_type IN ('positive', 'negative')),
  reason         VARCHAR(30),
  comment        VARCHAR(500),
  user_id        UUID NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_feedback_usage
  ON ai_feedback (usage_log_id);
```

### 설계 메모

- `reason` ENUM 값: `inaccurate`, `nonexistent_content`, `context_error`, `meaning_changed`, `unnecessary_change`, `other` — 앱 레벨에서 검증
- 사용자당 한 건의 피드백만 허용할 경우 UNIQUE(usage_log_id, user_id) 추가 고려

---

## 6. AiSummaryCache — AI 요약 캐시

> FD-AI §8.5

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID PK | |
| document_id | UUID NOT NULL | 대상 문서 (외부 DocumentModule, FK 없음) |
| document_version_id | UUID NOT NULL | 문서 버전 (외부, FK 없음) |
| content_hash | VARCHAR(64) NOT NULL | 문서 content_hash (무효화 판단용) |
| summary_type | VARCHAR(20) NOT NULL | `oneline`, `keypoints`, `section`, `custom` |
| custom_instruction | TEXT (nullable) | 맞춤 요약 시 사용자 지시문 |
| summary_text | TEXT NOT NULL | 요약 결과 |
| model_name | VARCHAR(100) NOT NULL | 생성에 사용된 모델명 |
| tenant_id | UUID NOT NULL | 테넌트 식별자 |
| created_by | UUID NOT NULL | 요약 요청자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ NOT NULL | |
| updated_at | TIMESTAMPTZ NOT NULL | 재요약 시 갱신 |

### DDL

```sql
CREATE TABLE ai_summary_cache (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id          UUID NOT NULL,
  document_version_id  UUID NOT NULL,
  content_hash         VARCHAR(64) NOT NULL,
  summary_type         VARCHAR(20) NOT NULL,
  custom_instruction   TEXT,
  summary_text         TEXT NOT NULL,
  model_name           VARCHAR(100) NOT NULL,
  tenant_id            UUID NOT NULL,
  created_by           UUID NOT NULL,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX uq_ai_summary_cache_doc_type
  ON ai_summary_cache (document_id, document_version_id, summary_type)
  WHERE custom_instruction IS NULL;

CREATE INDEX idx_ai_summary_cache_doc
  ON ai_summary_cache (document_id, content_hash);
```

### 설계 메모

- `document_id`, `document_version_id`, `created_by`는 외부 모듈 엔티티 — FK 대신 앱 레벨에서 유효성 확인
- 캐시 무효화: `content_hash` 비교로 판단, `document.content-updated` 이벤트 시 해당 document_id 레코드 전체 삭제
- 부분 고유 인덱스로 일반 요약의 중복 방지 (custom 요약은 동일 타입이어도 지시문이 다를 수 있으므로 제외)

---

## 7. EmbeddingTask — 임베딩 작업

> FD-EMB §3.1

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID PK | Task 고유 식별자 |
| document_id | UUID NOT NULL | 대상 문서 (외부 DocumentModule, FK 없음) |
| version | INTEGER NOT NULL | 대상 문서 버전 |
| tenant_id | UUID NOT NULL | 테넌트 ID |
| status | VARCHAR(15) NOT NULL | `pending`, `processing`, `completed`, `failed`, `cancelled`, `partial` |
| trigger_type | VARCHAR(20) NOT NULL | `publish`, `update`, `shared_content`, `manual_retry` |
| priority | INTEGER NOT NULL | 우선순위 (1=최고) |
| total_chunks | INTEGER (nullable) | 전체 청크 수 (processing 진입 후 설정) |
| processed_chunks | INTEGER DEFAULT 0 | 처리 완료 청크 수 |
| failed_chunks | INTEGER DEFAULT 0 | 실패 청크 수 |
| error_code | VARCHAR(20) (nullable) | 최종 에러 코드 |
| error_message | TEXT (nullable) | 상세 에러 메시지 |
| started_at | TIMESTAMPTZ (nullable) | 처리 시작 시각 |
| completed_at | TIMESTAMPTZ (nullable) | 처리 완료 시각 |
| created_at | TIMESTAMPTZ NOT NULL | 생성 시각 |

### DDL

```sql
CREATE TABLE embedding_task (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id       UUID NOT NULL,
  version           INTEGER NOT NULL,
  tenant_id         UUID NOT NULL,
  status            VARCHAR(15) NOT NULL DEFAULT 'pending',
  trigger_type      VARCHAR(20) NOT NULL,
  priority          INTEGER NOT NULL DEFAULT 2,
  total_chunks      INTEGER,
  processed_chunks  INTEGER NOT NULL DEFAULT 0,
  failed_chunks     INTEGER NOT NULL DEFAULT 0,
  error_code        VARCHAR(20),
  error_message     TEXT,
  started_at        TIMESTAMPTZ,
  completed_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_embedding_task_doc_status
  ON embedding_task (document_id, status);

CREATE INDEX idx_embedding_task_tenant
  ON embedding_task (tenant_id, created_at DESC);
```

### 설계 메모

- `document_id`는 외부 모듈 엔티티 — FK 대신 앱 레벨에서 유효성 확인
- `status`, `trigger_type`은 앱 레벨에서 검증 — 확장 가능성 고려
- `partial` 상태: 일부 청크만 성공, 문서 수준 `embedding_status=partial`과 동기화

---

## 8. EmbeddingChunk — 임베딩 청크

> FD-EMB §3.2

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID PK | 청크 고유 식별자 |
| task_id | UUID NOT NULL | FK(embedding_task) — 소속 Task |
| document_id | UUID NOT NULL | 소속 문서 (외부 DocumentModule, FK 없음) |
| block_ids | UUID[] NOT NULL | 이 청크를 구성하는 블록 ID 목록 (블록→청크 역추적용) |
| content_hash | VARCHAR(64) NOT NULL | 청크 텍스트의 SHA-256 해시 |
| status | VARCHAR(10) NOT NULL | `pending`, `completed`, `failed` |
| error_code | VARCHAR(20) (nullable) | 실패 시 에러 코드 |
| vector_id | VARCHAR(100) (nullable) | Milvus에 저장된 벡터 ID |
| created_at | TIMESTAMPTZ NOT NULL | 생성 시각 |

### DDL

```sql
CREATE TABLE embedding_chunk (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id        UUID NOT NULL REFERENCES embedding_task(id) ON DELETE CASCADE,
  document_id    UUID NOT NULL,
  block_ids      UUID[] NOT NULL,
  content_hash   VARCHAR(64) NOT NULL,
  status         VARCHAR(10) NOT NULL DEFAULT 'pending',
  error_code     VARCHAR(20),
  vector_id      VARCHAR(100),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_embedding_chunk_task
  ON embedding_chunk (task_id, status);

CREATE INDEX idx_embedding_chunk_doc
  ON embedding_chunk (document_id);
```

### 설계 메모

- `block_ids`로 블록→청크 역추적 가능 — 블록 단위 변경 감지 시 해당 청크만 재임베딩
- `content_hash`로 변경 없는 청크는 스킵 가능

---

## 9. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [02-module-architecture.md](../../02-architecture/02-module-architecture.md) — AI AssistantModule 모듈 배치 (AI 어시스턴트 소분류)
- [FD-AI-AI어시스턴트.md](../../01-requirements/features/FD-AI-AI어시스턴트.md) — §3 프롬프트 관리, §8 데이터 모델
- [FD-EMB-임베딩파이프라인.md](../../01-requirements/features/FD-EMB-임베딩파이프라인.md) — §3 임베딩 데이터 모델
- [FD-AUD-감사로그.md](../../01-requirements/features/FD-AUD-감사로그.md) — §2.4 `prompt.updated` 감사 이벤트
- [audit-log-module.md](../audit-log/data.md) — AuditLog (프롬프트 변경 감사 기록)
