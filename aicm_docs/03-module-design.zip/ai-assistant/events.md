# AI Assistant 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 발행 이벤트 개요

| # | 이벤트명 | 티어 | 채널 | 트리거 |
|---|----------|------|------|--------|
| 1 | `ai.summary.requested` | Important | BullMQ (`ai-summary`) | 문서 published 전환 |
| 2 | `ai.summary.completed` | Best-effort | EventBus | 자동 요약 생성 완료 |
| 3 | `ai.summary.failed` | Best-effort | EventBus | 자동 요약 최종 실패 |
| 4 | `ai.cache.invalidated` | Best-effort | EventBus | 문서 content_hash 변경 |
| 5 | `ai.usage.logged` | Best-effort | EventBus | AI 기능 호출 이력 기록 |
| 6 | `prompt.updated` | Best-effort | EventBus | 프롬프트 버전 생성/롤백 |
| 7 | `embedding.completed` | Best-effort | EventBus | 임베딩 성공 완료 |
| 8 | `embedding.failed` | Best-effort | EventBus | 임베딩 최종 실패 |
| 9 | `embedding.progress` | Best-effort | EventBus | 대량 재임베딩 진행률 |

---

## 2. 발행 이벤트 상세

### 2.1 `ai.summary.requested` — 자동 요약 큐 등록

- **티어**: Important
- **채널**: BullMQ — `ai-summary` 큐
- **트리거**: `document.published` 이벤트 수신 시, 자동 요약이 활성이고 content_hash 변경이 감지된 경우
- **비고**: 자동 요약이 꺼져 있으면 enqueue 스킵
- **페이로드**:

```typescript
interface AiSummaryRequestedPayload {
  schemaVersion: 1;
  documentId: string;     // UUID
  versionId: string;      // UUID
  contentHash: string;    // 문서 content_hash
  tenantId: string;       // UUID
  priority: number;       // 1=최고, 기본 2
}
```

- **소비자**: AiSummaryWorker (동일 모듈 내부)
- **재시도**: 지수 백오프 (초기 5s, ×2), 최대 3회
- **DLQ**: `ai-summary-dlq` — 최대 재시도 소진 후 이동
- **멱등성**: `jobId = summary:${documentId}:${versionId}` — 동일 조합 중복 Job 자동 무시
- **Reconciliation**: schedule.md §2.2 (Summary 보정 배치)
- **규칙**: BR-AIA-001, BR-AIA-003

---

### 2.2 `ai.summary.completed` — 자동 요약 완료

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: AiSummaryWorker가 자동 요약 생성 완료
- **페이로드**:

```typescript
interface AiSummaryCompletedPayload {
  schemaVersion: 1;
  documentId: string;
  versionId: string;
  summaryText: string;
  modelName: string;
  tokenCount: number;
  tenantId: string;
}
```

- **소비자**:
  - NotificationModule — 요약 완료 알림 (작성자에게)
  - AggregationModule — 통계 집계

---

### 2.3 `ai.summary.failed` — 자동 요약 실패

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: AiSummaryWorker에서 요약 생성 최대 재시도 소진
- **페이로드**:

```typescript
interface AiSummaryFailedPayload {
  schemaVersion: 1;
  documentId: string;
  versionId: string;
  errorCode: string;      // AIA_SUMMARY_FAILED 등
  retryCount: number;
  tenantId: string;
}
```

- **소비자**:
  - NotificationModule — 실패 알림 (작성자 + 관리자)
  - AggregationModule — 실패 통계
- **규칙**: BR-AIA-002

---

### 2.4 `ai.cache.invalidated` — 요약 캐시 무효화

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: `document.content-updated` 이벤트 수신 시 content_hash 변경 감지
- **페이로드**:

```typescript
interface AiCacheInvalidatedPayload {
  schemaVersion: 1;
  documentId: string;
  contentHash: string;          // 새 content_hash
  invalidatedTypes: string[];   // 무효화된 요약 타입 목록
  tenantId: string;
}
```

- **소비자**: (내부 처리 — AiSummaryCache 무효화)
- **규칙**: BR-AIA-006

---

### 2.5 `ai.usage.logged` — AI 사용 이력 기록

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: AI 기능 호출 완료 (요약, 개선, 태그 추천)
- **페이로드**:

```typescript
interface AiUsageLoggedPayload {
  schemaVersion: 1;
  usageLogId: string;
  featureType: 'summary_auto' | 'summary_manual' | 'writing_improve' | 'tag_recommend';
  documentId: string;
  tenantId: string;
  userId: string;
  modelName: string;
  inputTokens: number;
  outputTokens: number;
  responseTimeMs: number;
}
```

- **소비자**:
  - AuditLogModule — 감사 로그 기록
- **규칙**: BR-AIA-017, BR-AIA-018

---

### 2.6 `prompt.updated` — 프롬프트 변경 감사

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: 프롬프트 새 버전 생성, 활성 버전 전환, 롤백
- **페이로드**:

```typescript
interface PromptUpdatedPayload {
  schemaVersion: 1;
  slotId: string;
  slotKey: string;
  action: 'version_created' | 'rollback';
  newVersionId: string;
  previousVersionId: string | null;
  changeNote: string | null;
  changedBy: string;          // UUID — 변경 수행자
  tenantId: string;
}
```

- **소비자**:
  - AuditLogModule — 감사 로그 기록 (프롬프트 변경 추적)
- **규칙**: BR-AIA-016

---

### 2.7 `embedding.completed` — 임베딩 성공 완료

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: EmbeddingWorker에서 문서 전체 청크 임베딩 완료
- **페이로드**:

```typescript
interface EmbeddingCompletedPayload {
  schemaVersion: 1;
  documentId: string;
  versionId: string;
  taskId: string;
  totalChunks: number;
  processedChunks: number;
  durationMs: number;
  tenantId: string;
}
```

- **소비자**:
  - NotificationModule — 임베딩 완료 알림 (묶음 알림, BR-EMB-006)
  - AggregationModule — 통계 집계

---

### 2.8 `embedding.failed` — 임베딩 최종 실패

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: EmbeddingWorker에서 최대 재시도 소진 또는 재시도 불가 에러
- **페이로드**:

```typescript
interface EmbeddingFailedPayload {
  schemaVersion: 1;
  documentId: string;
  versionId: string;
  taskId: string;
  totalChunks: number;
  processedChunks: number;
  failedChunks: number;
  errorCode: string;        // EMB_E001~E006
  durationMs: number;
  tenantId: string;
}
```

- **소비자**:
  - NotificationModule — 실패 알림 (작성자 + 관리자)
  - AggregationModule — 실패 통계

---

### 2.9 `embedding.progress` — 대량 재임베딩 진행률

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: 일괄 재임베딩 진행 중 일정 간격으로 발행
- **페이로드**:

```typescript
interface EmbeddingProgressPayload {
  schemaVersion: 1;
  bulkJobId: string;
  totalDocuments: number;
  completedDocuments: number;
  failedDocuments: number;
  progressPercent: number;    // 0~100
  tenantId: string;
}
```

- **소비자**:
  - NotificationModule — 관리자 진행률 알림

---

## 3. 소비 이벤트

| # | 이벤트명 | 발행자 | 채널 | 처리 내용 | 관련 규칙 |
|---|----------|--------|------|----------|-----------|
| 1 | `document.published` | DocumentModule | EventBus | (1) 자동 요약 트리거 — content_hash 변경 시 `ai-summary` 큐 등록 (2) 임베딩 트리거 — `embedding` 큐 등록 | BR-AIA-001, BR-EMB-015 |
| 2 | `document.content-updated` | DocumentModule | EventBus | 요약 캐시 무효화 → `ai.cache.invalidated` 발행 | BR-AIA-006 |
| 3 | `document.deleted` | DocumentModule | EventBus | Milvus + ES 벡터 물리 삭제, 진행 중 임베딩 Job 취소 | BR-EMB-016 |
| 4 | `document.suspended` | DocumentModule | EventBus | Milvus `is_suspended=true` 갱신 (벡터 물리 삭제 없이 필터 제외) | BR-EMB-024 |
| 5 | `document.unsuspended` | DocumentModule | EventBus | Milvus `is_suspended=false` 복원 + content_hash 비교 → 변경 시 재임베딩 | BR-EMB-025 |
| 6 | `shared-content.updated` | DocumentModule | EventBus | 공통 컨텐츠가 포함된 문서 일괄 재임베딩 트리거 | BR-EMB-009 |

### 소비 이벤트 처리 상세

#### `document.published` 처리

1. **요약 분기**: 자동 요약 활성 여부 확인 → 비활성이면 스킵. 활성이면 content_hash 비교 → 변경 시 `ai-summary` 큐에 Job 등록 (`jobId = summary:${documentId}:${versionId}`)
2. **임베딩 분기**: `embedding` 큐에 Job 등록 (`jobId = emb:${documentId}:${version}`). 기존 `processing` 상태의 Job이 있으면 취소 후 새 Job 생성 [BR-EMB-004]

#### `document.deleted` 처리

1. 진행 중인 EmbeddingTask가 있으면 `cancelled`로 전환
2. RetrievalServiceClient를 통해 Milvus에서 해당 문서의 벡터 물리 삭제
3. ES `aicm_chunks`에서도 삭제
4. 실패 시 3회 재시도 후 에스컬레이션

#### `document.suspended` 처리

1. RetrievalServiceClient를 통해 Milvus `is_suspended=true` 갱신
2. 갱신 실패 시 3회 재시도 후 `EMB_E002`로 에스컬레이션
3. 멱등 — 이미 `true`이면 무시

#### `shared-content.updated` 처리

1. 영향 받는 문서 목록 조회 (DocumentModule 읽기)
2. 각 문서에 대해 `embedding` 큐에 priority=3으로 Job 등록
3. `embedding.progress` 이벤트로 진행률 통지

---

## 4. 외부 서비스 호출

### 4.1 LlmOrchestratorClient

| 호출 시점 | 요청 개요 | 응답 | 서킷브레이커 |
|----------|----------|------|-------------|
| 자동 요약 생성 (Worker) | `POST /llm/generate` — 문서 본문 + 요약 프롬프트 | 요약 텍스트 (스트리밍/배치) | ● 적용 |
| 수동 요약 생성 (SSE) | `POST /llm/generate-stream` — 문서 본문 + 요약 프롬프트 + 요약 타입 | SSE 스트림 | ● 적용 |
| 글쓰기 개선 (SSE) | `POST /llm/generate-stream` — 블록 텍스트 + 개선 프롬프트 + 개선 타입 | SSE 스트림 | ● 적용 |
| 태그 추천 | `POST /llm/generate` — 문서 본문 + 태그 풀 + 태그 프롬프트 | 추천 태그 JSON | ● 적용 |
| 프롬프트 테스트 (관리자) | `POST /llm/generate` — 테스트 프롬프트 + 샘플 텍스트 | 생성 결과 + 토큰 수 + 응답시간 | ● 적용 |

**서킷브레이커 정책**:

| 항목 | 값 |
|------|---|
| 상태 키 | `{tenant_id}:circuit:llm-orchestrator` (Redis) |
| 실패 임계값 | 5회 연속 실패 |
| Open 유지 시간 | 30초 |
| Half-Open 시도 수 | 1건 |
| 타임아웃 | 30초 (스트리밍: 60초) |
| Fallback | 503 `AIA_SERVICE_UNAVAILABLE` 반환 |

### 4.2 RetrievalServiceClient

| 호출 시점 | 요청 개요 | 응답 | 서킷브레이커 |
|----------|----------|------|-------------|
| 임베딩 요청 (Worker) | `POST /embedding/upsert` — 청크 텍스트 + 메타데이터 | 벡터 ID 목록 | ● 적용 |
| 벡터 삭제 | `DELETE /embedding/documents/:documentId` — 문서 벡터 전체 삭제 | 삭제 건수 | ● 적용 |
| suspended 플래그 갱신 | `PATCH /embedding/documents/:documentId/metadata` — `is_suspended` 변경 | 갱신 확인 | ● 적용 |
| 임베딩 상태 확인 | `GET /embedding/documents/:documentId/status` — 벡터 존재 여부 + content_hash 비교 | 상태 정보 | ● 적용 |

**서킷브레이커 정책**:

| 항목 | 값 |
|------|---|
| 상태 키 | `{tenant_id}:circuit:retrieval-service` (Redis) |
| 실패 임계값 | 5회 연속 실패 |
| Open 유지 시간 | 30초 |
| Half-Open 시도 수 | 1건 |
| 타임아웃 | 30초 |
| Fallback | 임베딩 Worker → Job 재시도 (재시도 가능 에러), API → 503 반환 |

---

## 5. BullMQ 큐 요약

### 5.1 `ai-summary` 큐


| 항목 | 값 |
|------|---|
| 용도 | 자동 요약 비동기 생성 |
| 기술 | BullMQ (Redis) |
| 동시 처리 | 2 워커 |
| 우선순위 | 기본 2 |
| 재시도 | 지수 백오프 (초기 5s, ×2), 최대 3회 |
| 타임아웃 | 60초 |
| DLQ | `ai-summary-dlq` |
| 멱등성 | `jobId = summary:${documentId}:${versionId}` |

### 5.2 `embedding` 큐

| 항목 | 값 |
|------|---|
| 용도 | 문서 임베딩 비동기 처리 (청킹 + 벡터 생성) |
| 기술 | BullMQ (Redis) |
| 동시 처리 | `pm:embedding.concurrency` (기본 3) |
| 우선순위 | 신규 배포(1) > 문서 수정(2) > 공통 컨텐츠/대량(3) |
| 재시도 | 지수 백오프 (초기 1s, 최대 60s), 최대 3회 |
| 타임아웃 | 300초 (대용량 문서 고려) |
| DLQ | `embedding-dlq` |
| 멱등성 | `jobId = emb:${documentId}:${version}` |

### 5.3 큐 간 격리 원칙

`ai-summary` 큐와 `embedding` 큐는 **독립 워커**로 처리하여 상호 영향을 차단한다 [BR-EMB-008].

- 임베딩 처리 지연이 요약에 영향을 주지 않음
- 각 큐별 독립 DLQ 운영
- 각 큐별 독립 재시도 정책
- 각 큐별 독립 서킷브레이커 (외부 서비스 호출 시)

---

## 6. 이벤트 흐름 요약

```mermaid
sequenceDiagram
    participant Doc as DocumentModule
    participant AIA as AI AssistantModule
    participant SumQ as ai-summary 큐
    participant EmbQ as embedding 큐
    participant LLM as LlmOrchestrator
    participant Ret as RetrievalService
    participant Notif as NotificationModule
    participant Audit as AuditLogModule

    Doc->>AIA: document.published
    
    alt 자동 요약 활성 && content_hash 변경
        AIA->>SumQ: ai.summary.requested (enqueue)
        SumQ->>AIA: Worker 수신
        AIA->>LLM: POST /llm/generate
        LLM-->>AIA: 요약 텍스트
        AIA->>AIA: summary_status=completed
        AIA-->>Notif: ai.summary.completed (EventBus)
    end

    AIA->>EmbQ: embedding Job (enqueue)
    EmbQ->>AIA: Worker 수신
    AIA->>Ret: POST /embedding/upsert
    Ret-->>AIA: 벡터 ID
    AIA->>AIA: embedding_status=completed
    AIA-->>Notif: embedding.completed (EventBus)

    Note over AIA,Audit: AI 기능 호출 시
    AIA-->>Audit: ai.usage.logged (EventBus)
```
