# AI Assistant 캐시 설계

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 캐시 대상 요약

| # | 대상 | 전략 | 키 패턴 | TTL | 참조 |
|---|------|------|---------|-----|------|
| C1 | AiSummaryCache (수동 요약) | DB 기반 Cache-Aside | RDB 테이블 (`ai_summary_cache`) | 없음 (이벤트 기반 무효화) | §2.1 |
| C2 | 서킷브레이커 — LlmOrchestratorClient | Redis 상태 저장 | `{tenant_id}:circuit:llm-orchestrator` | 상태 전이 시 갱신 | §3.1 |
| C3 | 서킷브레이커 — RetrievalServiceClient | Redis 상태 저장 | `{tenant_id}:circuit:retrieval-service` | 상태 전이 시 갱신 | §3.2 |

> AI AssistantModule은 **Redis 전용 캐시 키를 사용하지 않는다**. 요약 캐시는 PostgreSQL 테이블 기반이며, Redis는 BullMQ 큐와 서킷브레이커 상태 저장 용도로만 사용한다.

---

## 2. 캐시 상세

### 2.1 AiSummaryCache — DB 레벨 캐시 (C1)

| 항목 | 내용 |
|------|------|
| **대상** | 수동 요약 결과 (사용자 요청 시 생성) |
| **전략** | Cache-Aside — PostgreSQL `ai_summary_cache` 테이블 기반 |
| **키** | `document_id + document_version_id + summary_type + content_hash` 조합 |
| **TTL** | 없음 — 이벤트 기반 무효화 |
| **저장소** | PostgreSQL (Redis 아님) |
| **크기 제한** | `summary_text` TEXT 컬럼, 모델 출력 길이에 의존 |

**캐시 히트 조건**:

| 필드 | 역할 |
|------|------|
| `document_id` | 대상 문서 식별 |
| `document_version_id` | 문서 버전 식별 |
| `summary_type` | 요약 유형: `oneline`, `keypoints`, `section`, `custom` |
| `content_hash` | 문서 본문 해시 — 내용 변경 여부 판단 |

4개 필드 조합이 모두 일치하면 캐시 히트로 판단하여 저장된 `summary_text`를 반환한다.

**읽기 흐름**:

```mermaid
sequenceDiagram
    participant User as 사용자
    participant API as AiAssistantController
    participant Service as AiSummaryService
    participant DB as PostgreSQL
    participant LLM as LlmOrchestrator

    User->>API: POST /ai/summary (수동 요약 요청)
    API->>Service: generateSummary()
    Service->>DB: SELECT FROM ai_summary_cache<br/>WHERE doc_id + version_id + type + content_hash
    alt 캐시 히트
        DB-->>Service: AiSummaryCache 레코드
        Service-->>API: 캐시된 요약 텍스트
    else 캐시 미스
        Service->>LLM: POST /llm/generate-stream (SSE)
        LLM-->>Service: 스트리밍 응답
        Service->>DB: UPSERT ai_summary_cache
        DB-->>Service: OK
        Service-->>API: SSE 스트리밍 요약
    end
    API-->>User: 응답 (캐시 히트: 즉시 / 미스: SSE)
```

**무효화 트리거**:

| 트리거 | 동작 |
|--------|------|
| `document.content-updated` 이벤트 수신 | content_hash 변경 감지 → 해당 `document_id`의 AiSummaryCache 레코드 전체 삭제 → `ai.cache.invalidated` 이벤트 발행 |

- 무효화는 `content_hash` 비교로 판단한다. 문서 내용이 실제로 변경되지 않았으면 캐시를 유지한다.
- 무효화 후 재적재는 다음 수동 요약 요청 시 Lazy Load (cache-aside 패턴).

**Fallback**:

| 상황 | 동작 |
|------|------|
| 캐시 미스 | LLM 호출 (SSE 스트리밍) → 결과를 `ai_summary_cache`에 저장 |
| LLM 서킷브레이커 Open | 503 `AIA_SERVICE_UNAVAILABLE` 반환 |
| DB 장애 | 캐시 조회 스킵 → LLM 직접 호출 시도 (결과 미저장) |

**부분 고유 인덱스** ([data.md](data.md) §6 참조):

```sql
CREATE UNIQUE INDEX uq_ai_summary_cache_doc_type
  ON ai_summary_cache (document_id, document_version_id, summary_type)
  WHERE custom_instruction IS NULL;
```

일반 요약(`custom_instruction IS NULL`)은 동일 문서+버전+타입 조합에 하나만 허용한다. 맞춤 요약(`custom`)은 지시문이 다를 수 있으므로 고유 제약에서 제외한다.

---

## 3. 서킷브레이커 상태 (Redis 저장)

외부 서비스 호출의 서킷브레이커 상태는 Redis에 저장된다. 키 패턴은 [redis.md](../../02-architecture/data/aicm/redis.md)의 `{tenant_id}:circuit:{service_name}` 규칙을 따른다.

### 3.1 LlmOrchestratorClient (C2)

| 항목 | 값 |
|------|---|
| 키 패턴 | `{tenant_id}:circuit:llm-orchestrator` |
| 대상 | LlmOrchestratorClient — AI 요약, 글쓰기 개선, 태그 추천, 프롬프트 테스트 |
| 실패 임계값 | 5회 연속 실패 |
| Open 유지 시간 | 30초 |
| Half-Open 시도 수 | 1건 |
| 타임아웃 | 30초 (스트리밍: 60초) |
| Fallback | 503 `AIA_SERVICE_UNAVAILABLE` 반환 |

> 상세: [events.md §4.1](events.md)

### 3.2 RetrievalServiceClient (C3)

| 항목 | 값 |
|------|---|
| 키 패턴 | `{tenant_id}:circuit:retrieval-service` |
| 대상 | RetrievalServiceClient — 임베딩 upsert, 벡터 삭제, suspended 플래그, 상태 확인 |
| 실패 임계값 | 5회 연속 실패 |
| Open 유지 시간 | 30초 |
| Half-Open 시도 수 | 1건 |
| 타임아웃 | 30초 |
| Fallback | Worker → Job 재시도 (재시도 가능 에러), API → 503 반환 |

> 상세: [events.md §4.2](events.md)

---

## 4. 분산 락

AI AssistantModule의 분산 락은 스케줄 배치 작업의 동시 실행 방지 용도이며, [schedule.md](schedule.md)에서 상세를 다룬다.

| 분산 락 키 | 용도 | TTL |
|-----------|------|-----|
| `{tenant_id}:lock:ai:embedding-recon` | Embedding Reconciliation 동시 실행 방지 | 300초 |
| `{tenant_id}:lock:ai:summary-recon` | Summary Reconciliation 동시 실행 방지 | 180초 |
| `{tenant_id}:lock:ai:usage-archive` | AiUsageLog 아카이빙 동시 실행 방지 | 3600초 |
| `{tenant_id}:lock:ai:partial-timeout` | partial 상태 타임아웃 체크 동시 실행 방지 | 120초 |

---

## 5. Redis 의존 요약

| 용도 | 키/큐 | 비고 |
|------|-------|------|
| BullMQ 큐 | `ai-summary` | 자동 요약 비동기 생성 |
| BullMQ 큐 | `embedding` | 임베딩 비동기 처리 |
| 서킷브레이커 | `{tenant_id}:circuit:llm-orchestrator` | LlmOrchestratorClient 상태 |
| 서킷브레이커 | `{tenant_id}:circuit:retrieval-service` | RetrievalServiceClient 상태 |
| 분산 락 | `{tenant_id}:lock:ai:*` (4종) | 스케줄 배치 동시 실행 방지 |
| 전용 캐시 키 | **없음** | AiSummaryCache는 PostgreSQL 테이블 기반 |

> AI AssistantModule은 Redis를 **캐시 저장소로 사용하지 않는다**. 요약 결과 캐싱은 PostgreSQL `ai_summary_cache` 테이블에서 처리하며, Redis는 BullMQ 큐 인프라, 서킷브레이커 상태 공유, 분산 락 용도로만 활용한다.
