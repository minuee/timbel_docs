# AI Assistant 스케줄 및 배치 작업

> - 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> - 비즈니스 규칙: [rules.md](./rules.md)
> - 이벤트: [events.md](./events.md)

---

## 1. 스케줄 작업 개요

| # | 작업명 | 목적 | cron 주기 | 설정 키 |
|---|--------|------|-----------|---------|
| 1 | Embedding Reconciliation | embedding 실패/누락 문서 재처리 | 매 30분 | `sc:ai.embedding_recon_cron` |
| 2 | Summary Reconciliation | AI 요약 실패 문서 재처리 | 매 30분 | `sc:ai.summary_recon_cron` |
| 3 | AiUsageLog 아카이빙 | 보관 기간 경과 사용 이력 아카이빙 | 매월 1일 02:00 | `sc:ai.usage_archive_cron` |
| 4 | partial 상태 타임아웃 체크 | partial 체류 시간 초과 문서 failed 전이 | 매 10분 | `sc:ai.partial_timeout_cron` |

---

## 2. 작업 상세

### 2.1 Embedding Reconciliation — 임베딩 보정

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | `embedding` 큐 처리 실패 또는 누락된 문서를 탐지하여 재처리 큐에 투입 |
| cron 표현식 | `*/30 * * * *` (매 30분) |
| 설정 키 | `sc:ai.embedding_recon_cron` |
| 관련 큐 | `embedding` |

#### 실행 로직

1. **대상 조건 쿼리**:
   - `embedding_status = 'failed'` AND `updated_at < NOW() - INTERVAL '30 minutes'` — 일정 시간 경과한 실패 건
   - `embedding_status = 'pending'` AND `updated_at < NOW() - INTERVAL '2 hours'` — 비정상 장기 대기 건 (큐 유실 추정)
   - `status = 'published'` AND `embedding_status IS NULL` — 임베딩 상태가 없는 게시 문서 (마이그레이션 누락)

2. **처리 절차**:
   - 대상 문서 목록 조회 (배치 크기: 100건)
   - 각 문서에 대해 `embedding` 큐에 priority=3으로 Job 등록
   - `embedding_status = 'pending'`으로 갱신
   - 처리 건수 로그 기록

3. **Document 모듈 Reconciliation과의 역할 분담**:
   - Document 모듈의 Reconciliation은 ES 인덱싱(`es-indexing` 큐) 실패/누락을 보정
   - AI Assistant 모듈의 Reconciliation은 벡터 DB 임베딩(`embedding` 큐) 실패/누락을 보정
   - 두 배치는 독립 실행되며, 실행 순서 의존성 없음

4. **완료 조건**: 대상 목록 전체 순회 완료 또는 배치 크기 한도 도달

#### 동시 실행 제어

| 항목 | 값 |
|------|---|
| 분산 락 키 | `{tenant_id}:lock:ai:embedding-recon` |
| TTL | 300초 (5분) |
| 획득 실패 시 | 해당 실행 스킵 — 다음 주기에 재시도 |

#### 실패 처리

| 항목 | 값 |
|------|---|
| 부분 실패 허용 | 허용 — 개별 문서 enqueue 실패 시 해당 건만 스킵하고 나머지 계속 처리 |
| 재시도 정책 | 배치 자체의 재시도 없음 — 다음 cron 주기에 자동 재실행 |
| 관리자 알림 조건 | 단일 실행에서 실패율 > 50% 시 알림 |

#### 설정

| 설정 키 | 기본값 | 설명 |
|---------|--------|------|
| `sc:ai.embedding_recon_cron` | `*/30 * * * *` | 실행 주기 |
| `pm:embedding.recon_batch_size` | 100 | 배치당 최대 처리 건수 |
| `pm:embedding.recon_failed_threshold_min` | 30 | failed 상태 경과 시간 임계값 (분) |
| `pm:embedding.recon_pending_threshold_min` | 120 | pending 장기 대기 임계값 (분) |

---

### 2.2 Summary Reconciliation — 요약 보정

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | AI 요약 생성 실패 문서를 탐지하여 재처리 큐에 투입 |
| cron 표현식 | `*/30 * * * *` (매 30분) |
| 설정 키 | `sc:ai.summary_recon_cron` |
| 관련 큐 | `ai-summary` |

#### 실행 로직

1. **대상 조건 쿼리**:
   - `summary_status = 'failed'` AND `updated_at < NOW() - INTERVAL '30 minutes'` — 일정 시간 경과한 실패 건
   - `summary_status = 'pending'` AND `updated_at < NOW() - INTERVAL '1 hour'` — 비정상 장기 대기 건
   - `status = 'published'` AND 자동 요약이 켜진 테넌트 AND `summary_status = 'none'` AND `auto_summary IS NULL` — 요약 누락 게시 문서

2. **처리 절차**:
   - 대상 문서 목록 조회 (배치 크기: 50건)
   - 각 문서에 대해 `ai-summary` 큐에 priority=3으로 Job 등록
   - `summary_status = 'pending'`으로 갱신
   - 처리 건수 로그 기록

3. **우선순위**: 요약은 비필수 기능이므로 priority=3 (최저) — 실시간 요약 요청(priority=1)이나 published 전환(priority=2)보다 낮은 우선순위

4. **완료 조건**: 대상 목록 전체 순회 완료 또는 배치 크기 한도 도달

#### 동시 실행 제어

| 항목 | 값 |
|------|---|
| 분산 락 키 | `{tenant_id}:lock:ai:summary-recon` |
| TTL | 180초 (3분) |
| 획득 실패 시 | 해당 실행 스킵 — 다음 주기에 재시도 |

#### 실패 처리

| 항목 | 값 |
|------|---|
| 부분 실패 허용 | 허용 — 개별 문서 enqueue 실패 시 스킵 |
| 재시도 정책 | 배치 자체의 재시도 없음 — 다음 cron 주기에 자동 재실행 |
| 관리자 알림 조건 | 단일 실행에서 실패율 > 50% 시 알림 |

#### 설정

| 설정 키 | 기본값 | 설명 |
|---------|--------|------|
| `sc:ai.summary_recon_cron` | `*/30 * * * *` | 실행 주기 |
| `pm:ai.summary_recon_batch_size` | 50 | 배치당 최대 처리 건수 |
| `pm:ai.summary_recon_failed_threshold_min` | 30 | failed 상태 경과 시간 임계값 (분) |
| `pm:ai.summary_recon_pending_threshold_min` | 60 | pending 장기 대기 임계값 (분) |

---

### 2.3 AiUsageLog 아카이빙

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 보관 기간이 경과한 AI 사용 이력 레코드를 아카이브 테이블로 이동하여 메인 테이블 성능 유지 |
| cron 표현식 | `0 2 1 * *` (매월 1일 02:00) |
| 설정 키 | `sc:ai.usage_archive_cron` |
| 관련 테이블 | `ai_usage_log`, `ai_usage_log_archive` |

#### 실행 로직

1. **대상 조건 쿼리**:
   - `created_at < NOW() - INTERVAL '${pm:ai.usage_log_retention_years} years'`
   - 기본: 1년 경과 레코드, 금융권 설정 시 5년

2. **처리 절차**:
   - 배치 단위(1000건)로 조회
   - `ai_usage_log_archive` 테이블에 INSERT
   - 원본 테이블에서 DELETE
   - 관련 `ai_feedbacks` 레코드도 함께 아카이빙
   - 처리 건수 로그 기록

3. **완료 조건**: 대상 레코드 전체 처리 완료

#### 동시 실행 제어

| 항목 | 값 |
|------|---|
| 분산 락 키 | `{tenant_id}:lock:ai:usage-archive` |
| TTL | 3600초 (1시간) — 대량 데이터 처리 고려 |
| 획득 실패 시 | 해당 실행 스킵 — 다음 월 실행 |

#### 실패 처리

| 항목 | 값 |
|------|---|
| 부분 실패 허용 | 허용 — 배치 단위 트랜잭션, 실패 배치만 롤백하고 다음 배치 계속 |
| 재시도 정책 | 배치 자체의 재시도 없음 — 다음 월 cron에서 미아카이빙 건 재처리 |
| 관리자 알림 조건 | 아카이빙 작업 실패 시 알림, 처리 건수 요약 알림 (성공 시에도) |

#### 설정

| 설정 키 | 기본값 | 설명 |
|---------|--------|------|
| `sc:ai.usage_archive_cron` | `0 2 1 * *` | 실행 주기 |
| `pm:ai.usage_log_retention_years` | 1 | 보관 기간 (년). 금융권 5년 |
| `pm:ai.usage_archive_batch_size` | 1000 | 배치당 처리 건수 |

---

### 2.4 partial 상태 타임아웃 체크

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | `partial` 상태로 일정 시간 이상 체류하는 문서를 `failed`로 전이하고 관리자에게 알림 |
| cron 표현식 | `*/10 * * * *` (매 10분) |
| 설정 키 | `sc:ai.partial_timeout_cron` |
| 관련 규칙 | BR-EMB-002 — partial 최대 1시간 체류 제한 |

#### 실행 로직

1. **대상 조건 쿼리**:
   - `embedding_status = 'partial'` AND `updated_at < NOW() - INTERVAL '${pm:embedding.partial_max_duration_min} minutes'`
   - 기본: 60분 초과 체류

2. **처리 절차**:
   - 대상 문서 목록 조회
   - 각 문서의 `embedding_status` = `failed`로 갱신
   - 해당 EmbeddingTask에 `error_code = 'EMB_PARTIAL_TIMEOUT'`, `error_message = 'partial 상태 체류 시간 초과'` 기록
   - `embedding.failed` 이벤트 발행 (관리자 알림 연동)
   - 처리 건수 로그 기록

3. **완료 조건**: 대상 목록 전체 처리 완료

#### 동시 실행 제어

| 항목 | 값 |
|------|---|
| 분산 락 키 | `{tenant_id}:lock:ai:partial-timeout` |
| TTL | 120초 (2분) |
| 획득 실패 시 | 해당 실행 스킵 — 다음 주기에 재시도 |

#### 실패 처리

| 항목 | 값 |
|------|---|
| 부분 실패 허용 | 허용 — 개별 문서 갱신 실패 시 스킵 |
| 재시도 정책 | 배치 자체의 재시도 없음 — 다음 cron 주기에 자동 재실행 |
| 관리자 알림 조건 | 타임아웃 전이 발생 시 항상 알림 |

#### 설정

| 설정 키 | 기본값 | 설명 |
|---------|--------|------|
| `sc:ai.partial_timeout_cron` | `*/10 * * * *` | 실행 주기 |
| `pm:embedding.partial_max_duration_min` | 60 | partial 최대 체류 시간 (분) |

---

## 3. 작업 의존 관계

```mermaid
graph TD
    subgraph "AI Assistant 스케줄"
        PT["partial 타임아웃 체크<br/>(*/10 * * * *)"]
        ER["Embedding Reconciliation<br/>(*/30 * * * *)"]
        SR["Summary Reconciliation<br/>(*/30 * * * *)"]
        UA["UsageLog 아카이빙<br/>(0 2 1 * *)"]
    end

    subgraph "Document 모듈 스케줄"
        DR["Document Reconciliation<br/>(ES 인덱싱 보정)"]
    end

    PT -->|"failed 전이 → 다음 주기에 재처리 대상"| ER
    ER -.->|"독립 실행 (의존 없음)"| DR
    SR -.->|"독립 실행"| ER

    classDef schedule fill:#dbeafe,stroke:#2563eb
    classDef external fill:#f3f4f6,stroke:#6b7280
    class PT,ER,SR,UA schedule
    class DR external
```

### 실행 순서 관계

| 관계 | 설명 |
|------|------|
| partial 타임아웃 → Embedding Reconciliation | partial 타임아웃 체크에서 `failed`로 전이된 문서가 다음 Embedding Reconciliation 주기에서 재처리 대상이 됨. **직접 의존 아님** — 각각 독립 cron |
| Embedding Reconciliation ↔ Document Reconciliation | 독립 실행. Embedding은 벡터 DB(Milvus) 보정, Document는 ES 인덱싱 보정. 동일 문서가 양쪽 모두 실패한 경우 각각 독립 재처리 |
| Summary Reconciliation ↔ Embedding Reconciliation | 독립 실행. 요약과 임베딩은 별도 큐(`ai-summary` vs `embedding`)로 운영 |
| UsageLog 아카이빙 | 완전 독립 — 다른 스케줄과 의존 관계 없음 |
