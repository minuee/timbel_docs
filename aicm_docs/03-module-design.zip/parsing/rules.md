# Parsing 비즈니스 규칙

> 원천: [FD-SCH-검색 §3~§5](../../01-requirements/features/FD-SCH-검색.md)
> API 스펙: [api.md](api.md)

---

## 1. 상태 전이

### 1.1 문서 파싱 상태

```mermaid
stateDiagram-v2
    [*] --> pending: 파일 업로드 완료
    pending --> processing: BR-PRS-013
    processing --> completed: BR-PRS-001/003
    processing --> completed_with_warnings: BR-PRS-004
    processing --> failed: BR-PRS-016
    failed --> processing: 수동 재시도
```

---

## 2. 비즈니스 규칙 카탈로그

### BR-PRS-001 — 블록 타입별 청킹

| 항목 | 내용 |
|------|------|
| **트리거** | 문서 published 시 블록 청킹 실행 |
| **조건** | 블록 에디터 문서 (블록 JSON 직접 파싱) |
| **동작** | 블록 타입에 따라 최적 청킹 전략을 적용한다: ① 텍스트/헤딩 블록 — 인접 블록을 의미 단위로 그루핑 (헤딩을 섹션 구분자로 활용) ② 테이블 블록 — 표 전체를 하나의 청크, 대형 표는 행 그룹 단위 분할 (마크다운/HTML 테이블 형식 변환) ③ 이미지 블록 — 캡션 + 멀티모달 분석 결과를 텍스트 청크로 변환 ④ 코드 블록 — 코드 + 인접 설명 블록을 하나의 청크로 구성 ⑤ 접기(토글) 블록 — 펼친 상태의 전체 내용을 청킹 대상에 포함 |
| **위반 시** | `PRS_PARSING_FAILED` (500) — 청킹 실패 시 관리자 알림 |
| **근거** | FD-SCH §3 BR-SCH-012 |

---

### BR-PRS-002 — 공통 컨텐츠 수정 시 재청킹

| 항목 | 내용 |
|------|------|
| **트리거** | 공통 컨텐츠(SharedContent) 원본 수정 시 |
| **조건** | 참조 블록이 존재하는 문서 |
| **동작** | 참조 원본의 최신 내용을 resolve하여 재청킹한다. 트리거 범위는 해당 공통 컨텐츠를 참조하는 **모든 문서**이다. |
| **위반 시** | — (비동기 처리, 실패 시 재시도) |
| **근거** | FD-SCH §3 BR-SCH-013 |

---

### BR-PRS-003 — 파일 업로드 자동 청킹

| 항목 | 내용 |
|------|------|
| **트리거** | 파일 첨부 블록이 포함된 문서 published 시 |
| **조건** | 첨부 파일 형식이 PDF, DOCX, HWP, HWPX, PPTX 중 하나 |
| **동작** | 파일에서 텍스트를 추출(parser-service 호출)한 후 자동 청킹한다. |
| **위반 시** | `PRS_PARSING_FAILED` (500) — 추출 실패 시 failed 상태 전이 |
| **근거** | FD-SCH §3 BR-SCH-014 |

---

### BR-PRS-004 — HWP 이중 파이프라인

| 항목 | 내용 |
|------|------|
| **트리거** | HWP/HWPX 파일 텍스트 추출 시 |
| **조건** | 파일 확장자 분기 |
| **동작** | ① HWPX — XML 직접 파싱 ② 구 HWP(바이너리) — LibreOffice headless로 DOCX 변환 후 파싱. 변환 품질 미달 문서는 예외 목록으로 분리하여 수동 검수 흐름을 제공한다. |
| **위반 시** | 변환 실패 시 `completed_with_warnings` 또는 `failed` 상태 전이 |
| **근거** | FD-SCH §3 BR-SCH-015 |

---

### BR-PRS-005 — 템플릿 기반 청킹 분기

| 항목 | 내용 |
|------|------|
| **트리거** | 청킹 실행 시 |
| **조건** | 문서에 `template_id`가 설정되어 있고, TemplateChunkingRule에 해당 템플릿의 규칙이 존재 |
| **동작** | TemplateChunkingRule에 따라 청킹 전략을 분기한다: FAQ 템플릿 → Q&A 쌍 단위(`qa_pair`), SOP 템플릿 → 스텝 단위(`step_unit`), 체크리스트 → 항목 단위(`item_unit`) 등. |
| **위반 시** | 규칙 미존재 시 ParsingConfig의 `default_chunking_strategy` 적용 |
| **근거** | FD-SCH §3 BR-SCH-016 |

---

### BR-PRS-006 — 청킹 메타데이터 부착

| 항목 | 내용 |
|------|------|
| **트리거** | 청킹 완료 시 |
| **조건** | 항상 |
| **동작** | 각 청크에 다음 메타데이터를 부착한다: 원본 문서 ID, 블록 ID, 블록 타입, 섹션 제목(헤딩), 템플릿 ID. |
| **위반 시** | — (필수 부착) |
| **근거** | FD-SCH §3 BR-SCH-017 |

---

### BR-PRS-007 — 문서 수정/삭제 시 청크 동기화

| 항목 | 내용 |
|------|------|
| **트리거** | 원본 문서 수정 또는 삭제 시 |
| **조건** | 해당 문서의 청크가 존재 |
| **동작** | 문서 수정 시 관련 청크를 재청킹하고, 문서 삭제 시 관련 청크를 삭제한다. |
| **위반 시** | — (비동기 처리, 실패 시 Reconciliation 배치에서 보정) |
| **근거** | FD-SCH §3 BR-SCH-018 |

---

### BR-PRS-008 — 블록 임베딩/가시성 토글

| 항목 | 내용 |
|------|------|
| **트리거** | 블록 메뉴에서 "임베딩 제외" / "숨김" 토글 시 |
| **조건** | 블록의 `embeddable`, `visible` 플래그 변경 |
| **동작** | `embeddable: false`인 블록은 청킹/임베딩 파이프라인에서 스킵한다. 허용 조합: ① 임베딩 포함 + 사용자에게 보임 (기본값) ② 임베딩 제외 + 사용자에게 보임 ③ 임베딩 제외 + 사용자에게 안 보임 |
| **위반 시** | — |
| **근거** | FD-SCH §4 BR-SCH-019 |

---

### BR-PRS-009 — 임베딩O + 가시성X 미허용

| 항목 | 내용 |
|------|------|
| **트리거** | 블록 플래그 변경 시 |
| **조건** | `embeddable: true` AND `visible: false` 조합 |
| **동작** | 해당 조합을 거부한다. 사용자가 볼 수 없는 콘텐츠는 RAG 답변의 근거로도 사용할 수 없다 (출처 검증 불가한 근거 차단 원칙). ParsingModule이 제공하는 validation 함수를 DocumentModule 블록 수정 API에서 호출한다. |
| **위반 시** | 설정 차단 — `PRS_INVALID_FLAG_COMBINATION` (422) |
| **근거** | FD-SCH §4 BR-SCH-020 |

---

### BR-PRS-010 — 플래그 변경 시 재처리

| 항목 | 내용 |
|------|------|
| **트리거** | 문서 수정 시 블록의 `embeddable`/`visible` 플래그 변경 |
| **조건** | 플래그 값이 실제로 변경된 경우 |
| **동작** | 해당 블록만 재청킹/재임베딩을 트리거한다. 전체 문서 재처리가 아닌 블록 단위 부분 재처리. |
| **위반 시** | — |
| **근거** | FD-SCH §4 BR-SCH-021 |

---

### BR-PRS-011 — 중첩 표 2depth 제한

| 항목 | 내용 |
|------|------|
| **트리거** | 표(Table) 파싱 시 |
| **조건** | 중첩된 표 구조 감지 |
| **동작** | 중첩 깊이를 **2depth**로 제한한다. 레이아웃용 바깥 표는 벗겨내고 안쪽 데이터 표만 취한다. 셀 병합된 표는 병합 컨텍스트를 보존하며 청킹한다. |
| **위반 시** | 2depth 초과 시 가장 안쪽 2레벨만 취하고 나머지는 무시 |
| **근거** | FD-SCH §5.2 BR-SCH-022 |

---

### BR-PRS-012 — 이미지 블록 멀티모달 분석

| 항목 | 내용 |
|------|------|
| **트리거** | 이미지 블록 청킹 시 |
| **조건** | RAG 연동 활성 |
| **동작** | LlmOrchestratorClient를 경유하여 멀티모달 LLM으로 이미지 설명 텍스트를 생성한다. 생성된 텍스트를 임베딩하여 벡터 DB에 저장한다. 이미지 내 표/차트는 OCR + 구조 분석으로 데이터를 추출한다. 캡션과 원본 이미지를 함께 저장하여 출처 표시 시 이미지도 제공한다. |
| **위반 시** | 서킷브레이커 Open 시 메타데이터(캡션)만 저장하고 멀티모달 분석은 스킵 |
| **근거** | FD-SCH §5.3 BR-SCH-023 |

---

## 2.1 모듈 구현 규칙 (BR-PRS-013+)

> FD-SCH에 정의되지 않은 모듈 구현 수준의 비즈니스 규칙이다.

### BR-PRS-013 — 파싱 전략 분기 (구현)

| 항목 | 내용 |
|------|------|
| **트리거** | `parsing` 큐 Job 소비 시 |
| **조건** | 파일 확장자 및 문서 유형에 따라 분기 |
| **동작** | Strategy 패턴으로 파싱 전략을 분기한다: ① HWPX → XML 직접 파싱 ② 구 HWP → LibreOffice headless → DOCX 변환 후 parser-service 호출 ③ PDF/DOCX/PPTX → parser-service 직접 호출 ④ 블록 에디터 문서 → 블록 JSON 직접 파싱 (parser-service 호출 불필요) |
| **위반 시** | 미지원 파일 형식 → `PRS_UNSUPPORTED_FORMAT` (422). 서버 측 파싱 실패 → `PRS_PARSING_FAILED` (500), DLQ 진입 |

---

### BR-PRS-014 — 청킹 전략 결정 우선순위

| 항목 | 내용 |
|------|------|
| **트리거** | 청킹 실행 시 |
| **조건** | 항상 |
| **동작** | 청킹 전략 결정 우선순위: ① TemplateChunkingRule (template_id 매칭) ② BoardParsingOverride (board_id 매칭) ③ ParsingConfig.default_chunking_strategy (글로벌 기본값). 상위 우선순위가 존재하면 하위를 무시한다. |
| **위반 시** | — |

---

### BR-PRS-015 — 청크 메타데이터 보강 (구현)

| 항목 | 내용 |
|------|------|
| **트리거** | 청킹 완료 후 SearchModule이 `parsing.completed` 이벤트를 소비하여 retrieval-service에 전달 시 |
| **조건** | 항상 |
| **동작** | SearchModule이 `POST /ingest/embed` 호출 시, ParsingModule의 청킹 설정(ParsingConfig → `chunking_config`)을 조회하여 요청에 동봉한다. ParsingModule이 직접 retrieval-service를 호출하지 않는다. 메타데이터에 `contextual_prefix` 전략이 설정되어 있으면 청크 텍스트 앞에 섹션 제목, 문서 제목 등 컨텍스트를 접두어로 부착한다. |
| **위반 시** | — |

---

### BR-PRS-016 — 파싱 실패 재시도

| 항목 | 내용 |
|------|------|
| **트리거** | `parsing` 큐 Job 처리 실패 시 |
| **조건** | 재시도 횟수 < 최대 재시도(3회) |
| **동작** | 지수 백오프로 재시도한다 (초기 10s, 최대 120s). 재시도 소진 후 DLQ(`parsing:dlq`)로 이동한다. `failed` 상태로 전이하고 관리자에게 Slack 알림을 발송한다. |
| **위반 시** | — (자동 처리) |

---

### BR-PRS-017 — 설정 저장 OCC

| 항목 | 내용 |
|------|------|
| **트리거** | `PUT /admin/search/parsing-config` |
| **조건** | 요청의 `version` ≠ DB의 현재 `version` |
| **동작** | 충돌을 감지하여 요청을 거부한다. 클라이언트는 최신 `version`을 다시 조회한 후 재시도해야 한다. |
| **위반 시** | `PRS_CONFIG_VERSION_CONFLICT` (409) |

---

## 3. 에러 코드 카탈로그

| 에러 코드 | HTTP | 메시지 | 관련 BR |
|-----------|------|--------|---------|
| PRS_PARSING_FAILED | 500 | 문서 파싱 실패 | BR-PRS-016 |
| PRS_CONFIG_VERSION_CONFLICT | 409 | 파싱 설정 버전 충돌 — 최신 버전 조회 후 재시도 | BR-PRS-017 |
| PRS_INVALID_FLAG_COMBINATION | 422 | 임베딩O + 가시성X 조합 미허용 | BR-PRS-009 |
| PRS_UNSUPPORTED_FORMAT | 422 | 미지원 파일 형식 | BR-PRS-013 |
| PRS_PARSER_UNAVAILABLE | 503 | parser-service 일시 장애 | BR-PRS-016 |
