# Parsing 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | ParsingModule |
| 문서 코드 | MS-PRS |
| 상태 | `draft` |
| 기능정의서 | [FD-SCH-검색](../../01-requirements/features/FD-SCH-검색.md) |
| 데이터 모델 | [parsing-module.md](./data.md) |
| 프로세스 흐름 | [flows/search-rag/](../../01-requirements/flows/search-rag/) |

---

## 모듈 책임

ParsingModule은 AICM의 **문서 파싱·청킹 파이프라인**을 담당한다. 파일 업로드 시점에 비동기(`parsing` BullMQ 큐)로 동작하며, 원본 파일에서 텍스트를 추출하고 검색·임베딩에 적합한 블록(청크)으로 변환한다.

| 영역 | 설명 |
|------|------|
| 문서 파싱 오케스트레이션 | 파일 업로드(PDF/DOCX/HWP/HWPX/PPTX) → parser-service 호출 → ParsedBlock 수신 |
| 파서 전략 관리 | Strategy 패턴으로 파일 확장자별 파싱 전략 분기 — HWPX(XML 직접), 구 HWP(LibreOffice → DOCX), 기타(parser-service) |
| ParsedBlock → Block 변환 | 파싱 결과를 DocumentModule의 Block 엔티티로 변환·저장 (쓰기 의존) |
| 파싱 상태 추적 | `pending` → `processing` → `completed` / `completed_with_warnings` / `failed` 상태 관리 |
| 블록 타입별 청킹 | 텍스트/헤딩 의미 단위 그루핑, 테이블 단위, 이미지 캡션+멀티모달 분석, 코드 인접 설명 결합 |
| 템플릿 기반 청킹 분기 | FAQ(Q&A 쌍), SOP(스텝 단위), 체크리스트(항목 단위) 등 TemplateChunkingRule 기반 전용 전략 |
| 청킹 메타데이터 부착 | 각 청크에 문서 ID, 블록 ID, 블록 타입, 섹션 제목, 템플릿 ID 메타데이터 부착 |
| 파싱 설정 CRUD | ParsingConfig(청킹 전략/사이즈/오버랩) + 하위 엔티티(BoardParsingOverride, TemplateChunkingRule) 관리 |

### 현재 범위 제외 기능

| 기능 | 제외 사유 | 향후 계획 |
|------|----------|----------|
| 파싱 전용 관리자 대시보드 | Phase 2 범위 — 파싱 현황·실패율 전용 UI는 MVP 핵심 아님 | Phase 2에서 관리자 대시보드 확장 시 추가 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — parsing-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **ParsingConfig** | 시스템당 1행 싱글톤. 기본 청킹 전략(`semantic`/`fixed_token`/`sliding_window`), 청크 사이즈, 오버랩 비율. 검색 요청 시가 아닌 임베딩 파이프라인에서 소비 |
| **BoardParsingOverride** | ParsingConfig 하위. 게시판별 청킹 전략, 사이즈, 오버랩 오버라이드 |
| **TemplateChunkingRule** | ParsingConfig 하위. 템플릿별 청킹 전략 매핑 — FAQ(`qa_pair`), SOP(`step_unit`), 체크리스트(`item_unit`) 등 |

---

## 의존 관계

```mermaid
graph LR
    Parse["<b>ParsingModule</b>"]

    Doc["DocumentModule"]

    Parse -->|"쓰기<br/>ParsedBlock → Block"| Doc

    Parser["ParserServiceClient"]
    LLM["LlmOrchestratorClient"]

    Parse -.->|"파싱 요청"| Parser
    Parse -.->|"이미지 분석<br/>(청킹 시)"| LLM

    classDef hub fill:#fce7f3,stroke:#db2777,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef external fill:#fef3c7,stroke:#d97706

    class Parse hub
    class Doc provider
    class Parser,LLM external
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Parse → Document | DocumentModule | 쓰기 | ParsedBlock → Block 변환·저장 |
| Parse → ParserServiceClient | 외부 서비스 | HTTP | 외부 문서(PDF/DOCX/HWP 등) 파싱 요청 |
| Parse → LlmOrchestratorClient | 외부 서비스 | HTTP | 이미지 블록 멀티모달 분석 (청킹 시 설명 텍스트 생성) |

> 파싱 결과의 ES 인덱싱 및 검색은 [SearchModule](../search/README.md)을 참조한다.

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | ParsingConfig, BoardParsingOverride, TemplateChunkingRule |
| Redis / BullMQ | ● | BullMQ `parsing` 큐(문서 파싱), 서킷브레이커 상태(`{tenant_id}:circuit:{service_name}`) |
| Elasticsearch | — | |
| MinIO | ● | parser-service 경유 파일 접근 |
| EventBus | ● 소비/발행 | **소비**: `document.published`, `shared-content.updated`, `document.content-updated`, `document.deleted`, `block.visibility-changed` **발행**: `parsing.completed` |
| 외부 서비스 클라이언트 | ● | ParserServiceClient (문서 파싱), LlmOrchestratorClient (이미지 분석) |

---

## 외부 서비스 미연동 시 Graceful Degradation

| 구분 | 비활성 시 영향 | 핵심 기능 영향 |
|------|--------------|--------------|
| RAG | 청킹·임베딩 파이프라인 비활성화 (embedding 큐 스킵) | **없음** — 파싱(텍스트 추출)과 ES 키워드 인덱싱은 독립 동작 |

> **원칙**: 파싱(텍스트 추출 + Block 변환)은 어떤 환경에서도 동작한다. 청킹·임베딩(벡터화)은 RAG 연동이 활성일 때만 수행한다.

---

## 외부 설정값 카탈로그

ParsingModule은 SystemConfig Key-Value를 사용하지 않는다. 모든 파싱/청킹 설정은 ParsingConfig 전용 싱글톤 테이블에서 관리한다. [ADR-009](../../adr/009-search-config-singleton-merge.md) 참조.

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `parsing.queue_lag` | parsing 큐 대기 Job 수 | BullMQ Dashboard |
| `parsing.failure_rate` | parsing 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `circuit.parser.state_change` | ParserServiceClient 서킷 상태 전이 | Redis 키 변경 감지 |
| `circuit.llm-orchestrator.state_change` | LlmOrchestratorClient 서킷 상태 전이 | Redis 키 변경 감지 |

---

## 모니터링 알림 임계값

| 대상 | 조건 | 심각도 | 채널 |
|------|------|--------|------|
| parsing 큐 지연 | `parsing.queue_lag > 50` (10분 이상 지속) | WARNING | Slack + 대시보드 |
| parsing 실패율 | `parsing.failure_rate > 20%` (최근 1시간) | CRITICAL | Slack + PagerDuty |
| 서킷브레이커 Open | `circuit.parser.state_change == Open` | CRITICAL | Slack + PagerDuty |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-SCH-검색](../../01-requirements/features/FD-SCH-검색.md) | 기능정의서 (입력 원본) |
| [SearchModule](../search/README.md) | 검색·RAG 파이프라인 — 파싱 결과의 ES 인덱싱, 검색 기능 |
| [parsing-module.md](./data.md) | RDB 엔티티/DDL |
| [검색/RAG 파이프라인 흐름](../../01-requirements/flows/search-rag/) | 파싱→청킹→임베딩→검색 파이프라인 다이어그램 |
| [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md) | BullMQ 큐 설계, 파싱/임베딩 파이프라인 |
| [ADR-009](../../adr/009-search-config-singleton-merge.md) | SearchConfig/ParsingConfig 싱글톤 통합 결정 |
| [parser-service 논의](../../temp/discussion-parser.md) | parser-service 외부 API 인터페이스 합의 가이드 |
