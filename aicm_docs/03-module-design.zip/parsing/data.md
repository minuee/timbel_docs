# ParsingModule — RDB 엔티티

> 파싱 설정 싱글톤 테이블 + 하위 엔티티. [ADR-009](../../adr/009-search-config-singleton-merge.md) 참조

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    ParsingConfig ||--o{ BoardParsingOverride : "1:N"
    ParsingConfig ||--o{ TemplateChunkingRule : "1:N"
```

---

## 2. 엔티티 필드

### 2.1 ParsingConfig

시스템당 1행만 존재하는 **싱글톤 파싱 설정 테이블**. 청킹 파이프라인의 기본 전략, 사이즈, 오버랩을 관리한다.

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| default_chunking_strategy | VARCHAR(30) NOT NULL DEFAULT 'semantic' | 기본 청킹 전략 (`semantic` / `fixed_token` / `sliding_window`) |
| chunk_size | INT NOT NULL DEFAULT 512 | 청크 최대 토큰 수. retrieval-service는 sLLM 임베딩 모델 최적 범위에 따라 실제 `max_tokens`를 조정할 수 있다 |
| chunk_overlap_percent | INT NOT NULL DEFAULT 10 | 오버랩 비율 (%). 인접 청크 간 중복 토큰 비율 |
| updated_by | UUID, FK(User) | 최종 수정자 |
| version | INTEGER NOT NULL DEFAULT 1 | 낙관적 동시성 제어용 버전 ([BR-PRS-017](rules.md#br-prs-017--설정-저장-occ)) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `CHECK (default_chunking_strategy IN ('semantic', 'fixed_token', 'sliding_window'))`
- `CHECK (chunk_size > 0)`
- `CHECK (chunk_overlap_percent >= 0 AND chunk_overlap_percent <= 50)`

#### 설계 결정

**검색과 분리된 독립 싱글톤**
— 파싱/청킹은 "문서 발행(임베딩) 시" 소비되며, 검색 요청 시 소비되는 SearchConfig와 도메인이 다르다. `search_config`라는 이름 안에 파싱 설정이 있으면 의미론적으로 어색하므로 독립 테이블로 유지한다 ([ADR-009](../../adr/009-search-config-singleton-merge.md)).

**동기화 패턴**
— aicm-service가 `POST /ingest/embed` 요청 시 해당 문서에 적용할 청킹 설정을 `chunking_config` 파라미터로 동봉한다. retrieval-service는 파싱 설정을 캐싱하지 않는다 (stateless).

**초기 시딩**
— 앱 최초 배포 시 ParsingConfig에 파싱 기본값을 시딩한다. 이후 관리자가 ParsingConfig를 통해 직접 조정한다.

---

### 2.2 BoardParsingOverride

ParsingConfig 하위 엔티티. 게시판별 청킹 파라미터를 오버라이드한다.

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| parsing_config_id | UUID (FK) | ParsingConfig 참조 |
| board_id | UUID NOT NULL | 게시판 ID (UNIQUE) |
| chunking_strategy | VARCHAR(30) (nullable) | 청킹 전략 오버라이드. NULL이면 글로벌 `default_chunking_strategy` 사용 |
| chunk_size | INT (nullable) | 청크 사이즈 오버라이드. NULL이면 글로벌 `chunk_size` 사용 |
| chunk_overlap_percent | INT (nullable) | 오버랩 비율 오버라이드. NULL이면 글로벌 `chunk_overlap_percent` 사용 |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(board_id)` — 게시판당 파싱 오버라이드는 최대 1건
- `CHECK (chunking_strategy IS NULL OR chunking_strategy IN ('semantic', 'fixed_token', 'sliding_window'))`
- `CHECK (chunk_size IS NULL OR chunk_size > 0)`
- `CHECK (chunk_overlap_percent IS NULL OR (chunk_overlap_percent >= 0 AND chunk_overlap_percent <= 50))`

#### 설계 결정

**게시판별 파싱 오버라이드**
— 게시판마다 청킹 전략, 사이즈, 오버랩을 다르게 설정할 수 있다. NULL 컬럼은 글로벌 ParsingConfig의 기본값을 상속한다.

**created_at 미보유**
— 부모 설정(ParsingConfig)과 함께 upsert되는 패턴이므로 `created_at` 없이 `updated_at`만 보유한다 ([RDB 전체 조감도 §3.1](../../02-architecture/data/aicm/rdb.md) 예외 사항).

---

### 2.3 TemplateChunkingRule

ParsingConfig 하위 엔티티. 템플릿별 청킹 전략을 매핑한다.

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| parsing_config_id | UUID (FK) | ParsingConfig 참조 |
| template_id | UUID NOT NULL | 템플릿 ID (UNIQUE) |
| chunking_strategy | VARCHAR(30) NOT NULL | 청킹 전략: `qa_pair`(FAQ), `step_unit`(SOP), `item_unit`(체크리스트), `semantic`, `fixed_token`, `sliding_window` 등 |
| contextual_prefix_strategy | VARCHAR(30) NOT NULL DEFAULT 'none' | 컨텍스트 접두어 전략: `none`(미부착), `section_title`(섹션 제목), `doc_title`(문서 제목), `both`(문서+섹션 제목) |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(template_id)` — 템플릿당 청킹 규칙은 최대 1건

#### 설계 결정

**템플릿별 전용 청킹 전략**
— FAQ 템플릿은 Q&A 쌍 단위(`qa_pair`), SOP 템플릿은 스텝 단위(`step_unit`), 체크리스트는 항목 단위(`item_unit`)로 청킹한다. 범용 청킹 전략(`semantic`, `fixed_token`, `sliding_window`)도 템플릿에 할당 가능하다.

**컨텍스트 접두어 전략**
— 청크 텍스트 앞에 섹션 제목, 문서 제목 등 컨텍스트를 접두어로 부착하여 검색 품질을 높인다. retrieval-service에 `chunking_config`로 전달된다.

**우선순위**
— 동일 문서에 TemplateChunkingRule과 BoardParsingOverride가 모두 존재하면, TemplateChunkingRule이 우선한다 ([BR-PRS-014](rules.md#br-prs-014--청킹-전략-결정-우선순위)).

**created_at 미보유**
— BoardParsingOverride와 동일한 사유로 `updated_at`만 보유한다.

---

## 3. DDL 및 인덱스

### 3.1 ParsingConfig

```sql
CREATE TABLE parsing_config (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  default_chunking_strategy VARCHAR(30) NOT NULL DEFAULT 'semantic',
  chunk_size                INT NOT NULL DEFAULT 512,
  chunk_overlap_percent     INT NOT NULL DEFAULT 10,
  updated_by                UUID REFERENCES "user"(id),
  version                   INT NOT NULL DEFAULT 1,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_chunking_strategy
    CHECK (default_chunking_strategy IN ('semantic', 'fixed_token', 'sliding_window')),
  CONSTRAINT chk_chunk_size_positive
    CHECK (chunk_size > 0),
  CONSTRAINT chk_overlap_range
    CHECK (chunk_overlap_percent >= 0 AND chunk_overlap_percent <= 50)
);
```

### 3.2 BoardParsingOverride

```sql
CREATE TABLE board_parsing_override (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parsing_config_id     UUID NOT NULL REFERENCES parsing_config(id),
  board_id              UUID NOT NULL, -- FK 미설정: 모듈 간 느슨한 결합 유지 (앱 레벨 존재 검증)
  chunking_strategy     VARCHAR(30),
  chunk_size            INT,
  chunk_overlap_percent INT,
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_board_parsing_override UNIQUE (board_id),
  CONSTRAINT chk_bpo_strategy
    CHECK (chunking_strategy IS NULL OR chunking_strategy IN ('semantic', 'fixed_token', 'sliding_window')),
  CONSTRAINT chk_bpo_chunk_size
    CHECK (chunk_size IS NULL OR chunk_size > 0),
  CONSTRAINT chk_bpo_overlap
    CHECK (chunk_overlap_percent IS NULL OR (chunk_overlap_percent >= 0 AND chunk_overlap_percent <= 50))
);

CREATE INDEX idx_board_parsing_override_board ON board_parsing_override (board_id);
```

### 3.3 TemplateChunkingRule

```sql
CREATE TABLE template_chunking_rule (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  parsing_config_id           UUID NOT NULL REFERENCES parsing_config(id),
  template_id                 UUID NOT NULL,
  chunking_strategy           VARCHAR(30) NOT NULL,
  contextual_prefix_strategy  VARCHAR(30) NOT NULL DEFAULT 'none',
  updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_template_chunking_rule UNIQUE (template_id),
  CONSTRAINT chk_tcr_strategy
    CHECK (chunking_strategy IN (
      'semantic', 'fixed_token', 'sliding_window',
      'qa_pair', 'step_unit', 'item_unit')),
  CONSTRAINT chk_tcr_prefix_strategy
    CHECK (contextual_prefix_strategy IN (
      'none', 'section_title', 'doc_title', 'both'))
);

CREATE INDEX idx_template_chunking_rule_template ON template_chunking_rule (template_id);
```

---

## 4. 관련 문서

- [SearchModule data.md](../search/data.md) — SearchConfig, Synonym, StopWord, BoostRule, BoardRagConfig (SearchConfig와의 분리 관계)
- [ADR-009: 검색 설정 싱글톤 통합](../../adr/009-search-config-singleton-merge.md) — SearchConfig + ParsingConfig 2테이블 분리 결정
- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [02-chunking.md](../../01-requirements/flows/search-rag/02-chunking.md) — 청킹 파이프라인 흐름
