# Parsing API 스펙

> 기능정의서: [FD-SCH-검색](../../01-requirements/features/FD-SCH-검색.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [parsing-module.md](./data.md)

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /admin/search/parsing-config | 파싱 설정 조회 | ADMIN (`manage_search`) |
| PUT | /admin/search/parsing-config | 파싱 설정 수정 | ADMIN (`manage_search`) |

> 이 엔드포인트는 **ParsingModule이 소유**하며, SearchModule의 관리자 API를 통해 프록시된다. 관리자 UX에서 "검색 관리" 화면 내 파싱 설정 탭으로 통합 제공하기 위해 API 프리픽스를 `/admin/search/` 하위에 유지한다.

---

## 상세 API

### `GET` /admin/search/parsing-config

**설명**: 현재 파싱 설정을 조회한다. ParsingConfig 싱글톤 + 게시판별 오버라이드 + 템플릿별 청킹 규칙을 한 번에 반환한다.

**권한**: ADMIN (`manage_search`)

**Request**: 없음

**Response** (`200`):

```typescript
interface ParsingConfigResponse {
  config: ParsingConfigDto;
  boardOverrides: BoardParsingOverrideDto[];
  templateRules: TemplateChunkingRuleDto[];
}

interface ParsingConfigDto {
  id: string;
  defaultChunkingStrategy: 'semantic' | 'fixed_token' | 'sliding_window';
  chunkSize: number;
  chunkOverlapPercent: number;
  updatedBy: string;
  version: number;
  updatedAt: string;
}

interface BoardParsingOverrideDto {
  id: string;
  boardId: string;
  boardName: string;
  chunkingStrategy: 'semantic' | 'fixed_token' | 'sliding_window' | null;
  chunkSize: number | null;
  chunkOverlapPercent: number | null;
  updatedAt: string;
}

interface TemplateChunkingRuleDto {
  id: string;
  templateId: string;
  templateName: string;
  chunkingStrategy: string;
  contextualPrefixStrategy: string;
  updatedAt: string;
}
```

**에러**:

| 에러 코드 | HTTP | 설명 |
|-----------|------|------|
| FORBIDDEN | 403 | `manage_search` 권한 없음 |

---

### `PUT` /admin/search/parsing-config

**설명**: 파싱 설정을 수정한다. ParsingConfig + 게시판별 오버라이드 + 템플릿별 청킹 규칙을 한 번에 갱신한다. 낙관적 동시성 제어(OCC)를 적용한다.

**배열 업데이트 의미론**: `boardOverrides`와 `templateRules` 배열은 **전체 교체(full replace)** 방식이다. 요청에 포함된 배열이 기존 목록을 완전히 대체한다. 배열을 생략하면 해당 하위 설정은 변경하지 않는다. 빈 배열(`[]`)을 전달하면 기존 항목을 모두 삭제한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface UpdateParsingConfigDto {
  version: number;                                // 필수 — OCC용 현재 버전 (조회 시 받은 값)
  defaultChunkingStrategy?: 'semantic' | 'fixed_token' | 'sliding_window';
  chunkSize?: number;                             // 선택 — 청크 최대 토큰 수
  chunkOverlapPercent?: number;                    // 선택 — 오버랩 비율 (%)
  boardOverrides?: {
    boardId: string;
    chunkingStrategy?: 'semantic' | 'fixed_token' | 'sliding_window' | null;
    chunkSize?: number | null;
    chunkOverlapPercent?: number | null;
  }[];
  templateRules?: {
    templateId: string;
    chunkingStrategy: string;
    contextualPrefixStrategy: string;
  }[];
}
```

**Response** (`200`):

```typescript
interface ParsingConfigResponse {
  config: ParsingConfigDto;
  boardOverrides: BoardParsingOverrideDto[];
  templateRules: TemplateChunkingRuleDto[];
}
```

**에러**:

| 에러 코드 | HTTP | 설명 | 관련 BR |
|-----------|------|------|---------|
| PRS_CONFIG_VERSION_CONFLICT | 409 | 파싱 설정 버전 충돌 — 최신 버전 조회 후 재시도 | [BR-PRS-017](rules.md#br-prs-017--설정-저장-occ) |
| FORBIDDEN | 403 | `manage_search` 권한 없음 | — |

---

## 에러 코드 카탈로그

> 전체 에러 코드는 [rules.md §3](rules.md#3-에러-코드-카탈로그)을 참조한다.

| 에러 코드 | HTTP | 메시지 | 관련 BR |
|-----------|------|--------|---------|
| PRS_PARSING_FAILED | 500 | 문서 파싱 실패 | [BR-PRS-016](rules.md#br-prs-016--파싱-실패-재시도) |
| PRS_CONFIG_VERSION_CONFLICT | 409 | 파싱 설정 버전 충돌 — 최신 버전 조회 후 재시도 | [BR-PRS-017](rules.md#br-prs-017--설정-저장-occ) |
| PRS_INVALID_FLAG_COMBINATION | 422 | 임베딩O + 가시성X 조합 미허용 | [BR-PRS-009](rules.md#br-prs-009--임베딩o--가시성x-미허용) |
| PRS_UNSUPPORTED_FORMAT | 422 | 미지원 파일 형식 | [BR-PRS-013](rules.md#br-prs-013--파싱-전략-분기-구현) |
| PRS_PARSER_UNAVAILABLE | 503 | parser-service 일시 장애 | [BR-PRS-016](rules.md#br-prs-016--파싱-실패-재시도) |
