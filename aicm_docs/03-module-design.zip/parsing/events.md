# Parsing 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 모듈 아키텍처: [02-module-architecture.md §3.3](../../02-architecture/02-module-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 이벤트 매트릭스 요약

### 1.1 소비 이벤트

| 이벤트 | 발행자 | 신뢰성 티어 | 전달 수단 | 용도 |
|--------|--------|------------|----------|------|
| `document.published` | DocumentModule | Important | BullMQ `parsing` | 파일 첨부 블록이 있는 문서 published 시 자동 파싱 트리거 |
| `shared-content.updated` | DocumentModule | Best-effort | EventBus | 공통 컨텐츠 수정 시 참조 문서 재청킹 ([BR-PRS-002](rules.md#br-prs-002--공통-컨텐츠-수정-시-재청킹)) |
| `document.content-updated` | DocumentModule | Important | BullMQ `parsing` | 문서 수정 시 변경 블록 재청킹 ([BR-PRS-007](rules.md#br-prs-007--문서-수정삭제-시-청크-동기화)) |
| `document.deleted` | DocumentModule | Important | BullMQ `parsing` | 문서 삭제 시 관련 청크 삭제 ([BR-PRS-007](rules.md#br-prs-007--문서-수정삭제-시-청크-동기화)) |
| `block.visibility-changed` | DocumentModule | Best-effort | EventBus | 블록 플래그 변경 시 해당 블록 재처리 ([BR-PRS-010](rules.md#br-prs-010--플래그-변경-시-재처리)) |

### 1.2 발행 이벤트

| 이벤트 | 소비자 | 신뢰성 티어 | 전달 수단 | 용도 |
|--------|--------|------------|----------|------|
| `parsing.completed` | SearchModule | Important | BullMQ `parsing-events` | 파싱 완료 시 발행, SearchModule이 소비하여 ES 인덱싱·임베딩 시작 |

---

## 2. 소비 이벤트 상세

### 2.1 `document.published` — 파싱 트리거

**큐**: `parsing` (BullMQ, Important 티어)

**발행자**: DocumentModule

**처리 절차**:

1. 문서의 블록 목록을 조회하여 파일 첨부 블록 존재 여부 확인
2. 파일 첨부 블록이 없으면 → 이벤트 처리 종료 (블록 에디터 문서의 청킹은 SearchModule의 `document.published` 핸들러에서 직접 수행)
3. 파일 첨부 블록이 있으면 → 파싱 전략 분기 ([BR-PRS-013](rules.md#br-prs-013--파싱-전략-분기-구현))
4. parser-service 호출 → ParsedBlock 수신
5. ParsedBlock → Block 변환·저장 (DocumentModule 쓰기 의존)
6. RAG 연동이 활성이면 → 청킹 전략 결정 ([BR-PRS-014](rules.md#br-prs-014--청킹-전략-결정-우선순위)) → 청크 생성 + 메타데이터 부착 ([BR-PRS-006](rules.md#br-prs-006--청킹-메타데이터-부착))
7. 파싱 상태를 `completed` / `completed_with_warnings` / `failed`로 전이
8. 파싱 완료 시 `parsing.completed` 이벤트 발행 → SearchModule 통지

**페이로드**:

```typescript
interface ParsingJobPayload {
  actorId: string;
  orgId: string;
  traceId: string;
  triggeredAt: string;            // ISO 8601
  documentId: string;
  fileId: string;
  fileName: string;
  fileExtension: string;          // pdf, docx, hwp, hwpx, pptx
  boardId: string;
  templateId: string | null;
  attempt: number;                // 재시도 횟수
}
```

**멱등성**: `fileId` + `attempt` 기반. 동일 `fileId`에 대해 진행 중인 Job이 존재하면 skip.

**재시도 정책**: 최대 3회, 지수 백오프 (초기 10s, 최대 120s). 소진 후 DLQ `parsing:dlq`.

---

### 2.2 `shared-content.updated` — 공통 컨텐츠 재청킹

**전달 수단**: EventBus (Best-effort 티어)

**발행자**: DocumentModule

**처리 절차**:

1. 수정된 공통 컨텐츠(SharedContent)를 참조하는 문서 목록을 조회
2. 각 문서에 대해 참조 원본의 최신 내용을 resolve하여 재청킹
3. 실패 시 재시도 (Best-effort — 최종 보정은 Reconciliation 배치)

**멱등성**: `sharedContentId` + `updatedAt` 기반. 동일 버전에 대해 중복 처리 skip.

---

### 2.3 `document.content-updated` — 문서 수정 시 재청킹

**큐**: `parsing` (BullMQ, Important 티어)

**발행자**: DocumentModule

**처리 절차**:

1. 변경된 블록 목록을 페이로드에서 확인
2. 해당 블록의 기존 청크를 삭제하고 재청킹
3. 파싱 완료 시 `parsing.completed` 이벤트 발행

**멱등성**: `documentId` + `updatedAt` 기반.

**재시도 정책**: 최대 3회, 지수 백오프. 소진 후 DLQ `parsing:dlq`.

---

### 2.4 `document.deleted` — 문서 삭제 시 청크 삭제

**큐**: `parsing` (BullMQ, Important 티어)

**발행자**: DocumentModule

**처리 절차**:

1. 해당 문서의 모든 청크를 삭제
2. 청크 삭제 완료 (이 경우 `parsing.completed`를 발행하지 않음)

> **설계 결정**: 문서 삭제 시 `parsing.completed`를 발행하지 않는다. SearchModule은 `document.deleted` 이벤트를 직접 소비하여 ES 인덱스에서 문서를 제거하므로, ParsingModule이 추가로 삭제 통지를 보내면 중복 처리가 발생한다. ParsingModule은 자신의 책임 범위(청크 데이터 삭제)만 수행한다.

**멱등성**: `documentId` 기반. 이미 청크가 없으면 skip.

**재시도 정책**: 최대 3회, 지수 백오프. 소진 후 DLQ `parsing:dlq`.

---

### 2.5 `block.visibility-changed` — 블록 플래그 변경 시 재처리

**전달 수단**: EventBus (Best-effort 티어)

**발행자**: DocumentModule

**처리 절차**:

1. 변경된 블록의 `embeddable`/`visible` 플래그를 확인
2. `embeddable: true` + `visible: false` 조합이면 거부 ([BR-PRS-009](rules.md#br-prs-009--임베딩o--가시성x-미허용)). BR-PRS-009에 의해 API 레벨에서 이미 차단되므로 정상 흐름에서는 도달하지 않는다. 방어적 체크로 감지 시 WARN 로그를 기록하고 해당 이벤트를 skip한다.
3. 해당 블록만 재청킹/재임베딩 트리거 (전체 문서 재처리가 아닌 블록 단위 부분 재처리)

**멱등성**: `blockId` + `updatedAt` 기반.

---

## 3. 발행 이벤트 상세

### 3.1 `parsing.completed` — 파싱 완료 통지

**큐**: `parsing-events` (BullMQ, Important 티어)

**소비자**: SearchModule — ES 인덱싱·임베딩 시작

**페이로드**:

```typescript
interface ParsingCompletedEvent {
  eventId: string;
  eventType: 'parsing.completed';
  timestamp: string;              // ISO 8601
  data: {
    documentId: string;
    boardId: string;
    templateId: string | null;
    blockCount: number;
    chunkCount: number;           // 생성된 청크 수 (RAG 비활성 시 0)
    parsingVersion: number;       // 파싱 실행 버전 (멱등성 키로 활용)
    parsingStatus: 'completed' | 'completed_with_warnings' | 'failed';
  };
}
```

**재시도 정책**: 최대 3회, 지수 백오프 (초기 5s, 최대 60s). 소진 후 DLQ `parsing-events:dlq`.

---

## 4. 외부 서비스 호출

### 4.1 ParserServiceClient

| 항목 | 내용 |
|------|------|
| **용도** | 외부 문서(PDF/DOCX/HWP 등) 텍스트 추출 |
| **프로토콜** | HTTP (REST) |
| **서킷브레이커** | ● — `{tenant_id}:circuit:parser-service` (Redis 키) |
| **타임아웃** | 60s |
| **폴백** | 서킷 Open 시 → `failed` 상태 전이 + DLQ 진입. 서킷 HalfOpen 시 제한적 요청 허용 |

### 4.2 LlmOrchestratorClient

| 항목 | 내용 |
|------|------|
| **용도** | 이미지 블록 멀티모달 분석 (청킹 시 설명 텍스트 생성) |
| **프로토콜** | HTTP (REST) |
| **비고** | RAG 비활성 시 멀티모달·벡터 관련 호출 skip |
| **서킷브레이커** | ● — `{tenant_id}:circuit:llm-orchestrator` (Redis 키) |
| **타임아웃** | 30s |
| **폴백** | 서킷 Open 시 → 메타데이터(캡션)만 저장, 멀티모달 분석은 스킵. 파싱 자체는 중단하지 않음 |

---

## 5. 외부 서비스 미연동 시 Graceful Degradation

| 구분 | 비활성 시 영향 |
|------|----------------|
| RAG | 청킹·임베딩 파이프라인 비활성 (embedding 큐 enqueue 스킵), 이미지 멀티모달 분석 skip, retrieval-service 호출 skip |

**원칙**: 파싱(텍스트 추출 + Block 변환)은 어떤 환경에서도 동작한다. 청킹·임베딩(벡터화)은 RAG 연동이 활성일 때만 수행한다.

---

## 6. DLQ 처리

| 원본 큐 | DLQ | 모니터링 | 수동 처리 |
|---------|-----|---------|----------|
| `parsing` | `parsing:dlq` | BullMQ Dashboard, Slack 알림 | 관리자 수동 재시도 |
| `parsing-events` | `parsing-events:dlq` | BullMQ Dashboard, Slack 알림 | 관리자 수동 재시도 |

---

## 7. 멱등성 보장

| 큐/이벤트 | 멱등성 키 | 전략 |
|-----------|----------|------|
| `parsing` (`document.published`) | `fileId` + `attempt` | 동일 `fileId`에 대해 진행 중인 Job 존재 시 skip |
| `parsing` (`document.content-updated`) | `documentId` + `updatedAt` | 동일 버전에 대해 중복 처리 skip |
| `parsing` (`document.deleted`) | `documentId` | 이미 청크가 없으면 skip |
| `shared-content.updated` | `sharedContentId` + `updatedAt` | 동일 버전에 대해 중복 처리 skip |
| `block.visibility-changed` | `blockId` + `updatedAt` | 동일 버전에 대해 중복 처리 skip |
| `parsing-events` (`parsing.completed`) | `eventId` | 동일 이벤트 중복 발행 방지 |
