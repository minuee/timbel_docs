# SharedContent 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 모듈 아키텍처: [02-module-architecture.md §3.3](../../02-architecture/02-module-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [data.md](data.md)

---

## 1. 발행 이벤트

SharedContentModule이 발행하는 이벤트와 큐를 신뢰성 티어별로 정리한다.

### 1.1 Important 티어 — BullMQ 직접 enqueue

```typescript
/** 모든 BullMQ Job 페이로드의 공통 컨텍스트 (05-async-event-architecture.md §6.5) */
interface AsyncJobContext {
  actorId: string;
  orgId: string;
  traceId: string;
  triggeredAt: string;            // ISO 8601
}
```

#### `re-embedding` 큐

- **티어**: Important
- **채널**: BullMQ `re-embedding`
- **트리거**: `SharedContentService.update()` — 공통 컨텐츠 본문(content) 수정 완료 후 [BR-SHC-004]
- **비고**: RAG 연동이 활성일 때만 enqueue — **비활성 시 enqueue 자체를 스킵** [BR-SHC-016]
- **조건**: RAG 연동 활성 + SharedContentRef에 참조 문서가 1건 이상 존재
- **페이로드**:

```typescript
interface ReEmbeddingJobPayload extends AsyncJobContext {
  sharedContentId: string;
  documentId: string;               // 재임베딩 대상 문서 (문서별 1 Job)
  blockIds: string[];               // 해당 문서 내 공통 컨텐츠 참조 블록 ID 목록
  priority: 'shared_content_update';
}
```

- **소비자**: Worker → RetrievalServiceClient → retrieval-service (관련 청크 재임베딩)
- **멱등성 키**: `re-embed:{sharedContentId}:{updatedAt}:{documentId}` — BullMQ `jobId` 옵션으로 동일 수정·동일 문서 중복 enqueue 방지
- **재시도**: 최대 3회, 지수 백오프 — [05-async-event-architecture.md §6.6](../../02-architecture/05-async-event-architecture.md#66-dlqdead-letter-queue-전략)의 프로젝트 기본 `JobsOptions`와 동일 (`delay: 5000`, 지수 — 5s → 10s → 20s). 아키텍처 기본값과 불일치하지 않도록 별도 1초 초기 지연을 두지 않는다.
- **타임아웃**: 10분
- **Concurrency**: 1 (설정값, 기본 1)
- **DLQ**: `re-embedding-dlq` — 3회 재시도 소진 시 DLQ로 이동, Bull Board에서 수동 확인
- **보정 배치**: Reconciliation 배치(05-async-event-architecture.md §6.7)에서 re-embedding 실패 건을 주기적으로 점검하여 재투입

#### retrieval-service 서킷브레이커 연동

`re-embedding` Worker는 `embedding` Worker와 동일하게 retrieval-service를 호출한다. **서킷브레이커 정책·임계·Redis 키**는 Document 모듈 스펙 [document/events.md §3.3](../document/events.md#33-서킷브레이커-정책)과 동일하게 적용한다 (`RetrievalServiceClient`, `{tenant_id}:circuit:{service_name}` 공유).

| 서킷 상태 | Worker 동작 |
|-----------|--------------|
| **Closed** | 정상적으로 retrieval-service 호출 및 재시도 정책 적용 |
| **Open** | 호출을 시도하지 않고 Job을 **지연 재스케줄**한다 (예: Document 모듈 표준과 맞추어 약 60초 후 `moveToDelayed` 등). 동일 장애 구간에 N개 Job이 연쇄적으로 즉시 실패·재시도하여 DLQ에 N건이 쌓이는 것을 완화한다 |
| **HalfOpen** | Document 모듈과 동일 — 제한적 시도 후 성공 시 Closed, 실패 시 Open |

> **설계 근거**: 서킷 Open 상태에서 매 Job마다 3회 백오프 재시도를 소진하면 DLQ·알림이 문서 수에 비례해 폭증한다. Open 구간에는 **시도 횟수를 소비하지 않는 지연 재큐잉**을 우선한다 (구체 API는 BullMQ `moveToDelayed` / `changeDelay` 등 구현체에 따름).

#### 서킷·재시도 관련 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `circuit.retrieval.state_change` | retrieval-service 서킷 상태 전이 (Open / HalfOpen / Closed) | Document 모듈과 동일 — Redis 키 또는 클라이언트 훅 ([document/README.md](../document/README.md) 주요 메트릭 참조) |
| `re_embedding.job_deferred_circuit` | 서킷 Open으로 인해 지연 재스케줄된 `re-embedding` Job 수 (카운터) | Worker에서 지연 처리 시 increment |

> **대량 참조 시나리오**: 공통 컨텐츠 1건이 N개 문서에서 참조될 수 있다. 수정 시 N개의 개별 Job을 `re-embedding` 큐에 enqueue하며, `concurrency: 1`로 순차 처리하여 retrieval-service 부하를 제한한다. N이 매우 큰 경우(수백 건) 처리 완료까지 시간이 소요될 수 있으나, ADR-011 C-4에 따라 진행 상황은 Bull Board 대시보드에서 확인한다.

---

### 1.2 Best-effort 티어 — EventBus (NestJS EventEmitter)

#### `shared-content.updated`

- **티어**: Best-effort
- **채널**: EventBus (NestJS EventEmitter)
- **트리거**: `SharedContentService.update()` — 공통 컨텐츠 본문 수정 완료 후 [BR-SHC-004]
- **페이로드**:

```typescript
interface SharedContentUpdatedEvent {
  sharedContentId: string;
  updatedBy: string;
  updatedAt: string;                    // ISO 8601 — 수정 시점
  referencingDocumentIds: string[];     // 영향받는 문서 ID 목록
  schemaVersion: number;                // 이벤트 스키마 버전 (현재 1)
}
```

- **멱등성 키**: `sharedContentId:updatedAt` — 소비자가 동일 수정 이벤트를 중복 처리하지 않도록 방어
- **소비자**:
  - AuditLogModule — 감사 로그 `shared_content.updated` 기록
  - AggregationModule — 집계 캐시 무효화 (해당 문서 통계 갱신)

---

#### `shared-content.deactivated`

- **티어**: Best-effort
- **채널**: EventBus (NestJS EventEmitter)
- **트리거**: `SharedContentService.deactivate()` — 비활성 전환 [BR-SHC-005]
- **페이로드**:

```typescript
interface SharedContentDeactivatedEvent {
  sharedContentId: string;
  deactivatedBy: string;
  replacementId: string | null;
  referencingDocumentIds: string[];   // 경고 대상 문서 ID 목록
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 참조 문서 작성자에게 비활성 경고 알림 발송 ("공통 컨텐츠 '{name}'이 비활성화되었습니다. {count}개 문서에 영향됩니다")
  - AuditLogModule — 감사 로그 `shared_content.deactivated` 기록

---

#### `shared-content.activated`

- **티어**: Best-effort
- **채널**: EventBus (NestJS EventEmitter)
- **트리거**: `SharedContentService.activate()` — 재활성화 [BR-SHC-006]
- **페이로드**:

```typescript
interface SharedContentActivatedEvent {
  sharedContentId: string;
  activatedBy: string;
  schemaVersion: number;
}
```

- **소비자**:
  - AuditLogModule — 감사 로그 `shared_content.activated` 기록

---

## 2. 소비 이벤트

SharedContentModule이 외부 모듈로부터 수신하는 이벤트.

| 이벤트/콜백 | 발행자 | 채널 | 처리 내용 | 호출 실패 시 동작 |
|------------|--------|------|----------|------------------|
| 문서 블록 저장 시 참조 갱신 | DocumentModule | 직접 서비스 호출 | SharedContentRef 생성/삭제 — 블록에 공통 컨텐츠가 삽입/제거되면 참조 레코드를 갱신 | 에러를 DocumentModule에 전파 — 블록 저장 트랜잭션 롤백 |
| 문서 소프트 삭제 | DocumentModule | EventBus `document.deleted` | 참조 레코드 유지 (복구 시 참조 관계 보존) — 삭제 차단 카운트에서는 제외 (집계 기준은 [rules.md](rules.md) BR-SHC-003과 동일) | Best-effort, 유실 시 영향 제한적 |

### 2.1 참조 갱신 서비스 인터페이스

DocumentModule이 블록 저장 시 호출하는 SharedContentService 메서드의 계약이다.

```typescript
class SharedContentService {
  /**
   * 문서 블록 저장 후 공통 컨텐츠 참조 갱신.
   * 블록 내용에서 공통 컨텐츠 참조를 파싱하여 SharedContentRef를 동기화한다.
   * 호출자 트랜잭션 외부에서 실행 (최종 일관성).
   */
  async syncReferences(
    documentId: string,
    blocks: { blockId: string; sharedContentIds: string[] }[],
  ): Promise<void>;
}
```

---

## 3. BullMQ 큐 요약

| 큐 이름 | 트리거 | 우선순위 | 재시도 | 타임아웃 | DLQ | 처리 내용 |
|---------|--------|---------|--------|---------|-----|----------|
| `re-embedding` | 공통 컨텐츠 수정 시 | shared_content_update | 3회 (지수 백오프: 5s → 10s → 20s, §6.6 기본값과 동일) | 10분 | `re-embedding-dlq` | 참조 문서의 관련 청크 재임베딩 (retrieval-service 호출, 서킷 연동 §1.1) |

### 3.1 멱등성 보장 패턴

| 큐 | 멱등성 키 패턴 | 보장 방식 |
|-----|---------------|-----------|
| `re-embedding` | `re-embed:{sharedContentId}:{updatedAt}:{documentId}` | BullMQ `jobId` 옵션으로 동일 수정·동일 문서 중복 enqueue 방지. Worker에서 처리 전 해당 문서의 현재 임베딩 상태를 확인하여 이미 최신이면 스킵 |

### 3.2 Graceful Shutdown

배포 시 `re-embedding` Worker의 안전한 종료를 위한 전략이다.

1. **SIGTERM 수신 시**: `worker.close()` 호출 — 현재 처리 중인 Job이 완료될 때까지 대기 (최대 30초)
2. **타임아웃 초과 시**: 처리 중이던 Job은 `stalled` 상태로 전환되어 다른 인스턴스가 재처리
3. **DLQ 모니터링**: `re-embedding-dlq` Job은 Bull Board 대시보드에서 확인하고 수동 재처리

---

## 4. 감사 로그 액션

SharedContentModule이 기록하는 감사 로그 액션 목록. AuditLogModule의 NestJS Interceptor로 전역 기록.

| 액션 | 트리거 | 규칙 |
|------|--------|------|
| `shared_content.created` | 공통 컨텐츠 생성 | BR-SHC-011 |
| `shared_content.updated` | 공통 컨텐츠 수정 | BR-SHC-004 |
| `shared_content.deactivated` | 비활성 전환 | BR-SHC-005 |
| `shared_content.activated` | 재활성화 | BR-SHC-006 |
| `shared_content.deleted` | 삭제 (참조 없을 때만) | BR-SHC-003 |

---

## 5. 외부 서비스 및 기능 비활성 시 Graceful Degradation

### 5.1 방어 전략

| 구분 | 관련 큐/서비스 | 비활성 시 동작 | 영향 범위 |
|------|--------------|--------------|----------|
| 공통 컨텐츠 기능 | 모든 SharedContent API | `403 FEATURE_DISABLED` | 테넌트에서 기능을 끈 경우. 프론트엔드는 설정에 따라 `/공통` 슬래시 명령 숨김 |
| RAG | `re-embedding` 큐 | enqueue 스킵, Worker 미등록 | 재임베딩만 미수행 → 기존 임베딩은 stale 상태 유지, 키워드 검색은 영향 없음 |

### 5.2 구현 원칙

```
┌────────────────────────────────────────────────────────────┐
│  공통 컨텐츠 수정 흐름                                       │
│                                                             │
│  1. SharedContent 갱신  (트랜잭션 — 항상 수행)                │
│  2. 트랜잭션 커밋 ✅                                         │
│  3. 큐 enqueue (트랜잭션 밖에서 수행)                          │
│     ├── re-embedding: RAG 연동 활성일 때만 enqueue           │
│     └── EventBus shared-content.updated: 항상 발행           │
│                                                             │
│  ⚠ 상태 전이 성공 ≠ 큐 enqueue 필수                           │
│    → 공통 컨텐츠 수정은 핵심, 재임베딩은 부수효과               │
│    → 큐 enqueue 실패 시에도 공통 컨텐츠 수정은 성공 처리       │
└────────────────────────────────────────────────────────────┘
```
