# SharedContentModule — RDB 엔티티

> 공통 컨텐츠(환경변수형 재사용 블록) 관리 및 참조 추적

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    SharedContent ||--o{ SharedContentRef : "1:N"
    SharedContent ||--o| SharedContent : "replacement (self-ref)"

    SharedContentRef }o--|| Document : "N:1 (DocumentModule)"

    SharedContent {
        UUID id PK
        VARCHAR name
        VARCHAR slug UK
        TEXT description
        JSONB content
        JSONB tags
        BOOLEAN is_active
        UUID replacement_id FK
        UUID created_by
        UUID updated_by
    }

    SharedContentRef {
        UUID id PK
        UUID shared_content_id FK
        UUID document_id FK
        UUID block_id
    }
```

---

## 2. 엔티티 필드

### 2.1 SharedContent

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(200) | 표시명 (예: '고객센터 운영시간') |
| slug | VARCHAR(200, UNIQUE) | 검색/삽입용 키. name에서 정규화 생성 |
| description | TEXT (nullable) | 용도 설명 |
| content | JSONB | 공통 컨텐츠 본문 (Tiptap 블록 JSON). 인라인 삽입이므로 단순 텍스트~짧은 블록 수준 |
| tags | JSONB NOT NULL DEFAULT '["general"]' | 태그 배열: `법률/약관`, `연락처`, `상품정보`, `공통안내` 등. 미지정 시 `["general"]`. 하나의 공통 컨텐츠에 복수 태그 부여 가능 |
| is_active | BOOLEAN (default true) | 비활성(deprecated) 시 참조 문서에 경고 표시 |
| replacement_id | UUID (FK → SharedContent, nullable) | 비활성 시 대체할 공통 컨텐츠 |
| created_by | UUID | 최초 생성자 (외부 UserService의 userId) |
| updated_by | UUID | 최종 수정자 (외부 UserService의 userId) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(slug)` — slug 기반으로 공통 컨텐츠를 검색/삽입
- `CHECK (replacement_id IS NULL OR is_active = false)` — 대체 컨텐츠는 비활성 시에만 지정 가능
- `CHECK (replacement_id != id)` — 자기 자신을 대체 컨텐츠로 지정 불가

#### 설계 결정

**name과 slug 분리**
— FD-DOC §5에서 `name`을 "이름(슬러그) — 검색/자동완성용"으로 정의하였으나, 모듈 스펙에서는 표시명(`name`)과 검색키(`slug`)를 별도 필드로 분리하여 UX를 개선하였다. `name`은 관리자가 자유롭게 설정하는 사람이 읽는 표시명이고, `slug`는 `name`에서 정규화하여 자동 생성되는 기계적 검색/삽입 키이다. 이로써 표시명 변경 시에도 기존 참조가 `slug` 기반으로 안정적으로 동작한다.

**항상 최신 버전만 참조**
— 버전 고정(pinning)을 지원하지 않는다. 공통 컨텐츠를 수정하면 참조하는 모든 문서에 즉시 반영된다. 단순 운영을 우선으로 한다.

**수정 시 재임베딩 트리거**
— 공통 컨텐츠가 수정되면 SharedContentRef에서 참조 document_id 목록을 조회하여, 해당 문서들의 관련 청크 재임베딩을 BullMQ 큐로 트리거한다. 수정 이력은 AuditLog를 통해 추적한다.

**수정 권한: 관리자 전용**
— 공통 컨텐츠는 관리자만 생성/수정할 수 있다. 별도 승인 워크플로우를 거치지 않는다.

**삭제 차단 → 비활성 전환**
— SharedContentRef에 참조하는 문서가 존재하면 삭제가 차단된다. 대신 `is_active = false`로 비활성 처리하고, `replacement_id`로 대체 컨텐츠를 지정하여 마이그레이션을 유도한다. UI에서는 비활성된 공통 컨텐츠를 참조하는 블록에 경고 배지를 표시한다.

**replacement_id 자기 참조**
— SharedContent 테이블의 self-reference FK. 비활성 전환 시 "이 컨텐츠 대신 X를 사용하세요"라는 안내를 제공한다. 대체 컨텐츠가 또 비활성되는 체인은 앱 레벨에서 차단한다 (1-depth만 허용).

**tags JSONB 배열 + 기본값 `["general"]`**
— 하나의 공통 컨텐츠가 여러 분류에 걸칠 수 있으므로(`연락처`이면서 `공통안내` 등) JSONB 문자열 배열로 설계한다. FD-DOC §5에서 카테고리를 `NOT NULL`로 정의하였고, ADR-011 C-2의 취지를 유지하되 다중 값을 허용한다. 미지정 시 `["general"]`을 기본값으로 할당하며, 빈 배열(`[]`)은 앱 레벨에서 차단하여 최소 1개 태그를 보장한다. 허용 태그 값은 관리자가 **태그 관리 API**(`/api/shared-contents/tags`)로 CRUD하며, DB CHECK 제약 대신 앱 레벨에서 검증한다. `general` 태그는 DB 기본값에 사용되므로 삭제/slug 변경이 차단된다 [BR-SHC-020]. GIN 인덱스를 통해 `@>` 연산자로 특정 태그를 포함하는 공통 컨텐츠를 효율적으로 조회한다. 태그 slug 변경 시 해당 slug를 포함하는 모든 공통 컨텐츠의 `tags` 배열이 트랜잭션 내에서 일괄 갱신된다 [BR-SHC-021].

---

### 2.2 SharedContentRef

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| shared_content_id | UUID (FK → SharedContent) | 참조하는 공통 컨텐츠 |
| document_id | UUID (FK → Document) | 공통 컨텐츠를 삽입한 문서 |
| block_id | UUID NOT NULL | 참조 위치 블록 (정밀 추적) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(shared_content_id, document_id, block_id)` — 동일 블록에 같은 공통 컨텐츠 중복 참조 방지

#### 설계 결정

**참조 레코드 생명주기**
— 문서 편집 시 공통 컨텐츠를 삽입하면 참조 레코드를 생성하고, 해당 블록에서 공통 컨텐츠를 제거하면 참조 레코드를 삭제한다. 문서 삭제(소프트 딜리트) 시에는 참조 레코드를 유지한다 — 복원 시 참조 관계가 보존되어야 하기 때문이다.

**영향 범위 확인**
— 공통 컨텐츠 수정 전 이 테이블에서 참조 document_id 목록을 조회하여 "N개 문서에 영향됩니다" 경고를 표시한다.

**재임베딩 대상 조회**
— 공통 컨텐츠 수정 시 이 테이블에서 대상 document_id + block_id 목록을 조회하여 BullMQ re-embedding 큐에 작업을 등록한다.

**block_id NOT NULL**
— 첫 구축이므로 구버전 데이터 호환이 불필요하다. block_id를 필수로 기록하여 재임베딩 대상을 정밀하게 추적한다. nullable이면 앱 버그로 block_id 없이 INSERT가 되어도 DB가 막지 못하고, 재임베딩 대상 정밀 추적이 불가능해진다.

**updated_at 없음**
— 참조 관계는 생성/삭제만 존재하며 수정하지 않으므로 `updated_at`이 불필요하다.

---

## 3. DDL 및 인덱스

### 3.1 SharedContent

```sql
CREATE TABLE shared_content (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            VARCHAR(200) NOT NULL,
  slug            VARCHAR(200) NOT NULL,
  description     TEXT,
  content         JSONB NOT NULL,
  tags            JSONB NOT NULL DEFAULT '["general"]',
  is_active       BOOLEAN NOT NULL DEFAULT true,
  replacement_id  UUID REFERENCES shared_content(id),
  created_by      UUID NOT NULL,
  updated_by      UUID NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_shared_content_slug UNIQUE (slug),
  CONSTRAINT chk_replacement_only_inactive
    CHECK (replacement_id IS NULL OR is_active = false),
  CONSTRAINT chk_no_self_replacement
    CHECK (replacement_id IS DISTINCT FROM id)
);

-- 태그별 목록 조회 (GIN — JSONB 배열 containment 검색)
CREATE INDEX idx_shared_content_tags
  ON shared_content USING GIN (tags jsonb_path_ops);

-- 활성 컨텐츠 목록 조회
CREATE INDEX idx_shared_content_active
  ON shared_content (is_active)
  WHERE is_active = true;

-- FK 인덱스: replacement_id (self-ref)
CREATE INDEX idx_shared_content_replacement
  ON shared_content (replacement_id)
  WHERE replacement_id IS NOT NULL;
```

### 3.2 SharedContentRef

```sql
CREATE TABLE shared_content_ref (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  shared_content_id   UUID NOT NULL REFERENCES shared_content(id) ON DELETE RESTRICT,
  document_id         UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  block_id            UUID NOT NULL,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_shared_content_ref UNIQUE (shared_content_id, document_id, block_id)
);

-- 공통 컨텐츠별 영향 문서 조회 (수정 시 재임베딩 대상)
CREATE INDEX idx_shared_content_ref_content
  ON shared_content_ref (shared_content_id);

-- 문서별 참조 공통 컨텐츠 목록
CREATE INDEX idx_shared_content_ref_document
  ON shared_content_ref (document_id);
```

---

## 4. 관련 문서

- [README.md](./README.md) — 모듈 개요, 책임, 의존 관계
- [api.md](./api.md) — API 스펙
- [rules.md](./rules.md) — 비즈니스 규칙 카탈로그
- [events.md](./events.md) — 이벤트 및 부수효과
- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [document.md](../document/data.md) — Document, Block (SharedContentRef가 참조)
- [approval.md](../approval/data.md) — Approval (발행 워크플로우)
- [Redis 전략](../../02-architecture/data/aicm/redis.md) — BullMQ 큐 (re-embedding)
- [ES aicm_blocks 인덱스](../../02-architecture/data/aicm/es.md) — 재임베딩 시 인덱스 갱신
- [청킹 전략](../../01-requirements/flows/search-rag/02-chunking.md) — 공통 컨텐츠 변경 시 재청킹 흐름
