# SharedContent 비즈니스 규칙

> 기능정의서: [FD-DOC-문서관리 §5](../../01-requirements/features/FD-DOC-문서관리.md)
> API 스펙: [api.md](api.md)
> 데이터 모델: [data.md](data.md)

---

## 1. 상태 전이

### 1.1 SharedContent.is_active 상태 전이

```mermaid
stateDiagram-v2
    [*] --> active: 공통 컨텐츠 생성 (is_active=true)

    active --> inactive: 비활성 전환 [BR-SHC-005]
    inactive --> active: 재활성화 [BR-SHC-006]
```

> **SharedContent는 `is_active` boolean 플래그로 상태를 관리한다.** 별도 status ENUM이 아닌 boolean 방식이므로, "상태 전이"보다는 "활성/비활성 토글"에 가깝다. replacement_id는 비활성 시에만 지정 가능하다 (`CHECK (replacement_id IS NULL OR is_active = false)`).

---

## 2. 규칙 카탈로그

### 공통 컨텐츠 CRUD

#### BR-SHC-001: 항상 최신 버전 참조

- **트리거**: 문서 열람 시 공통 컨텐츠 렌더링
- **조건**: —
- **동작**: 공통 컨텐츠 ID → `SharedContent.content`(현재 최신 본문)로 치환하여 표시. 버전 고정(pinning) 미지원
- **위반 시**: — (시스템 동작 규칙)
- **근거**: FD-DOC §5 [BR-DOC-025] — 단순 운영 우선. 버전 고정 시 관리 복잡도가 급증하므로 항상 최신 버전만 참조

#### BR-SHC-002: 수정 시 참조 문서 즉시 반영

- **트리거**: `PATCH /api/shared-contents/:id` — 공통 컨텐츠 본문 수정
- **조건**: —
- **동작**: SharedContent.content 갱신 즉시, 해당 공통 컨텐츠를 참조하는 모든 문서에 자동 반영 (인라인 참조이므로 별도 전파 없이 렌더링 시점에 최신 본문 조회)
- **위반 시**: — (시스템 동작 규칙)
- **근거**: FD-DOC §5 [BR-DOC-027] — 개별 문서 수정 불필요

#### BR-SHC-003: 삭제 차단 — 참조 문서 존재 시

- **트리거**: `DELETE /api/shared-contents/:id` — 공통 컨텐츠 삭제 시도
- **조건**: `SharedContentRef`에 해당 `shared_content_id`를 참조하는 레코드가 1건 이상 존재하되, **연결 문서가 소프트 삭제되지 않은 경우만** 삭제 차단 카운트에 포함한다. 즉 `Document.deleted_at IS NOT NULL`인 문서에 대한 참조는 카운트에서 제외한다. 구현 시 `SharedContentRef`와 `Document`를 조인하여 `deleted_at IS NULL`인 행만 집계한다.
- **동작**: 삭제 차단 조건을 만족하면 삭제 거부하고 참조 문서 수를 응답에 포함한다. **삭제 차단 조건을 만족하지 않으면**(소프트 삭제된 문서만 참조하는 경우 등) 삭제를 진행한다.
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_IN_USE | 409 | {count}개 문서에서 참조 중이므로 삭제할 수 없습니다. 비활성 전환을 사용하세요 |

- **근거**: FD-DOC §5 [BR-DOC-026] — 참조 무결성 보호. data.md `SharedContentRef.shared_content_id ON DELETE RESTRICT`. 문서 소프트 삭제 시 참조 레코드는 유지하되 삭제 차단에서는 제외하는 것은 [events.md §2](events.md#2-소비-이벤트)의 `document.deleted` 처리와 동일한 운영 의도이다 (복구 시 참조 복원 가능, 이미 휴지통 문서만으로 공통 컨텐츠 영구 삭제 불가 방지).

#### BR-SHC-004: 수정 시 재임베딩 트리거

- **트리거**: `PATCH /api/shared-contents/:id` — 공통 컨텐츠 본문(content) 수정 완료 후
- **조건**: RAG(임베딩) 연동이 활성
- **동작**:
  1. SharedContentRef에서 참조 `document_id` + `block_id` 목록 조회
  2. 참조 문서별로 BullMQ `re-embedding` 큐에 Job enqueue
  3. EventBus `shared-content.updated` 이벤트 발행
- **위반 시**: — (피처 비활성 시 enqueue 스킵, 에러 아님)
- **근거**: FD-DOC §5 [BR-DOC-028], 비동기 이벤트 아키텍처 §6.1

---

### 비활성/활성 전환

#### BR-SHC-005: 비활성 전환

- **트리거**: `PATCH /api/shared-contents/:id/deactivate`
- **조건**: `SharedContent.is_active == true`
- **동작**:
  1. `SharedContent.is_active` → `false`
  2. `replacement_id` 지정 시 대체 컨텐츠 설정
  3. 참조 문서 작성자에게 비활성 경고 알림 발송 (EventBus `shared-content.deactivated`)
  4. 감사 로그 `shared_content.deactivated` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_ALREADY_INACTIVE | 409 | 이미 비활성 상태입니다 |
  | SHC_REPLACEMENT_INACTIVE | 422 | 대체 컨텐츠가 비활성 상태입니다 (1-depth 제한) |

- **근거**: FD-DOC §5 삭제/비활성 처리 — 삭제 대신 비활성 처리로 마이그레이션 유도

#### BR-SHC-006: 재활성화

- **트리거**: `PATCH /api/shared-contents/:id/activate`
- **조건**: `SharedContent.is_active == false`
- **동작**:
  1. `SharedContent.is_active` → `true`
  2. `replacement_id` → `null` (대체 컨텐츠 해제)
  3. 감사 로그 `shared_content.activated` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_ALREADY_ACTIVE | 409 | 이미 활성 상태입니다 |

- **근거**: 비활성된 공통 컨텐츠의 복원 필요성

---

### 데이터 무결성

#### BR-SHC-007: replacement 체인 1-depth 제한

- **트리거**: 비활성 전환 시 `replacement_id` 지정
- **조건**: 지정하려는 대체 컨텐츠(`replacement_id`)의 `is_active == true`
- **동작**: `replacement_id` 설정 허용
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_REPLACEMENT_INACTIVE | 422 | 대체 컨텐츠가 비활성 상태입니다. 활성 상태의 컨텐츠만 대체로 지정할 수 있습니다 |

- **근거**: data.md §설계 결정 — 대체 컨텐츠가 또 비활성되는 체인은 앱 레벨에서 차단 (1-depth만 허용)

#### BR-SHC-008: slug UNIQUE

- **트리거**: 공통 컨텐츠 생성/수정 시
- **조건**: `slug`가 기존 다른 SharedContent의 `slug`와 동일
- **동작**: 생성/수정 거부
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_SLUG_DUPLICATE | 409 | 이미 사용 중인 slug입니다: {slug} |

- **근거**: data.md `UNIQUE(slug)` — slug 기반 검색/삽입의 고유성 보장

#### BR-SHC-009: tags 앱 레벨 검증

- **트리거**: 공통 컨텐츠 생성/수정 시 `tags` 배열 지정
- **조건**: `tags` 배열의 각 값이 등록된 태그 목록(`GET /api/shared-contents/tags`)에 모두 포함
- **동작**: 태그 검증 통과. 빈 배열(`[]`)은 허용하지 않으며 최소 1개 태그를 요구한다. 미지정 시 `["general"]`을 기본값으로 할당한다.
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_INVALID_TAG | 422 | 유효하지 않은 태그입니다: {tag} |

- **근거**: data.md §설계 결정 — 태그 허용 목록은 관리자가 태그 관리 API로 CRUD한다. DB CHECK 제약 대신 앱 레벨에서 검증

#### BR-SHC-010: 자기 참조 replacement 차단

- **트리거**: 비활성 전환 시 `replacement_id` 지정
- **조건**: `replacement_id == id`
- **동작**: 지정 거부
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_SELF_REPLACEMENT | 422 | 자기 자신을 대체 컨텐츠로 지정할 수 없습니다 |

- **근거**: data.md `CHECK (replacement_id IS DISTINCT FROM id)`

#### BR-SHC-017: slug 자동 생성·정규화 (엣지 케이스)

- **트리거**: 공통 컨텐츠 생성 시 `slug`를 생략하거나, 표시명(`name`)으로부터 자동 생성할 때
- **조건·동작** (구현 기준):
  1. **문자 허용 범위**: 최종 slug는 **소문자 ASCII 영문, 숫자, 하이픈(`-`)** 만 사용한다. 공백은 하이픈으로 치환한다.
  2. **한글·비라틴 문자**: URL·검색키 일관성을 위해 **음역하지 않고 제거**한다. 제거 후 앞뒤 하이픈을 정리하고, 연속 하이픈은 하나로 병합한다. 결과가 빈 문자열이면 임의 고유 접두사(예: `sc-` + 짧은 UUID 앞 8자) 등으로 대체한다.
  3. **특수문자**: `/`, `&`, `#`, `?`, `%`, 제어문자 등 URL·식별자에 부적합한 문자는 **제거**한다. 공백과 동일하게 하이픈으로 통합할지 여부는 구현 선택이나, 최종 결과는 위 1항의 허용 문자 집합을 만족해야 한다.
  4. **충돌 시**: 동일 `org`(테넌트) 내 `UNIQUE(slug)`와 충돌하면 접미사 `-1`, `-2`, … 순으로 붙여 유일할 때까지 시도한다.
  5. **최대 길이**: DB 컬럼은 `VARCHAR(200)`이다. 기본 slug가 200자를 넘으면 **200자로 절단**한 뒤 충돌 시에는 절단본에 `-1` 등을 붙이되, **총 길이가 200자를 넘지 않도록** 절단 길이를 줄이거나 접미사를 짧게 유지한다.
- **위반 시**: — (정규화는 생성 파이프라인 내부 동작). 수동 입력 `slug`가 규격 위반이면 `VALIDATION_ERROR`, 중복이면 [BR-SHC-008] `SHC_SLUG_DUPLICATE`
- **근거**: data.md `slug` 필드 정의 및 RD-MS-02 구현 판단 축소

---

### 태그 관리

#### BR-SHC-018: 태그 slug UNIQUE

- **트리거**: 태그 생성/수정 시
- **조건**: `slug`가 기존 다른 태그의 `slug`와 동일
- **동작**: 생성/수정 거부
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_TAG_DUPLICATE | 409 | 이미 사용 중인 태그입니다: {slug} |

- **근거**: 태그 slug는 `SharedContent.tags` JSONB 배열의 값으로 사용되므로 고유해야 한다

#### BR-SHC-019: 태그 삭제 차단 — 사용 중

- **트리거**: `DELETE /api/shared-contents/tags/:slug`
- **조건**: `SharedContent.tags` JSONB 배열에 해당 slug를 포함하는 공통 컨텐츠가 1건 이상 존재
- **동작**: 삭제 거부하고 사용 중인 공통 컨텐츠 수를 응답에 포함
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_TAG_IN_USE | 409 | {count}개 공통 컨텐츠에서 사용 중이므로 삭제할 수 없습니다 |

- **근거**: 태그 삭제 시 해당 태그를 참조하는 공통 컨텐츠의 `tags` 배열이 비정상 상태가 되는 것을 방지

#### BR-SHC-020: general 태그 보호

- **트리거**: `DELETE` 또는 `PATCH /api/shared-contents/tags/general`
- **조건**: 대상 slug가 `general`
- **동작**: 삭제 거부, slug 변경 거부 (label 변경은 허용)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SHC_TAG_PROTECTED | 422 | 기본 태그(general)는 삭제하거나 slug를 변경할 수 없습니다 |

- **근거**: `general`은 `SharedContent.tags`의 DB 기본값(`DEFAULT '["general"]'`)으로 사용되므로 시스템 보호 대상

#### BR-SHC-021: 태그 slug 변경 시 공통 컨텐츠 일괄 갱신

- **트리거**: `PATCH /api/shared-contents/tags/:slug` — slug 변경 시
- **조건**: —
- **동작**: `SharedContent.tags` JSONB 배열에서 이전 slug를 새 slug로 일괄 교체 (`jsonb_set` 또는 배열 원소 치환). 트랜잭션 내에서 원자적으로 수행
- **위반 시**: — (시스템 동작 규칙)
- **근거**: 태그 slug는 `tags` 배열의 값으로 직접 저장되므로, slug 변경 시 참조 정합성 유지 필요

---

### 권한

#### BR-SHC-011: 관리자 전용 수정

- **트리거**: 공통 컨텐츠 생성/수정/비활성/삭제 API 호출
- **조건**: 요청자가 `manage_shared_content` 권한 보유 (ADMIN 역할)
- **동작**: 요청 처리 진행
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | 공통 컨텐츠 관리 권한이 없습니다 |

- **근거**: FD-DOC §5 — 공통 컨텐츠는 관리자만 생성/수정 가능. 별도 승인 워크플로우 없음

#### BR-SHC-012: 조회 권한 — 인증 사용자

- **트리거**: 공통 컨텐츠 목록/단건 조회 API
- **조건**: 인증된 사용자
- **동작**: 조회 허용
- **위반 시**: `UNAUTHORIZED` (401)
- **근거**: 공통 컨텐츠 열람은 문서 편집/열람 시 필요하므로 인증 사용자 전원에게 허용

---

### 기능·연동 비활성

#### BR-SHC-015: 공통 컨텐츠 기능 비활성 시 API 차단

- **트리거**: 공통 컨텐츠 관련 API 호출
- **조건**: 테넌트/운영 설정에서 공통 컨텐츠 기능이 꺼져 있음
- **동작**: `403 FEATURE_DISABLED` 반환. 프론트엔드는 설정에 따라 `/공통` 슬래시 명령 등을 숨김
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FEATURE_DISABLED | 403 | 공통 컨텐츠 기능이 비활성화되어 있습니다 |

- **근거**: ADR-011 C-5 — 라이선스·운영 정책에 따른 비활성

#### BR-SHC-016: RAG 비활성 시 큐 enqueue 스킵

- **트리거**: 공통 컨텐츠 수정 후 re-embedding 큐 enqueue 시점
- **조건**: RAG(임베딩) 연동이 꺼져 있음
- **동작**: `re-embedding` 큐 enqueue를 스킵하고 로그만 기록 (에러 아님)
- **위반 시**: — (방어 코드)
- **근거**: Document 모듈 BR-DOC-038과 동일 원칙 — 상태 전이와 큐 enqueue 분리

---

## 3. 규칙 요약 매트릭스

| 규칙 ID | 이름 | 주요 트리거 | 에러 코드 |
|---------|------|-----------|-----------|
| BR-SHC-001 | 항상 최신 버전 참조 | 문서 열람 시 렌더링 | — |
| BR-SHC-002 | 수정 시 즉시 반영 | PATCH /api/shared-contents/:id | — |
| BR-SHC-003 | 삭제 차단 | DELETE /api/shared-contents/:id | SHC_IN_USE |
| BR-SHC-004 | 수정 시 재임베딩 트리거 | PATCH /api/shared-contents/:id | — |
| BR-SHC-005 | 비활성 전환 | PATCH /api/shared-contents/:id/deactivate | SHC_ALREADY_INACTIVE, SHC_REPLACEMENT_INACTIVE |
| BR-SHC-006 | 재활성화 | PATCH /api/shared-contents/:id/activate | SHC_ALREADY_ACTIVE |
| BR-SHC-007 | replacement 체인 1-depth 제한 | 비활성 전환 시 replacement_id 지정 | SHC_REPLACEMENT_INACTIVE |
| BR-SHC-008 | slug UNIQUE | 생성/수정 | SHC_SLUG_DUPLICATE |
| BR-SHC-009 | tags 앱 레벨 검증 | 생성/수정 | SHC_INVALID_TAG |
| BR-SHC-010 | 자기 참조 replacement 차단 | 비활성 전환 시 | SHC_SELF_REPLACEMENT |
| BR-SHC-011 | 관리자 전용 수정 | 생성/수정/비활성/삭제 | FORBIDDEN |
| BR-SHC-012 | 조회 권한 | 목록/단건 조회 | UNAUTHORIZED |
| BR-SHC-015 | 공통 컨텐츠 기능 비활성 시 API 차단 | 모든 API | FEATURE_DISABLED |
| BR-SHC-016 | RAG 비활성 시 큐 스킵 | 수정 후 큐 enqueue | — |
| BR-SHC-017 | slug 자동 생성·정규화 | 생성(자동 slug) | VALIDATION_ERROR, SHC_SLUG_DUPLICATE |
| BR-SHC-018 | 태그 slug UNIQUE | 태그 생성/수정 | SHC_TAG_DUPLICATE |
| BR-SHC-019 | 태그 삭제 차단 | 태그 삭제 | SHC_TAG_IN_USE |
| BR-SHC-020 | general 태그 보호 | 태그 삭제/수정 | SHC_TAG_PROTECTED |
| BR-SHC-021 | 태그 slug 변경 시 일괄 갱신 | 태그 slug 수정 | — |

---

## 4. 에러 코드 카탈로그

> 전역 에러 코드 (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

| 에러 코드 | HTTP | 발생 규칙 | 메시지 템플릿 |
|-----------|------|----------|--------------|
| SHC_NOT_FOUND | 404 | — | 공통 컨텐츠를 찾을 수 없습니다 |
| SHC_IN_USE | 409 | BR-SHC-003 | {count}개 문서에서 참조 중이므로 삭제할 수 없습니다 |
| SHC_SLUG_DUPLICATE | 409 | BR-SHC-008 | 이미 사용 중인 slug입니다: {slug} |
| SHC_ALREADY_ACTIVE | 409 | BR-SHC-006 | 이미 활성 상태입니다 |
| SHC_ALREADY_INACTIVE | 409 | BR-SHC-005 | 이미 비활성 상태입니다 |
| SHC_REPLACEMENT_INACTIVE | 422 | BR-SHC-007 | 대체 컨텐츠가 비활성 상태입니다 |
| SHC_SELF_REPLACEMENT | 422 | BR-SHC-010 | 자기 자신을 대체 컨텐츠로 지정할 수 없습니다 |
| SHC_INVALID_TAG | 422 | BR-SHC-009 | 유효하지 않은 태그입니다: {tag} |
| SHC_TAG_NOT_FOUND | 404 | — | 태그를 찾을 수 없습니다 |
| SHC_TAG_DUPLICATE | 409 | BR-SHC-018 | 이미 사용 중인 태그입니다: {slug} |
| SHC_TAG_IN_USE | 409 | BR-SHC-019 | {count}개 공통 컨텐츠에서 사용 중이므로 삭제할 수 없습니다 |
| SHC_TAG_PROTECTED | 422 | BR-SHC-020 | 기본 태그(general)는 삭제하거나 slug를 변경할 수 없습니다 |
