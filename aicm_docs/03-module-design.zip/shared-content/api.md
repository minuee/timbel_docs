# SharedContent API 스펙

> 기능정의서: [FD-DOC-문서관리 §5](../../01-requirements/features/FD-DOC-문서관리.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [data.md](data.md)
> 이벤트: [events.md](events.md)

**비고**: 공통 컨텐츠 기능이 비활성이면 모든 엔드포인트 `403 FEATURE_DISABLED` [BR-SHC-015]

**API 경로**: `/api/shared-contents/...` — SharedContentModule은 독립 도메인 모듈이므로 Document 하위가 아닌 독립 경로를 사용한다 (ADR-011 C-1)

---

## 엔드포인트 요약

### 공통 컨텐츠

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /shared-contents | 공통 컨텐츠 목록 조회 | 인증 필요 |
| GET | /shared-contents/autocomplete | 자동완성 검색 | 인증 필요 |
| GET | /shared-contents/:id | 공통 컨텐츠 단건 조회 | 인증 필요 |
| POST | /shared-contents | 공통 컨텐츠 생성 | ADMIN |
| PATCH | /shared-contents/:id | 공통 컨텐츠 수정 | ADMIN |
| PATCH | /shared-contents/:id/deactivate | 비활성 전환 | ADMIN |
| PATCH | /shared-contents/:id/activate | 재활성화 | ADMIN |
| DELETE | /shared-contents/:id | 공통 컨텐츠 삭제 | ADMIN |
| GET | /shared-contents/:id/impact | 영향 범위 조회 | ADMIN |

### 태그 관리

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /shared-contents/tags | 태그 목록 조회 | 인증 필요 |
| POST | /shared-contents/tags | 태그 추가 | ADMIN |
| PATCH | /shared-contents/tags/:slug | 태그 수정 | ADMIN |
| DELETE | /shared-contents/tags/:slug | 태그 삭제 | ADMIN |

---

## 상세 API

### `GET` /shared-contents

**설명**: 공통 컨텐츠 목록을 조회한다. 태그 필터(다중), 활성 상태 필터를 지원한다.

**권한**: 인증 필요 [BR-SHC-012]

**Request**:

- Query params:

```typescript
interface ListSharedContentsQuery {
  tags?: string[];                 // 태그 필터 (OR — 하나라도 포함하면 매칭)
  isActive?: boolean;             // 활성 상태 필터 (기본 true)
  search?: string;                // name/slug LIKE 검색
  sort?: 'createdAt' | 'updatedAt' | 'name';
  order?: 'ASC' | 'DESC';
  page?: number;                  // 기본 1
  limit?: number;                 // 기본 20, 최대 100
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface SharedContentListItem {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  tags: string[];
  isActive: boolean;
  replacementId: string | null;
  referenceCount: number;         // 참조 문서 수
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
```

---

### `GET` /shared-contents/autocomplete

**설명**: 에디터 내 `/공통` 슬래시 명령에서 사용하는 자동완성 검색 API. 활성 컨텐츠만 반환한다.

**권한**: 인증 필요 [BR-SHC-012]

**Request**:

- Query params:

```typescript
interface AutocompleteQuery {
  q: string;                      // 필수 — 검색어 (name/slug prefix 매칭)
  tags?: string[];                 // 태그 필터 (OR)
  limit?: number;                 // 기본 10, 최대 30
}
```

**Response** (`200`):

```typescript
interface SharedContentAutocompleteItem {
  id: string;
  name: string;
  slug: string;
  tags: string[];
  description: string | null;
  contentPreview: string;         // content의 텍스트 미리보기 (max 100자)
}
```

---

### `GET` /shared-contents/:id

**설명**: 공통 컨텐츠 상세 정보를 조회한다. 본문(content) 포함.

**권한**: 인증 필요 [BR-SHC-012]

**Request**:

- Path params: `id` — 공통 컨텐츠 UUID

**Response** (`200`):

```typescript
interface SharedContentDetailResponse {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  content: Record<string, any>;   // Tiptap 블록 JSON
  tags: string[];
  isActive: boolean;
  replacementId: string | null;
  replacement: {                  // 대체 컨텐츠 요약 (있을 경우)
    id: string;
    name: string;
    slug: string;
  } | null;
  referenceCount: number;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SHC_NOT_FOUND | 404 | — |

---

### `POST` /shared-contents

**설명**: 새 공통 컨텐츠를 생성한다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Request**:

- Body:

```typescript
interface CreateSharedContentDto {
  name: string;                   // 필수 — 표시명 (max 200자)
  description?: string;           // 선택 — 용도 설명
  content: Record<string, any>;   // 필수 — Tiptap 블록 JSON
  tags?: string[];                 // 선택 — 미지정 시 ["general"] [BR-SHC-009]
}
```

**Response** (`201`):

```typescript
interface SharedContentDetailResponse { /* 단건 조회와 동일 */ }
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_SLUG_DUPLICATE | 409 | [BR-SHC-008](rules.md#br-shc-008-slug-unique) |
| SHC_INVALID_TAG | 422 | [BR-SHC-009](rules.md#br-shc-009-tags-앱-레벨-검증) |

**비즈니스 규칙 참조**: BR-SHC-008, BR-SHC-009, BR-SHC-011

> `slug`는 `name`에서 자동 생성된다 (정규화: 소문자 + 공백 → 하이픈). 직접 지정하지 않는다.

---

### `PATCH` /shared-contents/:id

**설명**: 공통 컨텐츠를 수정한다. 본문(content) 수정 시 재임베딩이 트리거된다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Request**:

- Body:

```typescript
interface UpdateSharedContentDto {
  name?: string;                  // 표시명 변경 (slug 재생성)
  description?: string;           // 용도 설명
  content?: Record<string, any>;  // 본문 변경 시 재임베딩 트리거
  tags?: string[];                 // 태그 변경 (전체 교체)
}
```

**Response** (`200`):

```typescript
interface UpdateSharedContentResponse {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  content: Record<string, any>;
  tags: string[];
  isActive: boolean;
  referenceCount: number;
  impactWarning: {                // content 변경 시 영향 경고 포함
    affectedDocumentCount: number;
    reEmbeddingTriggered: boolean;
  } | null;
  updatedBy: string;
  updatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_NOT_FOUND | 404 | — |
| SHC_SLUG_DUPLICATE | 409 | [BR-SHC-008](rules.md#br-shc-008-slug-unique) |
| SHC_INVALID_TAG | 422 | [BR-SHC-009](rules.md#br-shc-009-tags-앱-레벨-검증) |

**비즈니스 규칙 참조**: BR-SHC-002, BR-SHC-004, BR-SHC-008, BR-SHC-009

---

### `PATCH` /shared-contents/:id/deactivate

**설명**: 공통 컨텐츠를 비활성화한다. 대체 컨텐츠를 지정할 수 있다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Request**:

- Body:

```typescript
interface DeactivateSharedContentDto {
  replacementId?: string;         // 선택 — 대체 공통 컨텐츠 UUID
}
```

**Response** (`200`):

```typescript
interface DeactivateResponse {
  id: string;
  isActive: false;
  replacementId: string | null;
  replacement: {
    id: string;
    name: string;
    slug: string;
  } | null;
  affectedDocumentCount: number;  // 영향받는 문서 수
  deactivatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_NOT_FOUND | 404 | — |
| SHC_ALREADY_INACTIVE | 409 | [BR-SHC-005](rules.md#br-shc-005-비활성-전환) |
| SHC_REPLACEMENT_INACTIVE | 422 | [BR-SHC-007](rules.md#br-shc-007-replacement-체인-1-depth-제한) |
| SHC_SELF_REPLACEMENT | 422 | [BR-SHC-010](rules.md#br-shc-010-자기-참조-replacement-차단) |

**비즈니스 규칙 참조**: BR-SHC-005, BR-SHC-007, BR-SHC-010

---

### `PATCH` /shared-contents/:id/activate

**설명**: 비활성된 공통 컨텐츠를 재활성화한다. `replacement_id`가 해제된다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Response** (`200`):

```typescript
interface ActivateResponse {
  id: string;
  isActive: true;
  activatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_NOT_FOUND | 404 | — |
| SHC_ALREADY_ACTIVE | 409 | [BR-SHC-006](rules.md#br-shc-006-재활성화) |

**비즈니스 규칙 참조**: BR-SHC-006

---

### `DELETE` /shared-contents/:id

**설명**: 공통 컨텐츠를 삭제한다. 참조 문서가 존재하면 삭제가 차단된다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Response** (`200`):

```typescript
interface DeleteSharedContentResponse {
  id: string;
  deletedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_NOT_FOUND | 404 | — |
| SHC_IN_USE | 409 | [BR-SHC-003](rules.md#br-shc-003-삭제-차단--참조-문서-존재-시) |

**비즈니스 규칙 참조**: BR-SHC-003

> 참조 문서가 없는 경우에만 물리 삭제된다. 참조 중인 경우 `SHC_IN_USE` 에러와 함께 참조 문서 수를 반환한다. 비활성 전환(`PATCH /shared-contents/:id/deactivate`)으로 안내한다.

---

### `GET` /shared-contents/:id/impact

**설명**: 공통 컨텐츠 수정 전 영향 범위를 조회한다. 수정 전 사전 확인용 (ADR-011 C-3).

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Request**:

- Path params: `id` — 공통 컨텐츠 UUID

**Response** (`200`):

```typescript
interface ImpactResponse {
  sharedContentId: string;
  sharedContentName: string;
  totalDocumentCount: number;     // 참조 문서 수
  totalBlockCount: number;        // 참조 블록 수
  documents: ImpactDocumentItem[];
}

interface ImpactDocumentItem {
  documentId: string;
  documentTitle: string;
  boardId: string;
  boardName: string;
  blockCount: number;             // 해당 문서 내 참조 블록 수
  status: string;                 // 문서 상태
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_NOT_FOUND | 404 | — |

> 이 API는 GET 메서드로 캐싱 가능하다. 관리자 대시보드에서도 재사용 가능하며, 수정 API와 독립적으로 호출된다.

---

## 태그 관리 API

> 공통 컨텐츠에 부여할 수 있는 태그 허용 목록을 관리자가 직접 CRUD한다. 태그 값은 공통 컨텐츠 생성/수정 시 `tags` 배열에 넣을 수 있는 허용 값 집합이다.

### `GET` /shared-contents/tags

**설명**: 허용된 태그 전체 목록을 조회한다. 각 태그별 사용 건수를 포함한다.

**권한**: 인증 필요 [BR-SHC-012]

**Response** (`200`):

```typescript
interface TagListResponse {
  items: TagItem[];
}

interface TagItem {
  slug: string;                   // 태그 식별 키 (예: 'legal', 'contact')
  label: string;                  // 표시명 (예: '법률/약관', '연락처')
  usageCount: number;             // 이 태그를 사용 중인 공통 컨텐츠 수
  createdAt: string;
}
```

---

### `POST` /shared-contents/tags

**설명**: 새 태그를 추가한다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Request**:

- Body:

```typescript
interface CreateTagDto {
  label: string;                  // 필수 — 표시명 (max 50자)
  slug?: string;                  // 선택 — 미지정 시 label에서 자동 생성
}
```

**Response** (`201`):

```typescript
interface TagItem { /* 목록 조회와 동일 */ }
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_TAG_DUPLICATE | 409 | [BR-SHC-018](rules.md#br-shc-018-태그-slug-unique) |

---

### `PATCH` /shared-contents/tags/:slug

**설명**: 태그 표시명을 수정한다. slug 변경 시 해당 태그를 사용 중인 공통 컨텐츠의 `tags` JSONB 배열도 함께 갱신된다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Request**:

- Path params: `slug` — 태그 slug
- Body:

```typescript
interface UpdateTagDto {
  label?: string;                 // 표시명 변경
  slug?: string;                  // slug 변경 시 공통 컨텐츠 tags 배열 내 값도 일괄 갱신
}
```

**Response** (`200`):

```typescript
interface TagItem { /* 목록 조회와 동일 */ }
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_TAG_NOT_FOUND | 404 | — |
| SHC_TAG_DUPLICATE | 409 | [BR-SHC-018](rules.md#br-shc-018-태그-slug-unique) |
| SHC_TAG_PROTECTED | 422 | [BR-SHC-020](rules.md#br-shc-020-general-태그-보호) |

---

### `DELETE` /shared-contents/tags/:slug

**설명**: 태그를 삭제한다. 사용 중인 공통 컨텐츠가 있으면 삭제가 차단된다.

**권한**: ADMIN (`manage_shared_content`) [BR-SHC-011]

**Response** (`200`):

```typescript
interface DeleteTagResponse {
  slug: string;
  deletedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SHC-011](rules.md#br-shc-011-관리자-전용-수정) |
| SHC_TAG_NOT_FOUND | 404 | — |
| SHC_TAG_IN_USE | 409 | [BR-SHC-019](rules.md#br-shc-019-태그-삭제-차단--사용-중) |
| SHC_TAG_PROTECTED | 422 | [BR-SHC-020](rules.md#br-shc-020-general-태그-보호) |

> `general` 태그는 시스템 기본값이므로 삭제할 수 없다 [BR-SHC-020].

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **SharedContent 도메인 에러** 전체 목록은 [rules.md §4 에러 코드 카탈로그](rules.md#4-에러-코드-카탈로그) 참조
