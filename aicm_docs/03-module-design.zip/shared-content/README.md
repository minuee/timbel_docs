# SharedContent 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | SharedContentModule |
| 문서 코드 | MS-SHC |
| 상태 | `draft` |
| 기능정의서 | [FD-DOC-문서관리 §5](../../01-requirements/features/FD-DOC-문서관리.md) |
| 데이터 모델 | [data.md](./data.md) |
| 프로세스 흐름 | — |

---

## 모듈 책임

SharedContentModule은 여러 문서에서 공통으로 참조하는 **재사용 가능한 컨텐츠 블록**(환경변수형)의 관리를 담당한다. 한 번 수정하면 참조하는 모든 문서에 즉시 반영되는 것이 핵심 가치이다.

| 영역 | 설명 |
|------|------|
| 공통 컨텐츠 CRUD | 공통 컨텐츠 생성·조회·수정·삭제, 카테고리 분류, 자동완성 검색 |
| 참조 문서 추적 | SharedContentRef를 통해 어떤 문서의 어떤 블록이 공통 컨텐츠를 참조하는지 정밀 추적 |
| 재임베딩 트리거 | 공통 컨텐츠 수정 시 참조 문서의 관련 청크를 BullMQ `re-embedding` 큐에 enqueue하여 비동기 재임베딩 |
| 영향 범위 조회 | 수정 전 영향받는 문서 목록 조회 (관리자 사전 확인용) |
| 비활성/대체 관리 | 삭제 대신 비활성 처리, replacement_id로 대체 컨텐츠 안내 |

### 현재 범위 제외 기능

| 기능 | 근거 | 향후 계획 |
|------|------|----------|
| 버전 고정(pinning) | FD-DOC §5 BR-DOC-025 — 항상 최신 본문만 참조, 단순 운영 우선 | 운영 피드백에 따라 Phase 2 이후 검토 |
| 블록 단위 삽입 | FD-DOC §5 — 인라인 삽입만 지원 | 블록 레벨 삽입 수요 발생 시 확장 |
| 승인 워크플로우 | FD-DOC §5 — 관리자 권한으로 충분, AuditLog와 영향도 확인으로 통제 | 금융권 요건 발생 시 도입 검토 |

---

## 핵심 엔티티

> 필드 상세: [data.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **SharedContent** | 공통 컨텐츠 본체. name(표시명), slug(검색키), content(Tiptap JSON), category(분류), is_active(활성 플래그), replacement_id(대체 컨텐츠). 수정 이력은 AuditLog로 추적 |
| **SharedContentRef** | 참조 추적. 어떤 문서(document_id)의 어떤 블록(block_id)이 공통 컨텐츠를 참조하는지 기록. 삭제 차단, 재임베딩 대상 조회, 영향 범위 확인의 기반 데이터 |

---

## 의존 관계

```mermaid
graph LR
    SHC["<b>SharedContentModule</b>"]

    Doc["DocumentModule"]

    SHC -->|"읽기"| Doc

    SHC -.->|"re-embedding 큐<br/>(BullMQ Important)"| ReEmbed["re-embedding Worker"]
    SHC -.->|"EventBus<br/>(Best-effort)"| NTF["NotificationModule"]
    SHC -.->|"EventBus"| AUD["AuditLogModule"]

    classDef hub fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef consumer fill:#f3f4f6,stroke:#6b7280
    classDef queue fill:#fef3c7,stroke:#d97706

    class SHC hub
    class Doc provider
    class NTF,AUD consumer
    class ReEmbed queue
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| SHC → Document | DocumentModule | 읽기 | 참조 문서·블록 정보 조회 (SharedContentRef.document_id FK) |
| SHC → re-embedding | BullMQ 큐 | Important enqueue | 공통 컨텐츠 수정 시 참조 문서의 관련 청크 재임베딩 트리거 |
| SHC → Notification | NotificationModule | EventBus Best-effort | 비활성 전환 시 참조 문서 작성자 경고 알림 |
| SHC → AuditLog | AuditLogModule | EventBus Best-effort / Interceptor | 감사 로그 기록 |

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | SharedContent, SharedContentRef |
| Redis / BullMQ | ● | `re-embedding` 큐 (공통 컨텐츠 수정 시 대량 재임베딩) |
| Elasticsearch | — | |
| MinIO | — | |
| EventBus | ● 발행 | `shared-content.updated`, `shared-content.deactivated`, `shared-content.activated` |
| 외부 서비스 클라이언트 | — | re-embedding Worker가 RetrievalServiceClient를 호출하나, Worker는 인프라 레벨이므로 모듈 직접 호출은 아님 |

---

## 기능·연동 비활성 시 Graceful Degradation

상세: [events.md §5](events.md#5-외부-서비스-및-기능-비활성-시-graceful-degradation)

| 구분 | 비활성 시 영향 | 핵심 기능 영향 |
|------|--------------|--------------|
| 공통 컨텐츠 기능 | 모든 SharedContent API `403 FEATURE_DISABLED`. 프론트엔드는 설정에 따라 `/공통` 슬래시 명령 숨김 (ADR-011 C-5) | **문서 CRUD에 영향 없음** — 기존 참조는 렌더링 시 무시되거나 빈 값으로 표시 |
| RAG | `re-embedding` 큐 enqueue 스킵, Worker 미등록 | **공통 컨텐츠 CRUD에 영향 없음** — 재임베딩만 미수행, 키워드 검색은 정상 |

> **원칙**: 테넌트에서 공통 컨텐츠 기능을 끈 경우 API 전체가 비활성화된다. RAG만 꺼진 경우 재임베딩만 생략된다.

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `shared_content.update_count` | 시간당 공통 컨텐츠 수정 건수 | API 미들웨어 카운터 |
| `re_embedding.queue_lag` | `re-embedding` 큐 대기 Job 수 | BullMQ Dashboard |
| `re_embedding.failure_rate` | `re-embedding` 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `re_embedding.dlq_count` | `re-embedding-dlq`에 적재된 Job 수 | BullMQ Dashboard |
| `circuit.retrieval.state_change` | retrieval-service 서킷 상태 전이 (Open / HalfOpen / Closed) | Document 모듈과 동일 — RetrievalServiceClient·Redis 서킷 키 ([document/events.md §3.3](../document/events.md#33-서킷브레이커-정책)) |
| `re_embedding.job_deferred_circuit` | 서킷 Open으로 지연 재스케줄된 `re-embedding` Job 처리 건수 | re-embedding Worker 카운터 — events.md §1.1 |
| `shared_content.ref_count_max` | 단일 공통 컨텐츠의 최대 참조 문서 수 | 주기적 집계 쿼리 |
| `shared_content.deactivation_count` | 시간당 비활성 전환 건수 | API 미들웨어 카운터 |

---

## 모니터링 알림 임계값

| 대상 | 조건 | 심각도 | 채널 |
|------|------|--------|------|
| re-embedding 큐 지연 | `re_embedding.queue_lag > 50` (10분 이상 지속) | WARNING | Slack + 대시보드 |
| re-embedding 실패율 | `re_embedding.failure_rate > 20%` (최근 1시간) | CRITICAL | Slack + PagerDuty |
| re-embedding DLQ 적재 | `re_embedding.dlq_count > 0` | WARNING | Slack |
| 단일 컨텐츠 대량 참조 | `shared_content.ref_count_max > 500` | WARNING | 대시보드 |

---

## 로그 레벨 가이드

| 모듈/작업 | 로그 레벨 | 설명 |
|-----------|----------|------|
| re-embedding 큐 enqueue | `INFO` | 정상 트리거 흐름 기록 |
| re-embedding Worker 실패 | `ERROR` | 재시도 소진 전 각 실패 기록 |
| re-embedding DLQ 진입 | `ERROR` | 수동 개입 필요 |
| 의도적 큐 스킵 | `INFO` | RAG 비활성 등 의도된 스킵 (디버깅 용도) |
| 비활성 전환 알림 발송 | `INFO` | 정상 알림 흐름 |
| 삭제 차단 (참조 존재) | `WARN` | 사용자 실수 가능성, 모니터링 대상 |

---

## 외부 설정값 카탈로그

| 설정 키 | 기본값 | 용도 | 참조 |
|---------|--------|------|------|
| `lm:shared_content.max_content_size` | 10,000 (characters) | 공통 컨텐츠 본문 크기 상한 | — |
| `lm:shared_content.max_name_length` | 200 | 표시명 길이 상한 | data.md VARCHAR(200) |
| `pm:re_embedding.concurrency` | 1 | re-embedding Worker 동시 처리 수 | 05-async-event-architecture §6.1 |
| `pm:re_embedding.timeout_ms` | 600000 | re-embedding Job 타임아웃 (10분) | 05-async-event-architecture §6.1 |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-DOC-문서관리 §5](../../01-requirements/features/FD-DOC-문서관리.md) | 기능정의서 — 공통 컨텐츠 섹션 (입력 원본) |
| [ADR-011 §C](../../adr/011-round3-module-design-decisions.md) | SharedContent 설계 결정 5건 |
| [data.md](./data.md) | RDB 엔티티/DDL |
| [api.md](./api.md) | API 스펙 |
| [rules.md](./rules.md) | 비즈니스 규칙 카탈로그 |
| [events.md](./events.md) | 이벤트 및 부수효과 |
| [모듈 아키텍처 §3.2](../../02-architecture/02-module-architecture.md) | SharedContentModule 책임 정의 |
| [비동기 이벤트 아키텍처 §6.1](../../02-architecture/05-async-event-architecture.md) | re-embedding 큐 정의 |
