# AuthModule — RDB 엔티티

> AICM 내부 역할·팀 관리. User는 외부 서비스가 관리하며 AICM DB에 User 테이블은 없다

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    Role ||--o{ UserRole : "1:N"
    Role ||--o{ AdminPermission : "1:N"
    Role ||--o{ TeamRole : "1:N"

    Team ||--o{ TeamMember : "1:N"
    Team ||--o{ TeamRole : "1:N"
    Team ||--o{ Team : "self-ref 트리 (parent_id)"

    %% 외부 모듈 참조
    Role ||--o{ BoardPermission : "1:N (BoardModule)"
```

---

## 2. 엔티티 필드

### 2.1 Role

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(100) | 역할명 (예: '상담원', '게시판 관리자', '검색 관리자') |
| description | TEXT (nullable) | 역할 설명 |
| status | ENUM('active', 'inactive', 'locked') (default 'active') | 생명주기 상태 |
| is_system | BOOLEAN (default false) | 시스템 기본 역할 — true이면 삭제 불가 |
| lock_reason | VARCHAR(500) (nullable) | 긴급 잠금 사유 (status='locked'일 때만) |
| version | INTEGER (default 1) | 낙관적 동시성 제어(OCC) 버전 |
| created_by | UUID | 생성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(name)` — 역할명 중복 방지
- `is_system = true`인 Role은 앱 레벨에서 삭제를 차단한다
- `status`는 CHECK 제약으로 허용 값만 수용
- `lock_reason`은 `status = 'locked'`일 때만 값이 유효 (앱 레벨 검증)

#### 설계 결정

**Role = 단일 권한 경계**
— Role은 AICM의 유일한 권한 경계이다. 게시판 권한(BoardPermission)과 관리자 권한(AdminPermission)이 모두 Role을 경유한다. 하나의 역할에 게시판 접근 권한과 시스템 관리 권한을 함께 부여할 수 있어, "이 역할은 무엇을 할 수 있는가"를 한 곳에서 파악할 수 있다.

**BoardPermission과 AdminPermission을 분리한 이유**
— 두 권한은 스키마 구조가 다르다. BoardPermission은 `board_id`(리소스 스코프)가 필수이고, AdminPermission은 전역 권한이라 리소스 스코프가 없다. 스키마가 다르면 테이블을 분리하는 것이 FK·UNIQUE·인덱스 설계에서 깔끔하다. 향후 AdminPermission에 스코프가 추가되는 권한이 생기면 해당 권한만 별도 테이블로 분리한다.

**규모 산정**
— Role 자체는 10~20건 수준의 소규모 마스터 데이터이다. 게시판 수 10 × action 3 × Role 10 = 약 300건 BoardPermission, 권한 키 12 × Role 10 = 약 120건 AdminPermission이 파생된다.

**is_system 필드**
— 시스템 초기화 시 생성되는 기본 역할은 `is_system = true`로 설정되어 관리자가 실수로 삭제하는 것을 방지한다. DB 제약이 아닌 앱 레벨에서 삭제를 차단하며, 이름 변경과 권한 수정은 허용한다.

**Role 생명주기 (status)**
— FD-ACL §3.1에 정의된 3상태(active/inactive/locked) 생명주기를 지원한다. 비활성(inactive) Role은 신규 부여 목록에서 제외되며, 기존 사용자의 해당 Role 통한 권한이 해제된다. 잠금(locked) Role은 보안 사고 시 해당 역할을 통한 모든 권한을 즉시 정지한다.

**version 필드 (OCC)**
— 동시 수정 충돌을 방지하기 위한 낙관적 동시성 제어 필드. 수정 요청 시 요청 본문의 `version`과 DB 현재 `version`을 비교하여 불일치 시 409를 반환한다.

**Role 삭제 정책 — RESTRICT**
— FD-ACL BR-ACL-034에 따라, UserRole 또는 TeamRole에 할당된 상태이면 삭제를 차단한다. 먼저 모든 할당을 해제해야 삭제가 가능하다. 관련 FK 제약은 `ON DELETE RESTRICT`로 설정한다.

**프리셋 Role 시드 목록**

| 프리셋 Role | AdminPermission | 용도 |
|------------|-----------------|------|
| 일반 사용자 | (없음) | 신규 사용자 기본 역할 — 최소 문서 열람 권한 |
| 콘텐츠 관리자 | `manage_boards`, `manage_templates`, `manage_tags`, `manage_shared_content` | 게시판 구조 + 콘텐츠 도구 통합 관리 |
| 조직 관리자 | `manage_roles`, `manage_teams`, `manage_policies` | 역할·팀·승인 정책 관리 |
| 검색 관리자 | `manage_search` | 검색 튜닝 전담 |
| 시스템 관리자 | `manage_system`, `view_audit_logs`, `manage_prompts` | 시스템 설정 + 감사 로그 + AI 프롬프트 관리 |

프리셋 Role은 AdminPermission 키를 논리적으로 묶는 역할을 겸한다. 별도의 팀 카탈로그 테이블이나 코드 상수를 두지 않으며, 관리자가 프리셋을 복제·수정하여 조직에 맞는 커스텀 Role을 자유롭게 만들 수 있다.

**시딩 방식**: 앱 부트스트랩 시 upsert(`ON CONFLICT (name) DO UPDATE`)로 프리셋 Role을 시딩한다 (idempotent). `is_system = true`는 시딩 시에만 설정되며, 관리자가 프리셋 Role의 AdminPermission 구성을 변경한 경우 시딩이 덮어쓰지 않는다 (`DO UPDATE SET description = EXCLUDED.description` — name과 is_system만 보장, AdminPermission 매핑은 유지).

---

### 2.2 UserRole

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID | 외부 서비스의 사용자 ID (FK 없음) |
| role_id | UUID (FK → Role) | AICM 내부 역할 |
| created_by | UUID | 할당 수행자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(user_id, role_id)` — 동일 사용자에게 같은 역할 중복 할당 방지
- `user_id`에 FK 제약 없음 — 외부 서비스의 UUID만 저장 ([rdb.md §3.3 외부 참조 규칙](../../02-architecture/data/aicm/rdb.md#33-외부-참조-규칙) 참조)
- `role_id REFERENCES role(id) ON DELETE RESTRICT` — 할당이 남아있으면 Role 삭제 차단

#### 설계 결정

**N:M 매핑 테이블**
— 1명의 사용자가 여러 Role을 가질 수 있고, 1개의 Role에 여러 사용자가 속할 수 있다. UserRole은 이 N:M 관계의 매핑 테이블이다.

**updated_at 없음**
— 매핑 관계는 추가/삭제만 존재하며 "수정"이라는 개념이 없다. 역할 변경 시 기존 매핑을 삭제하고 새 매핑을 생성한다.

---

### 2.3 AdminPermission

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| role_id | UUID (FK → Role) | 대상 역할 |
| permission_key | VARCHAR(50) | 관리 권한 키 (예: `manage_boards`, `manage_teams`) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(role_id, permission_key)` — 동일 역할에 같은 권한 중복 부여 방지
- `permission_key`는 앱 레벨에서 허용 키 목록을 검증한다 (확장 가능성을 고려하여 CHECK 대신 앱 검증, [rdb.md §3.4](../../02-architecture/data/aicm/rdb.md#34-enum-처리-방식) 참조)

#### 설계 결정

**ADMIN 전용 관리 권한**
— AdminPermission은 ADMIN 역할의 세부 관리 권한을 정의한다. ADMIN 미만 역할(NORMAL/SUPERVISOR/AGENT)의 AdminPermission은 평가하지 않는다. 권한이 있으면 해당 관리 자원의 CRUD 전체가 가능하고, 없으면 관리 화면 자체에 접근 불가하다.

**앱 레벨 키 검증**
— 현재 permission_key 12종: `manage_boards`, `manage_roles`, `manage_teams`, `manage_policies`, `manage_templates`, `manage_tags`, `manage_shared_content`, `manage_search`, `manage_prompts`, `manage_system`, `view_audit_logs`, `bypass_approval`. 새 관리 권한 추가 시 앱 코드에 키를 등록하면 되므로 DB 마이그레이션이 불필요하다.

**updated_at 없음**
— UserRole과 동일하게 추가/삭제만 존재한다.

---

### 2.4 Team

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(100) | 팀명 |
| description | TEXT (nullable) | 팀 설명 |
| parent_id | UUID (FK → Team, nullable) | 상위 팀. null이면 최상위 |
| status | ENUM('active', 'inactive') (default 'active') | 생명주기 상태 |
| team_source | VARCHAR(20) (default 'manual') | 팀 출처: `manual`(수동 생성), `org_sync`(조직도 동기화) |
| expires_at | TIMESTAMPTZ (nullable) | 임시 그룹 유효기간 (NULL이면 무기한) |
| is_external | BOOLEAN (default false) | 외부 인사 시스템 연동 그룹 여부 |
| version | INTEGER (default 1) | 낙관적 동시성 제어(OCC) 버전 |
| created_by | UUID | 생성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(name)` — 팀명 중복 방지
- `CHECK (team_source IN ('manual', 'org_sync'))` — 허용된 출처만
- `CHECK (status IN ('active', 'inactive'))` — 허용된 상태만
- `parent_id`는 자기 자신을 참조할 수 없다 (앱 레벨 검증 — 순환 참조 방지)

#### 설계 결정

**조직 단위 (권한 직접 보유 아님)**
— Team은 동일한 역할을 공유하는 사용자 팀이다. Team 자체는 권한을 갖지 않으며, TeamRole을 통해 Role을 부여한다. 팀에 소속된 멤버는 팀의 Role을 상속받는다.

**계층 구조 (parent_id)**
— Team은 재귀 트리 구조를 가진다. `parent_id = NULL`이면 최상위 팀이다. 상위 팀에 부여된 역할(TeamRole)은 하위 팀 소속 멤버에게 자동 상속된다. 유효 역할 산출 시 소속 팀부터 루트까지 상위를 순회하여 TeamRole을 합산한다 (additive-only, DENY 없음). 의사결정 배경은 [ADR-005](../../adr/005-usergroup-hierarchy-and-org-provider.md)를 참조한다.

**team_source 필드**
— 수동 생성 팀(`manual`)과 외부 조직도 동기화 팀(`org_sync`)을 구분한다. `org_sync` 팀은 외부 UserService의 조직도에서 동기화된 것으로, 멤버 직접 편집이 제한된다. `manual` 팀은 관리자가 자유롭게 생성·편집할 수 있는 목적별 팀(TF, 프로젝트 등)이다.

**status 필드**
— Team 비활성화 시 소속 멤버의 권한 상속이 중단된다. 삭제 대신 비활성화를 사용하여 이력을 보존한다.

**expires_at 필드**
— 외부 협력사 임시 그룹의 유효기간을 설정한다. 만료 시 시스템이 자동으로 비활성 처리한다 (FD-ACL BR-ACL-015).

**version 필드 (OCC)**
— Role과 동일한 낙관적 동시성 제어 패턴. 동시 수정 충돌 방지.

---

### 2.5 TeamMember

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| team_id | UUID (FK → Team) | 소속 팀 |
| user_id | UUID | 외부 서비스의 사용자 ID (FK 없음) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(team_id, user_id)` — 동일 팀에 같은 사용자 중복 소속 방지
- `user_id`에 FK 제약 없음 — 외부 서비스의 UUID만 저장

#### 설계 결정

**updated_at 없음**
— 소속 관계는 추가/삭제만 존재한다. UserRole과 동일한 패턴이다.

---

### 2.6 TeamRole

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| team_id | UUID (FK → Team) | 대상 팀 |
| role_id | UUID (FK → Role) | 부여할 역할 |
| created_by | UUID | 할당 수행자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(team_id, role_id)` — 동일 팀에 같은 역할 중복 부여 방지
- `role_id REFERENCES role(id) ON DELETE RESTRICT` — 할당이 남아있으면 Role 삭제 차단

#### 설계 결정

**팀 → 역할 매핑**
— 팀에 소속된 멤버 전원이 TeamRole에 지정된 Role을 상속받는다. 하나의 팀에 여러 Role을 부여할 수 있고, 하나의 Role이 여러 팀에 부여될 수 있다.

**유효 역할(effective roles) 산출**
— 사용자의 유효 역할 = UserRole(직접 할당) ∪ TeamRole(소속 팀 + 상위 팀 순회). 소속 팀에서 루트까지 parent_id를 따라 상위 팀을 순회하며, 각 팀의 TeamRole을 합산한다. 쿼리 시점에 합산하며, 팀 변경이 즉시 권한에 반영된다. 조직도 조회는 OrgProvider를 통해 추상화되어 있으며 ([02-module-architecture.md §3.4](../../02-architecture/02-module-architecture.md) 참조), 데이터 소스(AICM DB 또는 외부 UserService)를 환경변수로 전환할 수 있다.

**updated_at 없음**
— 매핑 관계는 추가/삭제만 존재한다.

---

## 3. DDL 및 인덱스

### 3.1 Role

```sql
CREATE TABLE role (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         VARCHAR(100) NOT NULL,
  description  TEXT,
  status       VARCHAR(20) NOT NULL DEFAULT 'active',
  is_system    BOOLEAN NOT NULL DEFAULT false,
  lock_reason  VARCHAR(500),
  version      INTEGER NOT NULL DEFAULT 1,
  created_by   UUID NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_role_name UNIQUE (name),
  CONSTRAINT chk_role_status CHECK (status IN ('active', 'inactive', 'locked'))
);

CREATE INDEX idx_role_status
  ON role (status);
```

### 3.2 UserRole

```sql
CREATE TABLE user_role (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    UUID NOT NULL,
  role_id    UUID NOT NULL REFERENCES role(id) ON DELETE RESTRICT,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_user_role UNIQUE (user_id, role_id)
);

CREATE INDEX idx_user_role_role
  ON user_role (role_id);

CREATE INDEX idx_user_role_user
  ON user_role (user_id);
```

### 3.3 AdminPermission

```sql
CREATE TABLE admin_permission (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  role_id        UUID NOT NULL REFERENCES role(id) ON DELETE CASCADE,
  permission_key VARCHAR(50) NOT NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_admin_permission UNIQUE (role_id, permission_key)
);

CREATE INDEX idx_admin_permission_role
  ON admin_permission (role_id);

CREATE INDEX idx_admin_permission_key
  ON admin_permission (permission_key);
```

### 3.4 Team

```sql
CREATE TABLE team (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          VARCHAR(100) NOT NULL,
  description   TEXT,
  parent_id     UUID REFERENCES team(id) ON DELETE RESTRICT,
  status        VARCHAR(20) NOT NULL DEFAULT 'active',
  team_source   VARCHAR(20) NOT NULL DEFAULT 'manual',
  expires_at    TIMESTAMPTZ,
  is_external   BOOLEAN NOT NULL DEFAULT false,
  version       INTEGER NOT NULL DEFAULT 1,
  created_by    UUID NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_team_name UNIQUE (name),
  CONSTRAINT chk_team_source CHECK (team_source IN ('manual', 'org_sync')),
  CONSTRAINT chk_team_status CHECK (status IN ('active', 'inactive'))
);

CREATE INDEX idx_team_parent
  ON team (parent_id)
  WHERE parent_id IS NOT NULL;

CREATE INDEX idx_team_source
  ON team (team_source, status);

CREATE INDEX idx_team_expires
  ON team (expires_at)
  WHERE expires_at IS NOT NULL;
```

### 3.5 TeamMember

```sql
CREATE TABLE team_member (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id   UUID NOT NULL REFERENCES team(id) ON DELETE CASCADE,
  user_id    UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_team_member UNIQUE (team_id, user_id)
);

CREATE INDEX idx_team_member_team
  ON team_member (team_id);

CREATE INDEX idx_team_member_user
  ON team_member (user_id);
```

### 3.6 TeamRole

```sql
CREATE TABLE team_role (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  team_id   UUID NOT NULL REFERENCES team(id) ON DELETE CASCADE,
  role_id    UUID NOT NULL REFERENCES role(id) ON DELETE RESTRICT,
  created_by UUID NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_team_role UNIQUE (team_id, role_id)
);

CREATE INDEX idx_team_role_team
  ON team_role (team_id);

CREATE INDEX idx_team_role_role
  ON team_role (role_id);
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙, 외부 참조 규칙
- [board-module.md](../board/data.md) — BoardPermission (Role이 참조됨)
- [자원 분류 및 권한 체계](../../02-architecture/resource-classification.md) — 3분류 권한 모델, 권한 평가 흐름
- [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) — 권한 평가 로직, PermissionService
- [ADR-005](../../adr/005-usergroup-hierarchy-and-org-provider.md) — Team 계층 확장 및 OrgProvider 패턴 도입
