# Auth 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | AuthModule + PermissionModule + TenantModule |
| 문서 코드 | MS-ACL |
| 상태 | `draft` |
| 기능정의서 | [FD-ACL-권한체계](../../01-requirements/features/FD-ACL-권한체계.md) |
| 데이터 모델 | [auth-module.md](./data.md) |
| 프로세스 흐름 | [04-permission-evaluation.md](../../01-requirements/flows/approval-permission/04-permission-evaluation.md) |
| 아키텍처 | [03-auth-architecture.md](../../02-architecture/03-auth-architecture.md), [04-permission-architecture.md](../../02-architecture/04-permission-architecture.md) |

---

## 모듈 책임

AuthModule + PermissionModule + TenantModule은 AICM의 **공통 모듈(Shared 계층)**로, 모든 도메인 모듈이 의존하는 횡단 관심사(인증·인가·멀티테넌트)를 담당한다. 세 모듈은 각각 독립된 NestJS 모듈이지만, 하나의 문서 세트로 관리한다.

### AuthModule — 인증 + 역할·팀 관리

| 영역 | 설명 |
|------|------|
| 인증 (토큰 검증) | AuthGuard + Provider 패턴 — EcpAuthProvider(SaaS: ECP 포털 토큰) / LocalAuthProvider(온프렘: 자체 JWT). `DEPLOY_MODE` 환경변수로 분기 |
| 역할(Role) CRUD | AICM 내부 역할 생성·조회·수정·삭제. 시스템 프리셋 Role(`is_system = true`) 관리. Role 생명주기(active/inactive/locked) 상태 전이 |
| 사용자 역할 할당 (UserRole) | 외부 userId ↔ AICM Role N:M 매핑. 개인 직접 할당 경로 |
| AdminPermission 관리 | 역할에 관리 권한 키(`permission_key`) 부여·해제. 12개 키 앱 레벨 검증 |
| 팀(Team) CRUD | 조직 단위 생성·조회·수정·비활성화·삭제(물리 삭제 — [BR-ACL-014](rules.md#br-acl-014-팀-삭제-정책)). 재귀 트리(`parent_id`), `team_source`(manual/org_sync), 유효기간(`expires_at`) 관리 |
| 팀 멤버 관리 (TeamMember) | Team ↔ User 매핑. `org_sync` 팀은 멤버 직접 편집 제한 |
| 팀 역할 관리 (TeamRole) | Team ↔ Role 매핑. 팀 소속 멤버 전원이 Role 상속 |
| 조직도 조회 (OrgProvider) | 사용자의 소속 팀 + 상위 팀 목록 조회를 인터페이스로 추상화. LocalOrgProvider(AICM DB) / UserServiceOrgProvider(외부 API). `ORG_SOURCE` 환경변수로 분기 |

### PermissionModule — 인가 (권한 평가)

| 영역 | 설명 |
|------|------|
| 유효 역할 산출 | UserRole(직접 할당) ∪ TeamRole(소속 팀 + 상위 팀 순회, OrgProvider 활용). 비활성/잠금 Role 및 비활성 Team 제외. additive-only, deny 없음 |
| 3계층 권한 평가 | Board Grant(BoardPermission) → Document Restriction → Block Restriction 순차 평가 |
| 자원 분류별 평가 | 문서 자원: BoardPermission + Restriction, 관리 자원: ADMIN + AdminPermission, 개인 자원: 소유자 확인 |
| SYSTEM/ADMIN 바이패스 | SYSTEM 전체 바이패스, ADMIN VIEW 바이패스(메타정보 수준, 감사 로그 기록) |
| 검색 권한 필터 구성 | 접근 가능 board_id 목록, 제한 document_id/block_id 목록 산출 — SearchModule에 pre-filter 제공 |

#### PermissionService 인터페이스

> 원천: [03-auth-architecture.md §5.5](../../02-architecture/03-auth-architecture.md)

```typescript
interface PermissionService {
  getEffectiveRoles(userId: string): Promise<Role[]>;
  checkBoardAccess(userId: string, boardId: string, action: BoardAction): Promise<boolean>;
  checkDocumentAccess(userId: string, documentId: string, action: BoardAction): Promise<boolean>;
  checkBlockAccess(userId: string, blockId: string, action: BoardAction): Promise<boolean>;
  getAccessibleBoardIds(userId: string, action: BoardAction): Promise<string[]>;
  getUserTeamIds(userId: string): Promise<string[]>;
  getRestrictedDocumentIds(userId: string): Promise<string[]>;

  getRoleBoardPermissions(roleId: string): Promise<BoardPermissionSummary[]>;
}
```

`getRoleBoardPermissions`는 AuthModule의 역할 상세 API(`GET /roles/:id`)에서 사용하며, PermissionModule이 BoardModule의 BoardPermission 데이터를 읽기 전용 조회하여 요약을 반환한다.

#### PermissionGuard 사용 예시

PermissionGuard는 컨트롤러/핸들러에 `@Permissions()` 데코레이터로 자원 유형별 권한 검증을 적용한다.

```typescript
// 관리 자원: AdminPermission 검증
@Permissions({ type: 'admin', key: 'manage_boards' })
@Post('/boards')
async createBoard(@Body() dto: CreateBoardDto) { ... }

// 문서 자원: BoardPermission 검증 (boardId는 요청에서 추출)
@Permissions({ type: 'board', action: 'EDIT', boardIdParam: 'boardId' })
@Post('/boards/:boardId/documents')
async createDocument(@Param('boardId') boardId: string) { ... }

// 개인 자원: 소유자 확인
@Permissions({ type: 'owner', ownerIdField: 'userId' })
@Patch('/me/settings')
async updateSettings() { ... }

// 복합 조건: 관리 자원 + AdminPermission (여러 키 중 하나 보유)
@Permissions({ type: 'admin', key: ['manage_boards', 'manage_templates'] })
@Get('/admin/content-stats')
async getContentStats() { ... }
```

### TenantModule — 멀티테넌트

| 영역 | 설명 |
|------|------|
| 테넌트 식별 | TenantMiddleware — 요청 토큰에서 테넌트 ID 추출 |
| DB 커넥션 라우팅 | TenantConnectionResolver — 테넌트별 DataSource 선택 |
| 컨텍스트 전파 | AsyncLocalStorage 기반 — 요청 스코프 내에서 테넌트 정보 전파 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — auth-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **Role** | 역할 마스터. name(VARCHAR(100), UNIQUE), description, `status`(active/inactive/locked), `is_system`(true이면 삭제 불가), `lock_reason`, `version`(OCC), `created_by`. BoardPermission과 AdminPermission이 모두 Role에 부여되는 **단일 권한 경계**. 10~20건 수준 소규모 마스터 |
| **UserRole** | User ↔ Role N:M 매핑. `user_id`(FK 없음 — 외부 서비스 UUID), `role_id`(FK → Role, ON DELETE RESTRICT), `created_by`. `UNIQUE(user_id, role_id)` |
| **AdminPermission** | Role ↔ permission_key 매핑. 관리 자원 접근 권한. 12개 키(`manage_boards`, `manage_roles`, `manage_teams`, `manage_policies`, `manage_templates`, `manage_tags`, `manage_shared_content`, `manage_search`, `manage_prompts`, `manage_system`, `view_audit_logs`, `bypass_approval`). 앱 레벨 키 검증, `UNIQUE(role_id, permission_key)` |
| **Team** | 조직 단위. 재귀 트리(`parent_id`), `status`(active/inactive), `team_source`(manual/org_sync), `expires_at`(임시 그룹 유효기간), `version`(OCC). 상위 팀 역할은 하위에 자동 상속 |
| **TeamMember** | Team ↔ User 매핑. `UNIQUE(team_id, user_id)`. `user_id`는 FK 없음 |
| **TeamRole** | Team ↔ Role 매핑. `UNIQUE(team_id, role_id)`, `role_id`(FK → Role, ON DELETE RESTRICT), `created_by`. 팀 소속 멤버 전원이 지정 Role 상속 |

> **외부 참조**: BoardPermission(BoardModule 소유)은 PermissionModule이 읽기 전용 조회한다. DocumentRestriction(DocumentModule 소유)도 동일.

---

## 의존 관계

```mermaid
graph LR
    Auth["<b>AuthModule</b><br/>인증 + 역할·팀"]
    Perm["<b>PermissionModule</b><br/>인가"]
    Tenant["<b>TenantModule</b><br/>멀티테넌트"]

    Perm -->|"읽기"| Board["BoardModule<br/>(BoardPermission)"]
    Perm -->|"읽기"| Doc["DocumentModule<br/>(Restriction)"]

    AllDomain["모든 도메인 모듈"] -.->|"AuthGuard<br/>PermissionGuard"| Auth
    AllDomain -.->|"권한 평가"| Perm
    AllDomain -.->|"테넌트 컨텍스트"| Tenant

    Auth -->|"OrgProvider"| USC["UserServiceClient<br/>(외부 API)"]
    Auth -->|"읽기"| Perm

    classDef shared fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef consumer fill:#f3f4f6,stroke:#6b7280

    class Auth,Perm,Tenant shared
    class Board,Doc provider
    class AllDomain,USC consumer
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Permission → Board | BoardModule | 읽기 | BoardPermission 기반 권한 평가 (Board Grant 계층) |
| Permission → Document | DocumentModule | 읽기 | DocumentRestriction 기반 권한 평가 |
| Auth → UserServiceClient | 인프라 | 외부 API | OrgProvider(UserServiceOrgProvider) — 외부 조직도 조회 |
| Auth → Permission | PermissionModule | 읽기 | 역할 상세 조회 시 BoardPermission 요약을 PermissionModule 경유로 획득 |
| 모든 도메인 모듈 → Auth | — | Guard | AuthGuard를 통한 인증 |
| 모든 도메인 모듈 → Permission | — | Guard/Service | PermissionGuard 또는 PermissionService 직접 호출을 통한 권한 평가 |
| 모든 도메인 모듈 → Tenant | — | Middleware | TenantMiddleware를 통한 테넌트 식별 및 DB 라우팅 |

> **PermissionModule의 읽기 의존**: PermissionModule은 공통 계층이지만 BoardModule·DocumentModule의 권한 데이터를 읽기 전용 조회한다. 이는 순환 의존이 아닌 단방향 읽기 의존이다 ([모듈 아키텍처 §3.3.1](../../02-architecture/02-module-architecture.md) 참조).
>
> **AuthModule의 의존 원칙**: AuthModule은 BoardModule에 직접 의존하지 않으며, BoardPermission 데이터는 PermissionModule을 경유하여 조회한다.

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | Role, UserRole, AdminPermission, Team, TeamMember, TeamRole |
| Redis / BullMQ | ● | 유효 역할/AdminPermission 캐싱, OrgProvider 응답 캐싱, `acl.events` 큐 (권한 변경 이벤트), `acl.events-dlq` (DLQ) |
| Elasticsearch | — | |
| MinIO | — | |
| EventBus | ● | `board.permissions_updated` 수신 (BoardModule 발행) |
| 외부 서비스 클라이언트 | ● | UserServiceClient (조직도 조회 — UserServiceOrgProvider) |

---

## 배포 및 마이그레이션 가이드

### 초기 배포 순서

1. **DB 마이그레이션**: `role`, `user_role`, `admin_permission`, `team`, `team_member`, `team_role` 테이블 생성 (DDL은 [data.md §3](./data.md#3-ddl-및-인덱스) 참조)
2. **프리셋 Role 시딩**: 앱 부트스트랩 시 upsert로 5개 프리셋 Role 자동 생성 (`일반 사용자`, `콘텐츠 관리자`, `조직 관리자`, `검색 관리자`, `시스템 관리자`)
3. **BullMQ 큐 등록**: `acl.events`, `acl.events-dlq` 큐 자동 생성 (앱 시작 시)
4. **Redis 키 네임스페이스**: 캐시 키 패턴은 [cache.md §3](./cache.md#3-키-패턴-요약) 참조
5. **환경변수 확인**: `DEPLOY_MODE`(saas/onprem), `ORG_SOURCE`(local/user_service)

### 마이그레이션 주의사항

- Role 테이블의 `status`, `lock_reason`, `version`, `created_by` 컬럼은 기존 데이터가 있는 경우 `ALTER TABLE ADD COLUMN ... DEFAULT` 로 무중단 추가 가능
- UserRole, TeamRole의 FK가 `ON DELETE RESTRICT`로 변경되므로, 기존 `ON DELETE CASCADE` 설정이 있다면 FK를 재생성해야 함
- Team 테이블의 `is_active` → `status` 전환 시 `is_active = true → 'active'`, `is_active = false → 'inactive'` 데이터 마이그레이션 필요

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-ACL-권한체계](../../01-requirements/features/FD-ACL-권한체계.md) | 기능정의서 (입력 원본) |
| [auth-module.md](./data.md) | RDB 엔티티/DDL |
| [events.md](./events.md) | 이벤트 및 부수효과 (BullMQ `acl.events` 큐) |
| [cache.md](./cache.md) | 캐시 전략 (유효 역할, AdminPermission, OrgProvider) |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 인증 흐름, 3계층 권한 모델, 검색/RAG 권한 필터 |
| [인가 아키텍처](../../02-architecture/04-permission-architecture.md) | 자원 분류, 역할 계층, AdminPermission 카탈로그 |
| [모듈 아키텍처 §3.2.1](../../02-architecture/02-module-architecture.md) | 공통 모듈 상세, Provider 패턴 |
| [ADR-005](../../adr/005-usergroup-hierarchy-and-org-provider.md) | Team 계층 확장 및 OrgProvider 패턴 도입 |
