# Auth 캐시 전략

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 아키텍처: [03-auth-architecture.md](../../02-architecture/03-auth-architecture.md)

---

## 1. 캐시 개요

| 캐시 대상 | 전략 | 저장소 | 키 패턴 | TTL | 무효화 트리거 |
|-----------|------|--------|---------|-----|-------------|
| 유효 역할 | cache-aside | Redis | `{tenant_id}:cache:auth:effective-roles:{user_id}` | 5m | 역할/팀 변경 시 |
| AdminPermission | cache-aside | Redis | `{tenant_id}:cache:auth:admin-permissions:{user_id}` | 5m | 권한 변경 시 |
| OrgProvider 응답 | cache-aside | Redis | `{tenant_id}:cache:auth:org-ancestors:{user_id}` | 10m | 조직도 변경 시 |
| 세션 | — | Redis | `session:{session_id}` | 설정값 | 로그아웃 / 만료 |

---

## 2. 캐시 상세

### 2.1 유효 역할 캐시 (Effective Roles)

#### 기본 정보

- **전략**: cache-aside
- **키 패턴**: `{tenant_id}:cache:auth:effective-roles:{user_id}`
- **TTL**: 5분
- **직렬화**: JSON (roleId[], roleName[], source 정보)

#### 무효화

**설계 결정**: 무효화 전략은 '핵심 경로 즉시 무효화 + 광범위 변경 TTL 자연 만료'를 채택한다. 역할/팀 변경은 드문 관리 작업(일 1~2회 수준)이며, TTL 5분이면 최대 5분간의 stale 데이터를 수용한다.

| 트리거 | API | 전략 | 무효화 범위 | 근거 |
|--------|-----|------|-----------|------|
| UserRole 변경 | `PUT /users/:userId/roles` | **즉시 DEL** | 해당 userId 키 삭제 | 영향 범위 1명 — 즉시 반영 |
| TeamRole 변경 | `PUT /teams/:id/roles` | **TTL 만료** | 최대 5분 내 자연 갱신 | 하위 팀 순회 비용 회피 |
| TeamMember 변경 | `PUT /teams/:id/members` | **즉시 DEL** | 추가/제거된 userId의 키 삭제 | 영향 범위 소수 — 즉시 반영 |
| Team 활성/비활성 변경 | `PATCH /teams/:id` (status 변경) | **TTL 만료** | 최대 5분 내 자연 갱신 | 하위 팀 순회 비용 회피 |
| Team parentId 변경 | `PATCH /teams/:id` (parentId 변경) | **TTL 만료** | 최대 5분 내 자연 갱신 | 트리 구조 변경은 광범위 |
| Team 삭제 | `DELETE /teams/:id` | **TTL 만료** | 최대 5분 내 자연 갱신 | CASCADE 삭제 후 5분 내 수렴 |
| Role 삭제 | `DELETE /roles/:id` | **TTL 만료** | 최대 5분 내 자연 갱신 | is_system 역할 삭제 불가 + 드문 관리 작업, SCAN 부하 회피 |

#### Warm-up / Fallback

- **Warm-up**: 서비스 시작 시 preload 없음 (lazy-load). 캐시 miss 시 DB + OrgProvider 조합 조회
- **Fallback**: Redis 장애 시 매 요청 DB 조회 (성능 저하 감수, 보안 우선)

---

### 2.2 AdminPermission 캐시

#### 기본 정보

- **설계 결정**: 유효 역할 캐시와 동일 생명주기로 관리 (별도 캐시 분리 불필요 — 유효 역할 산출 시 AdminPermission도 함께 조회)
- **전략**: cache-aside
- **키 패턴**: `{tenant_id}:cache:auth:admin-permissions:{user_id}`
- **TTL**: 5분
- **직렬화**: JSON (permissionKey[])

#### 무효화

| 트리거 | API | 무효화 범위 | 근거 |
|--------|-----|-----------|------|
| 유효 역할 캐시와 동일 트리거 | — | §2.1 무효화 표 참조 | AdminPermission은 Role 기반이므로 역할 변경 시 함께 무효화 |
| AdminPermission CRUD | `PUT /roles/:id/admin-permissions` | **즉시 DEL** — 해당 Role을 보유한 모든 사용자의 키 삭제 | 영향 범위가 해당 Role 보유 사용자로 한정 |

#### Warm-up / Fallback

- **Warm-up**: 유효 역할 캐시와 동일 — 서비스 시작 시 preload 없음 (lazy-load)
- **Fallback**: 유효 역할 캐시와 동일 — Redis 장애 시 매 요청 DB 조회

---

### 2.3 OrgProvider 응답 캐시

#### 기본 정보

- **전략**: cache-aside (외부 API 호출 빈도 절감)
- **키 패턴**: `{tenant_id}:cache:auth:org-ancestors:{user_id}`
- **TTL**: 10분 ([03-auth-architecture.md §5.7](../../02-architecture/03-auth-architecture.md) "5~15분" 범위 내)
- **직렬화**: JSON (ancestorTeamIds: string[])

**설계 결정**: 조직도 변경의 최대 10분 지연은 수용 가능하다. 팀 멤버십 변경은 드문 관리 작업이며, 보안 임계 시나리오(퇴직자 접근 차단 등)는 UserRole 즉시 회수 또는 계정 비활성화로 대응한다. 즉시성이 필요하면 향후 push 기반 무효화를 도입한다.

#### 무효화

- TTL 기반 자동 만료가 주 메커니즘
- 향후 조직도 변경 이벤트가 정의되면 수신 시 전체 flush 추가 가능 (현재는 TTL만으로 운영)

#### Warm-up / Fallback

- **Warm-up**: preload 없음 (lazy-load)
- **Fallback**: Redis 장애 시 외부 API 직접 호출. stale 캐시 사용 불가 (보안상 최신 데이터 필요)
- **참고**: LocalOrgProvider 경로(`ORG_SOURCE = local`)에서는 AICM DB 직접 조회이므로 캐시 불필요

#### 서킷 브레이커

UserServiceOrgProvider 경로에서 외부 API 장애 시 cascading failure를 방지하기 위해 서킷 브레이커를 적용한다.

| 항목 | 값 |
|------|---|
| **열림 조건** | 최근 10회 요청 중 5회 이상 실패 (50% 실패율) 또는 연속 3회 타임아웃(500ms 초과) |
| **열림 상태 동작** | 외부 API 호출 없이 즉시 fallback 반환 (DB 직접 조회 — LocalOrgProvider 로직 사용) |
| **반열림 주기** | 30초 — 열림 상태에서 30초 후 단일 프로브 요청을 보내 API 복구 여부 확인 |
| **반열림 → 닫힘** | 프로브 요청 성공 시 닫힘 전환, 정상 호출 재개 |
| **반열림 → 열림** | 프로브 요청 실패 시 열림 유지, 30초 후 재시도 |
| **폴백 전략** | `LocalOrgProvider` 로직으로 AICM DB의 Team 계층에서 직접 조회. 외부 API보다 정확도가 낮을 수 있으나 서비스 가용성 우선 |
| **메트릭** | `auth.cache.org_provider.circuit_state` (closed/open/half-open), `auth.cache.org_provider.fallback_count` |

---

### 2.4 세션 관리

#### 기본 정보

- **전략**: 세션 저장소 (캐시와 별도 관심사)
- **키 패턴**: `session:{session_id}`
- **TTL**: SystemConfig 설정값
- **직렬화**: JSON (userId, tenantId, userServiceRole, loginAt 등)

#### 무효화

| 시나리오 | 동작 |
|---------|------|
| 로그아웃 | DEL |
| 세션 만료 | TTL 자동 만료 |
| 관리자 강제 로그아웃 | DEL |

#### Warm-up / Fallback

- **Fallback**: 세션 미존재 시 401 Unauthorized 반환

---

## 3. 키 패턴 요약

> `redis.md`와 일치를 보장한다.

| 키 패턴 | 타입 | TTL | 용도 |
|---------|------|-----|------|
| `{tenant_id}:cache:auth:effective-roles:{user_id}` | String | 5m | 유효 역할 캐시 |
| `{tenant_id}:cache:auth:admin-permissions:{user_id}` | String | 5m | AdminPermission 캐시 |
| `{tenant_id}:cache:auth:org-ancestors:{user_id}` | String | 10m | OrgProvider 응답 캐시 |
| `session:{session_id}` | String | 설정값 | 사용자 세션 |

---

## 4. AdminPermission 즉시 무효화 — Redis Pipeline 전략

AdminPermission CRUD 시(`PUT /roles/:id/admin-permissions`), 해당 Role을 보유한 모든 사용자의 캐시를 즉시 삭제해야 한다. 영향 사용자 수가 많을 경우 개별 DEL 명령의 RTT 누적이 문제가 되므로, Redis pipeline을 사용한다.

| 항목 | 값 |
|------|---|
| **트리거** | `PUT /roles/:id/admin-permissions`, `PATCH /roles/:id/status` |
| **절차** | 1. 해당 Role을 보유한 userId 목록 조회 (UserRole + TeamRole → TeamMember 조인) |
|  | 2. `{tenant_id}:cache:auth:admin-permissions:{userId}` + `{tenant_id}:cache:auth:effective-roles:{userId}` 키 목록 생성 |
|  | 3. Redis `pipeline().del(key1).del(key2)...exec()` 단일 라운드트립으로 일괄 삭제 |
| **배치 크기** | 파이프라인 당 최대 500개 DEL 명령. 초과 시 분할 실행 |
| **타임아웃** | 파이프라인 실행 50ms 이내 목표. 초과 시 warn 로그 기록 |
| **실패 처리** | 파이프라인 부분 실패 시 남은 키는 TTL(5분)에 의해 자연 만료. 전체 Redis 장애 시에도 API 응답은 정상 반환 (캐시 무효화 실패 → stale 5분 허용) |

---

## 5. 캐시 스탬피드 방어

대규모 TeamRole 변경(팀에 새 Role 부여/해제) 시, 해당 팀 소속 다수 사용자의 캐시가 TTL 만료로 동시에 갱신되면 DB에 순간 부하가 집중된다(cache stampede). 이를 방어하기 위해 두 가지 패턴을 적용한다.

### 5.1 Staggered TTL (±10% 랜덤화)

캐시 저장 시 기본 TTL에 ±10% 랜덤 편차를 추가하여 동시 만료를 분산시킨다.

| 항목 | 값 |
|------|---|
| **기본 TTL** | 5분 (300초) |
| **랜덤화 범위** | 270초 ~ 330초 (±10%) |
| **적용 대상** | `effective-roles`, `admin-permissions` 캐시 키 |
| **구현** | `ttl = BASE_TTL + random(-0.1, 0.1) * BASE_TTL` — Redis SET 시 계산된 TTL 적용 |

### 5.2 Singleflight 패턴

동일 키에 대한 동시 캐시 miss가 발생하면, 첫 번째 요청만 DB 조회를 수행하고 나머지는 그 결과를 대기하여 공유한다.

| 항목 | 값 |
|------|---|
| **목적** | 동일 userId의 유효 역할 캐시 miss 시 DB 조회 1회로 합침 |
| **구현** | 인프로세스 Promise 기반 singleflight — 키(`{tenantId}:{userId}`)별 진행 중인 Promise를 Map에 보관하고, 동일 키 요청은 기존 Promise를 `await` |
| **타임아웃** | singleflight 대기 최대 500ms. 초과 시 독립 DB 조회로 폴백 |
| **멀티 인스턴스** | 인프로세스 singleflight는 인스턴스별 독립 동작. Redis 분산 락까지는 불필요 — staggered TTL과 조합으로 충분한 부하 분산 달성 |

### 5.3 적용 시나리오

```
대규모 TeamRole 변경 발생
  → 영향 사용자 캐시: TTL 자연 만료 대기 (staggered 270~330초)
  → 만료 시점이 분산되어 DB 조회가 시간축으로 분산
  → 동일 시점 만료된 키에 대해서는 singleflight가 중복 조회 방지
```

---

## 6. 모니터링 메트릭

| 메트릭 | 설명 | 경고 임계값 |
|--------|------|-----------|
| `auth.cache.effective_roles.hit_rate` | 유효 역할 캐시 히트율 | < 80% — 무효화 빈도 또는 TTL 재검토 |
| `auth.cache.effective_roles.miss_latency_p99` | 캐시 miss 시 DB+OrgProvider 조합 조회 P99 | > 200ms — 쿼리 최적화 필요 |
| `auth.cache.org_provider.hit_rate` | OrgProvider 응답 캐시 히트율 | < 70% — TTL 상향 검토 |
| `auth.cache.org_provider.api_latency_p99` | 외부 API 호출 P99 (UserServiceOrgProvider) | > 500ms — 서킷 브레이커 검토 |
| `auth.cache.org_provider.circuit_state` | 서킷 브레이커 상태 | open — 외부 API 장애 확인 |
| `auth.cache.org_provider.fallback_count` | 폴백(DB 직접 조회) 횟수 | > 0 — 외부 API 복구 모니터링 |
| `auth.cache.invalidation.duration_p99` | 즉시 무효화 소요 시간 P99 | > 50ms — 파이프라인 배치 크기 조정 |
| `auth.cache.invalidation.pipeline_size` | 파이프라인 DEL 명령 수 평균 | > 500 — 분할 실행 빈도 확인 |
| `auth.cache.singleflight.coalesced_count` | singleflight로 합쳐진 DB 조회 수 | — (대규모 변경 시 증가 예상) |
| `auth.cache.singleflight.timeout_count` | singleflight 대기 타임아웃 횟수 | > 0 — DB 조회 지연 확인 |
