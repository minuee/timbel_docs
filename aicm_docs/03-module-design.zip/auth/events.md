# Auth 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 모듈 아키텍처: [02-module-architecture.md §3.3](../../02-architecture/02-module-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 발행 이벤트

AuthModule이 발행하는 이벤트를 신뢰성 티어별로 정리한다. 권한 변경은 캐시 무효화·검색 가시성 재평가·사용자 알림 등 다수 소비자에게 영향을 미치므로 **Important 티어(BullMQ)**로 분류한다.

### 1.1 Important 티어 — BullMQ

모든 이벤트는 단일 큐 `acl.events`에 발행한다. 소비자는 이벤트명(`eventName` 필드)으로 분기 처리한다.

| 항목 | 값 |
|------|---|
| 큐 이름 | `acl.events` |
| 재시도 정책 | 지수 백오프 최대 3회 (5s → 10s → 20s), 최종 실패 시 DLQ 이동 |
| DLQ | `acl.events-dlq` — 최종 실패 이벤트 적재, 관리자 모니터링 대시보드에서 재처리/폐기 |
| 멱등 키 | `{eventName}:{entityId}` — 소비자가 동일 이벤트 중복 수신 시 멱등 처리에 사용 |
| 트레이싱 | 모든 페이로드에 `traceId`(OpenTelemetry) 포함 — end-to-end 추적 |
| 스키마 호환성 | 필드 추가는 자유, 필드 제거·타입 변경 시 새 이벤트명 도입 |

---

#### 발행 시나리오 구분: `acl.role.permissions_updated` vs `acl.board_permission.updated`

두 이벤트는 **관점**이 다르다. `acl.role.permissions_updated`는 **Role 중심** 이벤트로, 해당 Role에 할당된 모든 사용자에게 미치는 권한 변경을 통합 알린다(AdminPermission + BoardPermission 모두 포함, `affectedUserCount` 제공). `acl.board_permission.updated`는 **Board 중심** 이벤트로, 특정 게시판의 가시성 변경에 관심 있는 소비자(SearchModule 등)가 구독한다. BoardModule 경유 변경 시에는 **두 이벤트가 모두 발행**된다 — Role 관점과 Board 관점의 소비자가 각각 자신에게 필요한 이벤트를 구독하여 처리한다.

#### `acl.role.permissions_updated`

- **티어**: Important
- **채널**: BullMQ `acl.events`
- **트리거**: Role의 BoardPermission 또는 AdminPermission 변경 — `PUT /roles/:id/admin-permissions`, BoardModule의 BoardPermission 변경 시
- **페이로드**:

```typescript
interface AclRolePermissionsUpdatedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.role.permissions_updated';
  roleId: string;
  changedPermissions: {
    type: 'board' | 'admin';
    action: 'added' | 'removed';
    key: string;
    boardId?: string;
  }[];
  affectedUserCount: number;
  timestamp: string;
}
```

- **소비자**:
  - PermissionModule — 유효 역할/AdminPermission 캐시 무효화
  - SearchModule — 검색 가시성 재평가 (BoardPermission 변경 시)
  - NotificationModule — 영향 사용자 알림
- **멱등 키**: `acl.role.permissions_updated:{roleId}`

---

#### `acl.role.status_changed`

- **티어**: Important
- **채널**: BullMQ `acl.events`
- **트리거**: Role 비활성화/잠금/활성화 — `PATCH /roles/:id/status` [BR-ACL-022, BR-ACL-023]
- **페이로드**:

```typescript
interface AclRoleStatusChangedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.role.status_changed';
  roleId: string;
  previousStatus: 'active' | 'inactive' | 'locked';
  newStatus: 'active' | 'inactive' | 'locked';
  reason?: string;
  changedBy: string;
  timestamp: string;
}
```

- **소비자**:
  - PermissionModule — 유효 역할 캐시 무효화 (비활성/잠금 Role 제외)
  - NotificationModule — 영향 사용자 알림 (잠금 시 긴급 알림)
- **멱등 키**: `acl.role.status_changed:{roleId}`

---

#### `acl.team.members_updated`

- **티어**: Important
- **채널**: BullMQ `acl.events`
- **트리거**: Group 멤버 추가/제거/일괄 변경 — `PUT /teams/:id/members`
- **페이로드**:

```typescript
interface AclTeamMembersUpdatedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.team.members_updated';
  teamId: string;
  addedUserIds: string[];
  removedUserIds: string[];
  changedBy: string;
  timestamp: string;
}
```

- **소비자**:
  - PermissionModule — 유효 역할 재계산, 캐시 무효화
  - NotificationModule — 추가/제거된 사용자 알림
- **멱등 키**: `acl.team.members_updated:{teamId}`

---

#### `acl.team.status_changed`

- **티어**: Important
- **채널**: BullMQ `acl.events`
- **트리거**: Group 비활성화/활성화 — `PATCH /teams/:id` (`status` 변경), 유효기간 만료 자동 비활성화 [BR-ACL-013, BR-ACL-027]
- **페이로드**:

```typescript
interface AclTeamStatusChangedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.team.status_changed';
  teamId: string;
  previousStatus: 'active' | 'inactive';
  newStatus: 'active' | 'inactive';
  reason?: string;
  changedBy: string;
  timestamp: string;
}
```

- **소비자**:
  - PermissionModule — 유효 역할 재계산, 캐시 무효화
  - NotificationModule — 팀 멤버 알림
- **멱등 키**: `acl.team.status_changed:{teamId}`

---

#### `acl.user_role.updated`

- **티어**: Important
- **채널**: BullMQ `acl.events`
- **트리거**: 사용자에게 직접 Role 할당/해제 — `PUT /users/:userId/roles`
- **전체 교체 시 이벤트 발행 패턴**: `PUT /users/:userId/roles`는 전체 교체(PUT 시맨틱)이다. 기존 roleIds와 요청 roleIds를 비교하여 diff를 산출한 뒤, 단일 `acl.user_role.updated` 이벤트로 발행한다. 페이로드에 `addedRoleIds`/`removedRoleIds` 목록을 포함하여 소비자가 변경 내역을 일괄 처리할 수 있도록 한다.
- **FD-ACL §11 대비 페이로드 확장**: FD-ACL §11에서는 `{ roleId, action: 'assigned' | 'revoked' }` 단건 이벤트 모델을 기술하고 있으나, 모듈 스펙에서는 PUT 전체 교체 시맨틱에 맞게 diff 모델(`addedRoleIds[]`/`removedRoleIds[]`)로 확장했다. 소비자는 단건 반복 대신 한 번의 이벤트에서 전체 변경 내역을 파악할 수 있어 캐시 무효화와 알림 발송의 원자적 처리가 가능하다. **이벤트 페이로드의 SSoT는 본 문서(events.md)이며, FD §11은 개략 수준의 참조로 취급한다.**
- **페이로드**:

```typescript
interface AclUserRoleUpdatedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.user_role.updated';
  userId: string;
  addedRoleIds: string[];
  removedRoleIds: string[];
  changedBy: string;
  timestamp: string;
}
```

- **소비자**:
  - PermissionModule — 캐시 무효화
  - NotificationModule — 대상 사용자 알림
- **멱등 키**: `acl.user_role.updated:{userId}`

---

#### `acl.board_permission.updated`

- **티어**: Important
- **채널**: BullMQ `acl.events`
- **트리거**: 게시판별 권한 변경 (BoardPermission CRUD) — BoardModule에서 `board.permissions_updated` 이벤트 수신 후 AuthModule이 발행. 또는 `PUT /roles/:id/admin-permissions`에서 AdminPermission 변경 시 함께 발행. Admin API를 통해 Role의 BoardPermission이 직접 변경될 때에도 발행한다
- **페이로드**:

```typescript
interface AclBoardPermissionUpdatedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.board_permission.updated';
  roleId: string;
  boardId: string;
  changes: {
    action: 'VIEW' | 'EDIT' | 'APPROVE';
    type: 'added' | 'removed';
  }[];
  changedBy: string;
  timestamp: string;
}
```

- **소비자**:
  - SearchModule — 검색 가시성 재평가
  - PermissionModule — 캐시 무효화
- **멱등 키**: `acl.board_permission.updated:{roleId}:{boardId}`

---

## 2. 소비 이벤트

AuthModule(PermissionModule)이 외부 모듈로부터 수신하는 이벤트.

| 이벤트/콜백 | 발행자 | 채널 | 처리 내용 |
|------------|--------|------|----------|
| `board.permissions_updated` | BoardModule | EventBus (Best-effort) | BoardPermission 변경 시 `acl.board_permission.updated` 이벤트 발행 트리거. BullMQ 큐 기반이 아닌 인프로세스 EventBus이므로 유실 가능성이 있다. 유실 시 auth 캐시 TTL(5분) 자연 만료로 보정되며, 보안 리스크는 최대 5분 이내로 한정된다 |
| `acl.restriction.updated` | DocumentModule | BullMQ `document.events` | 문서 접근 제한(Restriction) 설정·해제·화이트리스트 변경 시 발행. AuthModule(PermissionModule)은 **소비자**로서 캐시 무효화를 수행. DocumentRestriction은 문서 도메인 엔티티이므로 발행 주체는 DocumentModule이다 |

### `acl.restriction.updated` 소비 상세

> **발행 주체**: DocumentModule. DocumentRestriction은 문서 도메인 소유 엔티티이므로, 해당 엔티티의 변경 이벤트는 DocumentModule이 발행한다. AuthModule(PermissionModule)은 이 이벤트의 **소비자**로서 캐시 무효화와 검색 가시성 재평가를 위해 수신한다.

- **페이로드** (DocumentModule이 정의):

```typescript
interface AclRestrictionUpdatedPayload {
  schemaVersion: 1;
  traceId: string;
  eventName: 'acl.restriction.updated';
  resourceType: 'document';
  resourceId: string;
  restricted: boolean;
  changes: {
    subjectType: 'USER' | 'TEAM';
    subjectId: string;
    action: 'VIEW' | 'EDIT' | 'APPROVE';
    type: 'added' | 'removed';
  }[];
  changedBy: string;
  timestamp: string;
}
```

- **AuthModule(PermissionModule) 소비 처리**:
  - 해당 리소스에 대한 권한 캐시 무효화
  - SearchModule에 검색 가시성 재평가 위임
  - RetrievalServiceClient에 임베딩 필터 갱신 위임
- **멱등 키**: `acl.restriction.updated:{resourceId}`

---

## 3. BullMQ 큐 요약

| 큐 이름 | 이벤트 수 | 재시도 | DLQ | 용도 |
|---------|----------|--------|-----|------|
| `acl.events` | 6개 발행 이벤트 | 3회 (지수 백오프 5s→10s→20s) | `acl.events-dlq` | 권한 변경 이벤트 통합 큐 |

> **의도적 미발행**: 팀 역할 변경(`PUT /teams/:id/roles`)에 대한 별도 BullMQ 이벤트는 발행하지 않는다. TeamRole 변경 시 영향 받는 사용자의 유효 역할 캐시는 TTL(5분) 자연 만료로 수렴하며, 관리자 전용 저빈도 작업 특성상 즉시 무효화의 실익이 이벤트 구현 복잡도 대비 낮다 ([cache.md §2.1](cache.md) 참조).

---

## 4. 감사 로그 액션

AuthModule이 기록하는 감사 로그 액션 목록.

| 액션 | 트리거 | 규칙 |
|------|--------|------|
| `role.created` | 역할 생성 | BR-ACL-001 |
| `role.updated` | 역할 수정 | — |
| `role.deleted` | 역할 삭제 | BR-ACL-004 |
| `role.status_changed` | 역할 상태 변경 (비활성화/잠금/활성화) | BR-ACL-022, BR-ACL-023 |
| `role.admin_permissions_updated` | AdminPermission 변경 | BR-ACL-008 |
| `team.created` | 팀 생성 | BR-ACL-009 |
| `team.updated` | 팀 수정 | — |
| `team.deleted` | 팀 삭제 | BR-ACL-014 |
| `team.status_changed` | 팀 상태 변경 | BR-ACL-013 |
| `team.members_updated` | 팀 멤버 변경 | — |
| `team.roles_updated` | 팀 역할 변경 | — |
| `user_role.updated` | 사용자 역할 할당/해제 | — |
| `user_role.auto_assigned` | 신규 사용자 온보딩 시 기본 역할 자동 할당 | BR-ACL-028 |
