# Auth API 스펙

> 기능정의서: [FD-ACL-권한체계](../../01-requirements/features/FD-ACL-권한체계.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [auth-module.md](./data.md)
> 아키텍처: [03-auth-architecture.md](../../02-architecture/03-auth-architecture.md), [04-permission-architecture.md](../../02-architecture/04-permission-architecture.md)

> 에러 응답은 [횡단 관심사 §8.2.1](../../02-architecture/07-cross-cutting-concerns.md)의 공통 에러 응답 포맷(`{ error, message, details? }`)을 따른다. 도메인 에러 코드(`ACL_*`)는 `error` 필드에 포함되며, HTTP 403은 전역 FORBIDDEN(권한 부족)과 도메인 에러 코드를 구분한다 — 클라이언트는 응답 body의 `error` 필드로 판별한다.

> **응답 형식**: 모든 응답은 [횡단 관심사 §8.4](../../02-architecture/07-cross-cutting-concerns.md)의 공통 래퍼 `{ data, meta, pagination }` 형식을 따른다. 본 문서의 DTO 인터페이스(`PaginatedResponse` 등)는 래퍼의 `data` 필드 내부 구조만 기술한다 — 래퍼 자체는 전역 ResponseInterceptor가 자동 적용하므로 모듈 스펙에서는 비즈니스 데이터 구조에 집중한다.

---

## 엔드포인트 요약

### 역할 관리

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| POST | /roles | 역할 생성 | ADMIN (`manage_roles`) |
| GET | /roles | 역할 목록 조회 | ADMIN (`manage_roles`) |
| GET | /roles/:id | 역할 상세 조회 | ADMIN (`manage_roles`) |
| PATCH | /roles/:id | 역할 수정 | ADMIN (`manage_roles`) |
| DELETE | /roles/:id | 역할 삭제 | ADMIN (`manage_roles`) |
| PATCH | /roles/:id/status | 역할 상태 변경 (비활성화/잠금/활성화) | ADMIN (`manage_roles`) |
| PUT | /roles/:id/admin-permissions | AdminPermission 설정 (전체 교체) | ADMIN (`manage_roles`) |
| GET | /roles/:id/users | 역할에 할당된 사용자 목록 | ADMIN (`manage_roles`) |

### 사용자 역할 관리

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /users/:userId/roles | 사용자의 역할 목록 | ADMIN (`manage_roles`) |
| PUT | /users/:userId/roles | 사용자 역할 할당 (전체 교체) | ADMIN (`manage_roles`) |
| GET | /users/:userId/effective-roles | 유효 역할 산출 | ADMIN (`manage_roles`) |

### 팀 관리

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| POST | /teams | 팀 생성 | ADMIN (`manage_teams`) |
| GET | /teams | 팀 목록/트리 조회 | ADMIN (`manage_teams`) |
| GET | /teams/:id | 팀 상세 조회 | ADMIN (`manage_teams`) |
| PATCH | /teams/:id | 팀 수정 | ADMIN (`manage_teams`) |
| DELETE | /teams/:id | 팀 삭제 (물리 삭제 — [BR-ACL-014](rules.md#br-acl-014-팀-삭제-정책)) | ADMIN (`manage_teams`) |
| GET | /teams/:id/members | 팀 멤버 목록 | ADMIN (`manage_teams`) |
| PUT | /teams/:id/members | 팀 멤버 설정 (전체 교체) | ADMIN (`manage_teams`) |
| GET | /teams/:id/roles | 팀 역할 목록 | ADMIN (`manage_teams`) |
| PUT | /teams/:id/roles | 팀 역할 설정 (전체 교체) | ADMIN (`manage_teams`) |

### 권한 확인

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /me/permissions | 현재 사용자의 유효 권한 요약 | 인증 필요 |

---

## 상세 API

### `POST` /roles

**설명**: 새 역할을 생성한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Body:

```typescript
interface CreateRoleDto {
  name: string;                      // 필수 — 역할명 (max 100자, UNIQUE)
  description?: string;              // 선택 — 역할 설명
}
```

**Response** (`201`):

```typescript
interface RoleResponse {
  id: string;
  name: string;
  description: string | null;
  status: 'active' | 'inactive' | 'locked';
  isSystem: boolean;
  lockReason: string | null;
  version: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
```

**비즈니스 규칙 참조**: [BR-ACL-001](rules.md#br-acl-001-역할-생성-필수-조건), [BR-ACL-002](rules.md#br-acl-002-역할명-중복-방지)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-ACL-001](rules.md#br-acl-001-역할-생성-필수-조건) |
| ACL_ROLE_NAME_DUPLICATE | 409 | [BR-ACL-002](rules.md#br-acl-002-역할명-중복-방지) |

---

### `GET` /roles

**설명**: 역할 목록을 조회한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Query params:

```typescript
interface ListRolesQuery {
  search?: string;                   // 역할명 LIKE 검색
  isSystem?: boolean;                // 시스템 역할 필터
  status?: 'active' | 'inactive' | 'locked';  // 상태 필터
  sort?: 'name' | 'createdAt';
  order?: 'ASC' | 'DESC';
  page?: number;                     // 기본 1
  limit?: number;                    // 기본 20, 최대 100
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface RoleListItem {
  id: string;
  name: string;
  description: string | null;
  status: 'active' | 'inactive' | 'locked';
  isSystem: boolean;
  userCount: number;
  teamCount: number;
  adminPermissionCount: number;
  version: number;
  createdAt: string;
  updatedAt: string;
}
```

---

### `GET` /roles/:id

**설명**: 역할 상세 정보를 조회한다. BoardPermission, AdminPermission 목록을 포함한다. BoardPermission 요약은 PermissionModule(`getRoleBoardPermissions`)을 경유하여 조회한다. AuthModule은 BoardModule에 직접 의존하지 않는다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Path params: `id` — 역할 UUID

**Response** (`200`):

```typescript
interface RoleDetailResponse {
  id: string;
  name: string;
  description: string | null;
  status: 'active' | 'inactive' | 'locked';
  isSystem: boolean;
  lockReason: string | null;
  adminPermissions: AdminPermissionResponse[];
  boardPermissions: BoardPermissionSummary[];
  userCount: number;
  teamCount: number;
  version: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface AdminPermissionResponse {
  id: string;
  permissionKey: string;
  createdAt: string;
}

interface BoardPermissionSummary {
  boardId: string;
  boardName: string;
  actions: ('VIEW' | 'EDIT' | 'APPROVE')[];
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| ACL_ROLE_NOT_FOUND | 404 | — |

---

### `PATCH` /roles/:id

**설명**: 역할 정보를 수정한다. `is_system` 역할도 이름 변경과 설명 수정은 허용한다. OCC 검증을 위해 `version` 필드가 필수이다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Body:

```typescript
interface UpdateRoleDto {
  name?: string;                     // max 100자, UNIQUE
  description?: string | null;
  version: number;                   // 필수 — OCC 버전 [BR-ACL-024]
}
```

**Response** (`200`): `RoleResponse`

**비즈니스 규칙 참조**: [BR-ACL-024](rules.md#br-acl-024-occ-버전-검증)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_ROLE_NOT_FOUND | 404 | — |
| ACL_ROLE_NAME_DUPLICATE | 409 | [BR-ACL-002](rules.md#br-acl-002-역할명-중복-방지) |
| ACL_CONCURRENT_MODIFICATION | 409 | [BR-ACL-024](rules.md#br-acl-024-occ-버전-검증) |

---

### `DELETE` /roles/:id

**설명**: 역할을 삭제한다. `is_system = true`인 역할은 삭제할 수 없다. UserRole 또는 TeamRole에 할당된 상태이면 삭제를 차단한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Path params: `id` — 역할 UUID

**Response** (`200`):

```typescript
interface DeleteRoleResponse {
  id: string;
  deleted: true;
}
```

**비즈니스 규칙 참조**: [BR-ACL-003](rules.md#br-acl-003-is_system-역할-삭제-차단), [BR-ACL-004](rules.md#br-acl-004-역할-삭제-시-할당-존재-확인-restrict)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_ROLE_NOT_FOUND | 404 | — |
| ACL_SYSTEM_ROLE_DELETE | 403 | [BR-ACL-003](rules.md#br-acl-003-is_system-역할-삭제-차단) |
| ACL_ROLE_IN_USE | 409 | [BR-ACL-004](rules.md#br-acl-004-역할-삭제-시-할당-존재-확인-restrict) |

---

### `PATCH` /roles/:id/status

**설명**: 역할 상태를 변경한다. 비활성화(inactive), 긴급 잠금(locked), 재활성화(active) 전이를 수행한다. 잠금 시 `lockReason`이 필수이다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Body:

```typescript
interface UpdateRoleStatusDto {
  status: 'active' | 'inactive' | 'locked';
  lockReason?: string;               // status='locked'일 때 필수 (max 500자)
}
```

**Response** (`200`): `RoleResponse`

**비즈니스 규칙 참조**: [BR-ACL-022](rules.md#br-acl-022-role-비활성화재활성화), [BR-ACL-023](rules.md#br-acl-023-role-긴급-잠금해제), [BR-ACL-025](rules.md#br-acl-025-마지막-관리자-보호)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_ROLE_NOT_FOUND | 404 | — |
| ACL_INVALID_STATUS_TRANSITION | 409 | [BR-ACL-022](rules.md#br-acl-022-role-비활성화재활성화), [BR-ACL-023](rules.md#br-acl-023-role-긴급-잠금해제) |
| ACL_LOCK_REASON_REQUIRED | 400 | [BR-ACL-023](rules.md#br-acl-023-role-긴급-잠금해제) |
| ACL_LAST_ADMIN_PROTECTION | 409 | [BR-ACL-025](rules.md#br-acl-025-마지막-관리자-보호) |

---

### `PUT` /roles/:id/admin-permissions

**설명**: 역할의 AdminPermission을 설정한다 (전체 교체). 기존 매핑을 삭제하고 새 매핑으로 대체.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Body:

```typescript
interface SetAdminPermissionsDto {
  permissionKeys: AdminPermissionKey[];  // 관리 권한 키 배열 (빈 배열이면 전부 해제)
}
```

**Response** (`200`):

```typescript
interface AdminPermissionResponse {
  id: string;
  permissionKey: string;
  createdAt: string;
}
```

**비즈니스 규칙 참조**: [BR-ACL-007](rules.md#br-acl-007-permission_key-앱-레벨-검증), [BR-ACL-008](rules.md#br-acl-008-adminpermission-전체-교체)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_ROLE_NOT_FOUND | 404 | — |
| ACL_INVALID_PERMISSION_KEY | 422 | [BR-ACL-007](rules.md#br-acl-007-permission_key-앱-레벨-검증) |

---

### `GET` /roles/:id/users

**설명**: 특정 역할에 직접 할당된(UserRole) 사용자 목록을 조회한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Path params: `id` — 역할 UUID
- Query params:

```typescript
interface RoleUsersQuery {
  page?: number;                     // 기본 1
  limit?: number;                    // 기본 20, 최대 100
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<RoleUserItem> { /* 공통 페이지네이션 */ }

interface RoleUserItem {
  userId: string;
  userName: string;
  userServiceRole: string;           // user_service 역할 (SYSTEM/ADMIN/NORMAL 등)
  assignedAt: string;                // UserRole.created_at
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| ACL_ROLE_NOT_FOUND | 404 | — |

---

### `GET` /users/:userId/roles

**설명**: 특정 사용자에게 직접 할당된(UserRole) 역할 목록을 조회한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Path params: `userId` — 외부 사용자 UUID

**Response** (`200`):

```typescript
interface UserRoleItem {
  roleId: string;
  roleName: string;
  status: 'active' | 'inactive' | 'locked';
  isSystem: boolean;
  hasAdminPermissions: boolean;
  assignedAt: string;
}
```

---

### `PUT` /users/:userId/roles

**설명**: 사용자의 직접 할당 역할을 설정한다 (전체 교체). AdminPermission이 포함된 Role을 NORMAL 이하 사용자에게 할당하면 거부한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Body:

```typescript
interface SetUserRolesDto {
  roleIds: string[];                 // 역할 UUID 배열 (빈 배열이면 전부 해제)
}
```

**Response** (`200`): `UserRoleItem[]`

**비즈니스 규칙 참조**: [BR-ACL-005](rules.md#br-acl-005-adminpermission-포함-역할의-normal-이하-사용자-할당-차단), [BR-ACL-025](rules.md#br-acl-025-마지막-관리자-보호)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_ROLE_NOT_FOUND | 404 | — |
| ACL_ADMIN_ROLE_TO_NORMAL | 400 | [BR-ACL-005](rules.md#br-acl-005-adminpermission-포함-역할의-normal-이하-사용자-할당-차단) |
| ACL_LAST_ADMIN_PROTECTION | 409 | [BR-ACL-025](rules.md#br-acl-025-마지막-관리자-보호) |

---

### `GET` /users/:userId/effective-roles

**설명**: 사용자의 유효 역할을 산출한다. UserRole(직접 할당) ∪ TeamRole(소속 팀 + 상위 팀 순회)의 합집합. 비활성/잠금 상태의 Role과 비활성 Team은 제외한다.

**권한**: ADMIN (`manage_roles`)

**Request**:

- Path params: `userId` — 외부 사용자 UUID

**Response** (`200`):

```typescript
interface EffectiveRolesResponse {
  userId: string;
  directRoles: EffectiveRoleItem[];
  inheritedRoles: EffectiveRoleItem[];
  mergedRoles: EffectiveRoleItem[];
}

interface EffectiveRoleItem {
  roleId: string;
  roleName: string;
  status: 'active' | 'inactive' | 'locked';
  sources: ('direct' | 'team')[];
  sourceTeamIds?: string[];
  sourceTeamNames?: string[];
  adminPermissions: string[];
}
```

**비즈니스 규칙 참조**: [BR-ACL-015](rules.md#br-acl-015-유효-역할-산출)

---

### `POST` /teams

**설명**: 새 팀을 생성한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Body:

```typescript
interface CreateTeamDto {
  name: string;                      // 필수 — 팀명 (max 100자, UNIQUE)
  description?: string;              // 선택 — 팀 설명
  parentId?: string;                 // 선택 — 상위 팀 UUID (null이면 최상위)
  expiresAt?: string;                // 선택 — 유효기간 (ISO 8601)
  forceCreate?: boolean;             // 선택 — 그룹 계층 깊이 상한 초과 시 강제 생성 허용 [BR-ACL-026]
}
```

**Response** (`201`):

```typescript
interface TeamResponse {
  id: string;
  name: string;
  description: string | null;
  parentId: string | null;
  status: 'active' | 'inactive';
  teamSource: 'manual' | 'org_sync';
  expiresAt: string | null;
  isExternal: boolean;
  version: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
```

**비즈니스 규칙 참조**: [BR-ACL-009](rules.md#br-acl-009-팀-생성-필수-조건), [BR-ACL-010](rules.md#br-acl-010-팀명-중복-방지), [BR-ACL-011](rules.md#br-acl-011-팀-순환-참조-방지), [BR-ACL-026](rules.md#br-acl-026-그룹-계층-깊이-상한)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-ACL-009](rules.md#br-acl-009-팀-생성-필수-조건) |
| ACL_TEAM_NAME_DUPLICATE | 409 | [BR-ACL-010](rules.md#br-acl-010-팀명-중복-방지) |
| ACL_PARENT_TEAM_NOT_FOUND | 404 | [BR-ACL-009](rules.md#br-acl-009-팀-생성-필수-조건) |
| ACL_DEPTH_LIMIT_EXCEEDED | 409 | [BR-ACL-026](rules.md#br-acl-026-그룹-계층-깊이-상한) |

> **`ACL_DEPTH_LIMIT_EXCEEDED` details 스키마**:
> ```typescript
> details: {
>   currentDepth: number;   // 요청된 위치의 현재 깊이
>   maxDepth: number;       // 허용 상한 (기본 5)
>   parentTeamId: string;   // 부모 팀 ID
> }
> ```

---

### `GET` /teams

**설명**: 팀 목록을 조회한다. `format=tree`이면 트리 구조로 반환한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Query params:

```typescript
interface ListTeamsQuery {
  format?: 'list' | 'tree';         // 기본 'list'
  parentId?: string;                 // list 모드 — 특정 부모의 자식만
  teamSource?: 'manual' | 'org_sync'; // 출처 필터
  status?: 'active' | 'inactive';    // 상태 필터
  search?: string;                   // 팀명 LIKE 검색
  page?: number;                     // 기본 1 (list 모드만)
  limit?: number;                    // 기본 50, 최대 200 (list 모드만)
}
```

**Response** (`200` — list 모드):

```typescript
interface PaginatedResponse<TeamListItem> { /* 공통 페이지네이션 */ }

interface TeamListItem {
  id: string;
  name: string;
  description: string | null;
  parentId: string | null;
  parentName: string | null;
  status: 'active' | 'inactive';
  teamSource: 'manual' | 'org_sync';
  expiresAt: string | null;
  memberCount: number;
  roleCount: number;
  childCount: number;
  version: number;
  createdAt: string;
  updatedAt: string;
}
```

**Response** (`200` — tree 모드):

```typescript
interface TeamTreeNode {
  id: string;
  name: string;
  status: 'active' | 'inactive';
  teamSource: 'manual' | 'org_sync';
  memberCount: number;
  roleCount: number;
  children: TeamTreeNode[];
}
```

---

### `GET` /teams/:id

**설명**: 팀 상세 정보를 조회한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Path params: `id` — 팀 UUID

**Response** (`200`): `TeamResponse`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| ACL_TEAM_NOT_FOUND | 404 | — |

---

### `PATCH` /teams/:id

**설명**: 팀 정보를 수정한다. `org_sync` 팀은 이름·설명·비활성 변경만 허용하며, `parentId` 변경은 제한한다. OCC 검증을 위해 `version` 필드가 필수이다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Body:

```typescript
interface UpdateTeamDto {
  name?: string;                     // max 100자, UNIQUE
  description?: string | null;
  parentId?: string | null;          // org_sync 팀은 변경 제한
  status?: 'active' | 'inactive';    // inactive 설정 시 팀 비활성화 [BR-ACL-013]
  expiresAt?: string | null;         // 유효기간 변경 (ISO 8601)
  forceCreate?: boolean;             // 선택 — parentId 변경 시 계층 깊이 상한 초과 강제 허용 [BR-ACL-026]
  version: number;                   // 필수 — OCC 버전 [BR-ACL-024]
}
```

**Response** (`200`): `TeamResponse`

**비즈니스 규칙 참조**: [BR-ACL-011](rules.md#br-acl-011-팀-순환-참조-방지), [BR-ACL-013](rules.md#br-acl-013-팀-비활성화-시-권한-상속-중단), [BR-ACL-024](rules.md#br-acl-024-occ-버전-검증), [BR-ACL-026](rules.md#br-acl-026-그룹-계층-깊이-상한)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_TEAM_NOT_FOUND | 404 | — |
| ACL_TEAM_NAME_DUPLICATE | 409 | [BR-ACL-010](rules.md#br-acl-010-팀명-중복-방지) |
| ACL_CIRCULAR_REFERENCE | 409 | [BR-ACL-011](rules.md#br-acl-011-팀-순환-참조-방지) |
| ACL_CONCURRENT_MODIFICATION | 409 | [BR-ACL-024](rules.md#br-acl-024-occ-버전-검증) |
| ACL_DEPTH_LIMIT_EXCEEDED | 409 | [BR-ACL-026](rules.md#br-acl-026-그룹-계층-깊이-상한) |

> `ACL_DEPTH_LIMIT_EXCEEDED` details 스키마는 [POST /teams](#post-teams) 참조.

---

### `DELETE` /teams/:id

**설명**: 팀을 삭제한다. 하위 팀이 존재하면 삭제할 수 없다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Path params: `id` — 팀 UUID

**Response** (`200`):

```typescript
interface DeleteTeamResponse {
  id: string;
  deleted: true;
}
```

**비즈니스 규칙 참조**: [BR-ACL-014](rules.md#br-acl-014-팀-삭제-정책)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_TEAM_NOT_FOUND | 404 | — |
| ACL_TEAM_HAS_CHILDREN | 409 | [BR-ACL-014](rules.md#br-acl-014-팀-삭제-정책) |

---

### `GET` /teams/:id/members

**설명**: 팀 멤버 목록을 조회한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Path params: `id` — 팀 UUID
- Query params:

```typescript
interface TeamMembersQuery {
  page?: number;                     // 기본 1
  limit?: number;                    // 기본 50, 최대 200
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<TeamMemberItem> { /* 공통 페이지네이션 */ }

interface TeamMemberItem {
  userId: string;
  userName: string;
  userServiceRole: string;
  addedAt: string;                   // TeamMember.created_at
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| ACL_TEAM_NOT_FOUND | 404 | — |

---

### `PUT` /teams/:id/members

**설명**: 팀 멤버를 설정한다 (전체 교체). `org_sync` 팀은 멤버 직접 편집이 제한된다. FD-ACL §9.5에서 diff 방식(`addUserIds`/`removeUserIds`)이었으나, 멤버 매핑의 추가/삭제만 존재하는 특성상 PUT 시맨틱(전체 교체)으로 단순화하여 구현 복잡도를 낮추고 idempotent 보장을 강화한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Body:

```typescript
interface SetTeamMembersDto {
  userIds: string[];                 // 사용자 UUID 배열 (빈 배열이면 전부 해제)
}
```

**Response** (`200`): `TeamMemberItem[]`

**비즈니스 규칙 참조**: [BR-ACL-012](rules.md#br-acl-012-org_sync-팀-멤버-직접-편집-제한)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_TEAM_NOT_FOUND | 404 | — |
| ACL_ORG_SYNC_MEMBER_EDIT | 403 | [BR-ACL-012](rules.md#br-acl-012-org_sync-팀-멤버-직접-편집-제한) |

---

### `GET` /teams/:id/roles

**설명**: 팀에 부여된 역할 목록을 조회한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Path params: `id` — 팀 UUID

**Response** (`200`):

```typescript
interface TeamRoleItem {
  roleId: string;
  roleName: string;
  status: 'active' | 'inactive' | 'locked';
  isSystem: boolean;
  hasAdminPermissions: boolean;
  assignedAt: string;                // TeamRole.created_at
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| ACL_TEAM_NOT_FOUND | 404 | — |

---

### `PUT` /teams/:id/roles

**설명**: 팀의 역할을 설정한다 (전체 교체). AdminPermission이 포함된 Role 할당 시, 팀에 ADMIN 미만 멤버가 있으면 경고를 응답에 포함한다.

**권한**: ADMIN (`manage_teams`)

**Request**:

- Body:

```typescript
interface SetTeamRolesDto {
  roleIds: string[];                 // 역할 UUID 배열 (빈 배열이면 전부 해제)
}
```

**Response** (`200`):

```typescript
interface SetTeamRolesResponse {
  roles: TeamRoleItem[];
  warnings: TeamRoleWarning[];
}

interface TeamRoleWarning {
  roleId: string;
  roleName: string;
  message: string;                   // 'ADMIN 미만 멤버가 포함되어 있어 AdminPermission이 적용되지 않을 수 있습니다'
  nonAdminMemberCount: number;
}
```

**비즈니스 규칙 참조**: [BR-ACL-006](rules.md#br-acl-006-adminpermission-포함-역할의-팀-할당-시-경고), [BR-ACL-025](rules.md#br-acl-025-마지막-관리자-보호)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| ACL_TEAM_NOT_FOUND | 404 | — |
| ACL_ROLE_NOT_FOUND | 404 | — |
| ACL_LAST_ADMIN_PROTECTION | 409 | [BR-ACL-025](rules.md#br-acl-025-마지막-관리자-보호) |

---

### `GET` /me/permissions

**설명**: 현재 인증된 사용자의 유효 권한을 요약한다. 프론트엔드 권한 렌더링용.

> 이 엔드포인트는 PermissionModule이 제공하며, Auth 도메인 API 문서에 함께 기술한다.

**권한**: 인증 필요 (추가 AdminPermission 불필요)

**Response** (`200`):

```typescript
interface MyPermissionsResponse {
  userId: string;
  userServiceRole: string;
  effectiveRoles: {
    roleId: string;
    roleName: string;
    source: 'direct' | 'team';
  }[];
  adminPermissions: AdminPermissionKey[];
  accessibleBoards: {
    boardId: string;
    boardName: string;
    actions: ('VIEW' | 'EDIT' | 'APPROVE')[];
  }[];
}
```

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **Auth 도메인 에러** 전체 목록은 [rules.md §3 에러 코드 카탈로그](rules.md#3-에러-코드-카탈로그) 참조

---

## 공통 타입

```typescript
type UserServiceRole = 'SYSTEM' | 'ADMIN' | 'NORMAL' | 'SUPERVISOR' | 'AGENT';
type BoardAction = 'VIEW' | 'EDIT' | 'APPROVE';
type TeamSource = 'manual' | 'org_sync';
type RoleStatus = 'active' | 'inactive' | 'locked';
type TeamStatus = 'active' | 'inactive';

type AdminPermissionKey =
  | 'manage_roles'
  | 'manage_boards'
  | 'manage_teams'
  | 'manage_policies'
  | 'bypass_approval'
  | 'manage_templates'
  | 'manage_tags'
  | 'manage_shared_content'
  | 'manage_search'
  | 'manage_prompts'
  | 'manage_system'
  | 'view_audit_logs';
```
