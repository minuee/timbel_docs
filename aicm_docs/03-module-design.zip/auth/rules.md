# Auth 비즈니스 규칙

> 기능정의서: [FD-ACL-권한체계](../../01-requirements/features/FD-ACL-권한체계.md)
> API 스펙: [api.md](api.md)
> 아키텍처: [03-auth-architecture.md](../../02-architecture/03-auth-architecture.md), [04-permission-architecture.md](../../02-architecture/04-permission-architecture.md)

> **API 경로 표기**: 글로벌 `/api` prefix는 배포 환경에서 리버스 프록시로 부여되며, 모듈 스펙에서는 prefix 없이 기술한다.

---

## 1. 상태 전이

### 1.1 Role 생명주기

```mermaid
stateDiagram-v2
    [*] --> active: 역할 생성 [BR-ACL-001]

    active --> inactive: 비활성화 [BR-ACL-022]
    active --> locked: 긴급 잠금 [BR-ACL-023]
    inactive --> active: 재활성화 [BR-ACL-022]
    locked --> active: 잠금 해제 [BR-ACL-023]

    note right of inactive
        신규 부여 목록에서 제외
        기존 사용자 권한 해제
        할당 이력은 보존
    end note

    note right of locked
        보안 사고 시 긴급 정지
        lock_reason 필수
        잠금 사용자에게 알림
    end note
```

### 1.2 Team 운영 상태

```mermaid
stateDiagram-v2
    [*] --> active: 팀 생성 [BR-ACL-009]

    active --> inactive: 비활성화 / 유효기간 만료 [BR-ACL-013, BR-ACL-027]
    inactive --> active: 활성화 [BR-ACL-013]

    active --> deleted: 삭제 [BR-ACL-014]
    inactive --> deleted: 삭제 [BR-ACL-014]

    note right of inactive
        비활성 팀의 TeamRole은
        유효 역할 산출에서 제외
    end note

    note right of deleted
        하위 팀 존재 시
        삭제 차단 (RESTRICT)
    end note
```

---

## 2. 규칙 카탈로그

### 역할 생성

#### BR-ACL-001: 역할 생성 필수 조건

- **트리거**: `POST /roles`
- **조건**: 요청자가 ADMIN 역할이고 `manage_roles` AdminPermission을 보유
- **동작**: Role 레코드 생성 (`is_system = false`, `status = 'active'`). 시스템 프리셋 Role은 앱 초기화 시에만 `is_system = true`로 생성
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_roles 권한 없음 |
- **근거**: FD-ACL §3.1 — Role은 AICM의 유일한 권한 경계

#### BR-ACL-002: 역할명 중복 방지

- **트리거**: 역할 생성 또는 수정 시
- **조건**: `name`이 `role` 테이블 내에서 유일함 (`UNIQUE(name)` DB 제약)
- **동작**: 역할 생성/수정 허용
- **위반 시**: `ACL_ROLE_NAME_DUPLICATE` (409) — 이미 사용 중인 역할명입니다
- **근거**: 데이터 아키텍처 §2.1 — `UNIQUE(name)` 제약

---

### 역할 삭제

#### BR-ACL-003: is_system 역할 삭제 차단

- **트리거**: `DELETE /roles/:id`
- **조건**: 대상 Role의 `is_system == true`
- **동작**: 삭제 거부
- **위반 시**: `ACL_SYSTEM_ROLE_DELETE` (403) — 시스템 기본 역할은 삭제할 수 없습니다
- **근거**: FD-ACL §3.1 — 프리셋 Role은 삭제 불가, 이름 변경과 권한 수정은 허용. 데이터 아키텍처 §2.1 — `is_system = true`인 Role은 앱 레벨에서 삭제를 차단

#### BR-ACL-004: 역할 삭제 시 할당 존재 확인 (RESTRICT)

- **트리거**: `DELETE /roles/:id` (is_system이 아닌 역할)
- **조건**: 대상 Role의 `is_system == false`
- **동작**:
  1. UserRole — 해당 역할의 UserRole 레코드 존재 여부 확인 → 존재하면 삭제 차단
  2. TeamRole — 해당 역할의 TeamRole 레코드 존재 여부 확인 → 존재하면 삭제 차단
  3. 모든 할당이 없는 경우에만 삭제 진행:
     - AdminPermission — 해당 역할의 모든 AdminPermission 레코드 CASCADE 삭제
     - BoardPermission — 해당 역할의 모든 BoardPermission 레코드 CASCADE 삭제 (BoardModule 소유, FK CASCADE)
     - Role 레코드 삭제
  4. 감사 로그 `role.deleted` 기록
- **위반 시**: `ACL_ROLE_IN_USE` (409) — 해당 역할이 사용자 또는 팀에 할당되어 있어 삭제할 수 없습니다. 먼저 모든 할당을 해제해주세요
- **근거**: FD-ACL BR-ACL-034 — 할당 존재 시 삭제 차단 (RESTRICT 정책). 데이터 아키텍처 DDL — `role_id REFERENCES role(id) ON DELETE RESTRICT`

---

### AdminPermission 관리

#### BR-ACL-005: AdminPermission 포함 역할의 NORMAL 이하 사용자 할당 차단

- **트리거**: `PUT /users/:userId/roles` — AdminPermission이 포함된 Role을 할당할 때
- **조건**: 대상 사용자의 user_service 역할이 NORMAL/SUPERVISOR/AGENT — 대상 사용자의 역할은 인증 토큰(UserContext)에서 추출하거나, 토큰에 없는 경우 UserServiceClient를 통해 외부 조회한다
- **동작**: API가 400 에러를 반환하여 할당을 거부
- **위반 시**: `ACL_ADMIN_ROLE_TO_NORMAL` (400) — AdminPermission이 포함된 역할은 ADMIN 이상 사용자에게만 할당할 수 있습니다
- **근거**: FD-ACL §6 BR-ACL-031 — AdminPermission 포함 역할 부여 차단. 04-permission-architecture.md §5.4 — 백엔드 API에서 원천 차단

#### BR-ACL-006: AdminPermission 포함 역할의 팀 할당 시 경고

- **트리거**: `PUT /teams/:id/roles` — AdminPermission이 포함된 Role을 할당할 때
- **조건**: 팀(하위 팀 포함)에 user_service 역할이 ADMIN 미만인 멤버가 존재
- **동작**: 할당 자체는 허용하되, 응답에 경고를 포함. AdminPermission은 ADMIN 역할 멤버에게만 실제 효력을 가짐
- **위반 시**: — (경고만 반환, 차단하지 않음)
- **근거**: FD-ACL §6 BR-ACL-031 — 그룹 할당 시 ADMIN 미만 멤버가 있으면 UI 경고 표시. 04-permission-architecture.md §5.4 — 그룹에 ADMIN 멤버도 있을 수 있으므로 완전 차단은 부적절

#### BR-ACL-007: permission_key 앱 레벨 검증

- **트리거**: `PUT /roles/:id/admin-permissions`
- **조건**: 요청의 `permissionKeys` 배열에 포함된 모든 키가 허용 목록에 존재해야 함
- **동작**: 허용 목록: `manage_roles`, `manage_boards`, `manage_teams`, `manage_policies`, `bypass_approval`, `manage_templates`, `manage_tags`, `manage_shared_content`, `manage_search`, `manage_prompts`, `manage_system`, `view_audit_logs`
- **위반 시**: `ACL_INVALID_PERMISSION_KEY` (422) — 유효하지 않은 관리 권한 키입니다: {key}
- **근거**: FD-ACL §6 — 12종 권한 키. 데이터 아키텍처 §2.3 — 앱 레벨에서 허용 키 목록을 검증 (확장 가능성을 고려하여 CHECK 대신 앱 검증)

#### BR-ACL-008: AdminPermission 전체 교체

- **트리거**: `PUT /roles/:id/admin-permissions`
- **조건**: —
- **동작**: 기존 AdminPermission 레코드 전체 삭제 후 새 매핑으로 INSERT (PUT 시맨틱). `UNIQUE(role_id, permission_key)` 제약에 의해 중복 방지. 감사 로그 `role.admin_permissions_updated` 기록 — details: `{ roleId, roleName, added: string[], removed: string[], final: string[] }`
- **위반 시**: —
- **근거**: 데이터 아키텍처 §2.3 — 매핑 관계는 추가/삭제만 존재, "수정"이 없음

---

### 역할 상태 관리

#### BR-ACL-022: Role 비활성화/재활성화

- **트리거**: `PATCH /roles/:id/status` — `{ status: 'inactive' }` 또는 `{ status: 'active' }`
- **조건**: 대상 Role이 active → inactive 또는 inactive → active 전이 가능
- **동작**:
  - **비활성화 시**: `Role.status = 'inactive'`. 해당 Role은 신규 부여 목록에서 제외되며, 기존에 부여된 사용자/그룹에서 해당 Role을 통한 권한이 해제된다. Role 자체와 할당 이력(UserRole, TeamRole)은 보존. `acl.role.status_changed` 이벤트 발행
  - **재활성화 시**: `Role.status = 'active'`. 기존 할당이 보존되어 있으므로 즉시 권한 복원. `acl.role.status_changed` 이벤트 발행
- **위반 시**: `ACL_INVALID_STATUS_TRANSITION` (409) — 허용되지 않는 상태 전이입니다
- **근거**: FD-ACL §3.1 BR-ACL-008 — Role 비활성화 시 기존에 부여된 사용자/그룹에서 권한이 해제된다

#### BR-ACL-023: Role 긴급 잠금/해제

- **트리거**: `PATCH /roles/:id/status` — `{ status: 'locked', lockReason: '...' }` 또는 `{ status: 'active' }` (잠금 해제)
- **조건**: active → locked 전이 시 `lockReason` 필수. locked → active 전이만 허용 (locked → inactive 불가)
- **동작**:
  - **잠금 시**: `Role.status = 'locked'`, `Role.lock_reason = lockReason`. 해당 역할을 통한 모든 권한이 즉시 정지. 잠금된 역할을 보유한 사용자에게 알림 발송. `acl.role.status_changed` 이벤트 발행
  - **잠금 해제 시**: `Role.status = 'active'`, `Role.lock_reason = null`. 권한 즉시 복원. `acl.role.status_changed` 이벤트 발행
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | ACL_LOCK_REASON_REQUIRED | 400 | 긴급 잠금 시 잠금 사유는 필수입니다 |
  | ACL_INVALID_STATUS_TRANSITION | 409 | 허용되지 않는 상태 전이입니다 |
- **근거**: FD-ACL §3.1 BR-ACL-009 — Role 긴급 잠금 시 해당 역할을 통한 모든 권한이 즉시 정지된다

---

### 팀 생성

#### BR-ACL-009: 팀 생성 필수 조건

- **트리거**: `POST /teams`
- **조건**: 요청자가 ADMIN 역할이고 `manage_teams` AdminPermission을 보유. `name`이 기존 팀과 중복되지 않음 [BR-ACL-010]. `parentId` 지정 시 해당 팀이 존재하고 활성 상태
- **동작**: Team 레코드 생성 (`team_source = 'manual'`, `status = 'active'`)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_teams 권한 없음 |
  | ACL_PARENT_TEAM_NOT_FOUND | 404 | 상위 팀 미존재 또는 비활성 |
  | ACL_TEAM_NAME_DUPLICATE | 409 | 이미 사용 중인 팀명 |
- **근거**: FD-ACL §3.2 — Team은 동일한 역할을 공유하는 사용자 그룹

#### BR-ACL-010: 팀명 중복 방지

- **트리거**: 팀 생성 또는 수정 시
- **조건**: `name`이 `team` 테이블 내에서 유일함 (`UNIQUE(name)` DB 제약)
- **동작**: 팀 생성/수정 허용
- **위반 시**: `ACL_TEAM_NAME_DUPLICATE` (409) — 이미 사용 중인 팀명입니다
- **근거**: 데이터 아키텍처 §2.4 — `UNIQUE(name)` 제약

#### BR-ACL-011: 팀 순환 참조 방지

- **트리거**: 팀 생성 시 `parentId` 지정, 또는 `PATCH /teams/:id` (`parentId` 변경)
- **조건**: 새 `parent_id`가 자기 자신이 아니며, 자신의 하위 트리에 속하는 팀도 아님
- **동작**: `parent_id` 설정/변경 허용
- **위반 시**: `ACL_CIRCULAR_REFERENCE` (409) — 순환 참조가 발생합니다. 자기 자신 또는 자신의 하위 팀을 부모로 지정할 수 없습니다
- **근거**: 데이터 아키텍처 §2.4 — `parent_id`는 자기 자신을 참조할 수 없다 (앱 레벨 검증)

---

### 팀 멤버 관리

#### BR-ACL-012: org_sync 팀 멤버 직접 편집 제한

- **트리거**: `PUT /teams/:id/members` — `team_source = 'org_sync'`인 팀에 대해
- **조건**: 대상 팀의 `team_source == 'org_sync'`
- **동작**: 멤버 직접 편집 거부
- **위반 시**: `ACL_ORG_SYNC_MEMBER_EDIT` (403) — 조직도 동기화 팀의 멤버는 직접 편집할 수 없습니다. 외부 조직도에서 관리됩니다
- **근거**: 데이터 아키텍처 §2.4 — `org_sync` 팀은 외부 UserService의 조직도에서 동기화된 것. `manual` 팀은 관리자가 자유롭게 편집 가능

---

### 팀 비활성화/삭제

#### BR-ACL-013: 팀 비활성화 시 권한 상속 중단

- **트리거**: `PATCH /teams/:id` (`status` → `inactive`)
- **조건**: —
- **동작**: `Team.status = 'inactive'`. 비활성 팀의 TeamRole은 유효 역할 산출(BR-ACL-015) 시 제외된다. 팀 자체와 소속 멤버·TeamRole 레코드는 유지되며, 재활성화 시 즉시 권한 복원. `acl.team.status_changed` 이벤트 발행
- **위반 시**: —
- **근거**: FD-ACL §3.2 BR-ACL-014 — Group 비활성화 시 구성원의 해당 그룹을 통한 권한이 해제되지만, 그룹 구조와 이력은 보존

#### BR-ACL-014: 팀 삭제 정책

- **트리거**: `DELETE /teams/:id`
- **조건**: 하위 팀이 존재하지 않음 (DB `ON DELETE RESTRICT` + 앱 레벨 검증)
- **동작**:
  1. TeamMember — 해당 팀의 모든 TeamMember 레코드 CASCADE 삭제
  2. TeamRole — 해당 팀의 모든 TeamRole 레코드 CASCADE 삭제
  3. Team 레코드 삭제
  4. 감사 로그 `team.deleted` 기록 — details: `{ teamId, teamName, teamSource, memberCount: number, roleCount: number }`
- **위반 시**: `ACL_TEAM_HAS_CHILDREN` (409) — 하위 팀이 존재하는 팀은 삭제할 수 없습니다. 하위 팀을 먼저 정리해주세요
- **근거**: 데이터 아키텍처 DDL — `parent_id REFERENCES team(id) ON DELETE RESTRICT`. TeamMember/TeamRole은 `ON DELETE CASCADE`

---

### 유효 역할 산출

#### BR-ACL-015: 유효 역할 산출 (additive-only)

- **트리거**: 권한 평가 시 (`PermissionService.getEffectiveRoles()`)
- **조건**: —
- **동작**:
  ```
  유효 역할(userId) =
    UserRole(직접 할당, role.status = 'active')
    ∪ TeamRole(본인 직접 소속 팀, team.status = 'active', role.status = 'active')
    ∪ TeamRole(소속 팀의 상위 팀 ... 루트까지, 각 team.status = 'active', role.status = 'active')
  ```
  팀 계층 순회는 OrgProvider에 위임 (`getUserAncestorTeamIds(userId)`). 비활성 팀(`status = 'inactive'`)의 TeamRole은 제외. 비활성(`inactive`) 또는 잠금(`locked`) 상태의 Role은 제외. 모든 유효 역할의 권한을 합산(additive-only). deny(명시적 거부)는 없음
- **위반 시**: —
- **근거**: FD-ACL §3.4 BR-ACL-016, BR-ACL-018, BR-ACL-019 — 유효 역할 = 직접 할당 ∪ 그룹 상속 합집합. deny 도입 시 권한 디버깅 복잡도 극단적 상승. 비활성/잠금 상태 Role과 비활성 Group은 유효 역할 합산에서 제외

---

### 낙관적 동시성 제어

#### BR-ACL-024: OCC 버전 검증

- **트리거**: `PATCH /roles/:id`, `PATCH /teams/:id` 등 Role·Team 수정 시
- **조건**: 요청 본문에 `version` 필드가 포함되어야 함
- **동작**: DB의 현재 `version`과 요청의 `version`을 비교. 일치하면 수정 진행 + `version = version + 1`. 불일치하면 수정 거부
- **위반 시**: `ACL_CONCURRENT_MODIFICATION` (409) — 다른 사용자에 의해 수정되었습니다. 최신 데이터를 다시 조회해주세요
- **근거**: FD-ACL §3.4 BR-ACL-035 — Role·Team 수정 시 version 필드 기반 낙관적 동시성 제어

---

### 마지막 관리자 보호

#### BR-ACL-025: 마지막 관리자 보호

- **트리거**: `PUT /users/:userId/roles` (역할 해제), `PUT /teams/:id/roles` (팀 역할 제거), `PATCH /roles/:id/status` (비활성화/잠금)
- **조건**: 변경 후 시스템에 최상위 관리자 역할 보유자(manage_roles + manage_system 포함)가 0명이 되는 경우
- **동작**: 변경을 거부하여 최소 1명의 관리자를 보장
- **위반 시**: `ACL_LAST_ADMIN_PROTECTION` (409) — 시스템에 최소 1명의 관리자가 유지되어야 합니다. 마지막 관리자의 역할 해제 또는 비활성화는 차단됩니다
- **근거**: FD-ACL §6 BR-ACL-032 — 시스템에 최상위 관리자 역할 보유자가 최소 1명은 유지되어야 한다

---

### 그룹 계층 관리

#### BR-ACL-026: 그룹 계층 깊이 상한

- **트리거**: `POST /teams` (`parentId` 지정), `PATCH /teams/:id` (`parentId` 변경)
- **조건**: 새로운 계층 깊이가 SystemConfig `group_max_depth`(기본 10단계)를 초과하는 경우
- **동작**: 깊이 초과 시 경고를 응답에 포함하고, 관리자 확인(`forceCreate=true`) 시 진행 허용
- **위반 시**: `ACL_DEPTH_LIMIT_EXCEEDED` (409) — 그룹 계층 깊이가 상한({maxDepth}단계)을 초과합니다. 확인 후 진행하려면 forceCreate 옵션을 사용하세요
- **근거**: FD-ACL §3.2 BR-ACL-011 — 그룹 계층 깊이 상한은 기본 10단계

---

### 팀 유효기간 만료

#### BR-ACL-027: Team 유효기간 만료 자동 비활성화

- **트리거**: 스케줄 배치 (Team 유효기간 만료 확인)
- **조건**: `Team.expires_at IS NOT NULL AND Team.expires_at <= now() AND Team.status = 'active'`
- **동작**: `Team.status = 'inactive'`. 소속 멤버의 해당 팀 통한 권한이 해제. `acl.team.status_changed` 이벤트 발행. 감사 로그 `team.status_changed` 기록 — details: `{ teamId, reason: 'expires_at_reached' }`
- **위반 시**: —
- **근거**: FD-ACL §3.2 BR-ACL-015 — 외부 협력사 임시 그룹은 유효기간을 설정할 수 있으며, 만료 시 시스템이 자동으로 비활성 처리

---

### 신규 사용자 기본 역할 할당

#### BR-ACL-028: 신규 사용자 온보딩 시 기본 역할 자동 할당

- **트리거**: 사용자가 AICM에 최초 접근(로그인) 시, 해당 사용자의 UserRole이 0건인 경우
- **조건**: 시스템에 "일반 사용자" 프리셋 Role(`is_system = true`, AdminPermission 없음)이 존재
- **동작**:
  1. AuthModule이 사용자의 UserRole 존재 여부를 확인한다
  2. UserRole이 없으면 "일반 사용자" 프리셋 Role을 자동 할당한다 (UserRole INSERT)
  3. `acl.user_role.updated` 이벤트 발행 — `{ userId, addedRoleIds: [일반사용자RoleId], removedRoleIds: [] }`
  4. 감사 로그 `user_role.auto_assigned` 기록 — details: `{ userId, roleName: '일반 사용자', reason: 'onboarding' }`
- **할당 방식**: AuthGuard 인증 성공 후, PermissionService가 유효 역할을 산출하기 전에 AuthModule의 `ensureDefaultRole(userId)` 내부 메서드를 호출한다. 이 메서드는 UserRole 0건일 때만 동작하므로 기존 사용자에게는 영향 없음
- **위반 시**: —
- **근거**: FD-ACL §3.1 BR-ACL-007 — 신규 사용자 온보딩 시 "일반 사용자" 프리셋 Role이 기본 할당된다. data.md §2.1 프리셋 Role 시드 목록 — "일반 사용자" Role은 최소 문서 열람 권한을 제공

---

### 권한 평가

#### BR-ACL-016: [설계 원칙] 3계층 권한 평가 순서

- **트리거**: 문서 자원 접근 시 (`PermissionService.checkDocumentAccess()`, `checkBlockAccess()`)
- **조건**: —
- **동작**:
  1. **Board Grant**: 유효 역할이 해당 Board에 요청 action(VIEW/EDIT/APPROVE) 권한을 보유하는지 확인 → 없으면 거부
  2. **Document Restriction**: 문서에 제한이 걸려있는가(`restricted = true`) → 걸려있으면 화이트리스트(DocumentRestriction)에 user 또는 소속 team이 있는지 + action 확인 → 없으면 거부
  3. **Block Restriction**: 블록에 제한이 걸려있는가 → 동일 패턴
- **위반 시**: — (각 단계에서 FORBIDDEN 반환)
- **근거**: 03-auth-architecture.md §5.2, §5.5 — 3계층 권한 모델

#### BR-ACL-017: [설계 원칙] SYSTEM 전체 바이패스

- **트리거**: 모든 자원 접근 시
- **조건**: 요청자의 user_service 역할이 `SYSTEM`
- **동작**: 모든 권한 평가를 건너뛰고 즉시 허용. 문서·관리·개인 자원 모두 전체 바이패스
- **위반 시**: —
- **근거**: FD-ACL §2 BR-ACL-002 — SYSTEM은 유일하게 모든 자원(개인 자원 포함)을 무조건 바이패스

#### BR-ACL-018: [설계 원칙] ADMIN VIEW 바이패스 (메타정보 수준)

- **트리거**: 문서 자원 VIEW 접근 시, 개인 자원 VIEW 접근 시
- **조건**: 요청자의 user_service 역할이 `ADMIN`이고, BoardPermission(VIEW)을 보유하지 않음
- **동작**:
  - **문서 자원**: 메타정보 수준으로 VIEW 허용 (블록 본문·댓글 내용·버전 본문·첨부 URL 제외). 응답에 `view_source: 'bypass'` 포함. 감사 로그 기록
  - **개인 자원**: VIEW만 바이패스 (수정 불가). 감사 로그 기록
  - **관리 자원**: ADMIN VIEW 바이패스 없음 — AdminPermission 평가 필요
  - EDIT/APPROVE는 바이패스되지 않으며 BoardPermission이 필요
- **위반 시**: —
- **근거**: FD-ACL §4.1 BR-ACL-003, BR-ACL-023 — API 응답 레이어에서 필드 필터링. 04-permission-architecture.md §4.3 — 관리 사각지대 방지

#### BR-ACL-019: [설계 원칙] AdminPermission 평가 (ADMIN 미만 즉시 거부)

- **트리거**: 관리 자원 접근 시
- **조건**: 요청자의 user_service 역할 확인
- **동작**:
  - **SYSTEM**: 전체 바이패스 [BR-ACL-017]
  - **ADMIN**: 유효 역할의 AdminPermission에서 해당 `permission_key` 보유 여부 확인. 있으면 CRUD 전체 허용, 없으면 거부
  - **NORMAL/SUPERVISOR/AGENT**: AdminPermission 평가 자체를 수행하지 않고 즉시 거부
- **위반 시**: FORBIDDEN (403)
- **근거**: FD-ACL §6 BR-ACL-020, BR-ACL-030 — 관리 자원 권한은 이진 판단. ADMIN이 아니면 평가 자체를 수행하지 않음

#### BR-ACL-020: [설계 원칙] 검색 권한 필터 구성

- **트리거**: 검색 쿼리 실행 전 (`PermissionService.getAccessibleBoardIds()`, `getRestrictedDocumentIds()`)
- **조건**: —
- **동작**:
  1. 접근 가능 board_id 목록 산출 — `BoardPermission WHERE role_id IN (유효 역할) AND action = 'VIEW'`
  2. 접근 불가 제한 document_id 목록 산출 — `restricted = true`이면서 화이트리스트에 미포함
  3. SearchModule에 pre-filter 제공 (ES 쿼리 또는 retrieval-service filters 파라미터)
- **위반 시**: —
- **근거**: 03-auth-architecture.md §5.6 — 검색/RAG 권한 필터. pre-filtering 방식

---

### 테넌트

#### BR-ACL-021: [설계 원칙] 테넌트 식별 필수

- **트리거**: 모든 API 요청
- **조건**: —
- **동작**: TenantMiddleware가 요청 토큰에서 테넌트 ID를 추출하고, AsyncLocalStorage에 저장. TenantConnectionResolver가 해당 테넌트의 DB 커넥션을 선택. 테넌트 ID가 없거나 유효하지 않으면 요청 거부
- **위반 시**: `UNAUTHORIZED` (401)
- **근거**: 02-module-architecture.md §3.2.1 — TenantModule 책임

---

## 3. 에러 코드 카탈로그

> 전역 에러 코드 (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

| 에러 코드 | HTTP | 발생 규칙 | 메시지 템플릿 |
|-----------|------|----------|--------------|
| ACL_ADMIN_ROLE_TO_NORMAL | 400 | BR-ACL-005 | AdminPermission이 포함된 역할은 ADMIN 이상 사용자에게만 할당할 수 있습니다 |
| ACL_CIRCULAR_REFERENCE | 409 | BR-ACL-011 | 순환 참조가 발생합니다 |
| ACL_CONCURRENT_MODIFICATION | 409 | BR-ACL-024 | 다른 사용자에 의해 수정되었습니다. 최신 데이터를 다시 조회해주세요 |
| ACL_DEPTH_LIMIT_EXCEEDED | 409 | BR-ACL-026 | 그룹 계층 깊이가 상한을 초과합니다 |
| ACL_INVALID_PERMISSION_KEY | 422 | BR-ACL-007 | 유효하지 않은 관리 권한 키입니다: {key} |
| ACL_INVALID_STATUS_TRANSITION | 409 | BR-ACL-022, BR-ACL-023 | 허용되지 않는 상태 전이입니다 |
| ACL_LAST_ADMIN_PROTECTION | 409 | BR-ACL-025 | 시스템에 최소 1명의 관리자가 유지되어야 합니다 |
| ACL_LOCK_REASON_REQUIRED | 400 | BR-ACL-023 | 긴급 잠금 시 잠금 사유는 필수입니다 |
| ACL_ORG_SYNC_MEMBER_EDIT | 403 | BR-ACL-012 | 조직도 동기화 팀의 멤버는 직접 편집할 수 없습니다 |
| ACL_PARENT_TEAM_NOT_FOUND | 404 | BR-ACL-009 | 상위 팀을 찾을 수 없습니다 |
| ACL_ROLE_IN_USE | 409 | BR-ACL-004 | 해당 역할이 사용자 또는 팀에 할당되어 있어 삭제할 수 없습니다 |
| ACL_ROLE_NAME_DUPLICATE | 409 | BR-ACL-002 | 이미 사용 중인 역할명입니다 |
| ACL_ROLE_NOT_FOUND | 404 | — | 역할을 찾을 수 없습니다 |
| ACL_SYSTEM_ROLE_DELETE | 403 | BR-ACL-003 | 시스템 기본 역할은 삭제할 수 없습니다 |
| ACL_TEAM_HAS_CHILDREN | 409 | BR-ACL-014 | 하위 팀이 존재하는 팀은 삭제할 수 없습니다 |
| ACL_TEAM_NAME_DUPLICATE | 409 | BR-ACL-010 | 이미 사용 중인 팀명입니다 |
| ACL_TEAM_NOT_FOUND | 404 | — | 팀을 찾을 수 없습니다 |

---

## 4. 규칙 요약 매트릭스

| 규칙 ID | 이름 | 주요 트리거 | 에러 코드 |
|---------|------|-----------|-----------|
| BR-ACL-001 | 역할 생성 필수 조건 | POST /roles | FORBIDDEN |
| BR-ACL-002 | 역할명 중복 방지 | 역할 생성/수정 시 | ACL_ROLE_NAME_DUPLICATE |
| BR-ACL-003 | is_system 역할 삭제 차단 | DELETE /roles/:id | ACL_SYSTEM_ROLE_DELETE |
| BR-ACL-004 | 역할 삭제 시 할당 존재 확인 (RESTRICT) | DELETE /roles/:id | ACL_ROLE_IN_USE |
| BR-ACL-005 | AdminPermission 포함 역할의 NORMAL 이하 사용자 할당 차단 | PUT /users/:userId/roles | ACL_ADMIN_ROLE_TO_NORMAL |
| BR-ACL-006 | AdminPermission 포함 역할의 팀 할당 시 경고 | PUT /teams/:id/roles | — (경고만) |
| BR-ACL-007 | permission_key 앱 레벨 검증 | PUT /roles/:id/admin-permissions | ACL_INVALID_PERMISSION_KEY |
| BR-ACL-008 | AdminPermission 전체 교체 | PUT /roles/:id/admin-permissions | — |
| BR-ACL-009 | 팀 생성 필수 조건 | POST /teams | FORBIDDEN, ACL_PARENT_TEAM_NOT_FOUND, ACL_TEAM_NAME_DUPLICATE |
| BR-ACL-010 | 팀명 중복 방지 | 팀 생성/수정 시 | ACL_TEAM_NAME_DUPLICATE |
| BR-ACL-011 | 팀 순환 참조 방지 | 팀 생성/수정 시 parentId 검증 | ACL_CIRCULAR_REFERENCE |
| BR-ACL-012 | org_sync 팀 멤버 직접 편집 제한 | PUT /teams/:id/members | ACL_ORG_SYNC_MEMBER_EDIT |
| BR-ACL-013 | 팀 비활성화 시 권한 상속 중단 | PATCH /teams/:id (status 변경) | — |
| BR-ACL-014 | 팀 삭제 정책 | DELETE /teams/:id | ACL_TEAM_HAS_CHILDREN |
| BR-ACL-015 | 유효 역할 산출 (additive-only) | PermissionService.getEffectiveRoles() | — |
| BR-ACL-016 | [설계 원칙] 3계층 권한 평가 순서 | 문서 자원 접근 시 | — (FORBIDDEN) |
| BR-ACL-017 | [설계 원칙] SYSTEM 전체 바이패스 | 모든 자원 접근 시 | — |
| BR-ACL-018 | [설계 원칙] ADMIN VIEW 바이패스 | 문서/개인 자원 VIEW 시 | — |
| BR-ACL-019 | [설계 원칙] AdminPermission 평가 | 관리 자원 접근 시 | FORBIDDEN |
| BR-ACL-020 | [설계 원칙] 검색 권한 필터 구성 | 검색 쿼리 실행 전 | — |
| BR-ACL-021 | [설계 원칙] 테넌트 식별 필수 | 모든 API 요청 | UNAUTHORIZED |
| BR-ACL-022 | Role 비활성화/재활성화 | PATCH /roles/:id/status | ACL_INVALID_STATUS_TRANSITION |
| BR-ACL-023 | Role 긴급 잠금/해제 | PATCH /roles/:id/status | ACL_LOCK_REASON_REQUIRED, ACL_INVALID_STATUS_TRANSITION |
| BR-ACL-024 | OCC 버전 검증 | Role/Team 수정 시 | ACL_CONCURRENT_MODIFICATION |
| BR-ACL-025 | 마지막 관리자 보호 | 역할 해제/비활성화 시 | ACL_LAST_ADMIN_PROTECTION |
| BR-ACL-026 | 그룹 계층 깊이 상한 | 팀 생성/수정 시 parentId 검증 | ACL_DEPTH_LIMIT_EXCEEDED |
| BR-ACL-027 | Team 유효기간 만료 자동 비활성화 | 스케줄 배치 | — |
| BR-ACL-028 | 신규 사용자 온보딩 시 기본 역할 자동 할당 | 최초 로그인 시 UserRole 0건인 경우 | — |
