# AuditLogModule — RDB 엔티티

> 감사 로그 (금융권 컴플라이언스)

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    %% AuditLog는 완전 독립 — FK 없음.
    %% resource_type + resource_id로 대상 리소스를 논리적으로 참조한다.

    AuditLog {
        UUID id PK
        UUID actor_id
        VARCHAR actor_role
        VARCHAR action
        VARCHAR resource_type
        UUID resource_id
        JSONB details
        VARCHAR ip_address
        TEXT user_agent
    }
```

---

## 2. 엔티티 필드

### 2.1 AuditLog

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| actor_id | UUID | 액션 수행자 (외부 UserService의 userId, FK 없음) |
| actor_role | VARCHAR(50) (nullable) | 수행 시점의 역할 (스냅샷) |
| action | VARCHAR(50) | 액션 유형 |
| resource_type | VARCHAR(30) | 대상 리소스 타입 |
| resource_id | UUID (nullable) | 대상 리소스 ID |
| details | JSONB (nullable) | 변경 전/후 스냅샷, 추가 컨텍스트 |
| ip_address | VARCHAR(45) (nullable) | 클라이언트 IP (IPv6 대응) |
| user_agent | TEXT (nullable) | 클라이언트 User-Agent |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `action`은 앱 레벨에서 검증 — 액션 유형이 지속적으로 확장될 수 있으므로 CHECK 제약 대신 앱 레벨 검증
- `resource_type`은 앱 레벨에서 검증 — 리소스 타입이 확장 가능하므로 앱 레벨 검증

#### 설계 결정

**불변 (Immutable) — INSERT ONLY**
— AuditLog는 한 번 생성되면 수정·삭제하지 않는다. 앱 레벨에서 UPDATE/DELETE를 차단하고, DB 권한으로도 INSERT만 허용하여 감사 로그의 무결성을 보장한다. `updated_at` 컬럼이 없다.

**액션 유형 (action)**
— 네임스페이스(`domain.action`) 패턴으로 구분한다. 액션 유형은 앱 레벨에서 검증하며 지속적으로 확장 가능하다.

문서 도메인:
- `document.created`: 문서 생성
- `document.updated`: 문서 수정 (기본 정보 변경)
- `document.deleted`: 문서 삭제 (소프트 딜리트)
- `document.restored`: 삭제된 문서 복원
- `document.status_changed`: 문서 상태 전이 (draft→pending_review→published 등)
- `document.suspended`: 긴급 회수 (검색/RAG 일시 정지)
- `document.archived`: 문서 폐기 (아카이빙). 소프트 딜리트와 구분되는 운영 종료 처리
- `document.version_created`: 새 버전 생성 (승인 요청 시 제출 버전)
- `document.rollback_started`: 이전 발행 버전으로 롤백 시작 (Copy-forward). details에 `{ target_version_number, target_version_id }` 기록
- `document.draft_discarded`: 최초 작성 문서를 발행 전 폐기
- `document.owner_changed`: 담당자 변경. details에 `{ before: { assignee_id }, after: { assignee_id } }` 기록
- `document.expired`: 유효기간 만료로 인한 자동 정지. details에 `{ expires_at }` 기록
- `document.extended`: 유효기간 연장. details에 `{ before: { expires_at }, after: { expires_at } }` 기록

발행 승인 도메인:
- `approval.submitted`: 승인 요청 제출
- `approval.approved`: 최종 승인 완료
- `approval.rejected`: 최종 반려
- `approval.withdrawn`: 요청 철회
- `approval.step_approved`: 다단계 승인에서 개별 단계 통과. details에 step_order, approver 정보 기록
- `approval.step_rejected`: 다단계 승인에서 개별 단계 반려. details에 step_order, 반려 사유 기록
- `approval.bypassed`: 긴급 발행(승인 우회). details에 bypass_reason, bypasser 정보 기록

삭제 요청 승인 도메인:
- `approval.delete_submitted`: 삭제 요청 제출. details에 삭제 사유 기록
- `approval.delete_approved`: 삭제 요청 최종 승인. 후속으로 소프트 딜리트 실행
- `approval.delete_rejected`: 삭제 요청 최종 반려
- `approval.delete_withdrawn`: 삭제 요청 철회
- `approval.delete_step_approved`: 삭제 요청 다단계 개별 단계 통과. details에 step_order 기록
- `approval.delete_step_rejected`: 삭제 요청 다단계 개별 단계 반려. details에 step_order, 반려 사유 기록

커뮤니티 도메인:
- `community.comment_created`: 의견(댓글) 추가. resource_type=`comment`
- `community.comment_updated`: 의견 수정
- `community.comment_deleted`: 의견 삭제
- `community.comment_mention`: 의견에서 사용자 멘션. details에 `{ mentioned_user_ids }` 기록

관리자 액션 도메인:
- `board.created`: 게시판 생성. details에 `board_type`, `parent_id` 기록
- `board.updated`: 게시판 수정. details에 변경 전/후 기록
- `board.deleted`: 게시판 삭제
- `board.moved`: 게시판 트리 위치 변경. details에 `parent_before`, `parent_after` 기록
- `template.created`: 템플릿 생성. details에 `category` 기록
- `template.cloned`: 템플릿 복제
- `template.deactivated`: 템플릿 비활성 처리
- `shared_content.created`: 공통 컨텐츠 생성
- `shared_content.updated`: 공통 컨텐츠 수정. details에 `affected_documents_count` 기록
- `shared_content.deactivated`: 공통 컨텐츠 비활성 처리
- `tag.merged`: 태그 병합. details에 `source_tags`, `target_tag` 기록
- `tag.deleted`: 태그 삭제. details에 `affected_documents_count` 기록
- `tag.renamed`: 태그 이름 변경. details에 `name_before`, `name_after` 기록
- `approval_template.created`: 결재라인 템플릿 생성. details에 단계 구성(승인 유형, approver_source/target, is_mandatory, name 등) 기록
- `approval_template.updated`: 결재라인 템플릿 수정. details에 변경 전/후 스냅샷 기록
- `approval_template.deleted`: 결재라인 템플릿 삭제. details에 연결된 게시판 수 기록
- `search_config.changed`: 검색 튜닝 설정 변경. details에 `config_key`, `before`, `after` 기록
- `parsing_config.changed`: 파싱 설정 변경. details에 `config_key`, `before`, `after` 기록
- `system_config.changed`: 시스템 설정 변경. details에 `config_key`, `before`, `after` 기록
- `prompt.updated`: AI 프롬프트 설정 변경. details에 `slot_key`, `before`, `after` 기록

권한 도메인:
- `role.created`: 역할 생성
- `role.updated`: 역할 수정 (BoardPermission/AdminPermission 구성 변경)
- `role.deactivated`: 역할 비활성
- `role.assigned`: 사용자에게 역할 부여 (UserRole)
- `role.unassigned`: 사용자 역할 해제
- `team.created`: 팀 생성
- `team.updated`: 팀 수정
- `team.member_added`: 팀 멤버 추가
- `team.member_removed`: 팀 멤버 제거
- `team.role_assigned`: 팀에 역할 부여 (TeamRole)
- `team.role_unassigned`: 팀 역할 해제
- `restriction.enabled`: 문서/블록 접근 제한 활성화. details에 `target_type`, `target_id` 기록
- `restriction.disabled`: 문서/블록 접근 제한 해제
- `restriction.whitelist_changed`: 화이트리스트 변경. details에 `added`, `removed` 기록

인증 도메인:
- `auth.login_success`: 로그인 성공. details에 `method` (ECP/자체) 기록
- `auth.login_failed`: 로그인 실패. details에 `reason`, `attempt_count` 기록
- `auth.logout`: 로그아웃
- `auth.session_expired`: 세션 만료
- `auth.suspicious_access`: 비정상 접근 감지

**리소스 타입 (resource_type)**
— `document`, `board`, `template`, `approval`, `approval_template`, `role`, `team`, `restriction`, `shared_content`, `tag`, `system_config`, `search_config`, `parsing_config`, `prompt`, `auth`, `comment`. `resource_type` + `resource_id`로 대상 리소스를 논리적으로 참조한다 (FK 없음).

**details JSONB 스냅샷**
— 변경 전/후 데이터를 `{"before": {...}, "after": {...}}` 구조로 저장한다. 삭제 시에는 `before`만, 생성 시에는 `after`만 기록한다.

**NestJS Interceptor 기반 전역 수집**
— NestJS Interceptor로 전역 동작하여 도메인 모듈에 대한 코드 레벨 의존이 없다. 별도 테이블로 운영 데이터와 분리하여 성능 영향을 최소화한다.

**actor_role 스냅샷**
— `actor_role`은 액션 수행 시점의 역할을 스냅샷으로 저장한다. 이후 역할이 변경되더라도 감사 로그에는 행위 시점의 역할이 남는다.

**보관 정책**
— 기본 1년(`audit.retention_days = 365`), 금융권 권장 5년. 보관 기간은 SystemConfig에서 설정한다. 기간 경과 후 콜드 스토리지로 아카이빙한다 (즉시 삭제가 아님).

**감사 범위**
— 문서 변경, 커뮤니티 상호작용(댓글), 권한 변경, 관리자 액션, 인증이 감사 대상이다. 문서 열람/검색 로그는 감사 대상에서 제외하고 별도 Access Log(ES `aicm_access_logs`)로 관리한다 ([06-cross-cutting-concerns.md](../../02-architecture/06-cross-cutting-concerns.md) §8.1.1 참조). 좋아요(Like)는 토글 빈도가 높아 감사 대상에서 제외하고 AggregationModule 집계로 추적한다.

**양방향 조회 지원 ((-코드) 패턴 대응)**
— 고객사 시스템에서 동일 이벤트를 행위자/대상자 관점으로 이중 로깅하는 패턴(예: 삭제(1009) vs 삭제(-1009))은 스키마 변경 없이 `actor_id` + `resource_id` + `details` 조합으로 양방향 조회가 가능하다.
- "내가 한 활동" = `WHERE actor_id = :userId`
- "나에게 일어난 일" = `WHERE resource_id IN (내 문서들) AND action IN (...)`
- details JSONB에 `target_user_id` 등 부가 컨텍스트를 기록한다 (예: 담당자변경 시 이전/이후 담당자, 멘션 시 대상 사용자 목록).

**이상 패턴 감지**
— 대량 삭제, 권한 일괄 변경 등 이상 패턴 감지 시 관리자에게 알림을 발송한다.

**ip_address VARCHAR(45)**
— IPv6 최대 길이(39자) + 여유분을 고려하여 45자로 설정한다.

---

## 3. DDL 및 인덱스

### 3.1 AuditLog

```sql
CREATE TABLE audit_log (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id      UUID NOT NULL,
  actor_role    VARCHAR(50),
  action        VARCHAR(50) NOT NULL,
  resource_type VARCHAR(30) NOT NULL,
  resource_id   UUID,
  details       JSONB,
  ip_address    VARCHAR(45),
  user_agent    TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 사용자별 이력: 특정 사용자의 활동 감사
CREATE INDEX idx_audit_log_actor_created
  ON audit_log (actor_id, created_at DESC);

-- 리소스별 이력: 특정 문서/게시판 등의 변경 이력 추적
CREATE INDEX idx_audit_log_resource_created
  ON audit_log (resource_type, resource_id, created_at DESC);

-- 액션 유형별 조회: 특정 유형의 감사 로그 필터링
CREATE INDEX idx_audit_log_action_created
  ON audit_log (action, created_at DESC);

-- 기간 조회 + 아카이빙 대상 선정
CREATE INDEX idx_audit_log_created
  ON audit_log (created_at);
```

### 3.2 파티셔닝 전략

금융권 5년 보관(`audit.retention_days = 1825`) 시 예상 볼륨:
- 일 평균 1,000건 × 365일 × 5년 = **약 180만 건** (활성 사용자 200명 기준)
- 활성 사용자 1,000명 이상이면 **수천만 건** 도달 가능

**권장: `created_at` 기반 RANGE 파티션 (월 단위)**

```sql
CREATE TABLE audit_log (
  ...
) PARTITION BY RANGE (created_at);

CREATE TABLE audit_log_2026_01 PARTITION OF audit_log
  FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');
-- 월별 파티션 자동 생성 (pg_partman 또는 앱 배치)
```

- 보관 기간 만료 시 `DROP TABLE audit_log_YYYY_MM` → 물리 삭제가 아닌 파티션 드롭으로 즉시 용량 회수
- 아카이빙 대상 파티션을 pg_dump로 콜드 스토리지에 백업 후 드롭
- 기간 조회 시 파티션 프루닝으로 스캔 범위가 자동 축소되어 성능 유지

**초기 구축 시**: 파티셔닝 없이 단일 테이블로 시작해도 무방. 데이터가 100만 건을 초과하거나 조회 성능이 저하되면 마이그레이션으로 파티셔닝을 도입한다.

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [system-config.md](../system-config/data.md) — SystemConfig (`audit.retention_days` 보관 기간 설정)
- [document.md](../document/data.md) — Document (감사 대상)
- [approval.md](../approval/data.md) — Approval, 삭제 요청 승인 (감사 대상)
- [community.md](../community/data.md) — Comment (감사 대상)
- [auth.md](../auth/data.md) — Role, UserRole (권한 변경 감사 대상)
- [notification.md](../notification/data.md) — Notification (이상 패턴 감지 시 알림)

---

## 부록: 고객사(날리지큐브) 통계 항목 매핑

고객사 통계 항목을 AICM 감사 로그 액션에 매핑한 표이다. (-코드)는 대상자 관점 이벤트로, AICM에서는 단일 레코드의 actor_id/resource_id 역방향 조회로 대응한다.

### A. audit_log에 매핑되는 항목

| 코드 | 고객사 항목 | AICM action | 비고 |
|------|------------|-------------|------|
| 1009 / -1009 | 삭제 | `document.deleted` | 소프트 딜리트 |
| 1025 / -1025 | 의견추가 | `community.comment_created` | resource_type=comment |
| 1027 / -1027 | 의견삭제 | `community.comment_deleted` | |
| 1029 / -1029 | 의견수정 | `community.comment_updated` | |
| 1034 / -1034 | 복원 | `document.restored` | |
| 1039 | 등록 | `document.status_changed` | status→published |
| 1047 / -1047 | 폐기 | `document.archived` | |
| 1059 / -1059 | 의견멘션 | `community.comment_mention` | details에 mentioned_user_ids |
| 1021 | 기간만료 | `document.expired` | 배치 처리, is_suspended=true |
| 1022 | 기간연장 | `document.extended` | details에 before/after 날짜 |
| 3001 | 최초작성 | `document.created` | |
| 3010 | 기본정보수정 | `document.updated` | |
| 3012 | 버전업 | `document.version_created` | |
| 3013 | 등록취소 | `approval.withdrawn` | |
| 3014 | 최초작성폐기 | `document.draft_discarded` | |
| 3015 / -3015 | 담당자변경 | `document.owner_changed` | details에 before/after assignee_id |
| 3101 | 시행요청 | `approval.submitted` | |
| 3111 / -3111 | 1차승인 | `approval.step_approved` | details.step_order=1 |
| 3112 / -3112 | 1차반려 | `approval.step_rejected` | details.step_order=1 |
| 3121 / -3121 | 2차승인 | `approval.step_approved` | details.step_order=2 |
| 3122 / -3122 | 2차반려 | `approval.step_rejected` | details.step_order=2 |
| 3151 | 삭제요청 | `approval.delete_submitted` | Approval.type=DELETE |
| 3161 / -3161 | 삭제요청1차승인 | `approval.delete_step_approved` | details.step_order=1 |
| 3162 / -3162 | 삭제요청1차반려 | `approval.delete_step_rejected` | details.step_order=1 |
| 3171 / -3171 | 삭제요청2차승인 | `approval.delete_step_approved` | details.step_order=2 |
| 3172 / -3172 | 삭제요청2차반려 | `approval.delete_step_rejected` | details.step_order=2 |
| 3180 | 요청 취소 | `approval.withdrawn` | |
| 3181 | 시행 요청 취소 | `approval.withdrawn` | |
| 3182 | 삭제 요청 취소 | `approval.delete_withdrawn` | |

### B. 미수용 항목

| 코드 | 고객사 항목 | 미수용 사유 |
|------|------------|-----------|
| 1013 | 첨부조회 | 접근 로그 영역. ES `aicm_access_logs`에 `action = 'ATTACHMENT_VIEW'`로 기록 ([es.md](../../02-architecture/data/aicm/es.md), [06-cross-cutting-concerns.md](../../02-architecture/06-cross-cutting-concerns.md) §8.1.1). 향후 문서 등급 도입 시 고등급 문서는 audit_log에도 이중 기록 가능 |
| 1031 / -1031 | 조회 / 피조회 | 접근 로그 영역. ES `aicm_access_logs`에 `action = 'VIEW'`로 기록. 볼륨 이슈로 audit_log에서는 제외하되, 향후 문서 등급 도입 시 고등급 문서는 audit_log에도 `document.viewed` 액션으로 이중 기록 가능 |
| 1054 / -1054 | 공감추가 | 토글 빈도 높아 감사 가치 낮음. AggregationModule 집계로 추적 |
| 1056 / -1056 | 공감삭제 | 동일 사유 |
| 3011 | 저장 | 노션 스타일 자동 저장으로 명시적 저장 이벤트 없음 |
| 3110 | 1차승인요청 | AICM은 단계 진입이 자동 — 별도 "요청" 이벤트 없음 |
| 3120 | 2차승인요청 | 동일 사유 |
| 3160 | 삭제요청1차승인요청 | 동일 사유 |
| 3170 | 삭제요청2차승인요청 | 동일 사유 |
| 3503 | DOC 첨부조회 | 접근 로그 영역. ES `aicm_access_logs`에 기록 (1013과 동일) |
