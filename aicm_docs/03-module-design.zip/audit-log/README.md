# AuditLog 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | AuditLogModule |
| 문서 코드 | MS-AUD |
| 상태 | `미착수` |
| 기능정의서 | [FD-AUD-감사로그](../../01-requirements/features/FD-AUD-감사로그.md) |
| 데이터 모델 | [audit-log-module.md](./data.md) |
| 프로세스 흐름 | [flows/audit-log/](../../01-requirements/flows/audit-log/) |

---

## 모듈 책임

<!-- TODO: 감사 로그 기록(Interceptor), 조회, 내보내기 -->

---

## 핵심 엔티티

| 엔티티 | 설명 |
|--------|------|
| AuditLog | |

---

## 의존 관계

<!-- TODO: AuditLog는 NestJS Interceptor로 전역 동작. EventBus에서 approval.approved, community.comment_created 등 소비 -->

```mermaid
graph LR
    %% TODO: 의존 관계 다이어그램 작성
```

---

## 인프라 사용 요약

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | | |
| Redis / BullMQ | | |
| Elasticsearch | | |
| MinIO | | |
| EventBus | | |
| 외부 서비스 클라이언트 | | |
