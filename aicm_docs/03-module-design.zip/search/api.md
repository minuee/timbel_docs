# Search API 스펙

> 기능정의서: [FD-SCH-검색](../../01-requirements/features/FD-SCH-검색.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [search-config-module.md](./data.md)

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| POST | /search | 키워드 검색 | VIEW (게시판 기반 필터) |
| POST | /search/rag | RAG 검색 (AI 답변) | VIEW (게시판 기반 필터) |
| GET | /search/autocomplete | 검색어 자동완성 | 인증 필요 |
| GET | /search/presets | 내 필터 프리셋 목록 | 인증 필요 |
| POST | /search/presets | 필터 프리셋 저장 | 인증 필요 |
| PUT | /search/presets/:id | 필터 프리셋 수정 | 인증 필요 (소유자) |
| DELETE | /search/presets/:id | 필터 프리셋 삭제 | 인증 필요 (소유자) |
| GET | /admin/search/config | 검색 설정 조회 | ADMIN (`manage_search`) |
| PUT | /admin/search/config | 검색 설정 수정 | ADMIN (`manage_search`) |
| GET | /admin/search/synonyms | 동의어 그룹 목록 | ADMIN (`manage_search`) |
| POST | /admin/search/synonyms | 동의어 그룹 추가 | ADMIN (`manage_search`) |
| PUT | /admin/search/synonyms/:groupId | 동의어 그룹 수정 | ADMIN (`manage_search`) |
| DELETE | /admin/search/synonyms/:groupId | 동의어 그룹 삭제 | ADMIN (`manage_search`) |
| GET | /admin/search/stopwords | 불용어 목록 | ADMIN (`manage_search`) |
| POST | /admin/search/stopwords | 불용어 추가 | ADMIN (`manage_search`) |
| DELETE | /admin/search/stopwords/:id | 불용어 삭제 | ADMIN (`manage_search`) |
| GET | /admin/search/boost-rules | 부스팅 규칙 목록 | ADMIN (`manage_search`) |
| POST | /admin/search/boost-rules | 부스팅 규칙 추가 | ADMIN (`manage_search`) |
| PUT | /admin/search/boost-rules/:id | 부스팅 규칙 수정 | ADMIN (`manage_search`) |
| DELETE | /admin/search/boost-rules/:id | 부스팅 규칙 삭제 | ADMIN (`manage_search`) |
| GET | /admin/search/board-rag-configs | 게시판별 RAG 설정 목록 | ADMIN (`manage_search`) |
| PUT | /admin/search/board-rag-configs/:boardId | 게시판별 RAG 설정 수정 | ADMIN (`manage_search`) |
| GET | /admin/search/dashboard | 검색 품질 대시보드 | ADMIN (`manage_search`) |
| GET | /admin/search/logs | 검색 이력 조회 | ADMIN (`manage_search`) |
| POST | /admin/search/logs/export | 검색 이력 내보내기 (CSV/PDF) | ADMIN (`manage_search`) |
| POST | /admin/search/exclude | 긴급 검색 제외 | ADMIN (`manage_search`) |
| POST | /admin/search/restore | 긴급 검색 복원 | ADMIN (`manage_search`) |

> 파싱 설정 API(`/admin/search/parsing-config`)는 [ParsingModule api.md](../parsing/api.md)를 참조한다.

---

## 상세 API

### `POST` /search

**설명**: 키워드 검색을 실행한다. SearchRepository를 통한 `aicm_blocks` 인덱스 풀텍스트 검색.

**권한**: VIEW (접근 가능 게시판의 문서만 반환)

**Request**:

- Body:

```typescript
interface KeywordSearchDto {
  query: string;                          // 필수 — 검색어
  filters?: {
    boardIds?: string[];                  // 대상 게시판 (하위 포함 옵션)
    categoryIds?: string[];               // 대상 카테고리 (하위 포함 옵션, FD-SCH §1)
    dateRange?: { from: string; to: string };  // 기간 필터 (ISO 8601)
    authorId?: string;                    // 작성자 필터
    tagIds?: string[];                    // 태그 필터
    templateId?: string;                  // 문서 양식(템플릿) 필터
    bookmarkOnly?: boolean;              // 내 북마크에서만 검색
  };
  sort?: 'relevance' | 'newest' | 'popular';  // 정렬 기준, 기본값: relevance
  page?: number;                          // 페이지 번호, 기본값: 1
  limit?: number;                         // 페이지당 결과 수, 기본값: 20, 최대: 100
}
```

**Response** (`200`):

```typescript
interface KeywordSearchResponse {
  items: SearchResultItem[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
  spellSuggestion: string | null;         // 오타 교정 제안어
}

interface SearchResultItem {
  documentId: string;
  title: string;
  snippet: string;                        // 본문 발췌 (하이라이팅 마크업 포함)
  highlights: Record<string, string[]>;   // 필드별 하이라이팅 텍스트
  score: number;                          // 검색 관련도 스코어
  boardId: string;
  boardName: string;
  authorName: string;
  tags: string[];
  embeddingStatus: EmbeddingStatus;
  publishedAt: string;
  isAdminBypass: boolean;                 // true이면 snippet, highlights 제거 [BR-SCH-004]
}
```

**비즈니스 규칙 참조**: BR-SCH-001 (필드별 검색), BR-SCH-002 (nori 형태소 분석), BR-SCH-003 (게시판 권한 필터), BR-SCH-004 (ADMIN 바이패스 제한), BR-SCH-005 (Restriction 문서 제외), BR-SCH-029 (긴급 검색 제외)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SCH_SEARCH_FAILED | 503 | — |
| SCH_PERMISSION_DENIED | 403 | [BR-SCH-003](rules.md#br-sch-003-게시판-권한-필터) |

---

### `POST` /search/rag

**설명**: RAG 검색을 실행한다. retrieval-service에 시맨틱/하이브리드 검색을 위임하고 LLM이 답변을 생성한다. retrieval-service 연동 인터페이스(`SearchHybridRequest`/`SearchHybridResponse`)는 [외부 서비스 연동 §7.3](../../02-architecture/06-external-integration.md#73-retrieval-servicefastapi-연동)을 참조한다.

**비고**: RAG 연동이 꺼진 경우 `403 FEATURE_DISABLED`

**권한**: VIEW (접근 가능 게시판의 문서만 RAG 소스에 포함)

**Request**:

- Body:

```typescript
interface RagSearchDto {
  query: string;                          // 필수 — 자연어 질의
  filters?: {
    boardIds?: string[];                  // 대상 게시판
    categoryIds?: string[];               // 대상 카테고리 (하위 포함 옵션, FD-SCH §1)
    tagIds?: string[];                    // 태그 필터
    templateId?: string;                  // 문서 양식 필터
  };
  answerStyle?: 'concise' | 'detailed';   // 답변 스타일, 기본값: concise
}
```

**Response** (`200`):

```typescript
interface RagSearchResponse {
  answer: string;                         // AI 생성 답변
  confidenceScore: number;                // 전체 답변 신뢰도 (0.0~1.0)
  disclaimer: string;                     // 면책 문구 [BR-SCH-011]
  sources: RagSource[];                   // 출처 문서 목록
  chunks: RagChunk[];                     // 참조된 청크 상세
}

interface RagSource {
  documentId: string;
  title: string;
  boardName: string;
  relevanceScore: number;
}

interface RagChunk {
  chunkId: string;
  documentId: string;
  content: string;
  similarityScore: number;
  grounded: boolean;                      // grounding check 통과 여부 [BR-SCH-010]
}
```

**비즈니스 규칙 참조**: BR-SCH-006 (RAG 게시판 권한), BR-SCH-007 (ADMIN 바이패스 RAG 제외), BR-SCH-008 (Restriction 문서 RAG 제외), BR-SCH-009 (임베딩 미완료 문서 제외), BR-SCH-010 (Hallucination 완화), BR-SCH-011 (면책 문구), BR-SCH-030 (긴급 검색 제외)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SCH_RAG_UNAVAILABLE | 503 | — |
| SCH_RAG_TIMEOUT | 504 | — |
| SCH_PERMISSION_DENIED | 403 | [BR-SCH-006](rules.md#br-sch-006-rag-게시판-권한-제한) |
| FEATURE_DISABLED | 403 | — (RAG 검색 비활성) |

---

### `GET` /search/autocomplete

**설명**: 검색어 자동완성 + 오타 교정 제안을 반환한다.

**권한**: 인증 필요

**Request**:

- Query params:

```typescript
interface AutocompleteQuery {
  q: string;                              // 필수 — prefix 검색어
  limit?: number;                         // 기본 10, 최대 20
}
```

**Response** (`200`):

```typescript
interface AutocompleteResponse {
  suggestions: string[];                  // 자동완성 제안어 목록
  spellCorrection: string | null;         // 오타 교정 제안
}
```

---

### `GET` /search/presets

**설명**: 내 검색 필터 프리셋 목록을 조회한다.

**권한**: 인증 필요 (소유자 본인 것만 반환)

**Response** (`200`):

```typescript
interface PresetListResponse {
  presets: PresetDto[];
}

interface PresetDto {
  id: string;
  name: string;
  filters: PresetFilters;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

interface PresetFilters {
  boardIds?: string[];
  categoryIds?: string[];                  // 대상 카테고리 (FD-SCH §6.7)
  dateRange?: { from: string; to: string };
  authorId?: string;
  tagIds?: string[];
  templateId?: string;
  bookmarkOnly?: boolean;
}
```

---

### `POST` /search/presets

**설명**: 검색 필터 프리셋을 저장한다.

**권한**: 인증 필요

**Request**:

- Body:

```typescript
interface CreatePresetDto {
  name: string;                           // 필수 — 프리셋 이름 (max 100자)
  filters: PresetFilters;                 // 필수 — 필터 조건
  sortOrder?: number;                     // 표시 순서
}
```

**Response** (`201`): `PresetDto`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SCH_PRESET_LIMIT_EXCEEDED | 422 | [BR-SCH-026](rules.md#br-sch-026-필터-프리셋-저장-상한) |

---

### `PUT` /search/presets/:id

**설명**: 검색 필터 프리셋을 수정한다.

**권한**: 인증 필요 (소유자)

**Request**:

- Body:

```typescript
interface UpdatePresetDto {
  name?: string;
  filters?: PresetFilters;
  sortOrder?: number;
}
```

**Response** (`200`): `PresetDto`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | 소유자만 수정 가능 |
| NOT_FOUND | 404 | 프리셋 미존재 |

---

### `DELETE` /search/presets/:id

**설명**: 검색 필터 프리셋을 삭제한다.

**권한**: 인증 필요 (소유자)

**Response** (`200`): `{ deleted: true }`

---

### `GET` /admin/search/config

**설명**: SearchConfig 전체를 조회한다. 동의어, 불용어, 부스팅, 게시판 RAG 설정 포함.

**권한**: ADMIN (`manage_search`)

**Response** (`200`):

```typescript
interface SearchConfigResponse {
  config: SearchConfigDto;
  synonyms: SynonymGroupDto[];
  stopWords: StopWordDto[];
  boostRules: BoostRuleDto[];
  boardRagConfigs: BoardRagConfigDto[];
}

interface SearchConfigDto {
  id: string;
  kwNoriUserDict: string[];
  kwTitleWeight: number;
  kwBodyWeight: number;
  kwCaptionWeight: number;
  kwTagWeight: number;
  kwCommentWeight: number;
  ragDefaultSearchMode: 'keyword' | 'semantic' | 'hybrid';
  ragHybridBm25Weight: number;
  ragHybridVectorWeight: number;
  ragRrfK: number;
  ragRerankEnabled: boolean;
  ragRerankModel: string | null;
  ragRerankTopN: number | null;
  ragTopK: number;
  ragWindowContextSize: number;
  ragSimilarityThreshold: number;
  updatedBy: string;                      // 최종 수정자 UUID
  updatedAt: string;
  version: number;                        // OCC 버전 [BR-SCH-031]
}

interface SynonymGroupDto {
  id: string;
  groupName: string;
  words: string[];
  isActive: boolean;
}

interface StopWordDto {
  id: string;
  word: string;
  isActive: boolean;
}

interface BoostRuleDto {
  id: string;
  name: string;
  targetType: 'board' | 'tag' | 'document';
  targetId: string;
  targetName: string;                     // 보강 필드 — 대상 이름
  boostWeight: number;
  isActive: boolean;
}

interface BoardRagConfigDto {
  id: string;
  boardId: string;
  boardName: string;
  ragEnabled: boolean;
  topK: number | null;
  similarityThreshold: number | null;
}
```

---

### `PUT` /admin/search/config

**설명**: SearchConfig 핵심 파라미터를 수정한다. 낙관적 동시성 제어(OCC) 적용.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface UpdateSearchConfigDto {
  version: number;                        // 필수 — OCC 비교용 [BR-SCH-031]
  kwNoriUserDict?: string[];
  kwTitleWeight?: number;
  kwBodyWeight?: number;
  kwCaptionWeight?: number;
  kwTagWeight?: number;
  kwCommentWeight?: number;
  ragDefaultSearchMode?: 'keyword' | 'semantic' | 'hybrid';
  ragHybridBm25Weight?: number;
  ragHybridVectorWeight?: number;
  ragRrfK?: number;
  ragRerankEnabled?: boolean;
  ragRerankModel?: string | null;
  ragRerankTopN?: number | null;
  ragTopK?: number;
  ragWindowContextSize?: number;
  ragSimilarityThreshold?: number;
}
```

**Response** (`200`): `SearchConfigDto` (새 `version` 포함)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SCH_CONFIG_VERSION_CONFLICT | 409 | [BR-SCH-031](rules.md#br-sch-031-설정-저장-occ) |
| FORBIDDEN | 403 | `manage_search` 권한 없음 |

**비즈니스 규칙 참조**: BR-SCH-024 (설정 변경 캐시 무효화), BR-SCH-031 (OCC)

> **retrieval-service 설정 동기화**: `rag_*` 파라미터 변경 시 retrieval-service에 `PUT /config`로 push 동기화한다. 요청/응답 타입(`UpdateRetrievalConfigRequest`/`UpdateRetrievalConfigResponse`)은 [외부 서비스 연동 §7.3](../../02-architecture/06-external-integration.md#73-retrieval-servicefastapi-연동)을 참조한다.

---

### `POST` /admin/search/synonyms

**설명**: 동의어 그룹을 추가한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface CreateSynonymGroupDto {
  groupName: string;                      // 필수 — 그룹명
  words: string[];                        // 필수 — 동의어 목록 (최소 2개)
}
```

**Response** (`201`): `SynonymGroupDto`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SCH_SYNONYM_CONFLICT | 422 | 동의어가 불용어 목록에 존재하거나 순환 참조 |

---

### `PUT` /admin/search/synonyms/:groupId

**설명**: 동의어 그룹을 수정한다.

**권한**: ADMIN (`manage_search`)

**Request**: `CreateSynonymGroupDto`와 동일 구조

**Response** (`200`): `SynonymGroupDto`

---

### `DELETE` /admin/search/synonyms/:groupId

**설명**: 동의어 그룹을 삭제한다.

**권한**: ADMIN (`manage_search`)

**Response** (`200`): `{ deleted: true }`

---

### `POST` /admin/search/stopwords

**설명**: 불용어를 추가한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface CreateStopWordDto {
  word: string;                           // 필수 — 불용어
}
```

**Response** (`201`): `StopWordDto`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| SCH_SYNONYM_CONFLICT | 422 | 불용어가 동의어 목록에 존재 |

---

### `POST` /admin/search/boost-rules

**설명**: 부스팅 규칙을 추가한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface CreateBoostRuleDto {
  name: string;                           // 필수 — 규칙명
  targetType: 'board' | 'tag' | 'document';
  targetId: string;                       // 필수 — 대상 UUID
  boostWeight: number;                    // 필수 — 가중치 (> 0)
}
```

**Response** (`201`): `BoostRuleDto`

---

### `PUT` /admin/search/boost-rules/:id

**설명**: 부스팅 규칙을 수정한다.

**권한**: ADMIN (`manage_search`)

**Request**:

```typescript
interface UpdateBoostRuleDto {
  name?: string;
  boostWeight?: number;
  isActive?: boolean;
}
```

**Response** (`200`): `BoostRuleDto`

---

### `PUT` /admin/search/board-rag-configs/:boardId

**설명**: 게시판별 RAG 설정을 수정한다. 없으면 생성.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface UpdateBoardRagConfigDto {
  ragEnabled: boolean;
  topK?: number | null;
  similarityThreshold?: number | null;
}
```

**Response** (`200`): `BoardRagConfigDto`

---

### `GET` /admin/search/dashboard

**설명**: 검색 품질·성능 지표를 조회한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Query params:

```typescript
interface DashboardQuery {
  period?: '24h' | '7d' | '30d';          // 집계 기간, 기본값: 24h
}
```

**Response** (`200`):

```typescript
interface SearchDashboardResponse {
  keywordSearch: {
    totalCount: number;
    zeroResultRate: number;               // %
    avgResponseMs: number;
  };
  ragSearch: {
    totalCount: number;
    avgConfidenceScore: number;
    positiveFeedbackRate: number;          // %
    hallucinationRate: number;             // 신뢰도 < 0.5 비율
  };
  indexStatus: {
    pendingDocuments: number;
    failedDocuments: number;
  };
  topKeywords: { keyword: string; count: number }[];
  zeroResultKeywords: { keyword: string; count: number }[];
}
```

---

### `GET` /admin/search/logs

**설명**: 검색 이력을 조회한다. 금융권 감사 대비.

**권한**: ADMIN (`manage_search`)

**Request**:

- Query params:

```typescript
interface SearchLogQuery {
  from?: string;                          // 조회 시작 (ISO 8601)
  to?: string;                            // 조회 종료 (ISO 8601)
  searchType?: 'keyword' | 'rag';
  userId?: string;
  page?: number;                          // 기본값 1
  limit?: number;                         // 기본값 50, 최대 200
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface SearchLogDto {
  id: string;
  userId: string;
  userName: string;
  query: string;
  searchType: 'keyword' | 'rag';
  filters: Record<string, any> | null;
  resultCount: number;
  clickedDocumentIds: string[] | null;
  ragSourceChunkIds: string[] | null;
  ragConfidenceScore: number | null;
  responseTimeMs: number;
  createdAt: string;
}
```

---

### `POST` /admin/search/logs/export

**설명**: 검색 이력을 CSV 또는 PDF로 내보낸다. 비동기로 처리되며, ExportModule(`export` 큐)에 파일 생성을 위임한다. FD-SCH §6.6 참조.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface SearchLogExportDto {
  format: 'csv' | 'pdf';                  // 필수 — 내보내기 형식
  from?: string;                          // 조회 시작 (ISO 8601)
  to?: string;                            // 조회 종료 (ISO 8601)
  searchType?: 'keyword' | 'rag';         // 검색 방식 필터
  userId?: string;                        // 특정 사용자 필터
}
```

**Response** (`202`):

```typescript
interface ExportJobResponse {
  jobId: string;                          // export 큐 Job ID
  status: 'queued';
}
```

> 파일 생성·다운로드는 ExportModule에 위임한다. 완료 시 관리자에게 인앱 알림 + 다운로드 링크를 제공한다.

---

### `POST` /admin/search/exclude

**설명**: 긴급 검색 제외를 실행한다. 특정 문서 또는 게시판 전체를 키워드/RAG 검색 결과에서 즉시 제외한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface SearchExcludeDto {
  targetType: 'document' | 'board';
  targetId: string;                       // 문서 ID 또는 게시판 ID
  reason: string;                         // 필수 — 제외 사유 (감사 로그 기록)
}
```

**Response** (`200`):

```typescript
interface SearchExcludeResponse {
  targetType: string;
  targetId: string;
  excludedAt: string;
  affectedDocumentCount: number;          // 제외된 문서 수 (게시판 전체 제외 시)
}
```

**비즈니스 규칙 참조**: BR-SCH-029, BR-SCH-030

---

### `POST` /admin/search/restore

**설명**: 긴급 검색 제외를 복원한다.

**권한**: ADMIN (`manage_search`)

**Request**:

- Body:

```typescript
interface SearchRestoreDto {
  targetType: 'document' | 'board';
  targetId: string;
  reason: string;                         // 필수 — 복원 사유
}
```

**Response** (`200`):

```typescript
interface SearchRestoreResponse {
  targetType: string;
  targetId: string;
  restoredAt: string;
  affectedDocumentCount: number;
}
```

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED, EXTERNAL_SERVICE_UNAVAILABLE 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **Search 도메인 에러** 전체 목록은 [rules.md §3 에러 코드 카탈로그](rules.md#3-에러-코드-카탈로그) 참조

---

## 공통 타입

```typescript
type EmbeddingStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'partial' | 'skipped';
```

---

## retrieval-service 연동 인터페이스

SearchModule이 retrieval-service에 위임하는 API의 요청/응답 타입은 이 문서가 아닌 아키텍처 문서에서 정의한다. 구현 시 아래 문서를 참조한다.

| 기능 | 엔드포인트 | 타입 정의 위치 |
|------|-----------|--------------|
| 임베딩 (청킹+벡터 생성) | `POST /ingest/embed` | [외부 서비스 연동 §7.3](../../02-architecture/06-external-integration.md#73-retrieval-servicefastapi-연동) — `IngestEmbedRequest` / `IngestEmbedResponse` |
| 재임베딩 | `POST /ingest/re-embed` | 동일 문서 — `IngestReEmbedRequest` / `IngestEmbedResponse` |
| 임베딩 삭제 (단건) | `DELETE /sources/{sourceId}` | 동일 문서 — `DeleteSourceResponse` |
| 임베딩 삭제 (배치) | `DELETE /sources` | 동일 문서 — `BatchDeleteSourcesRequest` / `BatchDeleteSourcesResponse` |
| 메타데이터 갱신 | `PATCH /sources/{sourceId}/metadata` | 동일 문서 — `UpdateSourceMetadataRequest` / `UpdateSourceMetadataResponse` |
| 청크 목록 조회 | `GET /sources/{sourceId}/chunks` | 동일 문서 — `ListChunksResponse` |
| 시맨틱/하이브리드 검색 | `POST /search` | 동일 문서 — `SearchRequest` / `SearchResponse` |
| 검색 설정 push | `PUT /config` | 동일 문서 — `UpdateRetrievalConfigRequest` / `UpdateRetrievalConfigResponse` |
| 헬스체크 | `GET /health` | 동일 문서 — `HealthResponse` |
| 청킹 설정 (공유 타입) | — | 동일 문서 — `ChunkingConfig` |
