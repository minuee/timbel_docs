# Search 캐시 설계

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 캐시 대상 요약

| # | 대상 | 전략 | 키 패턴 | TTL | 참조 |
|---|------|------|---------|-----|------|
| C1 | SearchConfig | Cache-Aside | `cache:search:config` | 30m | §2.1 |
| C2 | 자동완성 결과 | Cache-Aside | `cache:search:autocomplete:{prefix}` | 10m | §2.2 |

---

## 2. 캐시 상세

### 2.1 SearchConfig 캐시 (C1)

| 항목 | 내용 |
|------|------|
| **대상** | SearchConfig 싱글톤 + 하위 엔티티 (Synonym, StopWord, BoostRule, BoardRagConfig) |
| **전략** | Cache-Aside (읽기 시 캐시 미스 → DB 조회 → 캐시 적재) |
| **키** | `cache:search:config` |
| **TTL** | 1800s (30m) |
| **직렬화** | JSON (msgpack 고려 가능, 현재 JSON으로 충분) |
| **크기 제한** | 약 10~50KB (동의어/불용어 수에 비례) |

**읽기 흐름**:

```mermaid
sequenceDiagram
    participant Service as SearchService
    participant Redis
    participant DB as PostgreSQL
    Service->>Redis: GET cache:search:config
    alt 캐시 히트
        Redis-->>Service: JSON (SearchConfig + 하위 엔티티)
    else 캐시 미스
        Service->>DB: SELECT SearchConfig + JOIN 하위 엔티티
        DB-->>Service: 결과
        Service->>Redis: SET cache:search:config (TTL 1800s)
        Redis-->>Service: OK
    end
```

**무효화 트리거**:

| 트리거 | 동작 |
|--------|------|
| `PUT /admin/search/config` 성공 | `DEL cache:search:config` |
| 동의어/불용어/부스팅/BoardRagConfig CUD | `DEL cache:search:config` |
| `search.config.updated` 이벤트 수신 (다른 인스턴스) | `DEL cache:search:config` |

**Warm-up 전략**:

- 애플리케이션 부트스트랩 시 `onModuleInit()`에서 SearchConfig 캐시를 선제적으로 적재한다.
- 캐시 무효화 후 즉시 재적재하지 않고, 다음 읽기 요청 시 Lazy Load한다 (write-through가 아닌 cache-aside).

**Fallback**:

- Redis 장애 시: DB 직접 조회로 폴백. 매 요청마다 DB를 조회하므로 성능 저하가 발생하나, 기능 정상 동작.
- 캐시 + DB 모두 실패 시: `SCH_SEARCH_FAILED` (503) 반환.

---

### 2.2 자동완성 캐시 (C2)

| 항목 | 내용 |
|------|------|
| **대상** | 자동완성 API 응답 (prefix → 제안어 목록) |
| **전략** | Cache-Aside |
| **키** | `cache:search:autocomplete:{prefix}` (prefix는 소문자 정규화 후 앞 3~5글자) |
| **TTL** | 600s (10m) |
| **직렬화** | JSON string array |
| **크기 제한** | 약 1KB 이하/키 |

**무효화 트리거**:

| 트리거 | 동작 |
|--------|------|
| SearchConfig 변경 (동의어/불용어 변경) | prefix 패턴 일괄 삭제: `DEL cache:search:autocomplete:*` (SCAN 기반) |
| 문서 발행/삭제/업데이트 이벤트 | 무효화하지 않음 — TTL 만료로 자연 갱신 (10분 지연 허용) |

**Fallback**:

- Redis 장애 시: ES suggest API 직접 호출로 폴백. 지연 증가(~100ms)하나 정상 동작.

---

## 3. 분산 락

SearchModule은 자체적으로 분산 락을 사용하지 않는다. 검색 설정 수정은 OCC(Optimistic Concurrency Control)로 동시성을 제어한다 ([BR-SCH-031](rules.md#br-sch-031-설정-저장-occ)).

스케줄링 배치 작업(Reconciliation, 아카이빙)의 동시 실행 방지를 위한 분산 락은 [schedule.md](schedule.md)에서 다룬다.

---

## 4. 서킷브레이커 상태 (Redis 저장)

외부 서비스 호출의 서킷브레이커 상태는 Redis에 저장된다.

| 키 패턴 | 대상 | TTL |
|---------|------|-----|
| `{tenant_id}:circuit:retrieval-service` | RetrievalServiceClient | 상태 전이 시 갱신, Half-Open 타임아웃에 따라 자동 만료 |

> 서킷브레이커 구현 상세는 [횡단 관심사 §8.5](../../02-architecture/07-cross-cutting-concerns.md) 참조.

> 파싱 관련 외부 서비스(parser-service, LLM Orchestrator) 서킷브레이커는 [ParsingModule](../parsing/)을 참조한다.
