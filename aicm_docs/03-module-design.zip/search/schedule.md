# Search 스케줄/배치 작업

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 작업 요약

| # | 작업명 | cron 설정 키 | 기본 주기 | 용도 |
|---|--------|-------------|----------|------|
| S1 | ES 인덱싱 Reconciliation | `sc:search.es_recon_cron` | `*/30 * * * *` (30분마다) | RDB ↔ ES 불일치 보정 |
| S2 | SearchLog 아카이빙 | `sc:search.log_archive_cron` | `0 2 1 * *` (매월 1일 02:00) | 5년 초과 SearchLog 아카이빙 + 원본 삭제 |

---

## 2. 작업 상세

### 2.1 ES 인덱싱 Reconciliation (S1)

| 항목 | 내용 |
|------|------|
| **cron** | `sc:search.es_recon_cron` — 기본값 `*/30 * * * *` |
| **BR 참조** | [BR-SCH-044](rules.md#br-sch-044-es-인덱싱-reconciliation) |

**대상 조건**:

- RDB에서 `status = 'published'`이고 `deleted_at IS NULL`인 문서 목록
- ES `aicm_blocks` 인덱스의 문서 ID 목록

**처리 절차**:

```mermaid
flowchart TD
    START([Reconciliation 시작]) --> LOCK{분산 락 획득}
    LOCK -- 실패 --> SKIP([이미 실행 중 — 스킵])
    LOCK -- 성공 --> FETCH_RDB[RDB published 문서 ID 목록 조회]
    FETCH_RDB --> FETCH_ES[ES 인덱싱된 문서 ID 목록 조회]
    FETCH_ES --> COMPARE[차집합 계산]
    COMPARE --> MISSING{RDB에 있고<br/>ES에 없는 문서?}
    MISSING -- 있음 --> REINDEX[es-indexing 큐에 재인덱싱 Job 추가]
    MISSING -- 없음 --> ORPHAN{ES에 있고<br/>RDB에 없는 문서?}
    REINDEX --> ORPHAN
    ORPHAN -- 있음 --> DELETE[ES에서 고아 문서 삭제]
    ORPHAN -- 없음 --> LOG[결과 로그 기록]
    DELETE --> LOG
    LOG --> RELEASE[분산 락 해제]
    RELEASE --> END([완료])
```

1. **분산 락 획득**: `{tenant_id}:lock:search:es-recon` (Redis, TTL 10m)
2. **RDB 조회**: `SELECT id FROM documents WHERE status = 'published' AND deleted_at IS NULL`
3. **검색 엔진 조회**: SearchRepository를 통해 인덱싱된 `document_id` 목록 수집 (ElasticsearchSearchAdapter에서는 `_search` 또는 `_scroll` 사용)
4. **누락 문서 보정**: RDB에 있으나 ES에 없는 문서 → `es-indexing` 큐에 재인덱싱 Job 추가
5. **고아 문서 정리**: ES에 있으나 RDB에 없는(또는 unpublished) 문서 → ES에서 삭제
6. **결과 로그**: 보정 건수, 소요 시간 기록

**동시 실행 제어**:

| 항목 | 내용 |
|------|------|
| 분산 락 키 | `{tenant_id}:lock:search:es-recon` |
| 락 TTL | 600s (10m) — 작업 최대 예상 시간 |
| 획득 실패 시 | 해당 주기 스킵 (다음 주기에 재시도) |

**실패 처리**:

| 단계 | 실패 시 |
|------|--------|
| 분산 락 획득 | 스킵 |
| RDB 조회 실패 | ERROR 로그, 락 해제, 종료 |
| ES 조회 실패 | ERROR 로그, 락 해제, 종료 |
| 개별 문서 재인덱싱 실패 | 해당 문서 건너뛰고 계속 (실패 문서는 다음 주기에 재시도) |
| 3회 연속 전체 실패 | WARNING 알림 (Slack) |

---

### 2.2 SearchLog 아카이빙 (S2)

| 항목 | 내용 |
|------|------|
| **cron** | `sc:search.log_archive_cron` — 기본값 `0 2 1 * *` |
| **BR 참조** | [BR-SCH-025](rules.md#br-sch-025-searchlog-보관-정책) |
| **보관 기간** | `lm:search.log_retention_years` — 기본 5년 |

**대상 조건**:

```sql
SELECT * FROM search_log
WHERE created_at < NOW() - INTERVAL '${retentionYears} years'
ORDER BY created_at ASC
```

**처리 절차**:

```mermaid
flowchart TD
    START([아카이빙 시작]) --> LOCK{분산 락 획득}
    LOCK -- 실패 --> SKIP([이미 실행 중 — 스킵])
    LOCK -- 성공 --> QUERY[보관 기간 초과 로그 조회]
    QUERY --> HAS_DATA{대상 존재?}
    HAS_DATA -- 없음 --> RELEASE[분산 락 해제]
    HAS_DATA -- 있음 --> BATCH[배치 단위로 처리<br/>1000건/배치]
    BATCH --> INSERT[아카이브 테이블에 INSERT]
    INSERT --> VERIFY[INSERT 건수 검증]
    VERIFY --> DELETE_ORIG[원본 테이블에서 DELETE]
    DELETE_ORIG --> MORE{남은 배치?}
    MORE -- 있음 --> BATCH
    MORE -- 없음 --> LOG[결과 로그 기록]
    LOG --> RELEASE
    RELEASE --> END([완료])
```

1. **분산 락 획득**: `{tenant_id}:lock:search:log-archive` (Redis, TTL 30m)
2. **대상 조회**: 보관 기간 초과 SearchLog 레코드
3. **배치 처리** (1000건 단위):
   - 아카이브 테이블(`search_log_archive`)에 INSERT
   - INSERT 건수와 대상 건수 일치 확인
   - 원본 테이블에서 DELETE
   - 트랜잭션 단위: 배치 1건 (INSERT + DELETE를 하나의 트랜잭션으로)
4. **결과 로그**: 아카이빙 건수, 소요 시간 기록

**동시 실행 제어**:

| 항목 | 내용 |
|------|------|
| 분산 락 키 | `{tenant_id}:lock:search:log-archive` |
| 락 TTL | 1800s (30m) |
| 획득 실패 시 | 해당 주기 스킵 |

**실패 처리**:

| 단계 | 실패 시 |
|------|--------|
| 분산 락 획득 | 스킵 |
| 아카이브 INSERT 실패 | 트랜잭션 롤백, ERROR 로그, 해당 배치 중단 후 다음 배치 계속 |
| 원본 DELETE 실패 | 트랜잭션 롤백 (INSERT도 롤백), ERROR 로그 |
| 3회 연속 전체 실패 | WARNING 알림 (Slack) |
| 보관 기간 미만 삭제 시도 | **차단** — 보관 기간 검증을 DELETE WHERE 조건에 재확인 |

**데이터 무결성 보장**:

- 아카이브 INSERT 후 건수 검증을 반드시 수행한다.
- DELETE WHERE 조건에 `created_at < threshold` 를 반드시 포함하여, 보관 기간 미만 데이터가 삭제되는 것을 원천 방지한다.
- 배치 처리 중 오류 발생 시 해당 배치만 롤백하고, 이전 성공 배치는 유지한다.

---

## 3. 설정 키 카탈로그

| 설정 키 | 타입 | 기본값 | 설명 |
|---------|------|--------|------|
| `sc:search.es_recon_cron` | string | `*/30 * * * *` | ES Reconciliation 실행 주기 |
| `sc:search.log_archive_cron` | string | `0 2 1 * *` | SearchLog 아카이빙 실행 주기 |
| `lm:search.log_retention_years` | number | 5 | SearchLog 보관 기간 (년) |
