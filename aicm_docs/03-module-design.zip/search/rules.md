# Search 비즈니스 규칙

> 원천: [FD-SCH-검색 §6](../../01-requirements/features/FD-SCH-검색.md)
> API 스펙: [api.md](api.md)

---

## 1. 상태 전이

> 문서 파싱 상태 전이는 [ParsingModule rules.md](../parsing/rules.md)를 참조한다.

### 1.1 검색 설정 변경 동기화 흐름

```mermaid
stateDiagram-v2
    [*] --> config_saved: 관리자 설정 수정
    config_saved --> cache_invalidated: Redis 캐시 삭제
    cache_invalidated --> event_published: search.config.updated 발행
    event_published --> es_synced: ES 인덱스 설정 반영 완료
    event_published --> retrieval_pushed: retrieval-service 캐시 무효화
    es_synced --> [*]
    retrieval_pushed --> [*]
```

---

## 2. 비즈니스 규칙 카탈로그

> BR-SCH-012~023, BR-SCH-040~043은 파싱/청킹 관련 규칙으로, [ParsingModule rules.md](../parsing/rules.md)의 BR-PRS-*로 이관되었다. 기존 번호 체계는 외부 참조 호환성을 위해 유지한다.

### BR-SCH-001 — 키워드 검색 필드별 가중치

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` 요청 시 |
| **조건** | 항상 |
| **동작** | SearchRepository를 통해 키워드 검색 시 `title^{kwTitleWeight}`, `body^{kwBodyWeight}`, `caption^{kwCaptionWeight}`, `tag^{kwTagWeight}`, `comment^{kwCommentWeight}` 가중치를 SearchConfig 값으로 적용한다. ElasticsearchSearchAdapter에서는 ES multi_match 쿼리로 구현한다. |
| **위반 시** | — (항상 적용) |

---

### BR-SCH-002 — nori 형태소 분석

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search`, `GET /search/autocomplete` |
| **조건** | 항상 |
| **동작** | 검색 쿼리에 nori_tokenizer를 적용한다. 사용자 사전(`kw_nori_user_dict`)에 등록된 복합명사는 단일 토큰으로 처리한다. |
| **위반 시** | — |

---

### BR-SCH-003 — 게시판 권한 필터 (키워드)

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` |
| **조건** | 요청 사용자가 ADMIN이 아닌 경우 |
| **동작** | PermissionModule에서 사용자의 VIEW 권한이 있는 게시판 ID 목록을 조회하여 SearchRepository에 게시판 필터로 전달한다. ElasticsearchSearchAdapter에서는 ES `terms` 필터로 주입한다. 조회 결과에는 해당 게시판의 문서만 포함된다. |
| **위반 시** | 권한 없는 게시판의 문서는 결과에서 제외됨 |

---

### BR-SCH-004 — ADMIN 바이패스 스니펫 제한

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` |
| **조건** | 결과 문서에 대해 요청자가 VIEW 권한은 없지만 ADMIN 바이패스로 포함된 경우 |
| **동작** | `isAdminBypass: true`로 표시하고, `snippet`과 `highlights`를 빈 문자열/빈 배열로 반환한다. 제목·메타데이터만 노출한다. |
| **위반 시** | 민감한 본문이 ADMIN 검색에 의해 노출됨 |

---

### BR-SCH-005 — Restriction 문서 키워드 검색 제외

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` |
| **조건** | 문서에 DocumentRestriction이 설정되어 있고, 요청자가 허용 목록(allowedUsers/allowedRoles)에 포함되지 않는 경우 |
| **동작** | 해당 문서를 검색 결과에서 완전히 제외한다. ADMIN 바이패스 대상도 아니다. |
| **위반 시** | 제한 문서가 비허용 사용자에게 노출됨 |

---

### BR-SCH-006 — RAG 게시판 권한 제한

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | 항상 |
| **동작** | 사용자의 VIEW 권한이 있는 게시판의 문서만 RAG 소스(청크 검색 대상)에 포함한다. retrieval-service에 `boardIds` 필터를 전달한다. |
| **위반 시** | SCH_PERMISSION_DENIED (403) |

---

### BR-SCH-007 — ADMIN 바이패스 RAG 제외

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | ADMIN이 VIEW 권한 없는 게시판 문서에 접근 시 |
| **동작** | RAG 검색에서는 키워드 검색과 달리 ADMIN 바이패스를 적용하지 않는다. VIEW 권한이 없는 게시판의 문서는 RAG 소스에서 완전히 제외된다. |
| **위반 시** | — (보안 정책) |

---

### BR-SCH-008 — Restriction 문서 RAG 제외

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | 문서에 DocumentRestriction 설정 시 |
| **동작** | BR-SCH-005와 동일하게 RAG 소스에서도 제외한다. |
| **위반 시** | 제한 문서의 내용이 AI 답변에 포함됨 |

---

### BR-SCH-009 — 임베딩 미완료 문서 RAG 제외

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | 문서의 `embedding_status` ≠ `completed` |
| **동작** | 임베딩이 완료되지 않은 문서는 RAG 소스에서 제외한다. 키워드 검색에는 영향 없음. |
| **위반 시** | — (벡터 검색 불가) |

---

### BR-SCH-010 — Hallucination 완화 (Grounding Check)

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | RAG 답변 생성 시 |
| **동작** | 각 청크에 대해 grounding check를 수행한다. 답변에 포함된 내용이 실제 소스 청크에 존재하는지 검증하고, 각 `RagChunk.grounded` 플래그를 설정한다. 전체 `confidenceScore`가 임계값 미만이면 경고를 포함한다. |
| **위반 시** | — (품질 보장 로직) |

---

### BR-SCH-011 — AI 면책 문구

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | 항상 |
| **동작** | RAG 응답에 `disclaimer` 필드를 포함한다. "AI가 생성한 답변이며, 정확성을 보장하지 않습니다. 중요한 결정에는 원문을 확인하세요." |
| **위반 시** | — (필수 포함) |

---

### BR-SCH-024 — 설정 변경 시 캐시 무효화

| 항목 | 내용 |
|------|------|
| **트리거** | SearchConfig 수정 시 |
| **조건** | 항상 |
| **동작** | ① Redis `cache:search:config` 삭제 ② `search.config.updated` 이벤트 발행 ③ retrieval-service에 설정 push |
| **위반 시** | 오래된 설정으로 검색 수행됨 |

---

### BR-SCH-025 — SearchLog 보관 정책

| 항목 | 내용 |
|------|------|
| **트리거** | SearchLog 아카이빙 배치 실행 시 |
| **조건** | `created_at` + 보관기간(`lm:search.log_retention_years`, 기본 5년) 초과 |
| **동작** | 보관 기간 초과 SearchLog를 아카이브 테이블로 이동(cold storage). 원본 삭제. |
| **위반 시** | 법적 보관 의무 위반 — 삭제 전 반드시 아카이빙 확인 |

---

### BR-SCH-026 — 필터 프리셋 저장 상한

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/presets` |
| **조건** | 사용자의 프리셋 수 ≥ `lm:search.preset_max_count` (기본 20) |
| **동작** | 요청을 거부한다. |
| **위반 시** | `SCH_PRESET_LIMIT_EXCEEDED` (422) |

---

### BR-SCH-027 — 프리셋 게시판 삭제 처리

| 항목 | 내용 |
|------|------|
| **트리거** | 검색 필터 프리셋 적용 시 |
| **조건** | 프리셋 내 필터 대상 게시판이 삭제된 경우 |
| **동작** | 삭제된 게시판 조건을 제외하고 나머지 조건만으로 검색을 실행한다. "일부 게시판이 삭제되어 필터에서 제외되었습니다" 안내 메시지를 표시한다. |
| **위반 시** | — |

---

### BR-SCH-028 — 프리셋 태그 변경 처리

| 항목 | 내용 |
|------|------|
| **트리거** | 검색 필터 프리셋 적용 시 |
| **조건** | 프리셋 내 필터 대상 태그가 삭제 또는 병합된 경우 |
| **동작** | 태그 병합 시 새 태그명으로 자동 전환하고, 태그 삭제 시 해당 조건을 제외한 뒤 나머지로 검색을 실행한다. 안내 메시지를 표시한다. |
| **위반 시** | — |

---

### BR-SCH-029 — 긴급 검색 제외 (키워드)

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /admin/search/exclude` |
| **조건** | `manage_search` 권한 |
| **동작** | 대상 문서(또는 게시판 전체)를 SearchRepository를 통해 검색 인덱스에서 `is_excluded: true`로 마킹하여 키워드 검색 결과에서 즉시 제외한다. 감사 로그에 사유를 기록한다. |
| **위반 시** | — |

---

### BR-SCH-030 — 긴급 검색 제외 (RAG)

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /admin/search/exclude` |
| **조건** | `manage_search` 권한, RAG 연동 활성 |
| **동작** | 대상 문서의 벡터 임베딩을 retrieval-service에서 비활성화(soft-delete)하여 RAG 소스에서도 제외한다. |
| **위반 시** | — |

---

### BR-SCH-031 — 설정 저장 OCC

| 항목 | 내용 |
|------|------|
| **트리거** | `PUT /admin/search/config` |
| **조건** | 요청의 `version` ≠ DB의 현재 `version` |
| **동작** | 충돌을 감지하여 요청을 거부한다. 클라이언트는 최신 `version`을 다시 조회한 후 재시도해야 한다. |
| **위반 시** | `SCH_CONFIG_VERSION_CONFLICT` (409) |

---

## 2.1 모듈 구현 규칙 (BR-SCH-032+)

> FD-SCH에 정의되지 않은 모듈 구현 수준의 비즈니스 규칙이다.

### BR-SCH-032 — 동의어 적용

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` |
| **조건** | SearchConfig.synonyms에 활성(`is_active=true`) 동의어 그룹이 존재 |
| **동작** | SearchRepository를 통해 검색 엔진의 동의어 설정에 반영하여 (ElasticsearchSearchAdapter에서는 ES nori synonym filter로 구현), 검색어가 동의어 그룹 내 다른 단어와 매칭되도록 한다. |
| **위반 시** | — |

---

### BR-SCH-033 — 불용어 제외

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` |
| **조건** | SearchConfig.stopWords에 활성 불용어 존재 |
| **동작** | 검색 쿼리에서 불용어를 제거하여 노이즈를 줄인다. |
| **위반 시** | — |

---

### BR-SCH-034 — 부스팅 규칙 적용

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search` |
| **조건** | BoostRule에 활성 규칙 존재 |
| **동작** | SearchRepository를 통해 검색 결과에 부스팅 가중치를 적용한다. ElasticsearchSearchAdapter에서는 ES `function_score` 쿼리로 구현한다. `target_type`에 따라 게시판/태그/문서 레벨에서 스코어를 조정한다. |
| **위반 시** | — |

---

### BR-SCH-035 — 검색 로그 필수 기록

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search`, `POST /search/rag` 완료 시 |
| **조건** | 항상 (성공/실패 무관) |
| **동작** | SearchLog 엔티티를 생성한다. 사용자 ID, 검색어, 검색 유형, 필터 조건, 결과 건수, 응답 시간 등을 기록한다. |
| **위반 시** | 감사 추적 불가 — 심각도 ERROR 로그 발행 |

---

### BR-SCH-036 — 하이브리드 검색 가중치

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` (mode=hybrid) |
| **조건** | `rag_default_search_mode == 'hybrid'` 또는 명시적 hybrid 모드 |
| **동작** | BM25 스코어 × `rag_hybrid_bm25_weight` + 벡터 유사도 × `rag_hybrid_vector_weight`를 RRF(Reciprocal Rank Fusion)로 통합한다. `rag_rrf_k` 파라미터를 적용한다. |
| **위반 시** | — |

---

### BR-SCH-037 — RAG 리랭킹

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | `rag_rerank_enabled == true` |
| **동작** | 초기 검색 결과를 `rag_rerank_model`로 리랭킹한다. 상위 `rag_rerank_top_n`개만 최종 소스로 사용한다. |
| **위반 시** | — |

---

### BR-SCH-038 — 게시판별 RAG 활성화 제어

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | BoardRagConfig에 `rag_enabled == false`인 게시판 |
| **동작** | 해당 게시판의 문서는 RAG 소스에서 제외한다. `rag_enabled == true`인 게시판만 RAG 대상이 된다. NULL인 경우 글로벌 기본값 적용. |
| **위반 시** | — |

---

### BR-SCH-039 — 게시판별 RAG 파라미터 오버라이드

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /search/rag` |
| **조건** | BoardRagConfig에 `top_k` 또는 `similarity_threshold`가 설정된 경우 |
| **동작** | 해당 게시판의 문서에 대해 게시판별 `top_k`, `similarity_threshold`를 적용한다. NULL 필드는 글로벌 SearchConfig 값을 상속한다. |
| **위반 시** | — |

---

### BR-SCH-044 — ES 인덱싱 Reconciliation

| 항목 | 내용 |
|------|------|
| **트리거** | `sc:search.es_recon_cron` (기본 매 30분) |
| **조건** | RDB와 ES 인덱스 간 불일치 감지 시 |
| **동작** | RDB의 published 문서 목록과 ES `aicm_blocks` 인덱스의 문서 목록을 비교하여 누락/초과 문서를 보정한다. |
| **위반 시** | — (자동 보정) |

---

## 3. 에러 코드 카탈로그

| 에러 코드 | HTTP | 메시지 | 관련 BR |
|-----------|------|--------|---------|
| SCH_SEARCH_FAILED | 503 | 검색 서비스 일시 장애 | — |
| SCH_RAG_UNAVAILABLE | 503 | RAG 서비스 일시 장애 | — |
| SCH_RAG_TIMEOUT | 504 | RAG 응답 시간 초과 | — |
| SCH_PERMISSION_DENIED | 403 | 검색 권한 없음 | BR-SCH-003, BR-SCH-006 |
| SCH_CONFIG_VERSION_CONFLICT | 409 | 설정 버전 충돌 — 최신 버전 조회 후 재시도 | BR-SCH-031 |
| SCH_PRESET_LIMIT_EXCEEDED | 422 | 필터 프리셋 저장 상한 초과 | BR-SCH-026 |
| SCH_SYNONYM_CONFLICT | 422 | 동의어/불용어 충돌 | — |
| SCH_EXCLUDE_TARGET_NOT_FOUND | 404 | 검색 제외 대상 미존재 | BR-SCH-029 |
| FEATURE_DISABLED | 403 | 기능 비활성화 (RAG 등) | — |
