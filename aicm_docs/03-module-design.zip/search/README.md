# Search 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | SearchModule |
| 문서 코드 | MS-SCH |
| 상태 | `draft` |
| 기능정의서 | [FD-SCH-검색](../../01-requirements/features/FD-SCH-검색.md) |
| 데이터 모델 | [search-config-module.md](./data.md) |
| 프로세스 흐름 | [flows/search-rag/](../../01-requirements/flows/search-rag/) |

---

## 모듈 책임

SearchModule은 AICM의 **검색·RAG 파이프라인**을 담당한다.

> 문서 파싱 파이프라인은 [ParsingModule](../parsing/README.md)을 참조한다.

### SearchModule

| 영역 | 설명 |
|------|------|
| 키워드 검색 | SearchRepository를 통한 `aicm_blocks` 풀텍스트 검색 — nori 형태소 분석, 필드별 가중치, 동의어/불용어 적용. 기본 구현체는 ElasticsearchSearchAdapter이며, 고객 요구에 따라 다른 검색 솔루션(다이퀘스트 등) 어댑터로 교체 가능 |
| RAG 검색 | retrieval-service에 시맨틱/하이브리드 검색 위임, LLM 답변 생성 오케스트레이션 |
| 자동완성 | 검색어 prefix 기반 자동완성 + 오타 교정(fuzzy matching) |
| 검색 필터 프리셋 | 사용자별 검색 필터 조합 저장·재사용 (SearchFilterPreset CRUD) |
| 개인 검색 선호 설정 | 사용자별 검색 기본값 관리 — 기본 정렬(관련도순/최신순/인기순), 기본 검색 범위(전체/특정 게시판). FD-SCH §6.1 사용자 튜닝 영역. MVP에서는 SearchFilterPreset으로 유사 기능 대체 가능, 전용 엔티티는 향후 검토 |
| 검색 설정 CRUD | SearchConfig(키워드+RAG 검색 파라미터) + 하위 엔티티(Synonym, StopWord, BoostRule, BoardRagConfig) 관리 |
| 설정 동기화 | SearchConfig 변경 시 `search.config.updated` 이벤트 발행 → retrieval-service 캐시 무효화, ES 인덱스 설정 반영 |
| 검색 이력 | SearchLog 기록·조회·내보내기 — 금융권 감사 증빙 (최소 5년 보관) |
| 관리자 대시보드 | 검색 품질·성능 지표 집계 (무결과율, 평균 응답 시간, RAG 신뢰도, 인기 검색어 등) |
| 긴급 검색 제외 | 관리자(`manage_search`)가 특정 문서·게시판을 검색 결과에서 즉시 제외/복원 |

> 파싱 설정 CRUD는 [ParsingModule](../parsing/README.md)이 소유한다. SearchModule 관리자 API에서 프록시한다.

### 현재 범위 제외 기능

| 기능 | FD 참조 | 제외 사유 | 향후 계획 |
|------|---------|----------|----------|
| 검색 테스트 환경 (Playground) | FD-SCH §6.3 | Phase 2 범위 — 관리자 전용 검색 파라미터 튜닝 도구로 MVP 핵심 아님 | Phase 2에서 관리자 대시보드 확장 시 추가. 필요 시 설계 결정 후 복원 가능 |
| 대화 컨텍스트 (멀티턴 RAG) | FD-SCH §6.2 | Phase 2 범위 — MVP에서는 단발 질의만 지원 | Phase 2에서 대화 세션 저장소 설계 후 추가 |
| 검색 결과 피드백 기반 개인화 랭킹 | FD-SCH §6.1 | 선택적 기능, MVP 범위 외 | Phase 2에서 검토 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — search-config-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **SearchConfig** | 시스템당 1행 싱글톤. 키워드 검색(`kw_*` — 필드 가중치, nori 사용자 사전)과 RAG 검색(`rag_*` — 하이브리드 가중치, 리랭킹, top_k, 유사도 임계값) 설정을 컬럼 프리픽스로 구분 |
| **Synonym** | SearchConfig 하위. 양방향 동의어 그룹 — `words` VARCHAR[] 배열로 그룹 내 모든 단어가 상호 동의어. ES nori synonym filter에 동기화 |
| **StopWord** | SearchConfig 하위. 검색 쿼리에서 제외할 단어. 전역 UNIQUE, `is_active`로 소프트 비활성화 지원 |
| **BoostRule** | SearchConfig 하위. 다형성 참조(`target_type` + `target_id`)로 게시판/태그/문서의 검색 스코어 가중치 조정. ES `function_score` 쿼리에 반영 |
| **BoardRagConfig** | SearchConfig 하위. 게시판별 RAG 활성화 여부, top_k, 유사도 임계값 오버라이드. NULL 필드는 글로벌 SearchConfig 기본값 상속 |
| **SearchLog** | 검색 이력 기록. 사용자별 검색어, 검색 유형(keyword/rag), 필터 조건, 결과 건수, 클릭 문서, RAG 신뢰도 등. 최소 5년 보관 (FD-SCH §6.6) |
| **SearchFilterPreset** | 사용자별 검색 필터 프리셋. 자주 사용하는 필터 조합(게시판+기간+태그+템플릿) 저장·재사용. 사용자당 기본 20개 상한 (FD-SCH §6.7) |

---

## SearchRepository 인터페이스

> 검색 솔루션 교체 대비 — B2B 납품 시 고객 요구에 따라 상용 검색 솔루션(다이퀘스트 등)으로 Adapter만 교체. [모듈 아키텍처 §3.3 규칙 4](../../02-architecture/02-module-architecture.md) 예외 사항.

SearchModule의 모든 검색 엔진 접근은 SearchRepository 인터페이스를 통한다. NestJS DI로 구현체를 주입하며, 기본 구현체는 ElasticsearchSearchAdapter이다.

### 인터페이스 정의

```typescript
interface SearchRepository {
  // ── 읽기(검색) ──

  /** 키워드 검색 — multi_match + collapse + inner_hits에 해당 */
  searchByKeyword(params: {
    query: string;
    filters: SearchFilters;
    boostRules: BoostRule[];
    fieldWeights: FieldWeights;
    page: number;
    size: number;
    sort: 'relevance' | 'newest' | 'popular';
  }): Promise<KeywordSearchResult>;

  /** 자동완성 — prefix + fuzzy matching */
  autocomplete(params: {
    prefix: string;
    size: number;
  }): Promise<AutocompleteResult>;

  /** 인덱싱된 문서 ID 목록 조회 — Reconciliation 배치용 */
  getIndexedDocumentIds(): Promise<string[]>;

  // ── 쓰기(인덱싱) ──

  /** 문서 블록 인덱싱 (신규/재발행) */
  indexDocumentBlocks(params: {
    documentId: string;
    blocks: IndexableBlock[];
    metadata: DocumentMetadata;
  }): Promise<void>;

  /** 문서 인덱스 삭제 */
  removeDocument(documentId: string): Promise<void>;

  /** 문서 메타데이터 필드 업데이트 (일시 정지, 태그 변경 등) */
  updateDocumentFields(params: {
    documentId: string;
    fields: Partial<IndexableMetadata>;
  }): Promise<void>;

  /** 긴급 검색 제외/복원 */
  setExcluded(documentId: string, excluded: boolean): Promise<void>;

  // ── 설정 동기화 ──

  /** 동의어/불용어/분석기 설정 동기화 */
  syncAnalyzerSettings(params: {
    synonyms: SynonymGroup[];
    stopWords: string[];
    userDict: string[];
  }): Promise<void>;
}
```

### SearchFilters

```typescript
interface SearchFilters {
  boardIds?: string[];         // 게시판 필터 (권한 기반)
  categoryIds?: string[];      // 카테고리 필터 (하위 포함 옵션, FD-SCH §1)
  dateRange?: { from: string; to: string };
  authorId?: string;
  tagIds?: string[];
  templateId?: string;
  excludeSuspended: boolean;   // is_suspended: false 필터 (항상 true)
  excludeDocumentIds?: string[]; // Restriction 제외 문서
}
```

### 보조 타입

```typescript
interface FieldWeights {
  title: number;     // kw_title_weight (기본 2.0)
  body: number;      // kw_body_weight (기본 1.0)
  caption: number;   // kw_caption_weight (기본 1.5)
  tag: number;       // kw_tag_weight (기본 1.5)
  comment: number;   // kw_comment_weight (기본 0.5)
}

interface IndexableBlock {
  blockIds: string[];      // 그룹을 구성하는 블록 ID 배열
  contentText: string;     // 그룹 내 블록들의 content_text 병합
  contentCaption: string;  // 그룹 내 블록들의 caption 병합
  sequence: number;        // 그룹 내 첫 블록의 sequence
}

interface DocumentMetadata {
  boardId: string;
  tags: string[];
  isSuspended: boolean;
  createdAt: string;       // ISO 8601
}

interface IndexableMetadata {
  isSuspended: boolean;
  isExcluded: boolean;
  tags: string[];
  boardId: string;
}

interface SynonymGroup {
  groupName: string;
  words: string[];
  isActive: boolean;
}

interface KeywordSearchResult {
  items: Array<{
    documentId: string;
    score: number;
    matchedBlocks: Array<{
      blockIds: string[];
      sequence: number;
      highlights: string[];
    }>;
  }>;
  total: number;
}

interface AutocompleteResult {
  suggestions: Array<{
    text: string;
    score: number;
  }>;
}
```

> **FieldWeights와 ES 매핑의 관계**: SearchConfig의 `kw_*_weight` 5개 필드는 **쿼리 시점**에 검색 필드별 가중치로 적용된다. ES `aicm_blocks` 매핑에는 `content_text`와 `content_caption` 2개 텍스트 필드만 존재하지만, title/tag/comment는 content_text에 병합되어 인덱싱되므로 `multi_match` 쿼리의 `fields` 파라미터에서 논리적 필드 구분을 유지한다. 다른 검색 솔루션에서는 물리적 필드 구조가 다를 수 있으므로, Adapter가 FieldWeights를 해당 엔진의 필드 구조에 맞게 변환한다.

### 타임아웃 정책

| 오퍼레이션 | 타임아웃 | 실패 시 |
|---|---|---|
| `searchByKeyword()` | 3s | `SCH_SEARCH_FAILED` (503) — 사용자에게 재시도 안내 |
| `autocomplete()` | 1s | 빈 결과 반환 (graceful) |
| `indexDocumentBlocks()` | 30s | 재시도 (BullMQ 재시도 정책 적용) |
| `removeDocument()` | 10s | 재시도 |
| `updateDocumentFields()` | 10s | 재시도 |
| `syncAnalyzerSettings()` | 60s | 실패 로그 + 다음 설정 변경 시 재시도 |

### 구현체 매핑

| 인터페이스 메서드 | ElasticsearchSearchAdapter 구현 | 비고 |
|---|---|---|
| `searchByKeyword()` | `multi_match` + `bool` filter + `collapse(document_id)` + `inner_hits` + `function_score` | [es.md §1.3](../../02-architecture/data/aicm/es.md) |
| `autocomplete()` | `prefix` query + `fuzzy` | |
| `getIndexedDocumentIds()` | `_search` / `_scroll` on `document_id` | schedule.md §2.1 |
| `indexDocumentBlocks()` | `_bulk` index API | es.md §1.4 |
| `removeDocument()` | `_delete_by_query` on `document_id` | |
| `updateDocumentFields()` | `_update_by_query` on `document_id` | 비정규화 필드 갱신 |
| `setExcluded()` | `_update_by_query` — `is_excluded` 필드 | |
| `syncAnalyzerSettings()` | index `close` → settings update → `open` | 배치 적용 |

> **설계 결정**: AccessLog(`aicm_access_logs`) 인덱스는 SearchRepository 범위에 포함하지 않는다. 접근 로그는 검색 솔루션과 무관한 운영 데이터이며, ES ILM에 강하게 의존하므로 교체 대상이 아니다.

---

## 의존 관계

```mermaid
graph LR
    %% SearchModule이 의존하는 대상
    Search["<b>SearchModule</b>"]

    Doc["DocumentModule"]
    Board["BoardModule"]
    Perm["PermissionModule"]

    Search -->|"읽기"| Doc
    Search -->|"읽기"| Board
    Search -->|"읽기"| Perm

    %% 외부 서비스
    Retrieval["RetrievalServiceClient"]

    Search -.->|"RAG 검색 위임"| Retrieval
    Search -.->|"설정 push"| Retrieval

    classDef hub fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef external fill:#fef3c7,stroke:#d97706

    class Search hub
    class Doc,Board,Perm provider
    class Retrieval external
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Search → Document | DocumentModule | 읽기 | 검색 결과 메타데이터 보강 (제목, 작성자, 태그, 게시판명 등) |
| Search → Board | BoardModule | 읽기 | 게시판 설정 조회 (RAG 활성화 여부, 게시판 타입) |
| Search → Permission | PermissionModule | 읽기 | 검색 권한 필터 구성 — 사용자의 접근 가능 게시판 ID 목록 조회 |
| Search → RetrievalServiceClient | 외부 서비스 | HTTP | RAG 시맨틱/하이브리드 검색 위임, 검색 설정 push — [API 타입 상세](../../02-architecture/06-external-integration.md#73-retrieval-servicefastapi-연동) |

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | SearchConfig, Synonym, StopWord, BoostRule, BoardRagConfig, SearchLog, SearchFilterPreset |
| Redis / BullMQ | ● | 검색 설정 캐시(`cache:search:config`, TTL 30m), 자동완성 캐시(`cache:search:autocomplete:{prefix}`, TTL 10m), BullMQ `search-events` 큐(설정 변경 이벤트 발행), 서킷브레이커 상태(`{tenant_id}:circuit:{service_name}`) |
| Elasticsearch | ● | `aicm_blocks` 인덱스 — SearchRepository(ElasticsearchSearchAdapter)를 통한 키워드 검색, nori 분석기 설정, 동의어/불용어/부스팅 반영. 검색 솔루션 교체 시 Adapter만 교체 |
| MinIO | — | |
| EventBus | ● 발행/소비 | **발행**: `search.config.updated`, `search.reindex.completed`, `search.reindex.failed`. **소비**: `document.published`, `document.content-updated`, `document.deleted`, `document.suspended`, `document.unsuspended`, `document.archived`, `shared-content.updated`, `block.visibility-changed`, `parsing.completed` |
| 외부 서비스 클라이언트 | ● | RetrievalServiceClient — 임베딩(`POST /ingest/embed`, `POST /ingest/re-embed`), 검색(`POST /search`), 설정 push(`PUT /config`), 삭제(`DELETE /sources/{sourceId}`, `DELETE /sources` 배치), 메타데이터 갱신(`PATCH /sources/{sourceId}/metadata`), 청크 조회(`GET /sources/{sourceId}/chunks`), 헬스체크(`GET /health`). [연동 인터페이스 상세](../../02-architecture/06-external-integration.md#73-retrieval-servicefastapi-연동) |

---

## 외부 서비스 미연동 시 Graceful Degradation

retrieval-service가 없거나 RAG 연동이 꺼진 환경에서도 키워드 검색은 정상 동작한다. 파싱 관련 외부 서비스(parser-service, LLM Orchestrator) Graceful Degradation은 [ParsingModule](../parsing/README.md)을 참조한다. 상세: [events.md §5](events.md#5-외부-서비스-미연동-시-graceful-degradation)

| 구분 | 연동 없을 때 영향 | 핵심 기능 영향 |
|------|------------------|--------------|
| RAG | RAG 검색 API `403 FEATURE_DISABLED`, `mode=all` 요청 시 키워드로 자동 폴백 | **없음** — 키워드 검색(SearchRepository)은 독립 동작 |

> **원칙**: 키워드 검색(SearchRepository → 기본 ElasticsearchSearchAdapter)은 어떤 환경에서도 동작한다. RAG 검색은 retrieval-service 연동이 있고 조직에서 활성화한 경우에만 사용한다.

### 검색 모드별 동작

```typescript
interface SearchQueryDto {
  query: string;
  mode?: 'keyword' | 'ai' | 'all';   // 미지정 시 SearchConfig 기본 모드 적용
  // ...
}
```

| 모드 | RAG 연동 활성 | RAG 연동 비활성 |
|------|----------------|----------------|
| `keyword` | SearchRepository 쿼리 | SearchRepository 쿼리 (정상) |
| `ai` | retrieval-service 위임 | `403 FEATURE_DISABLED` |
| `all` | SearchRepository + retrieval-service 병합 | **키워드로 자동 폴백** (AI 결과는 빈 배열, 에러 아님) |

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `search.keyword_count` | 시간당 키워드 검색 건수 | API 미들웨어 카운터 |
| `search.rag_count` | 시간당 RAG 검색 건수 | API 미들웨어 카운터 |
| `search.keyword_latency_ms` | 키워드 검색 평균 응답 시간 (p95) | API 미들웨어 |
| `search.rag_latency_ms` | RAG 검색 평균 응답 시간 (p95) | API 미들웨어 |
| `search.zero_result_rate` | 검색 무결과율 (24시간) | SearchLog 집계 |
| `search.rag_confidence_avg` | RAG 답변 평균 신뢰도 점수 | SearchLog 집계 |
| `circuit.retrieval.state_change` | RetrievalServiceClient 서킷 상태 전이 | Redis 키 변경 감지 |

---

## 모니터링 알림 임계값

| 대상 | 조건 | 심각도 | 채널 |
|------|------|--------|------|
| 키워드 검색 지연 | `search.keyword_latency_ms > 1000` (p95, 5분) | WARNING | Slack + 대시보드 |
| RAG 검색 지연 | `search.rag_latency_ms > 5000` (p95, 5분) | WARNING | Slack + 대시보드 |
| 검색 무결과율 급증 | `search.zero_result_rate > 30%` (1시간) | WARNING | Slack |
| 서킷브레이커 Open | `circuit.*.state_change == Open` | CRITICAL | Slack + PagerDuty |
| SearchLog 아카이빙 실패 | 아카이빙 배치 3회 연속 실패 | WARNING | Slack |

---

## 외부 설정값 카탈로그

SearchModule이 참조하는 외부 설정값 목록이다.

| 설정 키 | 기본값 | 용도 | 참조 |
|---------|--------|------|------|
| `lm:search.preset_max_count` | 20 | 사용자당 필터 프리셋 저장 상한 | BR-SCH-026 |
| `sc:search.es_recon_cron` | `*/30 * * * *` | ES 인덱싱 보정 주기 | schedule.md §2.1 |
| `sc:search.log_archive_cron` | `0 2 1 * *` | SearchLog 아카이빙 주기 | schedule.md §2.2 |
| `lm:search.log_retention_years` | 5 | SearchLog 보관 기간 (년) | BR-SCH-025 |

> SearchConfig의 설정값(필드 가중치 등)은 전용 싱글톤 테이블에서 관리하며, SystemConfig Key-Value에는 포함하지 않는다. [ADR-009](../../adr/009-search-config-singleton-merge.md) 참조.

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-SCH-검색](../../01-requirements/features/FD-SCH-검색.md) | 기능정의서 (입력 원본) |
| [UC-SCH-검색](../../01-requirements/usecases/user/UC-SCH-검색.md) | 유즈케이스 |
| [search-config-module.md](./data.md) | RDB 엔티티/DDL |
| [검색/RAG 파이프라인 흐름](../../01-requirements/flows/search-rag/) | 파싱→청킹→임베딩→검색 파이프라인 다이어그램 |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 검색 권한 필터 — VIEW 권한 기반 게시판 필터링, Restriction 제외 |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 이벤트 신뢰성 티어 |
| [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md) | BullMQ 큐 설계, 임베딩 파이프라인 |
| [외부 서비스 연동 §7.3](../../02-architecture/06-external-integration.md#73-retrieval-servicefastapi-연동) | retrieval-service API 타입 정의 — 임베딩, 검색, 설정 push, 네임스페이스, 삭제 |
| [ParsingModule](../parsing/README.md) | 문서 파싱 파이프라인 (파싱·청킹·임베딩 전처리) |
| [ADR-009](../../adr/009-search-config-singleton-merge.md) | SearchConfig/ParsingConfig 싱글톤 통합 결정 |
