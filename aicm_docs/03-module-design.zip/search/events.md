# Search 비동기 이벤트

> 아키텍처: [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md)
> Redis 큐/키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 기능정의서: [FD-SCH-검색 §9](../../01-requirements/features/FD-SCH-검색.md)

---

## 1. 이벤트 매트릭스 요약

### 1.1 발행 이벤트

| 이벤트 | 신뢰성 티어 | 전달 수단 | 소비자 |
|--------|------------|----------|--------|
| `search.config.updated` | Important | BullMQ `search-events` | retrieval-service (캐시 무효화), ES Sync Worker (인덱스 설정 반영) |
| `search.reindex.completed` | Important | BullMQ `search-events` | 관리자 알림 |
| `search.reindex.failed` | Important | BullMQ `search-events` | 관리자 알림, 모니터링 |

### 1.2 소비 이벤트

| 이벤트 | 발행자 | 신뢰성 티어 | 전달 수단 | 용도 |
|--------|--------|------------|----------|------|
| `document.published` | DocumentModule | Important | BullMQ `es-indexing` | SearchRepository 인덱싱, 임베딩 파이프라인 트리거 |
| `document.content-updated` | DocumentModule | Important | BullMQ `es-indexing` | SearchRepository 인덱스 갱신, 재임베딩 |
| `document.deleted` | DocumentModule | Important | BullMQ `es-indexing` | SearchRepository 인덱스 삭제, 벡터 삭제 |
| `document.suspended` | DocumentModule | Important | BullMQ `es-indexing` | SearchRepository `is_suspended: true`, 벡터 비활성화 |
| `document.unsuspended` | DocumentModule | Important | BullMQ `es-indexing` | SearchRepository `is_suspended: false`, 벡터 활성화 |
| `document.archived` | DocumentModule | Important | BullMQ `es-indexing` | SearchRepository 인덱스 삭제, 벡터 삭제 |
| `shared-content.updated` | DocumentModule | Best-effort | EventBus | 공유 블록 변경 → SearchRepository 갱신 |
| `block.visibility-changed` | DocumentModule | Best-effort | EventBus | 블록 `visible`/`embeddable` 변경 반영 |
| `parsing.completed` | ParsingModule | Important | BullMQ `parsing-events` | 파싱 완료 문서의 SearchRepository 인덱싱, 임베딩 파이프라인 트리거 |

---

## 2. 발행 이벤트 상세

### 2.1 `search.config.updated`

**큐**: `search-events` (BullMQ, Important 티어)

**발행 시점**: SearchConfig 수정 성공 후

**페이로드**:

```typescript
interface SearchConfigUpdatedPayload {
  eventId: string;           // UUID — 멱등성 키
  eventType: 'search.config.updated';
  timestamp: string;         // ISO 8601
  data: {
    configType: 'search';
    changedFields: string[];  // 변경된 필드명 목록
    version: number;          // 새 버전
    updatedBy: string;        // 수정자 userId
  };
}
```

**재시도 정책**: 최대 3회, 지수 백오프 (초기 1s, 최대 30s)

**소비 측 동작**:
1. retrieval-service: 내부 설정 캐시 무효화 및 재로딩
2. ES Sync Worker: 동의어/불용어/부스팅 설정을 ES 인덱스에 반영 (close → update → open)

---

### 2.2 `search.reindex.completed`

**큐**: `search-events` (BullMQ, Important 티어)

**발행 시점**: 전체 재인덱싱 작업 완료 시

**페이로드**:

```typescript
interface SearchReindexCompletedPayload {
  eventId: string;
  eventType: 'search.reindex.completed';
  timestamp: string;
  data: {
    totalDocuments: number;
    successCount: number;
    failureCount: number;
    durationMs: number;
  };
}
```

**재시도 정책**: 없음 (알림 전용) — 재인덱싱 완료 알림이므로 재시도하지 않는다. FD-SCH §9 참조.

---

### 2.3 `search.reindex.failed`

**큐**: `search-events` (BullMQ, Important 티어)

**발행 시점**: 전체 재인덱싱 작업 실패 시

**페이로드**:

```typescript
interface SearchReindexFailedPayload {
  eventId: string;
  eventType: 'search.reindex.failed';
  timestamp: string;
  data: {
    reason: string;
    failedAtStep: string;
    processedCount: number;
    totalCount: number;
  };
}
```

**재시도 정책**: 없음 (알림 전용) — 재인덱싱 실패 자체가 알림 이벤트이므로 재시도하지 않는다. FD-SCH §9 참조.

---

## 3. 소비 이벤트 상세

### 3.1 `document.published`

**큐**: `es-indexing` (BullMQ, Important 티어)

**발행자**: DocumentModule

**처리 절차**:

1. 문서 메타데이터 + 블록 내용 조회 (DocumentModule 읽기 의존)
2. SearchRepository를 통해 문서 블록 인덱싱 (ElasticsearchSearchAdapter: `aicm_blocks` bulk index)
3. RAG 연동이 활성이면 → 파일 첨부가 없는 블록 에디터 문서의 경우 직접 청킹 → `embedding` 큐에 벡터화 Job 추가. 파일 첨부가 있는 문서는 ParsingModule이 `parsing.completed` 이벤트로 완료 통보 후 처리 ([parsing.completed](#38-parsingcompleted) 참조)
   > `embedding` 큐는 [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md)에서 정의한다. 벡터화 처리는 retrieval-service가 소비한다.
4. 성공 시 로그 기록, 실패 시 재시도

> 파일 첨부 블록의 파싱 트리거는 [ParsingModule](../parsing/events.md)을 참조한다.

**멱등성**: `documentId` + `version` 기반. 동일 version 재처리 시 skip.

**재시도 정책**: 최대 3회, 지수 백오프 (초기 5s, 최대 120s). 소진 후 DLQ `es-indexing:dlq`.

---

### 3.2 `document.content-updated`

**큐**: `es-indexing` (BullMQ, Important 티어)

**처리 절차**:

1. 변경된 블록 목록 조회
2. SearchRepository를 통해 해당 문서의 기존 블록 삭제 후 재인덱싱
3. RAG 연동이 활성이면 → 변경된 블록 재청킹 → 재임베딩

**멱등성**: `documentId` + `version` 기반.

**재시도 정책**: 최대 3회, 지수 백오프 (초기 5s, 최대 120s). 소진 후 DLQ `es-indexing:dlq`.

---

### 3.3 `document.deleted`

**큐**: `es-indexing` (BullMQ, Important 티어)

**처리 절차**:

1. SearchRepository를 통해 해당 `documentId`의 문서 인덱스 삭제
2. RAG 연동이 활성이면 → retrieval-service에 벡터 hard-delete 요청

**멱등성**: `documentId` 기반 — 이미 삭제된 경우 no-op.

**재시도 정책**: 최대 3회, 지수 백오프 (초기 5s, 최대 120s). 소진 후 DLQ `es-indexing:dlq`.

---

### 3.4 `document.suspended` / `document.unsuspended`

**큐**: `es-indexing` (BullMQ, Important 티어)

**처리 절차**:

- **suspended**: SearchRepository를 통해 해당 문서의 `is_suspended: true` 갱신 (ElasticsearchSearchAdapter: `update_by_query`). 벡터 비활성화.
- **unsuspended**: SearchRepository를 통해 `is_suspended: false` 복원. 벡터 활성화.

**멱등성**: 현재 상태와 동일하면 skip.

**재시도 정책**: 최대 3회, 지수 백오프 (초기 5s, 최대 120s). 소진 후 DLQ `es-indexing:dlq`.

---

### 3.5 `document.archived`

**큐**: `es-indexing` (BullMQ, Important 티어)

**처리 절차**: `document.deleted`와 동일 (SearchRepository 삭제 + 벡터 삭제)

**멱등성**: `documentId` 기반 — 이미 삭제된 경우 no-op.

**재시도 정책**: `document.deleted`와 동일.

---

### 3.6 `shared-content.updated`

**전달 수단**: EventBus (NestJS EventEmitter, Best-effort)

**처리 절차**:

1. 공유 블록이 포함된 문서 목록 조회
2. 각 문서의 해당 블록만 SearchRepository를 통해 재인덱싱
3. 임베딩 재처리는 Best-effort (실패 시 다음 Reconciliation 배치에서 보정)

---

### 3.7 `block.visibility-changed`

**전달 수단**: EventBus (NestJS EventEmitter, Best-effort)

**처리 절차**:

1. 변경된 블록의 `visible`/`embeddable` 플래그 확인
2. `visible: false`이면 SearchRepository를 통해 해당 블록 제거
3. `embeddable: false`이면 벡터 DB에서 해당 블록 제거

---

### 3.8 `parsing.completed`

**큐**: `parsing-events` (BullMQ, Important 티어)

**발행자**: ParsingModule

**처리 절차**:

1. 파싱 완료 문서의 Block 내용 조회 (DocumentModule 읽기 의존)
2. SearchRepository를 통해 문서 블록 인덱싱
3. RAG 연동이 활성이면 → ParsingModule이 생성한 청크 메타데이터를 활용하여 `embedding` 큐에 벡터화 Job 추가

**멱등성**: `documentId` + `parsingVersion` 기반

**재시도 정책**: 최대 3회, 지수 백오프

---

## 4. 외부 서비스 호출

### 4.1 RetrievalServiceClient

| 항목 | 내용 |
|------|------|
| **용도** | RAG 시맨틱/하이브리드 검색 위임, 설정 push |
| **프로토콜** | HTTP (REST) |
| **비고** | RAG 비활성 시 retrieval-service 호출 skip |
| **서킷브레이커** | ● — `{tenant_id}:circuit:retrieval-service` (Redis 키) |
| **타임아웃** | 검색: 10s / 설정 push: 5s |
| **폴백** | 검색 실패 시 키워드 검색으로 자동 폴백 (mode=all), mode=ai이면 503 반환 |

---

## 5. 외부 서비스 미연동 시 Graceful Degradation

| 구분 | 연동 없을 때 영향 |
|------|------------------|
| RAG | RAG 검색 API 403 반환, 청킹·임베딩 파이프라인 비활성, retrieval-service 호출 skip |
| 자동 요약 | 문서 요약 기능 비활성 (SearchModule 직접 영향 없음, embedding 큐에 summary job 미생성) |

**원칙**: SearchRepository 기반 키워드 검색(기본: ElasticsearchSearchAdapter)은 어떤 환경에서도 동작한다. RAG 관련 기능은 연동 활성 여부 + 서킷브레이커 + 타임아웃 3중 방어.

---

## 6. DLQ 처리

| 원본 큐 | DLQ | 모니터링 | 수동 처리 |
|---------|-----|---------|----------|
| `es-indexing` | `es-indexing:dlq` | BullMQ Dashboard, Slack 알림 | 관리자 재처리 또는 Reconciliation 배치에서 자동 보정 |
| `search-events` | `search-events:dlq` | BullMQ Dashboard | 설정 push 재시도 |

---

## 7. 멱등성 보장

| 큐/이벤트 | 멱등성 키 | 전략 |
|-----------|----------|------|
| `es-indexing` (document.*) | `documentId` + `version` | 동일 version 이미 처리됨 → skip |
| `parsing-events` (parsing.completed) | `documentId` + `parsingVersion` | 동일 파싱 버전 이미 처리됨 → skip |
| `search-events` (config.updated) | `eventId` (UUID) | Redis `idem:search:{eventId}` TTL 24h — 중복 발행 방지 |
