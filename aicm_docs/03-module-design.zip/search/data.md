# SearchModule — RDB 엔티티

> search_config(검색) 싱글톤 테이블 + 하위 엔티티. [ADR-009](../../adr/009-search-config-singleton-merge.md) 참조

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    SearchConfig ||--o{ Synonym : "1:N"
    SearchConfig ||--o{ StopWord : "1:N"
    SearchConfig ||--o{ BoostRule : "1:N"
    SearchConfig ||--o{ BoardRagConfig : "1:N"

    SearchLog }o--|| User : "N:1"
    SearchLog ||--o| SearchLogArchive : "1:1 아카이빙"
    SearchFilterPreset }o--|| User : "N:1"
```

---

## 2. 엔티티 필드

### 2.1 SearchConfig

시스템당 1행만 존재하는 **싱글톤 검색 설정 테이블**. 키워드 검색(`kw_`)과 RAG 검색(`rag_`) 2개 영역의 설정을 컬럼 프리픽스로 구분한다.

#### 키워드 검색 영역 (`kw_`)

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| kw_nori_user_dict | TEXT[] | nori 사용자 사전 단어 목록. ES `user_dictionary_rules`에 동기화 |
| kw_title_weight | DECIMAL(3,1) NOT NULL DEFAULT 2.0 | 제목 필드 가중치 |
| kw_body_weight | DECIMAL(3,1) NOT NULL DEFAULT 1.0 | 본문 필드 가중치 |
| kw_caption_weight | DECIMAL(3,1) NOT NULL DEFAULT 1.5 | 캡션(이미지 설명) 필드 가중치 |
| kw_tag_weight | DECIMAL(3,1) NOT NULL DEFAULT 1.5 | 태그 필드 가중치 |
| kw_comment_weight | DECIMAL(3,1) NOT NULL DEFAULT 0.5 | 댓글 필드 가중치 |

#### RAG 검색 영역 (`rag_`)

| 필드 | 타입 | 설명 |
|------|------|------|
| rag_default_search_mode | VARCHAR(20) NOT NULL DEFAULT 'hybrid' | 기본 검색 모드 (`keyword`, `semantic`, `hybrid`) |
| rag_hybrid_bm25_weight | DECIMAL(3,2) NOT NULL DEFAULT 0.40 | 하이브리드 BM25 가중치 |
| rag_hybrid_vector_weight | DECIMAL(3,2) NOT NULL DEFAULT 0.60 | 하이브리드 벡터 가중치 |
| rag_rrf_k | INT NOT NULL DEFAULT 60 | RRF 상수 |
| rag_rerank_enabled | BOOLEAN NOT NULL DEFAULT false | 리랭킹 활성화 여부 |
| rag_rerank_model | VARCHAR (nullable) | 리랭킹 모델 식별자 |
| rag_rerank_top_n | INT (nullable) | 리랭킹 후 결과 수 |
| rag_top_k | INT NOT NULL DEFAULT 20 | 1차 검색 상위 K개 |
| rag_window_context_size | INT NOT NULL DEFAULT 1 | 인접 블록 확장 윈도우 |
| rag_similarity_threshold | DECIMAL(3,2) NOT NULL DEFAULT 0.70 | 유사도 임계값 |

#### 공통

| 필드 | 타입 | 설명 |
|------|------|------|
| updated_by | UUID, FK(User) | 최종 수정자 |
| version | INTEGER NOT NULL DEFAULT 1 | 낙관적 동시성 제어용 버전 ([BR-SCH-031](rules.md#br-sch-031-설정-저장-occ)) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- 모든 `kw_*_weight` 값은 `> 0` — 0 이하 값은 허용하지 않음
- `rag_hybrid_bm25_weight + rag_hybrid_vector_weight`는 앱 레벨에서 합계 1.0 검증

#### 설계 결정

**싱글톤 검색 설정 테이블**
— 기존 KeywordSearchConfig / RagSearchConfig 2개 싱글톤 테이블과 FieldWeight 1:1 테이블을 하나로 통합한다. 키워드 검색과 RAG 검색은 둘 다 "검색 요청 시" 소비되는 같은 도메인이다 ([ADR-009](../../adr/009-search-config-singleton-merge.md)).

**컬럼 프리픽스로 관심사 구분**
— `kw_` / `rag_` 프리픽스로 2개 영역을 논리적으로 구분한다. 동기화 패턴은 기존과 동일하다:
- `kw_*`: aicm-service → SearchRepository(ElasticsearchSearchAdapter)를 통해 적용
- `rag_*`: aicm-service → retrieval-service `PUT /config` push

**ES multi_match 가중치 반영**
— `kw_*_weight` 컬럼은 SearchRepository를 통해 검색 엔진의 필드별 가중치로 반영된다. ElasticsearchSearchAdapter에서는 ES `aicm_blocks` 인덱스의 `multi_match` 쿼리에서 `fields` 파라미터의 가중치(`^N`)로 적용된다. 예: `kw_title_weight = 2.0`이면 `"title^2.0"`으로 쿼리한다.

**초기 시딩**
— 앱 최초 배포 시 SearchConfig에 검색 기본값을 시딩한다. 이후 관리자가 SearchConfig를 통해 직접 조정한다.

---

### 2.2 Synonym

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| search_config_id | UUID (FK) | SearchConfig 참조 |
| group_name | VARCHAR(200) | 동의어 그룹명 (관리 편의) |
| words | VARCHAR[] | 동의어 목록 (PostgreSQL array). 예: `{'고객센터','콜센터','CS센터'}` |
| is_active | BOOLEAN | 활성 여부 (기본값 true) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 설계 결정

**양방향 동의어 그룹**
— 동의어는 단방향 매핑이 아니라 그룹 내 모든 단어가 서로 동의어로 동작한다. "고객센터"를 검색하면 "콜센터", "CS센터"가 포함된 문서도 반환된다.

**PostgreSQL array 타입**
— 동의어 목록을 정규화된 별도 테이블(synonym_word)로 분리하지 않고 `VARCHAR[]`로 저장한다. 동의어 그룹의 단어 수가 적고(보통 2~5개), 항상 그룹 단위로 읽기/쓰기하므로 array가 더 효율적이다.

**ES nori synonym filter 동기화**
— 동의어가 변경되면 ES 인덱스의 `nori_synonym` filter 설정을 업데이트하고, retrieval-service에도 동기화한다. ES synonym filter 업데이트는 인덱스 close/open 또는 reindex가 필요하므로, 변경 사항을 모아 배치로 적용한다.

---

### 2.3 StopWord

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| search_config_id | UUID (FK) | SearchConfig 참조 |
| word | VARCHAR(100) | 불용어 (UNIQUE) |
| is_active | BOOLEAN | 활성 여부 (기본값 true) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(word)` — **전역 유니크**. SearchConfig가 시스템당 1건(싱글톤)이므로 전역 유니크로 충분하다.

#### 설계 결정

**검색 제외 단어**
— 검색 쿼리에서 의미 없는 단어를 제거하여 검색 정확도를 높인다. 예: "의", "에서", "그리고" 등 한국어 조사/접속사.

**ES stop token filter 동기화**
— Synonym과 동일하게 변경 사항을 ES stop filter에 동기화한다.

**is_active 소프트 비활성화**
— 불용어를 물리 삭제하지 않고 `is_active = false`로 비활성화한다. 잘못 제거했을 때 복원이 용이하다.

---

### 2.4 BoostRule

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| search_config_id | UUID (FK) | SearchConfig 참조 |
| name | VARCHAR(200) | 규칙명 |
| target_type | VARCHAR(20) | 부스팅 대상: `board`, `tag`, `document` |
| target_id | UUID | 대상 ID (게시판/태그/문서의 UUID) |
| boost_weight | DECIMAL(5,2) | 가중치 배수 (기본값 1.0). >1: 상위 노출, <1: 하위 노출 |
| is_active | BOOLEAN | 활성 여부 (기본값 true) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `CHECK (target_type IN ('board', 'tag', 'document'))`
- `boost_weight > 0` — 0 이하 값은 허용하지 않음

#### 설계 결정

**다형성 참조 (target_type + target_id)**
— Board, Tag, Document 각각에 대해 별도 테이블을 두지 않고, `target_type`으로 대상 종류를 구분한다. FK 제약조건은 걸지 않는다 — target_type에 따라 참조 테이블이 달라지므로 단일 FK로 표현할 수 없다. 존재 검증은 앱 레벨에서 수행한다.

**ES function_score 쿼리 반영**
— 검색 시 활성 상태인 BoostRule을 조회하여 ES `function_score` 쿼리의 `functions` 배열에 weight factor로 주입한다. 예: `target_type = 'tag'`, `target_id = <긴급공지 태그 ID>`, `boost_weight = 2.0`이면 해당 태그가 부착된 문서의 검색 스코어에 2.0배를 곱한다.

**부스팅 규칙 예시:**

| name | target_type | boost_weight | 효과 |
|------|-------------|-------------|------|
| 긴급공지 우선 | `tag` | 2.0 | '긴급공지' 태그 문서를 2배 부스팅 |
| 공지사항 게시판 상위 | `board` | 1.5 | 공지사항 게시판 문서를 1.5배 부스팅 |
| 오래된 문서 하위 | `document` | 0.5 | 특정 문서를 0.5배로 낮춤 |

---

### 2.5 BoardRagConfig

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| search_config_id | UUID (FK) | SearchConfig 참조 |
| board_id | UUID NOT NULL | 게시판 ID (UNIQUE) |
| rag_enabled | BOOLEAN NOT NULL DEFAULT true | 해당 게시판 RAG 검색 활성화 여부 |
| top_k | INT (nullable) | 게시판별 top_k 오버라이드. NULL이면 글로벌 `rag_top_k` 사용 |
| similarity_threshold | DECIMAL(3,2) (nullable) | 게시판별 유사도 임계값 오버라이드 |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(board_id)` — 게시판당 RAG 오버라이드는 최대 1건

#### 설계 결정

**게시판별 RAG 오버라이드**
— 게시판마다 RAG 검색을 끄거나, 검색 파라미터를 다르게 설정할 수 있다. NULL 컬럼은 글로벌 SearchConfig의 `rag_*` 값을 상속한다.

**프롬프트·모델 게시판별 오버라이드 미지원**
— FD-SCH §6.5에 `prompt_template_id`, `model_id` 필드가 언급되어 있으나, 프롬프트와 모델은 전체 게시판에서 동일하게 관리하는 정책에 따라 BoardRagConfig에 포함하지 않는다. 프롬프트 관리는 PromptModule(PromptSlot/PromptVersion)에서, 모델 선택은 LLM Orchestrator에서 전역으로 관리한다.

---

### 2.6 SearchLog

검색 이력 기록. 금융권 감사 대비 핵심 엔티티 (FD-SCH §6.6). 최소 5년 보관.

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID NOT NULL, FK(User) | 검색 실행자 |
| tenant_id | UUID NOT NULL, FK(Tenant) | 테넌트 |
| query | TEXT NOT NULL | 검색어 (키워드) 또는 질의 (RAG) |
| search_type | VARCHAR(10) NOT NULL | 검색 방식 (`keyword` / `rag`) |
| filters | JSONB | 적용된 필터 조건 (board_ids, date_range, tag_ids, template_id 등) |
| result_count | INTEGER NOT NULL | 검색 결과 건수 |
| clicked_document_ids | UUID[] | 사용자가 클릭한 문서 ID 목록 (이벤트 기반 비동기 수집) |
| rag_source_chunk_ids | UUID[] | RAG 답변 생성 시 참조한 청크 ID 목록 (`search_type = rag`일 때) |
| rag_confidence_score | DECIMAL(3,2) | RAG 답변 전체 신뢰도 점수 (`search_type = rag`일 때) |
| response_time_ms | INTEGER NOT NULL | 검색 응답 시간 (밀리초) |
| created_at | TIMESTAMPTZ NOT NULL | 검색 실행 시각 |

#### 설계 결정

**검색 모듈 소속**
— 감사 로그(FD-AUD)와 별도로 관리한다. 감사 로그는 관리자 액션(설정 변경, 인덱스 재구성)을 기록하고, SearchLog는 사용자 검색 행위를 기록한다.

**보관 정책**
— 최소 5년 보관(금융권 감사 증빙). 보관 기간 경과 후 아카이빙/삭제는 관리자 설정에 따름.

**아카이브 스키마**
— `search_log_archive`는 `search_log`과 동일 스키마에 `archived_at` 컬럼이 추가된 형태. FK 제약 없음 (독립 보관).

---

### 2.7 SearchFilterPreset

사용자별 검색 필터 프리셋. 자주 사용하는 필터 조합 저장·재사용 (FD-SCH §6.7).

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID NOT NULL, FK(User) | 소유자 |
| name | VARCHAR(100) NOT NULL | 프리셋 이름 |
| filters | JSONB NOT NULL | 필터 조건 (`{ board_ids, category_ids, date_range, author_id, tag_ids, template_id, bookmark_only }`) |
| sort_order | INTEGER NOT NULL | 표시 순서 |
| created_at | TIMESTAMPTZ NOT NULL | 생성 시각 |
| updated_at | TIMESTAMPTZ NOT NULL | 수정 시각 |

#### 제약 조건

- 사용자당 저장 상한: 기본 20개 (`lm:search.preset_max_count`) — 상한 초과 시 `SCH_PRESET_LIMIT_EXCEEDED` (422)

#### 설계 결정

**사용자 소유 엔티티**
— 프리셋은 사용자별로 독립 관리되며, 다른 사용자의 프리셋에 접근할 수 없다.

**필터 대상 삭제/병합 처리**
— 게시판 삭제 시 해당 조건 제외 후 나머지 검색 + 안내 메시지 (BR-SCH-027). 태그 병합 시 새 태그명 자동 전환, 삭제 시 조건 제외 + 안내 (BR-SCH-028).

---

## 3. DDL 및 인덱스

### 3.1 SearchConfig

```sql
CREATE TABLE search_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

  -- 키워드 검색 (kw_)
  kw_nori_user_dict         TEXT[],
  kw_title_weight           DECIMAL(3,1) NOT NULL DEFAULT 2.0,
  kw_body_weight            DECIMAL(3,1) NOT NULL DEFAULT 1.0,
  kw_caption_weight         DECIMAL(3,1) NOT NULL DEFAULT 1.5,
  kw_tag_weight             DECIMAL(3,1) NOT NULL DEFAULT 1.5,
  kw_comment_weight         DECIMAL(3,1) NOT NULL DEFAULT 0.5,

  -- RAG 검색 (rag_)
  rag_default_search_mode   VARCHAR(20) NOT NULL DEFAULT 'hybrid',
  rag_hybrid_bm25_weight    DECIMAL(3,2) NOT NULL DEFAULT 0.40,
  rag_hybrid_vector_weight  DECIMAL(3,2) NOT NULL DEFAULT 0.60,
  rag_rrf_k                 INT NOT NULL DEFAULT 60,
  rag_rerank_enabled        BOOLEAN NOT NULL DEFAULT false,
  rag_rerank_model          VARCHAR,
  rag_rerank_top_n          INT,
  rag_top_k                 INT NOT NULL DEFAULT 20,
  rag_window_context_size   INT NOT NULL DEFAULT 1,
  rag_similarity_threshold  DECIMAL(3,2) NOT NULL DEFAULT 0.70,

  updated_by                UUID REFERENCES "user"(id),
  version                   INT NOT NULL DEFAULT 1,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_kw_title_weight_positive CHECK (kw_title_weight > 0),
  CONSTRAINT chk_kw_body_weight_positive CHECK (kw_body_weight > 0),
  CONSTRAINT chk_kw_caption_weight_positive CHECK (kw_caption_weight > 0),
  CONSTRAINT chk_kw_tag_weight_positive CHECK (kw_tag_weight > 0),
  CONSTRAINT chk_kw_comment_weight_positive CHECK (kw_comment_weight > 0)
);
```

### 3.2 Synonym

```sql
CREATE TABLE synonym (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_config_id  UUID NOT NULL REFERENCES search_config(id),
  group_name        VARCHAR(200) NOT NULL,
  words             VARCHAR[] NOT NULL,
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_synonym_active
  ON synonym (is_active)
  WHERE is_active = true;
```

### 3.3 StopWord

```sql
CREATE TABLE stop_word (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_config_id  UUID NOT NULL REFERENCES search_config(id),
  word              VARCHAR(100) NOT NULL,
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_stop_word UNIQUE (word)
);
```

### 3.4 BoostRule

```sql
CREATE TABLE boost_rule (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_config_id  UUID NOT NULL REFERENCES search_config(id),
  name              VARCHAR(200) NOT NULL,
  target_type       VARCHAR(20) NOT NULL,
  target_id         UUID NOT NULL,
  boost_weight      DECIMAL(5,2) NOT NULL DEFAULT 1.0,
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_boost_target_type
    CHECK (target_type IN ('board', 'tag', 'document')),
  CONSTRAINT chk_boost_weight_positive
    CHECK (boost_weight > 0)
);

CREATE INDEX idx_boost_rule_target
  ON boost_rule (target_type, target_id)
  WHERE is_active = true;

CREATE INDEX idx_boost_rule_active
  ON boost_rule (is_active)
  WHERE is_active = true;
```

### 3.5 BoardRagConfig

```sql
CREATE TABLE board_rag_config (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  search_config_id      UUID NOT NULL REFERENCES search_config(id),
  board_id              UUID NOT NULL,
  rag_enabled           BOOLEAN NOT NULL DEFAULT true,
  top_k                 INT,
  similarity_threshold  DECIMAL(3,2),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_board_rag_config UNIQUE (board_id)
);

CREATE INDEX idx_board_rag_config_board ON board_rag_config (board_id);
```

### 3.6 SearchLog

```sql
CREATE TABLE search_log (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id               UUID NOT NULL REFERENCES "user"(id),
  tenant_id             UUID NOT NULL,
  query                 TEXT NOT NULL,
  search_type           VARCHAR(10) NOT NULL,
  filters               JSONB,
  result_count          INTEGER NOT NULL,
  clicked_document_ids  UUID[],
  rag_source_chunk_ids  UUID[],
  rag_confidence_score  DECIMAL(3,2),
  response_time_ms      INTEGER NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_search_type CHECK (search_type IN ('keyword', 'rag'))
);

CREATE INDEX idx_search_log_user ON search_log (user_id, created_at DESC);
CREATE INDEX idx_search_log_tenant ON search_log (tenant_id, created_at DESC);
CREATE INDEX idx_search_log_type ON search_log (search_type, created_at DESC);
CREATE INDEX idx_search_log_created ON search_log (created_at DESC);
```

### 3.7 SearchLogArchive

```sql
CREATE TABLE search_log_archive (
  -- search_log와 동일 스키마
  id                    UUID PRIMARY KEY,
  user_id               UUID NOT NULL,
  tenant_id             UUID NOT NULL,
  query                 TEXT NOT NULL,
  search_type           VARCHAR(10) NOT NULL,
  filters               JSONB,
  result_count          INTEGER NOT NULL,
  clicked_document_ids  UUID[],
  rag_source_chunk_ids  UUID[],
  rag_confidence_score  DECIMAL(3,2),
  response_time_ms      INTEGER NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL,

  -- 아카이빙 메타데이터
  archived_at           TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_archive_search_type CHECK (search_type IN ('keyword', 'rag'))
);

CREATE INDEX idx_search_log_archive_created ON search_log_archive (created_at DESC);
CREATE INDEX idx_search_log_archive_tenant ON search_log_archive (tenant_id, created_at DESC);
```

### 3.8 SearchFilterPreset

```sql
CREATE TABLE search_filter_preset (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES "user"(id),
  name        VARCHAR(100) NOT NULL,
  filters     JSONB NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_preset_user ON search_filter_preset (user_id, sort_order);
```

---

## 4. 관련 문서

- [ParsingModule data.md](../parsing/data.md) — ParsingConfig, BoardParsingOverride, TemplateChunkingRule 엔티티
- [ADR-009: 검색 설정 싱글톤 통합](../../adr/009-search-config-singleton-merge.md) — 3테이블 → search_config + parsing_config 2테이블 결정
- [ADR-008: 검색 설정 3엔티티 분리](../../adr/008-search-config-three-entity-split.md) — 이전 결정 (Superseded)
- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [ES aicm_blocks 인덱스](../../02-architecture/data/aicm/es.md) — 키워드 검색 인덱스 (Synonym, StopWord, BoostRule이 반영되는 대상)
- [document.md](../document/data.md) — Document, Block, Tag (BoostRule의 target 대상)
- [board.md](../board/data.md) — Board (BoostRule의 target 대상, BoardRagConfig 대상)
- [02-chunking.md](../../01-requirements/flows/search-rag/02-chunking.md) — 청킹 파이프라인 흐름
