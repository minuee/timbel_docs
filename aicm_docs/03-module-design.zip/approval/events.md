# Approval 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 모듈 아키텍처: [02-module-architecture.md §3.3](../../02-architecture/02-module-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 발행 이벤트

ApprovalModule이 발행하는 이벤트와 큐를 신뢰성 티어별로 정리한다.

### 1.1 Important 티어 — BullMQ 직접 enqueue

```typescript
/** 모든 BullMQ Job 페이로드의 공통 컨텍스트 (05-async-event-architecture.md §6.5) */
interface AsyncJobContext {
  actorId: string;
  orgId: string;
  traceId: string;
  triggeredAt: string;            // ISO 8601
}
```

#### `scheduled-publish` 큐

- **티어**: Important
- **채널**: BullMQ `scheduled-publish`
- **트리거**: 승인 완료 시 예약 배포 선택 [BR-APR-019], 또는 `POST /api/approvals/:approvalId/schedule`
- **비고**: 예약 배포 기능이 비활성화된 운영 구성에서는 enqueue를 생략한다
- **페이로드**:

```typescript
interface ScheduledPublishJobPayload extends AsyncJobContext {
  approvalId: string;
  documentId: string;
  documentVersionId: string;
  scheduledPublishAt: string;     // ISO 8601 — delayed job의 delay 시간 계산에 사용
}
```

- **소비자**: Worker → ApprovalService.executeScheduledPublish() → DocumentModule.transitionToPublished() (Critical tx)
- **Job 옵션**:

```typescript
{
  jobId: `scheduled-publish:${approvalId}`,   // 멱등성 키 — 동일 건 중복 enqueue 방지
  delay: scheduledPublishAt - now(),           // 예약 시점까지 지연
  attempts: 3,
  backoff: { type: 'exponential', delay: 5000 },
  removeOnComplete: true,
  removeOnFail: false,
}
```

- **재시도**: 최대 3회, 지수 백오프 (5s → 10s → 20s). 최종 실패 시 `scheduled-publish-dlq`로 이동
- **동시 처리수**: 1 (예약 배포 순서 보장)
- **타임아웃**: 1분
- **DLQ**: `scheduled-publish-dlq` — 운영자 수동 재처리 또는 보정 배치에서 복구
- **예약 취소**: `Approval.bull_job_id`로 `queue.remove(jobId)` 호출. 이미 실행 중이면 취소 불가 → 사전 상태 검증

---

### 1.2 Best-effort 티어 — EventBus (NestJS EventEmitter)

모든 이벤트는 EventBus(NestJS EventEmitter)를 통해 Best-effort 티어로 발행된다. 재시도 없이 소비자 측에서 보상 처리한다.

**이벤트 페이로드 공통 DTO**: 아래 각 인터페이스는 분산 추적을 위해 **`traceId: string`** 을 **필수**로 포함한다. BullMQ `AsyncJobContext.traceId`([§1.1](#11-important-티어--bullmq-직접-enqueue))와 동일 목적으로 end-to-end 상관관계에 사용한다.

```typescript
/** 본 절 EventBus 이벤트의 공통 필드 — 각 페이로드 타입에 아래 두 필드가 포함됨 */
interface ApprovalEventBusPayloadBase {
  schemaVersion: 1;
  traceId: string;
}
```

#### `approval.submitted`

- **트리거**: 승인 요청 생성 (Document Controller → ApprovalService 내부 호출)
- **페이로드**:

```typescript
interface ApprovalSubmittedEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  documentVersionId: string | null;
  requesterId: string;
  templateId: string | null;
  stepCount: number;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 승인권자에게 승인 요청 알림 발송
  - AuditLogModule — `approval.submitted` 감사 로그 기록

---

#### `approval.step.approved`

- **트리거**: 중간 단계 승인 완료 [BR-APR-001]
- **페이로드**:

```typescript
interface ApprovalStepApprovedEvent {
  schemaVersion: 1;
  approvalId: string;
  stepOrder: number;
  actorId: string;
  isDelegated: boolean;
  nextStepOrder: number | null;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 다음 단계 승인권자에게 알림 발송
  - AuditLogModule — `approval.step_approved` 감사 로그 기록

---

#### `approval.step.rejected`

- **트리거**: 단계 반려 [BR-APR-002]
- **페이로드**:

```typescript
interface ApprovalStepRejectedEvent {
  schemaVersion: 1;
  approvalId: string;
  stepOrder: number;
  actorId: string;
  comment: string | null;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 요청자에게 반려 알림 발송
  - AuditLogModule — `approval.step_rejected` 감사 로그 기록

---

#### `approval.approved`

- **트리거**: 최종 단계 승인 완료 [BR-APR-013]. DocumentModule.transitionToPublished() Critical tx 완료 후 발행
- **페이로드**:

```typescript
interface ApprovalApprovedEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  documentVersionId: string;
  actorId: string;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 요청자에게 승인 완료 알림 발송
  - AuditLogModule — `approval.approved` 감사 로그 기록

> 임베딩/ES인덱싱/요약 큐 enqueue는 DocumentModule.transitionToPublished() 내부에서 수행한다. ApprovalModule은 이를 직접 호출하지 않는다.

---

#### `approval.rejected`

- **트리거**: 최종 반려 확정 [BR-APR-002]. DocumentModule.transitionToDraftOnReject() Critical tx 완료 후 발행
- **페이로드**:

```typescript
interface ApprovalRejectedEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  requesterId: string;
  comment: string | null;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 요청자에게 반려 알림 발송
  - AuditLogModule — `approval.rejected` 감사 로그 기록

---

#### `approval.withdrawn`

- **트리거**: 요청자 철회 [BR-APR-012]
- **페이로드**:

```typescript
interface ApprovalWithdrawnEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  requesterId: string;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 승인권자에게 철회 알림 발송
  - AuditLogModule — `approval.withdrawn` 감사 로그 기록

---

#### `approval.auto_rejected`

- **트리거**: SLA 타임아웃 자동 반려 [BR-APR-022]. 배치 작업(schedule.md `approval-auto-reject`)에서 발행
- **페이로드**:

```typescript
interface ApprovalAutoRejectedEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  slaHours: number;
  graceHours: number;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 요청자에게 "승인 기한 초과로 자동 반려" 알림, 승인권자에게 "미처리로 자동 반려" 알림
  - AuditLogModule — `approval.auto_rejected` 감사 로그 기록 (반려 사유: "SLA 타임아웃")

---

#### `approval.bypassed`

- **트리거**: 긴급 발행 [BR-APR-017]. DocumentModule.transitionToPublished() Critical tx 완료 후 발행
- **페이로드**:

```typescript
interface ApprovalBypassedEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  actorId: string;
  bypassReason: string;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 문서 작성자에게 긴급 발행 알림
  - AuditLogModule — `approval.bypassed` 감사 로그 기록

> 임베딩/ES인덱싱/요약 큐 enqueue는 DocumentModule.transitionToPublished() 내부에서 수행한다.

---

#### `approval.cancelled`

- **트리거**: 긴급 발행(bypass) 등으로 **기존 `pending` 승인 건**이 시스템에 의해 `cancelled`로 전환될 때(BR-APR-035 예외 경로)
- **페이로드**:

```typescript
interface ApprovalCancelledEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  /** 시스템 자동 취소 고정값 */
  cancelledBy: 'system';
  /** 취소 사유 구분 — 예: bypass로 대체됨 */
  reason: 'bypass';
  /** 새로 생성된 긴급 발행(bypassed) 승인 건 ID */
  newBypassApprovalId: string;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 기존 승인권자 등에게 "승인 건이 시스템에 의해 취소됨" 알림(정책에 따름)
  - AuditLogModule — `approval.cancelled` 감사 로그 기록

---

#### `approval.scheduled`

- **트리거**: 예약 배포 설정 [BR-APR-019]
- **페이로드**:

```typescript
interface ApprovalScheduledEvent {
  schemaVersion: 1;
  approvalId: string;
  documentId: string;
  scheduledPublishAt: string;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 요청자에게 예약 배포 설정 알림
  - AuditLogModule — `approval.scheduled` 감사 로그 기록

> BullMQ `scheduled-publish` 큐에 delayed job을 등록하는 것은 ApprovalService 내부에서 직접 수행한다 (§1.1 참조). 이 EventBus 이벤트는 알림/감사 용도.

---

#### `approval.delegated`

- **트리거**: 위임 설정 [BR-APR-020]
- **페이로드**:

```typescript
interface ApprovalDelegatedEvent {
  schemaVersion: 1;
  delegationId: string;
  delegatorId: string;
  delegateId: string;
  boardId: string;
  startDate: string;
  endDate: string;
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 위임 대상자에게 위임 알림 발송
  - AuditLogModule — `approval.delegated` 감사 로그 기록

---

#### `approval.delegation.released`

- **트리거**: 위임 해제 — 수동 해제, 기간 만료, 대상자 비활성화 [BR-APR-021]
- **페이로드**:

```typescript
interface ApprovalDelegationReleasedEvent {
  schemaVersion: 1;
  delegationId: string;
  releaseReason: 'manual' | 'expired' | 'delegate_deactivated';
  traceId: string;
}
```

- **소비자**:
  - NotificationModule — 위임자에게 해제 알림 발송
  - AuditLogModule — `approval.delegation_released` 감사 로그 기록

---

## 2. 소비 이벤트

ApprovalModule이 외부 모듈로부터 수신하는 이벤트/콜백.

| 이벤트/콜백 | 발행자 | 채널 | 처리 내용 | 호출 실패 시 동작 |
|------------|--------|------|----------|------------------|
| `board.config_updated` | BoardModule | EventBus | 게시판 설정(승인 정책 포함) 변경 감지 — 캐시 무효화 | Best-effort — 다음 API 호출 시 DB에서 재조회 |
| `user.deactivated` | AuthModule | EventBus | 위임 대상자 비활성화 감지 → 해당 위임 자동 해제 [BR-APR-021] | Best-effort — 배치(`approval-delegation-expire`)에서 보정 |

> **아키텍처 정합(P3)**: `02-module-architecture.md` EventBus 매트릭스에 본 이벤트가 아직 없을 수 있다. Auth/모듈 아키텍처 문서 갱신 시 본 행과 동기화한다. 운영 보정은 `approval-delegation-expire` 배치가 담당한다.

---

## 3. 외부 모듈 직접 호출

ApprovalModule이 Critical 트랜잭션 내에서 직접 호출하는 외부 모듈 메서드.

### 3.1 DocumentService (Critical tx)

모듈 간 공개 계약 식별자는 [api.md § Document 모듈 내부 계약](api.md#document-모듈-내부-계약-critical-트랜잭션)의 `DocumentExportService`(`documentId`, `approvalId` 중심)를 따른다. 아래 표는 **구현 시 자주 쓰는 오버로드**(버전·트랜잭션 매니저 명시)이다.

| 호출 시점 | 메서드 | 설명 | 실패 시 |
|----------|--------|------|--------|
| 최종 승인 (즉시 발행) | `transitionToPublished(documentId, versionId, txManager)` | Document.status → published, 큐 enqueue | 트랜잭션 전체 롤백 — 승인도 취소 |
| 최종 승인 (예약 발행) | `transitionToApprovedScheduled(documentId, versionId, scheduledAt, txManager)` | Document.status → approved_scheduled | 트랜잭션 전체 롤백 — 승인도 취소 |
| 반려 | `transitionToDraftOnReject(documentId, versionId, reason, txManager)` | Document.status → draft | 트랜잭션 전체 롤백 — 반려도 취소 |
| 철회 | `transitionToDraftOnReject(documentId, versionId, '철회', txManager)` | Document.status → draft | 트랜잭션 전체 롤백 |
| 자동 반려 | `transitionToDraftOnReject(documentId, versionId, 'SLA 타임아웃', txManager)` | Document.status → draft | 트랜잭션 전체 롤백 |

---

## 4. BullMQ 큐 요약

| 큐 이름 | 트리거 | 동시 처리수 | 재시도 | 타임아웃 | DLQ | 처리 내용 |
|---------|--------|-----------|--------|---------|-----|----------|
| `scheduled-publish` | 예약 배포 승인 | 1 | 3회 (지수 백오프 5s→10s→20s) | 1분 | `scheduled-publish-dlq` | 예약 시점 도래 → Document.status → published |

### 4.1 멱등성 보장 패턴

| 큐 | 멱등성 키 패턴 | 보장 방식 |
|----|---------------|-----------|
| `scheduled-publish` | `scheduled-publish:{approvalId}` | BullMQ `jobId` 옵션으로 중복 enqueue 방지. Worker에서 `Approval.status` 확인 — `approved`가 아니면 (이미 철회 등) 스킵. `Document.status` 확인 — 이미 `published`이면 스킵 |

### 4.2 EventBus 이벤트 멱등성

EventBus(Best-effort 티어)는 소비자 측에서 멱등 처리를 보장한다.

| 멱등성 키 패턴 | 적용 이벤트 | 소비자 처리 |
|---------------|-----------|-----------|
| `{eventName}:{approvalId}:{stepOrder}` | 승인/반려 단계 이벤트 | AuditLogModule이 `(approval_id, action, step_order)` 중복 검사 |
| `{eventName}:{approvalId}` | 건 전체 이벤트 | AuditLogModule이 `(approval_id, action)` 중복 검사 |
| `{eventName}:{delegationId}` | 위임 이벤트 | AuditLogModule이 `(delegation_id, action)` 중복 검사 |

> 모든 이벤트 페이로드에 `traceId`(OpenTelemetry)를 포함하여 end-to-end 추적을 지원한다.

### 4.3 이벤트 스키마 호환성

- 필드 추가는 자유 (backward-compatible)
- 필드 제거·타입 변경 시 새 이벤트명 도입 — [비동기 처리 아키텍처 §6.4](../../02-architecture/05-async-event-architecture.md) 참조
- 현재 모든 이벤트는 `schemaVersion: 1`

### 4.4 Graceful Shutdown

배포 시 BullMQ Worker의 안전한 종료를 위한 전략.

1. **SIGTERM 수신 시**: `worker.close()` 호출 — 현재 처리 중인 Job이 완료될 때까지 대기 (최대 30초)
2. **타임아웃 초과 시**: 처리 중이던 Job은 `stalled` 상태로 전환되어 다른 인스턴스가 재처리
3. **보정 배치**: `scheduled-publish` 큐의 경우, schedule.md의 `approval-scheduled-publish-reconcile` 보정 배치가 누락 건을 복구

---

## 5. 감사 로그 액션

ApprovalModule이 기록하는 감사 로그 액션 목록. 이벤트 소비자(AuditLogModule)가 EventBus 이벤트를 수신하여 비동기 기록.

| 액션 | 트리거 이벤트 | 관련 BR |
|------|-------------|---------|
| `approval.submitted` | `approval.submitted` | — |
| `approval.step_approved` | `approval.step.approved` | BR-APR-001 |
| `approval.step_rejected` | `approval.step.rejected` | BR-APR-002 |
| `approval.approved` | `approval.approved` | BR-APR-013 |
| `approval.rejected` | `approval.rejected` | BR-APR-002 |
| `approval.withdrawn` | `approval.withdrawn` | BR-APR-012 |
| `approval.auto_rejected` | `approval.auto_rejected` | BR-APR-022 |
| `approval.bypassed` | `approval.bypassed` | BR-APR-017 |
| `approval.cancelled` | `approval.cancelled` | BR-APR-035 예외(bypass 시 pending 대체) |
| `approval.scheduled` | `approval.scheduled` | BR-APR-019 |
| `approval.delegated` | `approval.delegated` | BR-APR-020 |
| `approval.delegation_released` | `approval.delegation.released` | BR-APR-021 |
