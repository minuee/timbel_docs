# Approval 비즈니스 규칙

> 기능정의서: [FD-APR-승인워크플로](../../01-requirements/features/FD-APR-승인워크플로.md)
> API 스펙: [api.md](api.md)
> 데이터 모델: [data.md](data.md)

---

## 1. 상태 전이

### 1.1 Approval.status 상태 전이

```mermaid
stateDiagram-v2
    [*] --> pending: 승인 요청 생성

    pending --> approved: 최종 단계 승인 [BR-APR-013]
    pending --> rejected: 단계 반려 [BR-APR-002]
    pending --> withdrawn: 요청자 철회 [BR-APR-012]
    pending --> auto_rejected: SLA 타임아웃 [BR-APR-022]
    pending --> bypassed: 긴급 발행 [BR-APR-017]
    pending --> cancelled: 기존 건 시스템 취소(긴급 발행이 대체) [BR-APR-035 예외]
```

> **확정 상태 불변**: `approved`, `rejected`, `withdrawn`, `auto_rejected`, `cancelled`, `bypassed`는 최종 상태이다. 상태 변경이 불가하며, 재승인이 필요하면 새 Approval 레코드를 생성한다 (BR-APR-007).

### 1.2 ApprovalStepResult.status 상태 전이

```mermaid
stateDiagram-v2
    [*] --> pending: 단계 생성 (제출 시점 결재라인 스냅샷)

    pending --> approved: 통과 판정 [BR-APR-001]
    pending --> rejected: 반려 판정 [BR-APR-002]
```

### 1.3 Approval.status 전이와 Document.status 연동

| Approval 전이 | Approval.type | Document 후속 처리 |
|---------------|---------------|-------------------|
| pending → approved | PUBLISH | Document.status → `published` (즉시) 또는 `approved_scheduled` (예약) |
| pending → rejected | PUBLISH | Document.status → `draft` |
| pending → withdrawn | PUBLISH | Document.status → `draft` |
| pending → auto_rejected | PUBLISH | Document.status → `draft` |
| pending → bypassed | PUBLISH | Document.status → `published` (즉시) |
| pending → approved | DELETE | Document.deleted_at = now() (소프트 딜리트) |
| pending → rejected | DELETE | 변경 없음 (문서 현상 유지) |
| pending → withdrawn | DELETE | 변경 없음 (문서 현상 유지) |

### 1.4 Critical 트랜잭션 타임아웃 · 실패 시 보상

`transitionToPublished()`, `transitionToDraftOnReject()` 등 ApprovalModule ↔ DocumentModule **동일 DB 트랜잭션** 경계 호출은 모듈 아키텍처상 Critical 트랜잭션이다.

| 항목 | 권장 |
|------|------|
| **타임아웃** | 애플리케이션·DB 세션 모두에서 Critical 트랜잭션에 **명시적 상한**을 둔다(예: DB `statement_timeout` / TypeORM·Prisma 트랜잭션 타임아웃 **30~60초** 범위 — 문서·버전·상태 전이·부수 쿼리 합산 기준). 일반 API 요청 타임아웃보다 길되, 무한 대기는 금지한다. |
| **타임아웃·데드락 시** | 트랜잭션 전체 **롤백**. Approval·Document 어느 한쪽만 반영된 상태를 남기지 않는다. 호출자에게는 `503`/`409`(낙관적 락 충돌) 등 구현체 표준에 맞는 오류를 반환한다. |
| **보상 트랜잭션(Compensating)** | 분산 2PC가 아닌 **단일 DB 트랜잭션**이므로 별도 보상 트랜잭션은 원칙적으로 불필요하다. 다만 **커밋 후** EventBus 발행·BullMQ enqueue 등 비동기 단계가 실패하면: (1) 아웃박스/재시도로 eventual consistency, 또는 (2) 운영 알림 후 **수동 보정**(schedule.md 보정 배치·DLQ)으로 맞춘다. |
| **배치·워커** | 자동 반려·예약 배포 보정 등은 Document 호출 실패 시 [schedule.md](schedule.md)의 재시도·다음 주기 재대상 정책을 따른다. |

**근거**: 모듈 아키텍처 Critical 트랜잭션 원칙, FD-APR 발행·반려 원자성.

---

## 2. 규칙 카탈로그

### 승인 판정

#### BR-APR-001: 승인 유형별 통과 판정

- **트리거**: 승인 액션 발생 (ApprovalDecision 생성)
- **조건**: 해당 단계의 `approval_type`에 따라 판정
  - `ANY`: approved 판단이 1건 이상 → 단계 approved
  - `ALL`: 모든 대상 승인자가 approved → 단계 approved
  - `COUNT`: approved 판단이 `required_count` 이상 → 단계 approved
- **동작**: ApprovalStepResult.status → `approved`, `completed_at` 기록. 다음 단계가 있으면 `Approval.current_step` 증가, 최종 단계이면 Approval.status → `approved`
- **근거**: FD-APR §2.3 — 3가지 승인 유형으로 실무 시나리오 커버

#### BR-APR-002: 승인 유형별 반려 판정

- **트리거**: 반려 액션 발생 (ApprovalDecision 생성)
- **조건**: 해당 단계의 `approval_type`에 따라 판정
  - `ANY`: 전원 반려 → 단계 rejected
  - `ALL`: 1명 반려 → 즉시 단계 rejected
  - `COUNT`: (전체 대상자 - 이미 반려한 수) < `required_count` → 즉시 단계 rejected
- **동작**: ApprovalStepResult.status → `rejected`, Approval.status → `rejected`, Document.status → `draft`
- **위반 시**: 해당 없음 (시스템 판정 로직)
- **근거**: FD-APR §4.1 — 단계 반려 시 전체 건 반려로 즉시 확정

---

### 정책 및 스냅샷

#### BR-APR-003: 템플릿/결재라인 변경 비소급

- **트리거**: ApprovalLineTemplate 수정 또는 게시판 mandatory_approval_config 변경
- **조건**: 진행 중(`pending`)인 Approval 건이 존재
- **동작**: 진행 중 건은 요청 시점에 기록된 ApprovalStepResult의 값으로 유지. 소급 적용 금지
- **근거**: ADR-011 A-3 — 기안자 구성 결재라인이 ApprovalStepResult에 기록됨

#### BR-APR-004: 제출 버전 자동 생성

- **트리거**: 승인 요청 (Document Controller → ApprovalService 내부 호출)
- **조건**: `Board.versioning_enabled = true` (상속 포함)
- **동작**: DocumentVersion 자동 생성 (`trigger = 'approval_request'`), `Approval.document_version_id`에 FK 설정. `versioning_enabled = false`이면 DocumentVersion 미생성
- **근거**: FD-APR §3 — 버전 관리 활성 시 승인 대상 문서의 정확한 버전 추적

---

### 문서 잠금 및 보호

#### BR-APR-005: 승인 대기 문서 수정 잠금

- **트리거**: 승인 요청 후 문서 수정 시도
- **조건**: Document.status == `pending_review`
- **동작**: 문서 수정 차단. 수정이 필요하면 철회(BR-APR-012) 후 재편집
- **위반 시**: `APR_DOCUMENT_LOCKED` (423)
- **근거**: FD-APR §3 — 승인 중 내용 변경 방지

#### BR-APR-006: 승인 전 문서 검색 제외

- **트리거**: 문서 검색/RAG 조회
- **조건**: Document.status == `pending_review`
- **동작**: 검색 및 RAG 대상에서 제외
- **근거**: FD-APR §3 — 미승인 문서의 노출 방지

#### BR-APR-007: Approval 일회성

- **트리거**: 반려/철회/자동반려 후 재요청
- **조건**: 기존 Approval 건이 확정 상태
- **동작**: 기존 건은 보존, 새 Approval 레코드 생성
- **위반 시**: `APR_ALREADY_PENDING` (409) — 이미 pending 상태인 건이 존재하면 재요청 차단
- **근거**: FD-APR §3 — 이력 추적을 위한 불변 레코드

---

### 승인자 제어

#### BR-APR-008: 자기 승인 제외

- **트리거**: 승인 요청
- **조건**: 게시판 `mandatory_approval_config.self_approve_blocked = true` (기본값)
- **동작**: 승인자 목록에서 요청자 본인 자동 제외. 요청자가 해당 단계의 유일한 승인 대상이면 승인 요청 차단
- **위반 시**:
  - `APR_SELF_APPROVE_BLOCKED` (403) — 유일 승인자인 경우
  - `APR_NO_ELIGIBLE_APPROVER` (422) — 제외 후 승인 가능자 없음
- **근거**: FD-APR §3.3 — 금융권 직무 분리 원칙

#### BR-APR-009: CC 권한 제한

- **트리거**: CC 대상자의 액션 시도
- **조건**: 사용자가 해당 Approval의 `cc_list`에만 포함 (승인자가 아님)
- **동작**: 열람 + 비구속적 코멘트만 허용. 승인/반려 불가
- **근거**: FD-APR §3.1 — CC는 참조 전용

#### BR-APR-010: (삭제 — 기안자 주도 모델로 통합)

> 기안자가 결재라인 전체를 자유 구성하므로 별도 승인자 선택 제어(allow_requester_pick)가 불필요하다. FD-APR §3.1 참조.

---

### 반려/철회/재요청

#### BR-APR-011: 재요청 시 1단계 재시작

- **트리거**: 반려 후 재요청
- **조건**: 이전 Approval이 `rejected` 또는 `auto_rejected`
- **동작**: 새 Approval 생성, 1단계부터 재진행. 이전 단계 승인은 무효
- **근거**: FD-APR §4.2 — 변경된 내용에 대한 전체 재검토 보장

#### BR-APR-012: 철회 허용

- **트리거**: 요청자의 철회 요청
- **조건**: Approval.status == `pending`
- **동작**: Approval.status → `withdrawn`, Document.status → `draft`, 진행된 StepResult/Decision 기록 보존
- **위반 시**: `APR_ALREADY_COMPLETED` (409) — 이미 확정된 건
- **근거**: FD-APR §5 — 요청자의 철회 권한 보장

---

### 승인 처리

#### BR-APR-013: 최종 승인 = 배포

- **트리거**: 최종 단계 승인 완료
- **조건**: `current_step > total_steps`
- **동작**: Approval.status → `approved`, ApprovalModule이 DocumentModule.transitionToPublished()를 **동일 트랜잭션**에서 호출 (Critical). 예약 배포 선택 시 Document.status → `approved_scheduled` + BullMQ `scheduled-publish` 큐에 delayed job 등록
- **비고**: 트랜잭션 타임아웃·롤백·비동기 단계 실패 시 보완은 §1.4 참조
- **근거**: 모듈 아키텍처 §3.3.1 — Critical 트랜잭션 보장

#### BR-APR-014: 관리자 오버라이드

- **트리거**: 관리자의 승인/반려 액션
- **조건**: ADMIN 역할 + 해당 게시판 관리 권한
- **동작**: `approver_target` 무시하고 전 단계 승인/반려 가능. `ApprovalDecision.is_override = true` 기록
- **비고**: 자기승인 차단(`self_approve_blocked`)은 관리자 오버라이드와 별도로 **BR-APR-034**를 따른다.
- **근거**: FD-APR §6.1 — 운영 긴급 대응

#### BR-APR-015: 동시 처리 충돌

- **트리거**: 동일 건에 동시 승인/반려 시도
- **조건**: ApprovalStepResult.status 또는 Approval.status가 이미 변경됨
- **동작**: 먼저 처리한 쪽 반영 (optimistic locking via `updated_at` 비교). 후순위 요청은 `APR_ALREADY_PROCESSED` 반환
- **위반 시**: `APR_ALREADY_PROCESSED` (409)
- **근거**: FD-APR §6.3 — 정합성 보장 + 불필요한 락 대기 방지

#### BR-APR-016: 일괄 승인/반려

- **트리거**: `POST /approvals/batch-decide`
- **조건**: 대상 승인 건 최대 50건
- **동작**: 순차 처리, 부분 실패 분리 보고. **각 `approvalId`는 건별 독립 트랜잭션**으로 처리하며(partial success — api.md batch-decide), 성공 건만 커밋·실패 건은 응답 `failedItems` 등에 포함한다. 각 건마다 **현재 pending인 단계**(`current_step`에 대응하는 `ApprovalStepResult`)를 자동 특정하여 단건 decide와 동일 규칙을 적용한다. 각 문서의 작성자에게 개별 알림 발송
- **근거**: FD-APR §6.2 — 금융권 분기 약관 개정 등 대량 승인

---

### 긴급 발행

#### BR-APR-017: 긴급 발행 권한

- **트리거**: `POST /approvals/bypass`
- **조건**: ADMIN 역할 + `bypass_approval` AdminPermission 보유
- **동작**: Approval 생성 (status = `bypassed`), 즉시 Document.status → `published`
- **위반 시**: `APR_BYPASS_NO_PERMISSION` (403)
- **근거**: FD-APR §7.2 — 콜센터 장애 공지 등 긴급 상황

#### BR-APR-018: 긴급 발행 사유 검증

- **트리거**: 긴급 발행 사유 입력
- **조건**: `bypass_reason` 길이 ≥ `lm:approval.bypass_reason_min_length` (기본 10자)
- **동작**: 검증 통과 후 bypass 진행
- **위반 시**: `APR_BYPASS_REASON_TOO_SHORT` (422)
- **근거**: FD-APR §7.3 — 단순 입력 방지, 사후 감사 시 실질적 사유 확보

---

### 예약 배포

#### BR-APR-019: 예약 배포

- **트리거**: 승인 시 예약 배포 선택 또는 `POST /approvals/:approvalId/schedule`
- **조건**: `scheduledPublishAt`이 현재 시각보다 미래
- **동작**: Document.status → `approved_scheduled`, `Approval.scheduled_at` 설정, BullMQ `scheduled-publish` 큐에 delayed job 등록 (`Approval.bull_job_id` 저장)
- **위반 시**: `APR_SCHEDULE_PAST_TIME` (422)
- **근거**: FD-APR §11.3

---

### 위임

#### BR-APR-020: 승인 위임

- **트리거**: `POST /approval-delegations`
- **조건**:
  - 해당 게시판의 `mandatory_approval_config.delegation_allowed = true`
  - 동일 게시판에 위임자의 활성 위임이 없음
  - 위임 대상자가 다른 위임의 delegate가 아님 (재위임 금지)
- **동작**: ApprovalDelegation 레코드 생성 (`is_active = true`). 위임 기간 내 해당 게시판의 승인 건에서 위임 대상자가 원래 승인자를 대신하여 처리 가능
- **위반 시**:
  - `APR_DELEGATION_NOT_ALLOWED` (403) — 정책 미허용
  - `APR_DELEGATION_DUPLICATE` (409) — 중복 위임
  - `APR_REDELEGATION_BLOCKED` (403) — 재위임 시도
- **근거**: FD-APR §8 — 금융권 교대 근무·부재 대응

#### BR-APR-021: 위임 자동 해제

- **트리거**: 배치 작업 (schedule.md `approval-delegation-expire` 참조) 또는 대상자 비활성화 이벤트
- **조건**: `end_date` 경과 또는 위임 대상자 비활성 상태
- **동작**: `ApprovalDelegation.is_active = false`, 위임자에게 알림 발송, `approval.delegation.released` 이벤트 발행
- **근거**: FD-APR §8.3 — 기간 만료 자동 정리

---

### 자동 반려

#### BR-APR-022: 자동 반려 (타임아웃)

- **트리거**: 배치 작업 (schedule.md `approval-auto-reject` 참조)
- **조건**: `Board.mandatory_approval_config.sla_hours IS NOT NULL`이고, **유효 경과 시간**(벽시계 경과에서 유지보수 구간 차감 — BR-APR-027)이 `sla_hours + auto_reject_grace_hours`를 초과
- **동작**: Approval.status → `auto_rejected`, Document.status → `draft`, 작성자·승인권자에게 알림 발송, `approval.auto_rejected` 이벤트 발행
- **근거**: ADR-011 A-4 — 별도 status로 감사 추적 명확화. FD-APR §4.4 — 유지보수 기간 SLA 미산입은 BR-APR-027과 조합

#### BR-APR-027: 시스템 유지보수 모드 시 SLA 타이머 일시 정지

- **트리거**: 자동 반려 배치 실행 시점, 유지보수 윈도우 적용 시
- **조건**:
  - `SystemConfig.maintenance_mode === true`(테넌트/조직 단위)인 경우 해당 주기에서 자동 반려 판정을 수행하지 않거나, 동일 효과로 SLA 시계를 정지한 것으로 간주한다 (ADR-011 §E-2 단순 구현).
  - `maintenance_mode === false`인 경우에도 **이미 기록된 유지보수 구간**(예: FD-MON 유지보수 창, `maintenance.started`/`maintenance.ended`로 확정된 시작·종료 시각)과 `[Approval.created_at, now())`의 겹침 합만큼을 벽시계 경과에서 차갭하여 `effective_elapsed`를 계산한다. 자동 반려 비교는 `effective_elapsed ≥ sla_hours + auto_reject_grace_hours`로 수행한다.
- **동작**: 점검 시간이 SLA에 산입되지 않음 — 점검 직후 자동 반려가 과도하게 발생하지 않도록 한다.
- **근거**: FD-APR §4.4, ADR-011 §E-2  
- **비고**: ADR-011 §E-2 본문의 "BR-APR-023" 표기는 FD·본 문서에 이미 부여된 BR-APR-023(관리 모드 판별)과 충돌하므로, **SLA 일시 정지 규칙은 BR-APR-027**로 정의한다.

---

### 게시판 모드 판별

#### BR-APR-023: 승인 필요 여부 판별

- **트리거**: 게시판 설정 조회
- **조건**: `Board.approval_required == true` (상속 포함 — null이면 상위 게시판에서 상속)
- **동작**: 승인 필수 활성. 해당 게시판의 `mandatory_approval_config`에서 필수 승인자 및 정책 옵션을 참조한다
- **근거**: FD-APR §2.5

---

### 필수 승인자 및 결재라인 검증

#### BR-APR-028: 필수 승인자 검증

- **트리거**: 승인 요청 (Document Controller → ApprovalService)
- **조건**: 게시판의 `mandatory_approval_config.mandatory_steps`에 필수 단계가 정의됨
- **동작**: 기안자가 구성한 결재라인에 모든 필수 단계가 position 규칙(FIRST/LAST/ANY)에 맞게 포함되었는지 검증. 누락 시 승인 요청 차단
- **위반 시**: `APR_MANDATORY_STEPS_MISSING` (422)
- **근거**: FD-APR §2.6 — 게시판 관리자가 설정한 필수 승인자는 기안자가 제거 불가

#### BR-APR-029: 결재라인 단계 수 검증

- **트리거**: 승인 요청
- **조건**: 게시판의 `mandatory_approval_config.min_steps` / `max_steps`가 설정됨
- **동작**: 기안자 결재라인의 총 단계 수(필수 단계 포함)가 `min_steps` ~ `max_steps` 범위 내인지 검증
- **위반 시**: `APR_STEP_COUNT_OUT_OF_RANGE` (422)
- **근거**: FD-APR §2.6

#### BR-APR-030: 승인자 권한 사전 검증

- **트리거**: 승인 요청
- **조건**: 결재라인에 `approver_source = 'USER'`인 단계가 존재
- **동작**: 지정된 각 사용자가 해당 게시판의 `APPROVE` BoardPermission을 보유하는지 검증. 미보유 시 승인 요청 차단
- **위반 시**: `APR_APPROVER_NO_PERMISSION` (422)
- **근거**: FD-APR §2.4

#### BR-APR-031: 삭제 요청 결재

- **트리거**: `approval_required = true` 게시판에서 **이미 published**인 문서에 대한 삭제 시도
- **조건**: 게시판·문서 상태가 삭제 승인 대상
- **동작**: `Approval.type = 'DELETE'`인 승인 건을 생성·완료한 뒤에만 소프트 딜리트 등 삭제 확정 (§1.3 전이표와 정합)
- **위반 시**: 승인 없이 삭제 시도 시 Document/권한 계층 정책에 따름 (필수 시 `FORBIDDEN` 등)
- **근거**: FD-APR — 삭제 요청 결재

#### BR-APR-032: 게시판 설정 검증

- **트리거**: 게시판 `mandatory_approval_config` 저장·갱신
- **조건**: `mandatory_steps` 배열의 단계 수(또는 정의된 필수 단계 수)가 `max_steps`를 초과하면 안 됨
- **동작**: 저장 시 검증 실패 시 요청 거부 (Board API 또는 동등 계층)
- **위반 시**: 검증 에러 (구현체 표준 — 예: `VALIDATION_ERROR` / 422)
- **근거**: FD-APR — 게시판 승인 설정 일관성

#### BR-APR-033: 위임 × 자기승인 교차

- **적용 범위**: **`decide`(승인/반려) 경로**에서만 — 활성 승인 건의 승인 대상자를 확정할 때(위임 확장 포함), 위임받은 사용자가 **그 건의 문서 작성자(요청자)**와 같으면 해당 단계에서 위임을 적용하지 않는다.
- **트리거**: `decide` 처리 시 승인 대상자·위임 매칭 판별
- **조건**: 위임이 활성이고, 위임받은 사용자(`delegate`)가 **해당 Approval 건의 문서 작성자**와 동일
- **동작**: 해당 건·해당 단계에서 위임은 **무효**. 원래 지정 승인자가 처리해야 함
- **위임 생성(`POST /approval-delegations`)**: 게시판 단위 위임이므로 **특정 승인 건의 문서 작성자와의 교차 검증은 수행하지 않는다** — 아직 대상 문서가 특정되지 않았거나 건별 검증이 성립하지 않는다.
- **위반 시**: `decide` 시 위 조건을 위반한 채 위임 경로로 처리하려 하면 `APR_DELEGATION_INVALID_SELF_AUTHOR` (422)
- **근거**: FD-APR — 직무 분리와 위임의 교차

#### BR-APR-034: 관리자 오버라이드여도 self_approve_blocked 유지

- **트리거**: 승인/반려 `decide` (관리자 오버라이드 경로 포함)
- **조건**: 게시판 `mandatory_approval_config.self_approve_blocked = true`
- **동작**: 관리자 오버라이드(BR-APR-014)로 타인 단계를 대리 처리할 수 있어도, **요청자 본인이 자신이 제출한 건을 스스로 승인·반려하는 것**은 허용하지 않는다
- **구현 가이드**: `decide` 시점에 `requester_id === actor_id`이면 자기승인 차단으로 거부한다. 오버라이드 플래그·역할과 무관하게 동일 검증을 선행한다
- **위반 시**: `APR_SELF_APPROVE_BLOCKED` (403)
- **근거**: FD-APR — 오버라이드 예외와 직무 분리의 구분

#### BR-APR-035: 문서당 활성(pending) Approval 1건

- **트리거**: 승인 요청 생성 (`createApproval` / Document Submit)
- **조건**: 동일 `document_id`에 `status = 'pending'`인 Approval이 이미 존재
- **동작**: 두 번째 pending 생성 금지
- **위반 시**: `APR_ACTIVE_APPROVAL_EXISTS` (409)
- **근거**: FD-APR — BR-APR-007과 함께 단일 진행 건 보장

---

### 입력 검증

#### BR-APR-024: 승인 요청 필수 필드 검증

- **트리거**: 승인 요청 (Document Controller → ApprovalService)
- **조건**: 문서 제목·본문 등 게시판별 필수 필드 설정에 따른 항목이 입력됨
- **동작**: 검증 통과 후 승인 요청 진행
- **위반 시**: `APR_REQUIRED_FIELDS_MISSING` (422)
- **근거**: FD-APR §3

#### BR-APR-025: 승인 권한 검증

- **트리거**: 승인/반려 액션
- **조건**: 해당 단계의 승인 대상자(`approver_source`/`approver_target`에 따라 — USER: 지정 사용자, ROLE: 해당 역할 + APPROVE 권한, TEAM: 해당 팀 소속 + APPROVE 권한) 또는 관리자 오버라이드(BR-APR-014)
- **동작**: 검증 통과 후 처리 진행
- **위반 시**: `APR_NO_APPROVE_PERMISSION` (403)
- **근거**: FD-APR §6

#### BR-APR-026: 상태 전제 조건 검증

- **트리거**: 승인/반려 액션
- **조건**: `Approval.status == 'pending'` AND 해당 단계가 현재 활성 단계(`step_order == current_step`)
- **동작**: 검증 통과 후 처리 진행
- **위반 시**: `APR_NOT_IN_REVIEW` (422)
- **근거**: FD-APR §4

---

## 3. 에러 코드 카탈로그

> 전체 에러 코드와 엔드포인트별 배치는 [api.md §에러 코드 참조](api.md#에러-코드-참조) 참조

| 에러 코드 | HTTP | 설명 | 관련 BR |
|-----------|------|------|---------|
| APR_ALREADY_PENDING | 409 | 이미 승인 진행 중인 문서에 재요청 | BR-APR-007 |
| APR_ACTIVE_APPROVAL_EXISTS | 409 | 문서당 활성(pending) Approval이 이미 존재 | BR-APR-035 |
| APR_DELEGATION_INVALID_SELF_AUTHOR | 422 | `decide` 시 위임 경로에서 문서 작성자와 동일하여 위임 불가 | BR-APR-033 |
| APR_SELF_APPROVE_BLOCKED | 403 | 자기 승인 차단으로 요청 불가 | BR-APR-008 |
| APR_NO_ELIGIBLE_APPROVER | 422 | 승인 가능한 승인자 없음 | BR-APR-008 |
| APR_ALREADY_PROCESSED | 409 | 이미 처리된 건에 중복 처리 | BR-APR-015 |
| APR_ALREADY_COMPLETED | 409 | 이미 완료된 건에 철회 시도 | BR-APR-012 |
| APR_DOCUMENT_LOCKED | 423 | 승인 대기 중 문서 수정 시도 | BR-APR-005 |
| APR_REQUIRED_FIELDS_MISSING | 422 | 필수 항목 미입력 | BR-APR-024 |
| APR_NO_APPROVE_PERMISSION | 403 | 승인 권한 없음 | BR-APR-025 |
| APR_BYPASS_NO_PERMISSION | 403 | 긴급 발행 권한 없음 | BR-APR-017 |
| APR_BYPASS_REASON_TOO_SHORT | 422 | 사유 최소 길이 미달 | BR-APR-018 |
| APR_SCHEDULE_PAST_TIME | 422 | 예약 시간 과거 | BR-APR-019 |
| APR_DELEGATION_DUPLICATE | 409 | 중복 위임 | BR-APR-020 |
| APR_REDELEGATION_BLOCKED | 403 | 재위임 시도 | BR-APR-020 |
| APR_DELEGATION_NOT_ALLOWED | 403 | 게시판 설정 위임 미허용 | BR-APR-020 |
| APR_NOT_IN_REVIEW | 422 | 검토 대기 상태 아님 | BR-APR-026 |
| APR_MANDATORY_STEPS_MISSING | 422 | 게시판 필수 승인자 누락 | BR-APR-028 |
| APR_STEP_COUNT_OUT_OF_RANGE | 422 | 결재라인 단계 수 범위 초과 | BR-APR-029 |
| APR_APPROVER_NO_PERMISSION | 422 | USER 지정 승인자 APPROVE 권한 미보유 | BR-APR-030 |
| APR_TEMPLATE_NOT_FOUND | 404 | 결재라인 템플릿 미존재 | — |
| APR_TEMPLATE_IN_USE | 409 | Board가 템플릿 참조 중 | — |
| APR_TEMPLATE_STEPS_INVALID | 422 | 템플릿 steps 검증 실패 | data.md §2.1 |
| APR_TEMPLATE_NAME_DUPLICATE | 409 | 템플릿명 중복 | — |
