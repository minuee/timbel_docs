# Approval 스케줄 및 배치 작업

> - 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> - 비즈니스 규칙: [rules.md](./rules.md)
> - 이벤트: [events.md](./events.md)

**Cron 타임존**: 본 문서의 cron 표현식은 모두 **`Asia/Seoul`** 기준이다(스케줄러·워커 프로세스 TZ 또는 명시적 zone 설정과 정합).

**예약 배포 경로(상호 배타)**: 예약 배포는 **(1) 승인 인라인** — `approved_scheduled`·`Approval.scheduled_at`·BullMQ — **또는 (2) 비승인 게시판의 `Document.scheduled_publish_at`** 중 **하나만** 사용한다. **동시 사용 불가**([api.md](api.md) `POST /approvals/:approvalId/schedule`, [document/data.md](../document/data.md)).

## 1. 스케줄 작업 개요

| # | 작업명 | 목적 | cron 주기 (Asia/Seoul) | 예상 실행 시간 | 설정 키 |
|---|--------|------|-----------|:-------------:|---------|
| 1 | 자동 반려 배치 | SLA 타임아웃 초과 승인 건 자동 반려 | `*/5 * * * *` (5분) | ~3초/100건 | `sc:approval.auto_reject_cron` |
| 2 | 승인 리마인더 배치 | 미처리 승인 건 승인권자 리마인더 알림 | `0 9 * * *` (매일 09:00) | ~3초/100건 | `sc:approval.reminder_cron` |
| 3 | 위임 만료 배치 | 기간 만료 위임 자동 해제 | `0 0 * * *` (매일 00:00) | ~1초/50건 | `sc:approval.delegation_expire_cron` |
| 4 | 예약 배포 보정 배치 | scheduled-publish 큐 누락 건 복구 | `*/30 * * * *` (30분) | ~2초/50건 | `sc:approval.scheduled_publish_recon_cron` |

## 2. 작업 상세

### 2.1 자동 반려 배치 (`approval-auto-reject`)

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | SLA 기한이 경과한 승인 건을 자동으로 `auto_rejected` 상태로 전환 |
| cron 표현식 | `*/5 * * * *` (5분마다, **Asia/Seoul**) |
| BR 참조 | BR-APR-022, BR-APR-027 |
| 최대 지연 허용치 | 5분 (FD-APR 비기능 요구사항) |
| 설정 키 | `SystemConfig.maintenance_mode` — true 시 SLA 자동 반려 판정 일시 정지 (FD-APR §4.4, ADR-011 §E-2) |

#### 실행 로직

1. **유지보수 모드(전역 일시 정지)**: 테넌트별 `SystemConfig.maintenance_mode === true`이면 해당 테넌트에 대해 **이번 주기는 자동 반려 대상 조회를 수행하지 않는다**(또는 동일 효과의 no-op). 점검 중에는 SLA 시계가 돌아가지 않은 것으로 간주한다 (BR-APR-027).
2. **유효 경과 시간(차감)**: `maintenance_mode === false`일 때, 각 후보 건에 대해 벽시계 경과 `now() - a.created_at`에서 **해당 테넌트의 유지보수 구간**과 `[a.created_at, now())`의 교집합 길이를 뺀 값을 `effective_elapsed`로 사용한다. 유지보수 구간은 SystemConfig/모니터링 모듈에 기록된 확정 창(시작·종료 시각)을 원천으로 하며, FD-MON의 유지보수 창·`monitoring.maintenance.*` 이벤트와 정합을 맞춘다 (BR-APR-027).
3. 문서 소속 게시판의 **유효** `mandatory_approval_config`에 SLA가 설정된 pending 승인 건 조회 — `sla_hours`·`auto_reject_grace_hours`는 `ApprovalLineTemplate`이 아니라 `Board.mandatory_approval_config` JSONB에 있다(data.md §2.1 설계 결정). **개념적 조건**(구현은 앱 레이어에서 `BoardExportService.getMandatoryApprovalConfig(boardId)`로 상속 해소 후 `effective_elapsed`를 산출·필터링하거나, 아래와 같이 SQL에서 재귀 CTE로 동일 의미를 구현한다):

> **Board 설정 상속**: `mandatory_approval_config`가 null인 게시판은 상위 `parent_id` 체인을 따라 올라가며, **첫 번째로 JSONB가 non-null인 조상**의 객체 전체를 유효 설정으로 본다(board/data.md `getMandatoryApprovalConfig`와 동일 — 필드 단위 병합이 아닌 replace 상속).

```sql
-- 참고: maintenance_pause_seconds(tenant_id, approval_created_at, now())
--       = 해당 구간과 겹치는 유지보수 창 길이 합(초). BR-APR-027.
WITH RECURSIVE board_effective_config AS (
  SELECT
    a.id AS approval_id,
    a.created_at,
    0 AS depth,
    b.id AS walk_board_id,
    b.parent_id,
    b.mandatory_approval_config AS mac
  FROM approval a
  JOIN document d ON d.id = a.document_id
  JOIN board b ON b.id = d.board_id
  WHERE a.status = 'pending'

  UNION ALL

  SELECT
    bec.approval_id,
    bec.created_at,
    bec.depth + 1,
    p.id,
    p.parent_id,
    p.mandatory_approval_config
  FROM board_effective_config bec
  JOIN board p ON p.id = bec.parent_id
  WHERE bec.mac IS NULL
    AND bec.parent_id IS NOT NULL
),
approval_board_sla AS (
  SELECT DISTINCT ON (approval_id)
    approval_id,
    created_at,
    (mac->>'sla_hours')::numeric AS sla_hours,
    coalesce((mac->>'auto_reject_grace_hours')::numeric, 0) AS auto_reject_grace_hours
  FROM board_effective_config
  WHERE mac IS NOT NULL
  ORDER BY approval_id, depth ASC
)
SELECT a.id, a.document_id, a.document_version_id,
       s.sla_hours, s.auto_reject_grace_hours, a.created_at
FROM approval a
JOIN approval_board_sla s ON s.approval_id = a.id
WHERE s.sla_hours IS NOT NULL
  -- 아래 비교식의 좌변은 구현체에서
  -- (now() - a.created_at - maintenance_pause_interval) >= (sla_hours + grace_hours) 로 치환
  AND a.created_at + (s.sla_hours || ' hours')::interval
                    + (s.auto_reject_grace_hours || ' hours')::interval
                    + coalesce(maintenance_pause_interval(:tenant_id, a.created_at, now()), interval '0')
      < now()
ORDER BY a.created_at ASC
LIMIT 100;
```

> `maintenance_pause_interval(...)`는 테넌트의 유지보수 창과 `[created_at, now())` 겹침 합을 `interval`로 반환하는 DB 함수 또는 애플리케이션에서 계산한 값으로 대체한다. **유지보수 구간 합만큼 마감 데드라인이 연장**되는 효과와 동일하다 (`+ pause`를 deadline 쪽에 더하는 형태로 표기함).

> **서비스 레이어 대안**: 배치 워커가 후보 `approval_id`만 DB에서 거칠게 조회한 뒤, 건마다 `document.board_id` → `getMandatoryApprovalConfig`로 SLA·grace를 확정하고 마감 비교를 수행해도 된다. 트리 깊이가 얕고 배치 상한(100건)이 있으므로 N+1이 허용 범위이면 단순 구현으로 충분하다.

4. 각 대상 건에 대해 트랜잭션 내에서:
   - `Approval.status → 'auto_rejected'`, `Approval.updated_at = now()`
   - DocumentModule.transitionToDraftOnReject() 호출 (Critical tx — 실패·재시도는 아래 §2.1·§2.4 및 `rules.md` §1.4 참조)
   - ApprovalHistory 생성: `action = 'auto_rejected'`, `comment = 'SLA 타임아웃'`
5. 트랜잭션 커밋 후:
   - EventBus `approval.auto_rejected` 이벤트 발행
6. 배치 사이즈: 100건 단위 페이징 처리

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:approval-auto-reject` (TTL 5분)
- 획득 실패 시 스킵 (다음 주기에 재실행)

#### 실패 처리

- 부분 실패 허용 — 개별 건 처리 실패 시 에러 로그 기록 후 다음 건 계속 처리
- 실패 건은 다음 주기에 재대상 포함 (status가 여전히 `pending`)
- 연속 3회 전체 배치 실패 시 운영자 Slack 알림

---

### 2.2 승인 리마인더 배치 (`approval-reminder`)

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 일정 기간 미처리된 승인 건의 승인권자에게 리마인더 알림 발송 |
| cron 표현식 | `0 9 * * *` (매일 09:00, **Asia/Seoul**) |
| 설정 키 | `lm:approval.stale_reminder_days` (기본 3일) |

#### 실행 로직

1. 미처리 승인 건 조회:

```sql
SELECT a.id, a.document_id, a.requester_id, a.current_step,
       asr.approver_source, asr.approver_target, asr.is_mandatory, asr.name, asr.approval_type
FROM approval a
JOIN approval_step_result asr
  ON asr.approval_id = a.id
  AND asr.step_order = a.current_step
WHERE a.status = 'pending'
  AND a.created_at < now() - interval '{staleReminderDays} days'
  AND a.created_at > now() - interval '90 days'
ORDER BY a.created_at ASC
LIMIT 200;
```

2. 각 대상 건에 대해:
   - 현재 단계의 승인 대상자 목록 결정 (`approver_source` / `approver_target` 및 제출 시 스냅샷 기반 역할·그룹 조회)
   - 위임 활성 여부 확인 — 위임 중이면 위임 대상자에게도 알림
   - NotificationModule을 통해 "승인 대기 중인 문서가 있습니다" 알림 발송
3. 중복 알림 방지: Redis 키 `{tenant_id}:reminder:{approvalId}` (TTL = 24시간)로 동일 건의 일일 중복 알림 스킵
4. 배치 사이즈: 200건 단위 페이징 처리

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:approval-reminder` (TTL 10분)

#### 실패 처리

- 부분 실패 허용 — 개별 알림 발송 실패 시 로그 기록 후 계속
- 다음 주기에 재대상 포함 (Redis 키가 없으면 재알림)

---

### 2.3 위임 만료 배치 (`approval-delegation-expire`)

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 기간 만료된 위임을 자동 해제 |
| cron 표현식 | `0 0 * * *` (매일 00:00, **Asia/Seoul**) |
| BR 참조 | BR-APR-021 |

#### 실행 로직

1. 만료 위임 조회:

```sql
SELECT id, delegator_id, delegate_id, board_id
FROM approval_delegation
WHERE is_active = true
  AND end_date < CURRENT_DATE
ORDER BY end_date ASC;
```

2. 각 대상 건에 대해:
   - `ApprovalDelegation.is_active → false`
   - EventBus `approval.delegation.released` 이벤트 발행 (`releaseReason = 'expired'`)
3. 전량 처리 (위임 건수가 소규모이므로 페이징 불필요)

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:delegation-expire` (TTL 5분)

#### 실패 처리

- 부분 실패 허용 — 개별 건 해제 실패 시 로그 기록 후 다음 건 계속
- 실패 건은 다음 주기에 재대상 포함 (is_active 여전히 true)

---

### 2.4 예약 배포 보정 배치 (`approval-scheduled-publish-reconcile`)

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | BullMQ delayed job이 누락되었거나 DLQ에 빠진 예약 배포 건을 탐지하여 복구 |
| cron 표현식 | `*/30 * * * *` (30분마다, **Asia/Seoul**) |
| 관련 큐 | `scheduled-publish` |
| BR 참조 | BR-APR-019 |

#### 실행 로직

1. **유지보수 모드(전역)**: 테넌트별 `SystemConfig.maintenance_mode === true`이면 **이번 주기는 예약 배포 보정을 수행하지 않는다**(또는 동일 효과의 no-op). BullMQ 워커·delayed job이 점검 중에 `transitionToPublished()`를 호출하는 것도 FD-APR·ADR-011 운영 정책과 맞추어 **실행하지 않거나**, job을 **유지보수 종료 시각 이후로 재스케줄**한다(구현체는 하나로 통일). 문서는 `approved_scheduled`를 유지하고, SLA 자동 반려 배치(§2.1)와 동일하게 “점검 중 발행 시계 정지”에 준하는 연기 효과를 낸다.
2. `maintenance_mode === false`일 때만 아래 조회·Document 연동을 진행한다.
3. 예약 시점이 지났는데 아직 처리되지 않은 건 조회:

```sql
SELECT a.id, a.document_id, a.document_version_id,
       a.scheduled_at, a.bull_job_id
FROM approval a
WHERE a.status = 'approved'
  AND a.scheduled_at IS NOT NULL
  AND a.scheduled_at < now() - interval '10 minutes'
ORDER BY a.scheduled_at ASC
LIMIT 50;
```

4. 각 대상 건에 대해:
   - BullMQ에서 해당 job 상태 확인 (completed/failed/missing)
   - job이 missing 또는 failed인 경우: 직접 발행 처리 수행 (DocumentModule.transitionToPublished())
   - 발행 성공 후 `Approval.scheduled_at → null`, `Approval.bull_job_id → null`

#### DocumentModule 장애 시 폴백

- **재시도**: `transitionToPublished()` 호출이 일시 오류(타임아웃, 연결 단절, 503 상호 호출)로 실패하면 지수 백오프로 **최소 3회 재시도**(초기 지연 예: 5s, 30s, 2m). 동일 건은 배치 주기(30분) 내 다음 실행에서도 후보로 남는다(`scheduled_at`·상태 유지).
- **보정 배치 역할**: 본 §2.4는 BullMQ 누락·실패 복구가 1차 목적이며, Document 모듈 장애로 남은 `approved_scheduled` 잔류 건을 **다음 주기에 자동 재처리**하는 안전망으로 동작한다.
- **한계·알림**: 재시도 소진 후에도 실패하면 ERROR 로그·메트릭(`scheduled_publish.failure_rate` 등) 및 연속 실패 시 Slack(기존 § 실패 처리)으로 알린다. 데이터 정합성을 위해 Approval을 임의로 `approved`로 되돌리지 않고, **동일 건 재시도 가능 상태**를 유지한다(수동 재처리는 DLQ·운영 대시보드 — 기존 문구 유지).
- **자동 반려 배치(§2.1)**: `transitionToDraftOnReject()` 실패 시에도 동일 원칙 — 건은 `pending`이면 다음 주기 재대상, 로그·알림.

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:recon:scheduled-publish` (TTL 15분)

#### 실패 처리

- 부분 실패 허용 — 개별 건 처리 실패 시 로그 기록 후 계속
- 연속 3회 전체 실패 시 운영자 Slack 알림
- DLQ 잔류 건은 운영자 대시보드에서 수동 재처리 가능

---

## 3. 작업 의존 관계

```mermaid
graph TD
    A["승인 완료 (트랜잭션)"] --> B["scheduled-publish 큐<br/>(delayed job)"]
    
    C["자동 반려 배치 (5분)"] --> D["EventBus approval.auto_rejected"]
    C --> E["DocumentModule.transitionToDraftOnReject()"]
    
    F["승인 리마인더 배치 (매일)"] --> G["NotificationModule 알림 발송"]
    
    H["위임 만료 배치 (매일)"] --> I["EventBus approval.delegation.released"]
    
    J["예약 배포 보정 (30분)"] -.->|"누락 건 복구"| K["DocumentModule.transitionToPublished()"]
```

> 자동 반려 배치와 예약 배포 보정 배치는 독립적으로 실행된다. 자동 반려 대상(`pending`)과 예약 배포 대상(`approved` + `scheduled_at`)은 상태가 다르므로 충돌하지 않는다.

---

## 4. `scheduled-publish` 워커 동시 처리 수 근거

BullMQ `scheduled-publish` 큐 소비 워커의 **`concurrency`** 값은 [events.md §1.1](events.md#11-important-티어--bullmq-직접-enqueue)에 명시된 대로 **1**로 둔다.

| 고려 사항 | 근거 |
|-----------|------|
| **Critical 트랜잭션** | Job 1건당 `DocumentModule.transitionToPublished()` 등 **동일 DB 트랜잭션**을 수행한다. 동시에 다수 Job이 커밋을 점유하면 **DB 커넥션 풀** 고갈·대기 타임아웃 위험이 커진다. |
| **풀·인스턴스 상한** | 워커 프로세스를 수평 확장할 때는 `concurrency × 워커 인스턴스 수`가 애플리케이션 **풀 최대 연결 수**를 넘지 않도록 조정한다 (예: 풀 max 20, 인스턴스 4대면 워커당 concurrency 5 이하 등 — 수치는 운영 환경에 맞게 튜닝). |
| **순서·락** | 예약 발행 Job이 동일 문서·관련 엔티티에 집중될 때 낮은 동시성이 낙관적 락 충돌과 재시도 부담을 줄인다. |

스펙상 기본값은 **concurrency = 1**이며, 운영에서 상향 시에는 위 표와 events.md를 함께 갱신한다.
