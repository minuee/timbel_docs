# Approval API 스펙

> 기능정의서: [FD-APR-승인워크플로](../../01-requirements/features/FD-APR-승인워크플로.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [data.md](data.md)

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /approval-templates | 결재라인 템플릿 목록 조회 | ADMIN |
| GET | /approval-templates/:id | 결재라인 템플릿 상세 조회 | ADMIN |
| POST | /approval-templates | 결재라인 템플릿 생성 | ADMIN |
| PATCH | /approval-templates/:id | 결재라인 템플릿 수정 | ADMIN |
| DELETE | /approval-templates/:id | 결재라인 템플릿 삭제 | ADMIN |
| GET | /approvals/inbox | 승인 대기 목록(인박스) 조회 | APPROVE |
| POST | /approvals/:approvalId/steps/:stepOrder/decide | 승인/반려 처리 | APPROVE |
| POST | /approvals/:approvalId/withdraw | 승인 철회 | EDIT (요청자) |
| POST | /approvals/bypass | 긴급 발행 | ADMIN (`bypass_approval`) |
| POST | /approvals/batch-decide | 일괄 승인/반려 | APPROVE |
| POST | /approvals/:approvalId/schedule | 예약 배포 설정 | APPROVE |
| GET | /approvals/:approvalId | 승인 요청 상세 조회 | VIEW |
| GET | /approvals/history | 승인 이력 조회 | VIEW |
| POST | /approval-delegations | 위임 설정 | APPROVE |
| DELETE | /approval-delegations/:delegationId | 위임 해제 | APPROVE (위임자) |
| GET | /approval-delegations | 내 위임 목록 조회 | 인증 필요 |

> **문서 제출(Submit)은 Document API 소관이다.** `POST /documents/:id/submit` 엔드포인트가 Document Controller에서 승인 요청 생성을 오케스트레이션한다 (ADR-011 A-2). Approval 모듈은 결재 행위(승인/반려/위임 등) 전용 API만 노출한다.
>
> **결재라인 템플릿 CRUD**는 ApprovalModule 소관이다 (ADR-011 §E-1). NestJS 글로벌 프리픽스 적용 시 실제 경로는 `/api` 접두가 붙는다 (예: `GET /api/approval-templates`).

---

## 연동 계약 (Document ↔ Approval)

### 공개 REST vs 내부 서비스

| 구분 | 진입점 | 호출 주체 |
|------|--------|-----------|
| 공개 REST API | Document 모듈 `POST /documents/:id/submit` | 클라이언트 |
| 내부 서비스 호출 | `ApprovalService.createApproval(dto)` (또는 동등한 애플리케이션 서비스 메서드) | Document Controller만 (HTTP 비노출) |

### Board 모듈 내부 계약 (필수 승인 설정)

ApprovalModule은 SLA·자동 반려 유예·위임 허용·필수 단계 등을 **문서의 `board_id` 기준 유효 설정**으로 조회해야 한다. BoardModule이 아래 인터페이스(또는 동등한 애플리케이션 서비스)를 제공한다.

```typescript
/** board/data.md `getMandatoryApprovalConfig`와 동일 의미 — null이면 상위 parent 재귀 상속 */
interface MandatoryApprovalConfig {
  mandatory_steps?: unknown[];
  self_approve_blocked?: boolean;
  delegation_allowed?: boolean;
  sla_hours?: number | null;
  auto_reject_grace_hours?: number;
  min_steps?: number;
  max_steps?: number;
  // 기타 board/data.md JSON 스키마 필드
}

interface BoardExportService {
  getMandatoryApprovalConfig(boardId: string): Promise<MandatoryApprovalConfig | null>;
}
```

> 구현체 이름은 `BoardExportService` / `BoardReadFacade` 등 프로젝트 컨벤션에 맞춰도 된다. 승인 요청 검증(BR-APR-028~030), 자동 반려 배치(schedule.md §2.1), 인박스 SLA 표시 등 **모든 게시판 정책 읽기**는 이 계약을 경유한다.

### Auth 모듈 내부 계약 (승인자 풀 · 권한)

인박스 필터링, 단계별 승인 권한 검증(BR-APR-025), `ROLE`/`TEAM` 단계의 실제 승인 가능 사용자 집계 등은 Auth 모듈이 제공하는 읽기 전용 파사드(또는 동등한 애플리케이션 서비스)를 경유한다.

```typescript
/** 게시판 단위 권한 액션 예: 'APPROVE' | 'VIEW' | 'EDIT' — 프로젝트 권한 enum과 정합 */
type BoardPermissionAction = string;

interface AuthExportService {
  /** 사용자가 해당 게시판에서 action 권한을 가지는지 */
  hasPermission(userId: string, boardId: string, action: BoardPermissionAction): Promise<boolean>;

  /** 역할명·게시판 기준으로 APPROVE 등 후보 사용자 ID 목록 (승인자 풀 확장 시 사용) */
  getUsersByRole(roleName: string, boardId: string): Promise<string[]>;

  /** 팀 ID·게시판 기준 소속 사용자 ID 목록 (TEAM 단계 승인 대상 집계 — BR-APR-025). `getUsersByRole`과 동일하게 게시판 단위 권한 필터에 사용 */
  getUsersByTeam(teamId: string, boardId: string): Promise<string[]>;
}
```

> 구현체 이름은 `AuthExportService` / `AuthReadFacade` 등 컨벤션에 맞춰도 된다. `getUsersByTeam`으로 TEAM 단계 후보를 확장하고, 위임 반영 등은 본 계약을 추가 확장하거나 별도 메서드로 보완할 수 있다.

### Document 모듈 내부 계약 (Critical 트랜잭션)

승인 완료·반려·철회·예약 승인 상태 반영 시 ApprovalModule이 동일 DB 트랜잭션 경계에서 호출한다. 아래 시그니처는 **모듈 간 계약**이며, `documentVersionId`·`EntityManager`/`QueryRunner` 등은 구현체에서 `approvalId` 조회로 해소하거나 오버로드로 노출한다.

```typescript
interface DocumentExportService {
  /** 최종 승인 후 즉시 발행 — approvalId로 연결된 버전·문서 상태를 일관되게 갱신 */
  transitionToPublished(documentId: string, approvalId: string): Promise<void>;

  /** 최종 승인 + 예약 배포 — Document → approved_scheduled, Approval.scheduled_at 등과 정합 */
  transitionToApprovedScheduled(
    documentId: string,
    approvalId: string,
    scheduledPublishAt: string,
  ): Promise<void>;

  /** 반려·철회·자동 반려 시 draft 복귀 */
  transitionToDraftOnReject(documentId: string, approvalId: string, reason: string): Promise<void>;
}
```

> 상세 호출 매트릭스·`txManager` 인자는 [events.md §3.1](events.md#31-documentservice-critical-tx)과 동일 의미로 유지하되, 공개 계약 문서에서는 위 식별자(`documentId`, `approvalId`) 중심으로 기술한다.

> 구현체 이름은 `DocumentExportService` / `DocumentWriteFacade` 등 프로젝트 컨벤션에 맞춰도 된다.

승인 요청 생성의 **HTTP 진입점은 Document Submit 한 곳**이다. Approval 모듈은 Submit용 공개 REST를 두지 않는다 (엔드포인트 요약 상단 주석과 동일).

**호출 흐름**: `POST /documents/:id/submit`에서 Document Controller가 요청 본문·문서 상태·권한을 검증한 뒤, 아래 `CreateApprovalInternalDto`로 매핑하여 `ApprovalService.createApproval(dto)`를 호출한다. 생성된 `approvalId` 등은 `SubmitDocumentResponse`에 담겨 클라이언트로 반환된다.

**DELETE 경로**: `DocumentController.deleteDocument()`(또는 동등한 삭제 요청 진입점)에서 게시판·문서 상태가 삭제 결재 대상이면, 내부적으로 `ApprovalService.createApproval({ ..., type: 'DELETE' })`를 호출한다 — HTTP 공개 계약은 Document 모듈이 오케스트레이션하고 FD-APR §11.4·BR-APR-031과 정합한다.

### CreateApprovalInternalDto (내부 전용)

이 DTO는 **Document 모듈의 Submit 엔드포인트 처리 과정에서만** Approval 측으로 전달된다. FD-APR §3.1·§3.2·API DTO 스키마와 정합한다.

```typescript
interface ApproverDto {
  type: 'USER' | 'ROLE' | 'TEAM';
  id: string;       // 사용자 UUID, 역할명, 또는 팀 ID
}

interface ApprovalStepDto {
  name: string;
  approvalType: 'ANY' | 'ALL' | 'COUNT';
  requiredCount?: number;
  approvers: ApproverDto[];
}

interface CreateApprovalInternalDto {
  documentId: string;
  /** 발행 승인(`PUBLISH`, 기본값) 또는 삭제 결재(`DELETE`). 생략 시 `'PUBLISH'`. DELETE 시에도 동일한 다단계·다인 결재라인을 사용하며, 최종 승인 시 Document 소프트 딜리트 등 후속은 Document/BR-APR-031이 담당 */
  type?: 'PUBLISH' | 'DELETE';
  comment?: string;
  ccUserIds?: string[];                    // BR-APR-009 — 참조라인
  templateId?: string;                     // 사용한 결재라인 템플릿 ID
  steps: ApprovalStepDto[];               // 기안자가 구성한 결재라인 (필수 승인자 포함)
}

interface CreateApprovalInternalResult {
  approvalId: string;
  status: 'pending';
  currentStepOrder: number;
  documentVersionId: string | null;
}
```

- **`type`**: 미지정 시 `'PUBLISH'`. DELETE 결재는 Document 삭제 요청 오케스트레이션에서만 전달한다.

- **DTO → `ApprovalStepResult` 매핑**: API(내부 DTO)의 `ApprovalStepDto.approvers: ApproverDto[]`는 저장 시 **단계당 하나의** `ApprovalStepResult` 행으로 변환된다. 동일 단계에 속한 모든 `ApproverDto`의 `type`은 동일해야 하며(검증), `approver_source` 컬럼에는 그 `type` 값을 저장한다. `id` 목록은 JSON 배열로 집계하여 `approver_target` JSONB에 넣는다 — `USER`는 UUID 문자열 배열, `ROLE`/`TEAM`은 단일 요소 배열 또는 스키마에 맞는 문자열 배열(data.md §2.3). 즉 **배열 DTO ≠ 복수 행**이고, DB 모델의 `approver_source` 단일 값 + `approver_target` 구조와 대응된다.

- Submit 시 Request Body(`SubmitDocumentDto`)는 위 필드와 **동일 의미**를 갖도록 [document/api.md](../document/api.md) Submit 섹션에서 정의한다. 공개 계약의 필드 나열·검증 규칙은 Document 스펙을 원천으로 하고, 본 절의 타입은 내부 서비스 경계용 참조이다.

---

## 상세 API

### `GET` /approval-templates

**설명**: 조직 내 결재라인 템플릿 목록을 조회한다. 비활성 템플릿 포함 여부는 쿼리로 제어한다.

**권한**: ADMIN (조직 관리자). 기안자(EDIT)도 활성 템플릿 조회 가능 (승인 요청 시 템플릿 선택용)

**Request**:

- Query params:

```typescript
interface ApprovalTemplateListQuery {
  isActive?: boolean;    // true/false 미지정 시 전체
  page?: number;         // 기본 1
  limit?: number;        // 기본 20, 최대 100
  sort?: 'name' | 'createdAt' | 'updatedAt';
  order?: 'ASC' | 'DESC';
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: { page: number; limit: number; totalItems: number; totalPages: number };
}

interface ApprovalTemplateListItem {
  id: string;
  name: string;
  description: string | null;
  isActive: boolean;
  stepCount: number;
  createdAt: string;
  updatedAt: string;
}
```

**에러 코드**: (목록 조회 특이 에러 없음 — 권한 실패 시 전역 `FORBIDDEN`)

---

### `GET` /approval-templates/:id

**설명**: 단일 결재라인 템플릿의 상세(단계 JSONB `steps` 포함)를 조회한다.

**권한**: ADMIN. 기안자(EDIT)도 활성 템플릿 조회 가능

**Request**: Path `id` — 템플릿 UUID

**Response** (`200`):

```typescript
interface ApprovalTemplateStepDto {
  stepOrder: number;
  name: string;
  approvalType: 'ANY' | 'ALL' | 'COUNT';
  requiredCount: number | null;
  approverSource: 'USER' | 'ROLE' | 'TEAM';
  approverTarget: unknown;       // 사용자 UUID 배열, 역할명, 또는 팀 ID
}

interface ApprovalTemplateDetailResponse {
  id: string;
  name: string;
  description: string | null;
  isActive: boolean;
  steps: ApprovalTemplateStepDto[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 설명 |
|------|------|------|
| APR_TEMPLATE_NOT_FOUND | 404 | 존재하지 않는 템플릿 ID |

---

### `POST` /approval-templates

**설명**: 결재라인 템플릿을 신규 생성한다.

**권한**: ADMIN

**Request**:

```typescript
interface CreateApprovalTemplateDto {
  name: string;                              // max 200자
  description?: string;
  isActive?: boolean;                        // 기본 true
  steps: ApprovalTemplateStepDto[];         // 1개 이상, stepOrder 중복 불가
}
```

**Response** (`201`): `ApprovalTemplateDetailResponse` (생성 직후 스냅샷)

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_TEMPLATE_STEPS_INVALID | 422 | steps 비어 있음, stepOrder 불연속, COUNT에 required_count 누락 등 | data.md §2.1 |
| APR_TEMPLATE_NAME_DUPLICATE | 409 | 동일 조직 내 템플릿명 중복 | — |

---

### `PATCH` /approval-templates/:id

**설명**: 결재라인 템플릿을 부분 수정한다. `steps` 교체 시에도 진행 중 승인 건에는 소급 적용되지 않는다 (BR-APR-003).

**권한**: ADMIN

**Request**: Path `id` + Body — `CreateApprovalTemplateDto`의 부분 필드(PATCH 관례)

```typescript
type PatchApprovalTemplateDto = Partial<CreateApprovalTemplateDto>;
```

**Response** (`200`): `ApprovalTemplateDetailResponse`

**에러 코드**:

| 코드 | HTTP | 설명 |
|------|------|------|
| APR_TEMPLATE_NOT_FOUND | 404 | 존재하지 않는 템플릿 |
| APR_TEMPLATE_STEPS_INVALID | 422 | steps 검증 실패 |

---

### `DELETE` /approval-templates/:id

**설명**: 결재라인 템플릿을 삭제한다. **하나 이상의 Board가 `default_approval_template_id`로 참조 중이면 삭제 불가.**

**권한**: ADMIN

**Request**: Path `id`

**Response** (`204`): 본문 없음

**에러 코드**:

| 코드 | HTTP | 설명 |
|------|------|------|
| APR_TEMPLATE_NOT_FOUND | 404 | 존재하지 않는 템플릿 |
| APR_TEMPLATE_IN_USE | 409 | 참조 중인 게시판 존재 — Board 연결 해제 후 삭제 |

---

### `GET` /approvals/inbox

**설명**: **현재 로그인 사용자**가 처리해야 할 승인 대기 건 목록(인박스)을 반환한다. `GET /approvals/history`는 감사·이력용이며, 본 엔드포인트는 승인권자 워크리스트용이다.

**권한**: APPROVE — 응답에는 호출자가 **현재 단계의 승인 대상자**(역할·지정·위임 반영)인 건만 포함한다. 관리자 오버라이드(BR-APR-014) 가능 사용자는 동일 필터 정책을 따르거나 조직 정책에 따라 전체 대기 건 조회를 허용할 수 있다(구현 시 README/권한 매트릭스와 정합).

**Request**:

- Query params:

```typescript
interface ApprovalInboxQuery {
  boardId?: string;           // 게시판 필터
  status?: 'pending';         // Phase 1 기본 pending만 — 향후 확장 시 enum 확대
  page?: number;              // 기본 1
  limit?: number;             // 기본 20, 최대 100
  sort?: 'requestedAt' | 'slaRemaining' | 'documentTitle';
  order?: 'ASC' | 'DESC';
}
```

**Response** (`200`):

```typescript
interface ApprovalSummary {
  approvalId: string;
  documentId: string;
  documentTitle: string;
  documentVersionId: string | null;
  boardId: string;
  boardName: string;
  requesterId: string;
  requesterName: string;
  requestedAt: string;              // Approval.created_at (ISO 8601)
  currentStep: number;
  totalSteps: number;
  type: 'PUBLISH' | 'DELETE';
  /** SLA 미설정(sla_hours NULL)이면 null. 설정 시 남은 시간(초) 또는 마감 시각 중 하나를 일관되게 반환 */
  slaRemainingSeconds: number | null;
  slaDeadlineAt: string | null;   // 유예 포함 예상 자동 반려 기준 시각 — BR-APR-022·BR-APR-027 보정 반영
}

interface ApprovalInboxResponse {
  items: ApprovalSummary[];
  meta: { page: number; limit: number; totalItems: number; totalPages: number };
}
```

**에러 코드**: (특이 도메인 코드 없음)

**비즈니스 규칙 참조**: BR-APR-025 (승인 권한), BR-APR-016 (일괄 처리 UI가 본 목록을 데이터 소스로 사용 가능)

---

### `POST` /approvals/:approvalId/steps/:stepOrder/decide

**설명**: 특정 단계에서 승인 또는 반려를 처리한다.

**권한**: APPROVE (해당 단계의 지정 승인자 또는 관리자 오버라이드 — BR-APR-014)

**Request**:

- Path params: `approvalId` — 승인 건 UUID, `stepOrder` — 단계 순서 (1-based)
- Body:

```typescript
interface DecideDto {
  action: 'approve' | 'reject';
  comment?: string;             // 반려 시 필수 여부는 운영 설정(반려 코멘트 필수 정책)에 따름
  /** 최종 단계 승인 시 예약 배포 선택 (ISO 8601, 미래 시점만). `Document.scheduled_publish_at` 경로와 동시 사용 불가 — schedule 엔드포인트 설명 참조 */
  scheduledPublishAt?: string;
}
```

**Response** (`200`):

```typescript
interface DecideResponse {
  approvalId: string;
  stepOrder: number;
  stepStatus: 'approved' | 'rejected' | 'pending';
  approvalStatus: 'pending' | 'approved' | 'rejected';
  nextStepOrder: number | null;
  scheduledPublishAt: string | null;
}
```

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_NO_APPROVE_PERMISSION | 403 | 승인 권한 없는 사용자의 승인/반려 시도 | [BR-APR-025](rules.md#br-apr-025) |
| APR_ALREADY_PROCESSED | 409 | 이미 처리된 승인 건에 중복 처리 시도 | [BR-APR-015](rules.md#br-apr-015) |
| APR_NOT_IN_REVIEW | 422 | 검토 대기 상태가 아닌 문서에 승인/반려 시도 | [BR-APR-026](rules.md#br-apr-026) |
| APR_SCHEDULE_PAST_TIME | 422 | 예약 배포 시간이 현재 시각 이전 | [BR-APR-019](rules.md#br-apr-019) |

**비즈니스 규칙 참조**: BR-APR-001 (유형별 통과 판정), BR-APR-002 (유형별 반려 판정), BR-APR-013 (승인 처리), BR-APR-015 (동시 처리 충돌)

---

### `POST` /approvals/:approvalId/withdraw

**설명**: 요청자가 pending 상태의 승인 요청을 철회한다. Document.status → `draft` 복원.

**권한**: EDIT (승인 요청자 본인만)

**Request**:

- Path params: `approvalId` — 승인 건 UUID
- Body:

```typescript
interface WithdrawDto {
  comment?: string;   // 철회 사유
}
```

**Response** (`200`):

```typescript
interface WithdrawResponse {
  approvalId: string;
  status: 'withdrawn';
}
```

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_ALREADY_COMPLETED | 409 | 이미 승인 완료된 건에 철회 시도 | [BR-APR-012](rules.md#br-apr-012) |
| APR_ALREADY_PROCESSED | 409 | 이미 반려/자동반려/긴급발행된 건에 철회 시도 | [BR-APR-015](rules.md#br-apr-015) |

**비즈니스 규칙 참조**: BR-APR-012

---

### `POST` /approvals/bypass

**설명**: 긴급 발행. 승인 절차를 우회하여 문서를 즉시 발행한다. **동일 문서에 기존 `pending` 승인 건이 있으면** `APR_ALREADY_PENDING` / `APR_ACTIVE_APPROVAL_EXISTS`로 거절하지 않고, FD-APR §7.3·BR-APR-035 예외에 따라 **먼저** 해당 건을 시스템에 의해 **`cancelled`**로 확정 전환(감사·이력·알림)한 뒤 **새** `bypassed` 건을 생성하고 문서를 `published`로 맞춘다(단일 트랜잭션 권장).

**권한**: ADMIN + `bypass_approval` AdminPermission

**Request**:

- Body:

```typescript
interface BypassDto {
  documentId: string;
  bypassReason: string;   // 최소 lm:approval.bypass_reason_min_length(기본 10)자
}
```

**Response** (`201`):

```typescript
interface BypassResponse {
  approvalId: string;
  status: 'bypassed';
  documentStatus: 'published';
}
```

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_BYPASS_NO_PERMISSION | 403 | 긴급 발행 권한 없는 사용자의 시도 | [BR-APR-017](rules.md#br-apr-017) |
| APR_BYPASS_REASON_TOO_SHORT | 422 | 사유가 최소 길이 미달 | [BR-APR-018](rules.md#br-apr-018) |

**비즈니스 규칙 참조**: BR-APR-017, BR-APR-018, BR-APR-035(예외 — 기존 pending은 본 엔드포인트에서 자동 `cancelled` 후 진행)

---

### `POST` /approvals/batch-decide

**설명**: 복수 승인 건을 일괄 승인 또는 반려한다. 순차 처리하며 부분 실패를 분리 보고한다. 요청 본문에는 `approvalId`만 넘기며 **`stepOrder`는 클라이언트가 지정하지 않는다**. 서버는 각 건에 대해 `Approval.status === 'pending'`이고 `ApprovalStepResult.step_order === Approval.current_step`이며 `ApprovalStepResult.status === 'pending'`인 **현재 활성 단계**를 자동으로 특정하여, 단건 `decide`와 동일한 권한·BR-APR-001/002/025/026 검증을 적용한다. 현재 단계가 아닌 건·이미 처리된 건은 `APR_NOT_IN_REVIEW` 또는 `APR_ALREADY_PROCESSED` 등으로 해당 항목만 실패 처리한다.

**트랜잭션 경계**: 각 `approvalId`는 **건별 독립 트랜잭션**으로 처리한다. 한 건이 실패해도 이미 커밋된 성공 건은 유지되며, 실패 건만 `results`·`failedItems`에 포함한다(**partial success** 패턴). 50건 전체를 단일 트랜잭션으로 묶지 않는다(1건 실패 시 나머지 일괄 롤백 방지).

**권한**: APPROVE

**Request**:

- Body:

```typescript
interface BatchDecideDto {
  action: 'approve' | 'reject';
  approvalIds: string[];      // 최대 50건 (BR-APR-016)
  comment?: string;           // 공통 코멘트
}
```

**Response** (`200`):

```typescript
interface BatchDecideResponse {
  total: number;
  succeeded: number;
  failed: number;
  results: BatchDecideResult[];
  /** success === false 인 항목만. partial success 시 실패 건 빠른 식별용(results와 동일 정보의 부분 집합) */
  failedItems: BatchDecideFailedItem[];
}

interface BatchDecideResult {
  approvalId: string;
  success: boolean;
  errorCode?: string;     // 실패 시 에러 코드 (APR_ALREADY_PROCESSED 등)
}

interface BatchDecideFailedItem {
  approvalId: string;
  errorCode?: string;
}
```

> `failedItems`는 `results` 중 `success === false`인 항목과 **동일 집합**으로 채운다(클라이언트 편의용 중복 표현).

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_NO_APPROVE_PERMISSION | 403 | 승인 권한 없음 | [BR-APR-025](rules.md#br-apr-025) |

> 개별 건 실패는 HTTP 200 응답 내 `results[].errorCode`로 반환한다 (전체 요청이 실패하는 것이 아님).

**비즈니스 규칙 참조**: BR-APR-016 (일괄 승인/반려)

---

### `POST` /approvals/:approvalId/schedule

**설명**: 승인 완료된 건에 예약 배포를 설정한다. Document.status → `approved_scheduled`.

**예약 배포 경로(상호 배타)**: 예약 배포는 **(1) 승인 워크플로 인라인** — 최종 승인 시 `DecideDto.scheduledPublishAt` 또는 본 API로 `approved_scheduled`·`Approval.scheduled_at`(및 BullMQ) 사용 — **과 (2) 비승인 게시판**의 `Document.scheduled_publish_at`([document/data.md](../document/data.md)) **중 하나만** 사용한다. **동시 사용 불가.** `Board.approval_required = true`인 문서는 (1)만, `false`인 문서는 (2)만 적용한다.

**권한**: APPROVE

**Request**:

- Path params: `approvalId` — 승인 건 UUID
- Body:

```typescript
interface SchedulePublishDto {
  scheduledPublishAt: string;   // ISO 8601, 미래 시점만 허용
}
```

**Response** (`200`):

```typescript
interface SchedulePublishResponse {
  approvalId: string;
  scheduledPublishAt: string;
  documentStatus: 'approved_scheduled';
}
```

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_SCHEDULE_PAST_TIME | 422 | 예약 시간이 과거 | [BR-APR-019](rules.md#br-apr-019) |

**비즈니스 규칙 참조**: BR-APR-019

---

### `GET` /approvals/:approvalId

**설명**: 승인 요청의 상세 정보를 조회한다. 단계별 결과, 개별 판단, 이력을 포함한다.

**권한**: VIEW (해당 문서 접근 권한)

**Request**:

- Path params: `approvalId` — 승인 건 UUID

**Response** (`200`):

```typescript
interface ApprovalDetailResponse {
  id: string;
  documentId: string;
  documentVersionId: string | null;
  templateId: string | null;
  templateName: string | null;
  type: 'PUBLISH' | 'DELETE';
  status: ApprovalStatus;
  currentStep: number;
  totalSteps: number;
  requesterId: string;
  requesterName: string;
  bypassReason: string | null;
  comment: string | null;
  ccList: CcResponse[];
  scheduledAt: string | null;
  createdAt: string;
  updatedAt: string;
  steps: StepResultResponse[];
}

type ApprovalStatus = 'pending' | 'approved' | 'rejected' | 'withdrawn' | 'auto_rejected' | 'cancelled' | 'bypassed';

interface StepResultResponse {
  id: string;
  stepOrder: number;
  name: string;
  approvalType: 'ANY' | 'ALL' | 'COUNT';
  requiredCount: number | null;
  approverSource: 'USER' | 'ROLE' | 'TEAM';
  approverTarget: unknown;
  isMandatory: boolean;
  status: 'pending' | 'approved' | 'rejected';
  completedAt: string | null;
  decisions: DecisionResponse[];
}

interface DecisionResponse {
  id: string;
  approverId: string;
  approverName: string;
  decision: 'approved' | 'rejected';
  comment: string | null;
  isDelegated: boolean;
  delegatedFromId: string | null;
  delegatedFromName: string | null;
  isOverride: boolean;
  createdAt: string;
}

interface CcResponse {
  userId: string;
  userName: string;
  comment: string | null;
  readAt: string | null;
}
```

---

### `GET` /approvals/history

**설명**: 승인 이력을 조회한다. 필터/페이지네이션 지원.

**권한**: VIEW (접근 가능 문서의 이력만 반환)

**Request**:

- Query params:

```typescript
interface ApprovalHistoryQuery {
  approvalId?: string;          // 특정 승인 건 이력
  documentId?: string;          // 특정 문서의 승인 이력
  actorId?: string;             // 특정 수행자 이력
  action?: string;              // 특정 액션 유형 필터
  sort?: 'createdAt';
  order?: 'ASC' | 'DESC';
  page?: number;                // 기본 1
  limit?: number;               // 기본 20, 최대 100
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface ApprovalHistoryItem {
  id: string;
  approvalId: string;
  documentId: string;
  documentTitle: string;
  actorId: string;
  actorName: string;
  action: string;
  stepOrder: number | null;
  comment: string | null;
  createdAt: string;
}
```

---

### `POST` /approval-delegations

**설명**: 승인 위임을 설정한다. 게시판 단위로 기간을 지정하여 다른 사용자에게 승인 권한을 위임한다.

**권한**: APPROVE (위임자 본인 — 해당 게시판의 승인 권한 보유 필수)

**Request**:

- Body:

```typescript
interface CreateDelegationDto {
  delegateId: string;     // 위임 대상자 UUID
  boardId: string;        // 위임 게시판 UUID
  startDate: string;      // 위임 시작일 (ISO 8601 date)
  endDate: string;        // 위임 종료일 (ISO 8601 date)
  reason?: string;        // 위임 사유 (max 500자)
}
```

**Response** (`201`):

```typescript
interface DelegationResponse {
  delegationId: string;
  delegatorId: string;
  delegateId: string;
  boardId: string;
  startDate: string;
  endDate: string;
  reason: string | null;
  isActive: boolean;
  createdAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 설명 | 관련 BR |
|------|------|------|---------|
| APR_DELEGATION_NOT_ALLOWED | 403 | 게시판 설정에서 위임 미허용 | [BR-APR-020](rules.md#br-apr-020) |
| APR_DELEGATION_DUPLICATE | 409 | 같은 게시판에 이미 유효한 위임 존재 | [BR-APR-020](rules.md#br-apr-020) |
| APR_REDELEGATION_BLOCKED | 403 | 위임받은 사용자의 재위임 시도 | [BR-APR-020](rules.md#br-apr-020) |

**비즈니스 규칙 참조**: BR-APR-020

---

### `DELETE` /approval-delegations/:delegationId

**설명**: 승인 위임을 수동 해제한다.

**권한**: APPROVE (위임자 본인)

**Request**:

- Path params: `delegationId` — 위임 UUID

**Response** (`200`):

```typescript
interface ReleaseDelegationResponse {
  delegationId: string;
  isActive: false;
  releaseReason: 'manual';
}
```

---

### `GET` /approval-delegations

**설명**: 내 위임 목록(내가 설정한 위임 + 내가 위임받은 건)을 조회한다.

**권한**: 인증 필요

**Request**:

- Query params:

```typescript
interface DelegationListQuery {
  type?: 'delegator' | 'delegate';  // 역할 필터 (설정자/대상자)
  isActive?: boolean;                // 활성 상태 필터
  boardId?: string;                  // 게시판 필터
}
```

**Response** (`200`):

```typescript
interface DelegationListItem {
  id: string;
  delegatorId: string;
  delegatorName: string;
  delegateId: string;
  delegateName: string;
  boardId: string;
  boardName: string;
  startDate: string;
  endDate: string;
  reason: string | null;
  isActive: boolean;
  createdAt: string;
}
```

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

### Approval 도메인 에러 코드

| 에러 코드 | HTTP | 설명 | 관련 BR | 적용 엔드포인트 |
|-----------|------|------|---------|----------------|
| APR_ALREADY_PENDING | 409 | 이미 승인 진행 중인 문서에 재요청(Document Submit 등) | BR-APR-007 | (Submit — Document API) |
| APR_SELF_APPROVE_BLOCKED | 403 | 자기 승인 차단으로 요청 불가 (유일 승인자) | BR-APR-008 | (Submit — Document API) |
| APR_NO_ELIGIBLE_APPROVER | 422 | 해당 단계에 승인 가능한 승인자 없음 | BR-APR-008 | (Submit — Document API) |
| APR_ALREADY_PROCESSED | 409 | 이미 처리된 건에 중복 처리 시도 | BR-APR-015 | decide, withdraw, batch-decide |
| APR_ALREADY_COMPLETED | 409 | 이미 완료된 건에 철회 시도 | BR-APR-012 | withdraw |
| APR_DOCUMENT_LOCKED | 423 | 승인 대기 중 문서 수정 시도 | BR-APR-005 | (Document API) |
| APR_REQUIRED_FIELDS_MISSING | 422 | 필수 항목 미입력 상태에서 승인 요청 | BR-APR-024 | (Submit — Document API) |
| APR_NO_APPROVE_PERMISSION | 403 | 승인 권한 없는 사용자의 처리 시도 | BR-APR-025 | decide, batch-decide |
| APR_BYPASS_NO_PERMISSION | 403 | 긴급 발행 권한 없음 | BR-APR-017 | bypass |
| APR_BYPASS_REASON_TOO_SHORT | 422 | 사유 최소 길이 미달 | BR-APR-018 | bypass |
| APR_SCHEDULE_PAST_TIME | 422 | 예약 시간이 과거 | BR-APR-019 | decide, schedule |
| APR_DELEGATION_DUPLICATE | 409 | 같은 게시판에 이미 유효한 위임 존재 | BR-APR-020 | delegation 생성 |
| APR_REDELEGATION_BLOCKED | 403 | 위임받은 사용자의 재위임 시도 | BR-APR-020 | delegation 생성 |
| APR_DELEGATION_NOT_ALLOWED | 403 | 게시판 설정에서 위임 미허용 | BR-APR-020 | delegation 생성 |
| APR_NOT_IN_REVIEW | 422 | 검토 대기 상태가 아닌 문서에 처리 시도 | BR-APR-026 | decide |
| APR_TEMPLATE_NOT_FOUND | 404 | 결재라인 템플릿 미존재 | — | template 상세/수정/삭제 |
| APR_TEMPLATE_IN_USE | 409 | Board가 템플릿 참조 중이어 삭제 불가 | — | template 삭제 |
| APR_TEMPLATE_STEPS_INVALID | 422 | 템플릿 steps JSONB 검증 실패 | data.md §2.1 | template 생성/수정 |
| APR_TEMPLATE_NAME_DUPLICATE | 409 | 동일 조직 내 템플릿명 중복 | — | template 생성 |
| APR_MANDATORY_STEPS_MISSING | 422 | 게시판 필수 승인자 누락 | BR-APR-028 | (Submit — Document API) |
| APR_STEP_COUNT_OUT_OF_RANGE | 422 | 결재라인 단계 수가 min_steps~max_steps 범위 벗어남 | BR-APR-029 | (Submit — Document API) |
| APR_APPROVER_NO_PERMISSION | 422 | USER 지정 승인자가 게시판 APPROVE 권한 미보유 | BR-APR-030 | (Submit — Document API) |
| APR_ACTIVE_APPROVAL_EXISTS | 409 | 문서당 활성(pending) Approval이 이미 1건 존재 | BR-APR-035 | (Submit — Document API), createApproval 내부 |
| APR_DELEGATION_INVALID_SELF_AUTHOR | 422 | decide 시 위임 확장 경로에서 위임 대상이 해당 건 문서 작성자와 동일하여 위임 적용 불가 | BR-APR-033 | decide(위임 경로) |

---

## 공통 타입

```typescript
type ApprovalStatus = 'pending' | 'approved' | 'rejected' | 'withdrawn' | 'auto_rejected' | 'cancelled' | 'bypassed';

type ApprovalType = 'PUBLISH' | 'DELETE';

type StepApprovalType = 'ANY' | 'ALL' | 'COUNT';
```
