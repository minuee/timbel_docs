# ApprovalModule — RDB 엔티티

> 결재라인 템플릿 관리, 기안자 주도 다단계/다인 승인, 참조라인(CC), 게시판 필수 승인자, 긴급 발행(Bypass), 삭제 요청 결재, 승인 이력 감사 추적, 예약 배포 관리

**아카이브 전략**: `approved`·`rejected`·`withdrawn`·`auto_rejected`·`bypassed`·`cancelled` 등 **완료·종료된 Approval** 레코드는 Phase 1에서 **영구 보관**한다(감사·이력 요구). 데이터량 증가에 따라 향후 **파티셔닝·아카이빙(콜드 스토리지 이전)** 을 검토한다.

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    ApprovalLineTemplate ||--o{ Approval : "0..1:N (템플릿 기반 승인 건)"

    Document ||--o{ Approval : "1:N (DocumentModule)"
    DocumentVersion ||--o| Approval : "1:0..1 (제출 버전)"

    Approval ||--o{ ApprovalStepResult : "1:N (단계별 결과)"
    Approval ||--o{ ApprovalHistory : "1:N (감사 이력)"

    ApprovalStepResult ||--o{ ApprovalDecision : "1:N (개별 승인자 판단)"

    ApprovalDelegation }o--|| Board : "N:1 (게시판별 위임)"

    ApprovalLineTemplate {
        UUID id PK
        VARCHAR name
        TEXT description
        JSONB steps "결재라인 단계 배열"
        BOOLEAN is_active
        UUID created_by
    }

    Approval {
        UUID id PK
        UUID document_id FK
        UUID document_version_id FK "제출 버전"
        UUID template_id FK "사용된 템플릿"
        VARCHAR type
        SMALLINT current_step
        SMALLINT total_steps
        UUID requester_id
        VARCHAR status "pending~bypassed,cancelled"
        TEXT bypass_reason
        TEXT comment
        JSONB cc_list "참조자 배열"
        TIMESTAMPTZ scheduled_at "예약 배포"
        VARCHAR bull_job_id "BullMQ job"
    }

    ApprovalStepResult {
        UUID id PK
        UUID approval_id FK
        SMALLINT step_order
        VARCHAR name "단계 이름"
        VARCHAR approver_source "USER ROLE TEAM"
        JSONB approver_target "승인자 대상"
        VARCHAR approval_type
        SMALLINT required_count
        BOOLEAN is_mandatory "필수 단계 여부"
        VARCHAR status
        TIMESTAMPTZ completed_at
    }

    ApprovalDecision {
        UUID id PK
        UUID step_result_id FK
        UUID approver_id
        VARCHAR decision
        TEXT comment
        BOOLEAN is_delegated "위임 처리 여부"
        UUID delegated_from_id "원래 승인자"
        BOOLEAN is_override "관리자 오버라이드"
    }

    ApprovalDelegation {
        UUID id PK
        UUID delegator_id "위임자"
        UUID delegate_id "위임 대상자"
        UUID board_id FK "위임 게시판"
        DATE start_date
        DATE end_date
        VARCHAR reason
        BOOLEAN is_active
    }

    ApprovalHistory {
        UUID id PK
        UUID approval_id FK
        UUID actor_id
        VARCHAR action
        SMALLINT step_order
        TEXT comment
    }
```

---

## 2. 엔티티 필드

### 2.1 ApprovalLineTemplate

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(200) | 템플릿명 (예: "금융상품 2단계 결재라인") |
| description | TEXT (nullable) | 템플릿 설명 |
| steps | JSONB (default '[]') | 결재라인 단계 배열. 아래 JSONB 구조 참조 |
| is_active | BOOLEAN (default true) | 활성 여부. 비활성 시 기안자가 선택 불가 |
| created_by | UUID | 생성자 (외부 UserService의 userId) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### steps JSONB 구조

```jsonc
[
  {
    "step_order": 1,
    "name": "팀장 검수",
    "approval_type": "ANY",            // "ANY" | "ALL" | "COUNT"
    "required_count": null,             // COUNT 유형일 때 정족수
    "approver_source": "ROLE",          // "USER" | "ROLE" | "TEAM"
    "approver_target": "team_leader"    // 역할명, 팀ID, 또는 사용자 UUID 배열
  },
  {
    "step_order": 2,
    "name": "QA 검토",
    "approval_type": "ALL",
    "required_count": null,
    "approver_source": "USER",
    "approver_target": ["uuid-박매니저", "uuid-최매니저"]
  }
]
```

#### 제약 조건

- `UNIQUE(name)` — 템플릿명 중복 방지
- steps JSONB 앱 레벨 검증: step_order 순차, approval_type은 `ANY`/`ALL`/`COUNT` 중 하나, COUNT일 때 required_count > 0 필수, approver_source는 `USER`/`ROLE`/`TEAM` 중 하나

#### 설계 결정

**결재라인 템플릿 (기존 ApprovalPolicy에서 전환)**
— 기존의 ApprovalPolicy(정책 기반 승인 엔진)를 **결재라인 템플릿**으로 역할을 전환한다. 템플릿은 자주 사용하는 결재라인 패턴을 저장하여 기안자의 편의를 돕는다. 기안자는 템플릿을 선택한 뒤 자유롭게 수정할 수 있으므로, 템플릿은 강제가 아닌 편의 도구이다. 게시판에 `default_approval_template_id`로 기본 템플릿을 연결할 수 있다.

**정책 옵션의 게시판 이동**
— 기존 ApprovalPolicy에 있던 `self_approve_blocked`, `delegation_allowed`, `sla_hours`, `auto_reject_grace_hours` 등 정책 옵션은 게시판의 `mandatory_approval_config` JSONB로 이동한다. 이는 게시판 단위로 승인 정책을 세밀하게 제어하기 위함이다.

**승인자 지정 방식 3종 (approver_source)**
— `USER`(특정 개인), `ROLE`(역할), `TEAM`(팀). `USER`가 추가되어 기안자가 승인자를 개인 단위로 직접 지정할 수 있다. `USER` 지정 시 해당 사용자가 게시판 `APPROVE` 권한을 보유해야 한다.

**결재라인 단계를 JSONB로 관리하는 이유**
— 템플릿 단계는 항상 템플릿과 함께 로드되며 독립 쿼리가 불필요하다. 템플릿당 1~5단계, 단계당 약 100바이트로 TOAST 임계값(~2KB) 미만이므로 행 내부에 인라인 저장된다.

**템플릿 비활성 처리**
— 템플릿을 삭제하지 않고 `is_active = false`로 비활성 처리한다. 비활성 템플릿은 기안자가 선택할 수 없지만, 기존에 진행 중인 승인 건은 영향받지 않는다 (ApprovalStepResult에 스냅샷이 있으므로).

**템플릿 변경 시 진행 중 건 보호**
— 승인 요청 시 기안자가 구성한 결재라인이 ApprovalStepResult에 기록된다. 템플릿이 이후 변경되어도 진행 중인 승인 건은 요청 시점의 결재라인으로 처리된다.

---

### 2.2 Approval

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 승인 대상 문서 |
| document_version_id | UUID (FK → DocumentVersion, nullable) | 제출 시점 버전. versioning_enabled=true 게시판에서 승인 요청 시 자동 생성 |
| template_id | UUID (FK → ApprovalLineTemplate, nullable) | 사용된 결재라인 템플릿. null이면 기안자가 빈 상태에서 직접 구성 |
| type | VARCHAR(20) (default 'PUBLISH') | 승인 목적: `PUBLISH`(발행), `DELETE`(삭제 요청) |
| current_step | SMALLINT (default 1) | 현재 진행 중인 단계 |
| total_steps | SMALLINT (default 1) | 전체 단계 수 (요청 시점에 기안자가 구성한 결재라인의 단계 수) |
| requester_id | UUID | 승인 요청자 (외부 UserService의 userId) |
| status | VARCHAR(20) | `pending`, `approved`, `rejected`, `withdrawn`, `auto_rejected`, `bypassed`, `cancelled` — `cancelled`는 bypass 등에 의해 기존 `pending` 건이 시스템에서 종료될 때 사용(작성자 철회 `withdrawn`과 구분) |
| bypass_reason | TEXT (nullable) | 긴급 발행 사유. `status = 'bypassed'`일 때 필수 |
| comment | TEXT (nullable) | 요청 사유 또는 변경 요약 |
| cc_list | JSONB (default '[]') | 참조자 목록. 아래 JSONB 구조 참조 |
| scheduled_at | TIMESTAMPTZ (nullable) | 예약 배포 시간. null이면 즉시 배포 |
| bull_job_id | VARCHAR(200) (nullable) | BullMQ delayed job ID. 예약 취소 시 job 삭제용 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### cc_list JSONB 구조

```jsonc
[
  {
    "user_id": "uuid-...",
    "comment": null,
    "read_at": null
  },
  {
    "user_id": "uuid-...",
    "comment": "검토 부탁드립니다",
    "read_at": "2026-03-25T10:00:00Z"
  }
]
```

#### 제약 조건

- `CHECK (type IN ('PUBLISH', 'DELETE'))`
- `CHECK (status IN ('pending', 'approved', 'rejected', 'withdrawn', 'auto_rejected', 'bypassed', 'cancelled'))`
- `CHECK (status <> 'bypassed' OR bypass_reason IS NOT NULL)` — 긴급 발행 시 사유 필수

#### 설계 결정

**status 전이 규칙**
— `pending` → `approved` | `rejected` | `withdrawn` | `auto_rejected` | `bypassed` | `cancelled`. 한 번 확정된 상태는 변경 불가하다. 새 승인이 필요하면 새 Approval 레코드를 생성한다.

| 전이 | type | 수행 주체 | 후속 처리 |
|------|------|----------|----------|
| pending → cancelled | PUBLISH \| DELETE | 시스템 (bypass 시 기존 pending 대체) | 문서 상태는 bypass 흐름에 따름 — 본 건은 시스템 취소로 종료. ApprovalHistory·이벤트 `approval.cancelled` 기록 |
| pending → approved | PUBLISH | 최종 단계 승인권자 | Document.status → `published` (또는 `approved_scheduled`) |
| pending → rejected | PUBLISH | 어느 단계의 승인권자든 | Document.status → `draft` |
| pending → withdrawn | PUBLISH | 요청자 본인 | Document.status → `draft` |
| pending → auto_rejected | PUBLISH | 시스템 (SLA 타임아웃) | Document.status → `draft` |
| pending → bypassed | PUBLISH | ADMIN + `bypass_approval` 권한자 | Document.status → `published` (즉시) |
| pending → approved | DELETE | 최종 단계 승인권자 | Document.deleted_at = now() (소프트 딜리트) |
| pending → rejected | DELETE | 어느 단계의 승인권자든 | 변경 없음 (문서 현상 유지) |
| pending → withdrawn | DELETE | 요청자 본인 | 변경 없음 (문서 현상 유지) |

**current_step / total_steps**
— 승인 요청 시점에 기안자가 구성한 결재라인의 단계 수를 `total_steps`에 설정한다. 단계별 승인이 완료될 때마다 `current_step`이 증가한다. `current_step > total_steps`이면 전체 승인 완료 → `status = approved`.

**`total_steps`와 `ApprovalStepResult` 행 수 불변 조건**
— `Approval.total_steps`는 **생성 시점**에 해당 승인 건에 삽입된 `ApprovalStepResult` 행 수와 **항상 동일**하게 설정되며, 이후 **변경되지 않는다**. 행 수와 컬럼 값의 일치는 DB `CHECK` 제약이나 트리거로 강제하지 않고, **서비스 레이어**(`ApprovalService.createApproval` 등 승인 건 생성 유일 경로)에서 삽입 직후·커밋 전에 보장한다. `(SELECT COUNT(*) FROM approval_step_result WHERE approval_id = …) = total_steps` 형태의 DDL `CHECK`는 성능·유지보수상 채택하지 않는다는 **설계 결정**으로 기록한다.

**template_id nullable**
— 기안자가 템플릿 없이 빈 상태에서 직접 결재라인을 구성한 경우 `template_id = null`이다. 긴급 발행(Bypass)에서도 null.

**긴급 발행 (Bypass)**
— `BYPASS_APPROVAL` AdminPermission을 가진 ADMIN 역할 사용자가 승인 절차를 우회하여 즉시 발행한다. `status = 'bypassed'`로 전환하고 `bypass_reason`에 사유를 기록한다 (ADR-011 A-5에 의해 `is_bypass` boolean을 제거하고 status enum으로 통합). 감사 로그와 ApprovalHistory에 모두 기록되어 사후 추적이 가능하다.

**자동 반려 (`auto_rejected`)**
— 문서 소속 게시판의 유효 `mandatory_approval_config`(상속 포함)에 SLA(`sla_hours`)가 설정된 경우, `Approval.created_at` 기준으로 `sla_hours + auto_reject_grace_hours` 경과 시 시스템이 자동으로 `auto_rejected` 상태로 전환한다 (ADR-011 A-4). 수동 반려(`rejected`)와 구분하여 감사 추적과 대시보드 필터링을 지원한다. Document.status는 `draft`로 복귀.

**제출 버전 (`document_version_id`)**
— `Board.versioning_enabled = true`인 게시판에서 승인 요청 시 DocumentVersion이 자동 생성되고(trigger='approval_request'), 해당 버전 ID를 FK로 보관한다. `versioning_enabled = false`인 게시판에서는 null — 승인은 현재 문서 기준 게이트 역할만 수행한다.

**철회 (withdrawn)**
— 요청자가 pending 상태의 승인 요청을 철회한다. 다단계 승인 도중 철회 시 진행된 단계의 ApprovalStepResult/ApprovalDecision 기록은 보존된다. Document.status가 `draft`로 복원된다. 철회 이력은 ApprovalHistory에 기록되어 감사 추적이 가능하다.

**승인 목적 (type)**
— `PUBLISH`(기본값)는 발행 승인, `DELETE`는 삭제 요청 승인이다. 동일한 다단계 승인 정책을 재사용하며, type에 따라 승인 완료 시 후속 처리가 달라진다.

| type | 승인 완료 시 후속 처리 |
|------|----------------------|
| PUBLISH | Document.status → `published` (또는 `approved_scheduled`) |
| DELETE | Document.deleted_at = now() (소프트 딜리트) |

**삭제 요청 결재 워크플로 (type = DELETE)**
— `Board.approval_required = true`인 게시판에서 문서 삭제 시, 직접 소프트 딜리트 대신 Approval(type=DELETE)을 생성하여 결재를 진행한다. 삭제 요청 중에도 문서는 현재 상태(published)를 유지하며 검색/RAG에 노출된다. Document.status에 `pending_delete`를 추가하지 않고, Approval(type=DELETE, status=pending) 존재 여부로 삭제 요청 상태를 판단한다 — 상태 모델 복잡도 최소화.

**승인-발행 트랜잭션**
— 최종 단계 승인 시 Document.status를 `published`로 전환하는 것은 Critical 트랜잭션이다. ApprovalModule이 DocumentModule.transitionToPublished()를 동일 트랜잭션에서 호출하여 원자성을 보장한다.

**CC를 JSONB로 관리하는 이유**
— 기존에는 ApprovalCc 별도 테이블로 관리했으나 JSONB 배열로 통합한다. 승인 건당 참조자 0~5명이며, 항상 승인 건과 함께 로드된다. `read_at` 갱신은 저빈도(CC 대상자가 승인 건을 열람할 때 1회)이며, "사용자 X가 CC된 모든 건 조회"는 드문 패턴이다. CC 코멘트는 승인 판정에 영향 없는 비구속적 의견이다.

**`cc_list` 동시 갱신과 락**
— `cc_list`는 Approval 행 단위 JSONB이므로, 동일 승인 건에 대한 동시 갱신(예: 다수 CC 열람자의 `read_at` 또는 코멘트 보강) 시 **낙관적 락(optimistic lock) 충돌**이 이론상 가능하다. 변경 빈도는 낮다고 가정하므로 Phase 1에서는 **`Approval` 레코드 레벨 OCC**(`updated_at` 비교 등 기존 BR-APR-015와 동일 패턴)로 충분하다는 설계 결정으로 둔다.

**예약 배포를 Approval 컬럼으로 관리하는 이유**
— 기존에는 ScheduledPublish 별도 테이블로 관리했으나 Approval의 nullable 컬럼 2개로 통합한다. (1) 예약 배포는 Approval과 1:1이며 필드가 `scheduled_at`, `bull_job_id` 2개뿐이다. (2) 기존 ScheduledPublish.document_id는 Approval.document_id와 중복이다. `scheduled_at IS NOT NULL`이면 예약 배포 건이다. 승인자가 승인 시 즉시 배포 대신 예약 배포를 선택하면 `scheduled_at`을 설정하고 BullMQ `scheduled-publish` 큐에 delayed job을 등록한다. 예약 시간 도래 시 Document.status → `published` 전환 후 `scheduled_at`, `bull_job_id`를 null로 초기화한다.

---

### 2.3 ApprovalStepResult

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| approval_id | UUID (FK → Approval) | 소속 승인 건 |
| step_order | SMALLINT | 단계 순서 (기안자가 구성한 순서) |
| name | VARCHAR(200) | 단계 이름 (기안자 지정, 예: "팀장 검수") |
| approval_type | VARCHAR(10) | 승인 유형: `ANY`, `ALL`, `COUNT` |
| required_count | SMALLINT (nullable) | 정족수 (COUNT 유형일 때) |
| approver_source | VARCHAR(10) | 승인자 지정 방식: `USER`, `ROLE`, `TEAM` |
| approver_target | JSONB | 승인자 대상 — 사용자 UUID 배열, 역할명(string), 또는 팀 ID(string) |
| is_mandatory | BOOLEAN (default false) | 게시판 필수 승인자 단계 여부. true이면 게시판 mandatory_steps에서 삽입된 단계 |
| status | VARCHAR(20) | `pending`, `approved`, `rejected` |
| completed_at | TIMESTAMPTZ (nullable) | 단계 완료 시각. pending이면 null |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(approval_id, step_order)` — 승인 건 내 단계 중복 방지
- `CHECK (status IN ('pending', 'approved', 'rejected'))`
- `CHECK (approval_type IN ('ANY', 'ALL', 'COUNT'))`
- `CHECK (approver_source IN ('USER', 'ROLE', 'TEAM'))`

#### 설계 결정

**기안자 구성 결재라인 기록**
— 기존에는 ApprovalPolicy.steps에서 스냅샷을 복사했으나, 새 모델에서는 **기안자가 직접 구성한 결재라인**이 ApprovalStepResult에 기록된다. 게시판 필수 승인자 단계(`is_mandatory = true`)와 기안자가 추가한 단계(`is_mandatory = false`)가 함께 저장된다.

**approver_source / approver_target 3종**
— `USER`(특정 개인 UUID 배열), `ROLE`(역할명 — 해당 역할 + 게시판 APPROVE 권한 보유자), `TEAM`(팀 ID — 해당 팀 소속 + 게시판 APPROVE 권한 보유자). `USER` 지정 시 해당 사용자가 게시판 `APPROVE` 권한을 보유해야 한다.

**is_mandatory (필수 단계 표시)**
— 게시판의 `mandatory_approval_config.mandatory_steps`에서 삽입된 단계는 `is_mandatory = true`로 표시한다. UI에서 "게시판 필수" 뱃지를 표시하고, 기안자가 해당 단계를 수정/삭제할 수 없음을 나타낸다.

**단계 완료 판정 로직**
— ApprovalDecision이 추가될 때마다 해당 단계의 완료 여부를 판정한다:
- `ANY`: approved 판단이 1건 이상이면 → 단계 approved
- `ALL`: 모든 대상 승인자가 approved이면 → 단계 approved. 1건이라도 rejected이면 → 단계 rejected
- `COUNT`: approved 판단이 `required_count` 이상이면 → 단계 approved

**updated_at 없음**
— status 변경은 pending → approved/rejected 1회이다. `completed_at`으로 완료 시점을 추적하므로 `updated_at`이 불필요하다.

---

### 2.4 ApprovalDecision

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| step_result_id | UUID (FK → ApprovalStepResult) | 소속 단계 결과 |
| approver_id | UUID | 판단을 내린 승인자 (외부 UserService의 userId) |
| decision | VARCHAR(10) | `approved`, `rejected` |
| comment | TEXT (nullable) | 승인/반려 사유 |
| is_delegated | BOOLEAN (default false) | 위임받은 사용자가 처리한 경우 true |
| delegated_from_id | UUID (nullable) | 원래 승인자 ID. `is_delegated = true`일 때 위임자를 추적 |
| is_override | BOOLEAN (default false) | 관리자 오버라이드로 처리한 경우 true (BR-APR-014) |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(step_result_id, approver_id)` — 동일 단계에서 동일 승인자의 중복 판단 방지
- `CHECK (decision IN ('approved', 'rejected'))`
- `CHECK (is_delegated = false OR delegated_from_id IS NOT NULL)` — 위임 처리 시 원래 승인자 필수

#### 설계 결정

**개별 승인자 판단 기록**
— 다인 승인(ALL/COUNT)에서 각 승인자의 판단과 코멘트를 개별 추적한다.

**위임 처리 추적 (`is_delegated`, `delegated_from_id`)**
— 위임받은 사용자가 승인/반려 시 `is_delegated = true`로 표시하고 `delegated_from_id`에 원래 승인자 ID를 기록한다. 이를 통해 "누가 대신 처리했는지"를 감사 추적할 수 있다. ApprovalDelegation 테이블과 조합하여 위임 맥락을 완전히 재구성할 수 있다.

**관리자 오버라이드 (`is_override`)**
— ADMIN 역할 + 게시판별 관리자 오버라이드 권한을 가진 사용자가 해당 단계의 지정 승인자가 아니더라도 승인/반려할 수 있다 (BR-APR-014). `is_override = true`로 표시하여 정규 승인과 구분한다.

**불변 (Append-Only)**
— 한 번 생성된 판단은 수정·삭제하지 않는다. 승인자가 판단을 번복해야 하면 해당 승인 건 자체를 철회 후 재요청해야 한다.

---

### 2.5 ApprovalHistory

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| approval_id | UUID (FK → Approval) | 소속 승인 건 |
| actor_id | UUID | 액션 수행자 (외부 UserService의 userId) |
| action | VARCHAR(20) | 아래 참조 |
| step_order | SMALLINT (nullable) | 단계별 액션인 경우 해당 단계 순서 |
| comment | TEXT (nullable) | 승인/반려 사유, 철회 메모, 예약 배포 설정 메모 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `CHECK (action IN ('submitted', 'approved', 'rejected', 'withdrawn', 'auto_rejected', 'cancelled', 'scheduled', 'step_approved', 'step_rejected', 'bypassed', 'delegated', 'delegation_released', 'delete_submitted', 'delete_approved', 'delete_rejected', 'delete_withdrawn', 'delete_step_approved', 'delete_step_rejected'))`

#### 설계 결정

**불변 이력 (Append-Only)**
— Approval의 모든 상태 변경을 이력으로 기록한다. 한 번 생성된 이력은 수정·삭제하지 않는다.

**action 유형**
- `submitted`: 승인 요청 제출
- `approved`: 최종 승인 완료
- `rejected`: 최종 반려
- `withdrawn`: 요청자 철회
- `auto_rejected`: SLA 타임아웃 자동 반려. comment에 "SLA 타임아웃" 기록
- `scheduled`: 예약 배포 설정
- `step_approved`: 다단계 개별 단계 통과. `step_order`에 해당 단계 번호 기록
- `step_rejected`: 다단계 개별 단계 반려
- `bypassed`: 긴급 발행. comment에 bypass_reason 기록
- `cancelled`: 시스템에 의한 승인 건 취소(예: 긴급 발행으로 기존 pending 대체). comment에 사유·대체 건 참조 등 기록
- `delegated`: 승인 위임 설정. comment에 위임 사유 기록
- `delegation_released`: 위임 해제

삭제 요청 관련 액션 (Approval.type = DELETE일 때):
- `delete_submitted`, `delete_approved`, `delete_rejected`, `delete_withdrawn`
- `delete_step_approved`, `delete_step_rejected`

**step_order nullable**
— 전체 건 수준 액션은 `step_order = null`. 단계별 액션(`step_approved`, `step_rejected`)은 해당 단계 번호를 기록한다.

---

### 2.6 ApprovalDelegation

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| delegator_id | UUID | 위임자 — 원래 승인자 (외부 UserService의 userId) |
| delegate_id | UUID | 위임 대상자 (외부 UserService의 userId) |
| board_id | UUID (FK → Board) | 위임이 적용되는 게시판 |
| start_date | DATE | 위임 시작일 |
| end_date | DATE | 위임 종료일 |
| reason | VARCHAR(500) (nullable) | 위임 사유 |
| is_active | BOOLEAN (default true) | 활성 상태. 기간 만료 또는 수동 해제 시 false |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(delegator_id, board_id) WHERE is_active = true` — 동일 게시판에서 동일 위임자의 활성 위임은 1건만 허용
- `CHECK (start_date <= end_date)` — 시작일이 종료일 이전
- `CHECK (delegator_id <> delegate_id)` — 자기 자신에게 위임 불가

#### 설계 결정

**게시판 단위 위임**
— 위임은 게시판(`board_id`) 단위로 설정한다. 전체 시스템 위임이 아니라, 특정 게시판의 승인 업무만 위임하므로 세밀한 권한 관리가 가능하다.

**기간 기반 자동 해제**
— `end_date`가 경과하면 배치 작업(schedule.md 참조)이 `is_active = false`로 전환한다. 위임 대상자가 비활성 상태가 되어도 자동 해제되며 위임자에게 알림이 발송된다 (BR-APR-021).

**재위임 차단**
— 위임받은 사용자(`delegate_id`)가 다시 다른 사용자에게 위임하는 것은 허용하지 않는다 (BR-APR-020). 앱 레벨에서 `delegate_id`가 이미 다른 위임의 `delegate_id`인지 검증한다.

**정책 수준 위임 허용 제어**
— `Board.mandatory_approval_config.delegation_allowed = false`이면 해당 게시판에서는 위임을 설정할 수 없다. 위임 생성 시 게시판의 `mandatory_approval_config`를 확인하여 차단한다.

**Soft Delete 패턴**
— 위임 이력을 보존하기 위해 물리 삭제하지 않고 `is_active = false`로 논리 삭제한다. 감사 추적 시 과거 위임 이력을 조회할 수 있다.

---

## 3. DDL 및 인덱스

### 3.1 ApprovalLineTemplate

```sql
CREATE TABLE approval_line_template (
  id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                      VARCHAR(200) NOT NULL,
  description               TEXT,
  steps                     JSONB NOT NULL DEFAULT '[]',
  is_active                 BOOLEAN NOT NULL DEFAULT true,
  created_by                UUID NOT NULL,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_approval_line_template_name UNIQUE (name)
);

CREATE INDEX idx_approval_line_template_active
  ON approval_line_template (is_active)
  WHERE is_active = true;
```

### 3.2 Approval

```sql
CREATE TABLE approval (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id           UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  document_version_id   UUID REFERENCES document_version(id) ON DELETE SET NULL,
  template_id           UUID REFERENCES approval_line_template(id) ON DELETE SET NULL,
  type                  VARCHAR(20) NOT NULL DEFAULT 'PUBLISH',
  current_step          SMALLINT NOT NULL DEFAULT 1,
  total_steps           SMALLINT NOT NULL DEFAULT 1,
  requester_id          UUID NOT NULL,
  status                VARCHAR(20) NOT NULL DEFAULT 'pending',
  bypass_reason         TEXT,
  comment               TEXT,
  cc_list               JSONB NOT NULL DEFAULT '[]',
  scheduled_at          TIMESTAMPTZ,
  bull_job_id           VARCHAR(200),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_approval_type
    CHECK (type IN ('PUBLISH', 'DELETE')),
  CONSTRAINT chk_approval_status
    CHECK (status IN ('pending', 'approved', 'rejected', 'withdrawn', 'auto_rejected', 'bypassed', 'cancelled')),
  CONSTRAINT chk_bypass_reason
    CHECK (status <> 'bypassed' OR bypass_reason IS NOT NULL)
);

CREATE INDEX idx_approval_document_status
  ON approval (document_id, type, status);

CREATE INDEX idx_approval_status_pending
  ON approval (type, status)
  WHERE status = 'pending';

CREATE INDEX idx_approval_requester
  ON approval (requester_id);

CREATE INDEX idx_approval_template
  ON approval (template_id)
  WHERE template_id IS NOT NULL;

CREATE INDEX idx_approval_scheduled
  ON approval (scheduled_at)
  WHERE scheduled_at IS NOT NULL;

CREATE INDEX idx_approval_version
  ON approval (document_version_id)
  WHERE document_version_id IS NOT NULL;
```

### 3.3 ApprovalStepResult

```sql
CREATE TABLE approval_step_result (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  approval_id              UUID NOT NULL REFERENCES approval(id) ON DELETE CASCADE,
  step_order               SMALLINT NOT NULL,
  name                     VARCHAR(200) NOT NULL,
  approval_type            VARCHAR(10) NOT NULL,
  required_count           SMALLINT,
  approver_source          VARCHAR(10) NOT NULL,
  approver_target          JSONB NOT NULL,
  is_mandatory             BOOLEAN NOT NULL DEFAULT false,
  status                   VARCHAR(20) NOT NULL DEFAULT 'pending',
  completed_at             TIMESTAMPTZ,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_step_result UNIQUE (approval_id, step_order),
  CONSTRAINT chk_step_result_status
    CHECK (status IN ('pending', 'approved', 'rejected')),
  CONSTRAINT chk_step_result_type
    CHECK (approval_type IN ('ANY', 'ALL', 'COUNT')),
  CONSTRAINT chk_step_result_source
    CHECK (approver_source IN ('USER', 'ROLE', 'TEAM'))
);

CREATE INDEX idx_step_result_approval_order
  ON approval_step_result (approval_id, step_order);

CREATE INDEX idx_step_result_pending
  ON approval_step_result (status)
  WHERE status = 'pending';
```

### 3.4 ApprovalDecision

```sql
CREATE TABLE approval_decision (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  step_result_id      UUID NOT NULL REFERENCES approval_step_result(id) ON DELETE CASCADE,
  approver_id         UUID NOT NULL,
  decision            VARCHAR(10) NOT NULL,
  comment             TEXT,
  is_delegated        BOOLEAN NOT NULL DEFAULT false,
  delegated_from_id   UUID,
  is_override         BOOLEAN NOT NULL DEFAULT false,
  created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_decision_approver UNIQUE (step_result_id, approver_id),
  CONSTRAINT chk_decision
    CHECK (decision IN ('approved', 'rejected')),
  CONSTRAINT chk_delegated_from
    CHECK (is_delegated = false OR delegated_from_id IS NOT NULL)
);

CREATE INDEX idx_decision_step_result
  ON approval_decision (step_result_id);

CREATE INDEX idx_decision_approver
  ON approval_decision (approver_id);
```

### 3.5 ApprovalHistory

```sql
CREATE TABLE approval_history (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  approval_id     UUID NOT NULL REFERENCES approval(id) ON DELETE CASCADE,
  actor_id        UUID NOT NULL,
  action          VARCHAR(30) NOT NULL,
  step_order      SMALLINT,
  comment         TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_approval_history_action
    CHECK (action IN (
      'submitted', 'approved', 'rejected', 'withdrawn', 'auto_rejected', 'cancelled',
      'scheduled', 'step_approved', 'step_rejected', 'bypassed',
      'delegated', 'delegation_released',
      'delete_submitted', 'delete_approved', 'delete_rejected', 'delete_withdrawn',
      'delete_step_approved', 'delete_step_rejected'
    ))
);

CREATE INDEX idx_approval_history_approval_created
  ON approval_history (approval_id, created_at);
```

### 3.6 ApprovalDelegation

```sql
CREATE TABLE approval_delegation (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  delegator_id    UUID NOT NULL,
  delegate_id     UUID NOT NULL,
  board_id        UUID NOT NULL REFERENCES board(id) ON DELETE CASCADE,
  start_date      DATE NOT NULL,
  end_date        DATE NOT NULL,
  reason          VARCHAR(500),
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_delegation_date_range CHECK (start_date <= end_date),
  CONSTRAINT chk_delegation_self CHECK (delegator_id <> delegate_id)
);

CREATE UNIQUE INDEX uq_delegation_active
  ON approval_delegation (delegator_id, board_id)
  WHERE is_active = true;

CREATE INDEX idx_delegation_delegate_active
  ON approval_delegation (delegate_id, is_active)
  WHERE is_active = true;

CREATE INDEX idx_delegation_end_date
  ON approval_delegation (end_date)
  WHERE is_active = true;
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [document-module.md](../document/data.md) — Document, DocumentVersion (Approval이 참조)
- [board-module.md](../board/data.md) — Board.approval_required, mandatory_approval_config, default_approval_template_id (게시판별 승인 설정)
- [audit-log-module.md](../audit-log/data.md) — 삭제 요청 관련 감사 로그 액션 (approval.delete_*)
- [shared-content-module.md](../shared-content/data.md) — SharedContent (발행 시 재임베딩 연관)
- [Redis 전략](../../02-architecture/data/aicm/redis.md) — BullMQ 큐 (scheduled-publish)
- [ES aicm_blocks 인덱스](../../02-architecture/data/aicm/es.md) — 발행 시 인덱싱
- [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) — 승인권자 Role, BYPASS_APPROVAL 권한
- [ADR-011](../../adr/011-round3-module-design-decisions.md) — §A Approval 결정사항 (위임 Phase 1, auto_rejected/bypassed status, template_id FK 전략)
- [FD-APR](../../01-requirements/features/FD-APR-승인워크플로.md) — 승인 워크플로 기능정의서 (원천 문서)
