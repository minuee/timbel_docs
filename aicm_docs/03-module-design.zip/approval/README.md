# Approval 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | ApprovalModule |
| 문서 코드 | MS-APR |
| 상태 | `draft` |
| 기능정의서 | [FD-APR-승인워크플로](../../01-requirements/features/FD-APR-승인워크플로.md) |
| 데이터 모델 | [data.md](./data.md) |
| ADR | [ADR-011 §A](../../adr/011-round3-module-design-decisions.md) |

---

## 모듈 책임

ApprovalModule은 AICM의 **결재 엔진**으로, 기안자 주도 결재라인 + 게시판 필수 승인자 기반의 하이브리드 다단계/다인 승인 워크플로를 관리한다. 다음 책임을 담당한다:

| 영역 | 설명 |
|------|------|
| 결재라인 템플릿 관리 | ApprovalLineTemplate CRUD, 자주 사용하는 결재라인 패턴 저장/재사용 |
| 승인/반려 처리 | 단계별 승인/반려 판정 (ANY/ALL/COUNT), 최종 단계 완료 시 DocumentModule Critical tx 호출 |
| 철회 | 요청자의 pending 건 철회, Document.status → draft 복원 |
| 긴급 발행 (Bypass) | ADMIN + `bypass_approval` 권한자의 승인 우회 즉시 발행 |
| 일괄 승인/반려 | 복수 건 순차 처리, 부분 실패 분리 보고 |
| 참조라인 (CC) | 승인 건 단위 CC 관리, 열람/비구속적 코멘트 |
| 필수 승인자 검증 | 게시판 mandatory_approval_config의 필수 단계가 결재라인에 포함되었는지 검증 |
| 승인 위임 (Delegation) | 게시판별 기간 위임, 재위임 차단, 자동 해제 |
| 자동 반려 (SLA 타임아웃) | sla_hours + grace_hours 경과 시 auto_rejected 상태 전환 |
| 예약 배포 | 승인 완료 후 예약 시점에 BullMQ delayed job으로 published 전환 |
| 삭제 요청 결재 | type=DELETE로 `approval_required=true` 게시판의 문서 삭제 승인 |
| 감사 이력 | ApprovalHistory를 통한 모든 상태 변경 Append-Only 기록 |

### 현재 범위 제외 기능

| 기능 | FD 참조 | 제외 사유 | 향후 계획 |
|------|---------|----------|----------|
| 단계별 SLA | FD-APR §12 | Phase 1은 건 전체 단일 SLA. 단계 진입 시점 기산은 복잡도 증가 | Phase 2에서 단계별 SLA 확장 |
| 에스컬레이션 | FD-APR §12 | 리마인더 비율별 단계적 알림·상위 에스컬레이션은 향후 확장 | Phase 2 |
| 긴급 발행 사후 검토 | FD-APR §12 | Phase 1은 감사 로그 기록까지. 사후 검토 워크플로 자동화는 Phase 2 | Phase 2 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — data.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **ApprovalLineTemplate** | 결재라인 템플릿. JSONB steps로 자주 사용하는 결재라인 패턴 저장. 기안자가 템플릿 선택 후 수정 가능 |
| **Approval** | 개별 승인 건. document_id + document_version_id FK, 6종 status (pending/approved/rejected/withdrawn/auto_rejected/bypassed) |
| **ApprovalStepResult** | 승인 단계별 결과. 기안자가 구성한 결재라인(approver_source/target, is_mandatory) 기록 |
| **ApprovalDecision** | 개별 승인자의 판단 기록. 위임(is_delegated), 오버라이드(is_override) 추적 |
| **ApprovalHistory** | 모든 승인 액션의 Append-Only 감사 이력 |
| **ApprovalDelegation** | 게시판별 승인 위임. 기간 지정, 자동 해제, 재위임 차단 |

---

## 의존 관계

```mermaid
graph LR
    %% ApprovalModule이 의존하는 대상
    Appr["<b>ApprovalModule</b>"]

    Doc["DocumentModule"]
    Board["BoardModule"]
    Auth["AuthModule"]

    Appr ==>|"Critical tx<br/>transitionToPublished()<br/>transitionToDraftOnReject()"| Doc
    Appr -->|"읽기<br/>approval_required·mandatory_approval_config"| Board
    Appr -->|"읽기<br/>역할/팀/권한 조회"| Auth

    %% ApprovalModule에 의존하는 대상
    Notif["NotificationModule"] -.->|"EventBus 수신"| Appr
    Audit["AuditLogModule"] -.->|"EventBus 수신"| Appr

    classDef hub fill:#fee2e2,stroke:#dc2626,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef consumer fill:#f3f4f6,stroke:#6b7280
    classDef critical fill:#dbeafe,stroke:#2563eb,stroke-width:2px

    class Appr hub
    class Doc critical
    class Board,Auth provider
    class Notif,Audit consumer
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Appr → Doc | DocumentModule | **Critical tx** | 승인 완료 시 `transitionToPublished()`, 반려/철회/자동반려 시 `transitionToDraftOnReject()` — 동일 트랜잭션 내 호출 |
| Appr → Board | BoardModule | 읽기 | 게시판의 `approval_required`, `versioning_enabled`, `mandatory_approval_config` 조회(상속 포함) — 아래 **BoardExportService** 계약 사용 |

**BoardExportService (내부 읽기 계약)**  
BoardModule은 Approval이 직접 `board` 테이블을 조인하지 않고도 상속이 반영된 설정을 쓸 수 있도록 `getMandatoryApprovalConfig(boardId): Promise<MandatoryApprovalConfig | null>` 형태의 export/facade를 제공한다. 시그니처·필드 정의는 `api.md`의 **Board 모듈 내부 계약 (필수 승인 설정)** 절을 원천으로 한다. Document Submit 검증, 자동 반려 배치, 인박스 SLA 등이 동일 구현을 공유한다.
| Appr → Auth | AuthModule | 읽기 | 승인권자 역할 조회, APPROVE 권한 검증, 팀 계층 구조, AdminPermission(`bypass_approval`) 확인 |
| NTF → Appr | NotificationModule | EventBus 수신 | 승인 관련 11종 이벤트를 수신하여 알림 발송 |
| AUD → Appr | AuditLogModule | EventBus 수신 | 승인 관련 모든 이벤트를 수신하여 감사 로그 비동기 기록 |

> **승인 요청 진입점**: Document Controller의 `POST /documents/:id/submit`이 오케스트레이션한다 (ADR-011 A-2). ApprovalModule은 ApprovalService를 통해 내부 호출을 받아 승인 건을 생성한다.

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | ApprovalLineTemplate, Approval, ApprovalStepResult, ApprovalDecision, ApprovalHistory, ApprovalDelegation |
| Redis / BullMQ | ● | `scheduled-publish` 큐 (예약 배포 delayed job), 배치 분산 락, 리마인더 중복 방지 키 |
| Elasticsearch | — | 직접 사용 없음 (DocumentModule이 임베딩/인덱싱 담당) |
| EventBus | ● 발행 | `approval.submitted`, `approval.approved`, `approval.rejected`, `approval.withdrawn`, `approval.auto_rejected`, `approval.bypassed`, `approval.scheduled`, `approval.step.approved`, `approval.step.rejected`, `approval.delegated`, `approval.delegation.released` |
| EventBus | ● 수신 | `board.config_updated` (캐시 무효화), `user.deactivated` (위임 자동 해제) |

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `approval.decide_latency_ms` | 승인/반려 API p95 응답 시간 | API 미들웨어 (목표: < 500ms) |
| `approval.batch_decide_latency_ms` | 일괄 승인/반려 API p95 응답 시간 | API 미들웨어 |
| `approval.auto_reject_count` | 시간당 자동 반려 건수 | 배치 카운터 |
| `approval.pending_count` | 현재 pending 상태 승인 건수 | 주기적 쿼리 (대시보드) |
| `approval.bypass_count` | 일간 긴급 발행 건수 | EventBus 카운터 |
| `approval.delegation_active_count` | 활성 위임 건수 | 주기적 쿼리 |
| `scheduled_publish.queue_lag` | scheduled-publish 큐 대기 Job 수 | BullMQ Dashboard |
| `scheduled_publish.failure_rate` | scheduled-publish 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `scheduled_publish.dlq_count` | scheduled-publish DLQ 잔류 건수 | BullMQ Dashboard |

---

## 모니터링 알림 임계값

| 대상 | 조건 | 심각도 | 채널 |
|------|------|--------|------|
| 승인 API 지연 | `approval.decide_latency_ms > 500` (5분 평균) | WARNING | Slack |
| 자동 반려 급증 | `approval.auto_reject_count > 50` (1시간) | WARNING | Slack |
| 긴급 발행 빈발 | `approval.bypass_count > 10` (1일) | WARNING | Slack |
| 예약 배포 큐 지연 | `scheduled_publish.queue_lag > 10` (10분 이상 지속) | WARNING | Slack + 대시보드 |
| 예약 배포 실패율 | `scheduled_publish.failure_rate > 20%` (최근 1시간) | CRITICAL | Slack + PagerDuty |
| DLQ 적체 | `scheduled_publish.dlq_count > 0` | CRITICAL | Slack + PagerDuty |
| 배치 연속 실패 | 자동 반려/위임 만료 배치 연속 3회 전체 실패 | CRITICAL | Slack |

---

## 로그 레벨 가이드

| 모듈/작업 | 로그 레벨 | 설명 |
|-----------|----------|------|
| 자동 반려 배치 실행 | `WARN` | 금융권 감사 관련이므로 모든 실행·실패를 WARN 이상으로 기록 |
| 긴급 발행 (Bypass) | `WARN` | 승인 우회 행위이므로 항상 WARN 기록 |
| 관리자 오버라이드 | `WARN` | 정규 승인 흐름 이탈이므로 WARN 기록 |
| DLQ 진입 | `ERROR` | 재시도 소진, 수동 개입 필요 |
| 위임 자동 해제 | `INFO` | 정상 운영 흐름 |
| Reconciliation 보정 | `INFO` | 정상 복구 흐름 |
| 의도적 큐·기능 스킵 | `INFO` | 운영 설정에 따른 스킵 (디버깅 용도) |

---

## 외부 설정값 카탈로그

ApprovalModule이 참조하는 외부 설정값 목록이다.

| 설정 키 | 기본값 | 용도 | 참조 |
|---------|--------|------|------|
| `lm:approval.bypass_reason_min_length` | 10 | 긴급 발행 사유 최소 길이 | BR-APR-018 |
| `lm:approval.stale_reminder_days` | 3 | 미처리 승인 리마인더 기준 일수 | schedule.md §2.2 |
| `sc:approval.auto_reject_cron` | `*/5 * * * *` | 자동 반려 배치 주기 | schedule.md §2.1 |
| `sc:approval.reminder_cron` | `0 9 * * *` | 승인 리마인더 배치 주기 | schedule.md §2.2 |
| `sc:approval.delegation_expire_cron` | `0 0 * * *` | 위임 만료 배치 주기 | schedule.md §2.3 |
| `sc:approval.scheduled_publish_recon_cron` | `*/30 * * * *` | 예약 배포 보정 배치 주기 | schedule.md §2.4 |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-APR-승인워크플로](../../01-requirements/features/FD-APR-승인워크플로.md) | 기능정의서 (원천 문서) |
| [ADR-011 §A](../../adr/011-round3-module-design-decisions.md) | Approval 결정사항 5건 |
| [data.md](./data.md) | RDB 엔티티/DDL |
| [api.md](./api.md) | API 스펙 |
| [rules.md](./rules.md) | 비즈니스 규칙 카탈로그 |
| [events.md](./events.md) | 이벤트 및 부수효과 |
| [schedule.md](./schedule.md) | 스케줄 및 배치 작업 |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 승인권자 Role, BYPASS_APPROVAL 권한 |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 이벤트 신뢰성 티어 |
| [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md) | BullMQ 큐 설정, DLQ 전략 |
