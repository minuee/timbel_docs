# TemplateModule — RDB 엔티티

> 문서 템플릿(보일러플레이트). 불변 원칙 — 변경 시 clone하여 새 템플릿 생성

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    %% 외부 모듈 참조
    Document }o--o| Template : "N:0..1 (DocumentModule)"
    Board }o--o| Template : "default_template_id (BoardModule)"
```

---

## 2. 엔티티 필드

### 2.1 Template

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(200) | 템플릿명 |
| description | TEXT (nullable) | 템플릿 설명 |
| category | VARCHAR(50) (nullable) | 템플릿 분류 (예: 'SOP', 'FAQ', '체크리스트', '공지', '장애대응') |
| content_blocks | JSONB | 기본 본문 — Tiptap 블록 JSON 배열. 문서 생성 시 에디터에 자동 채워짐 |
| default_tags | VARCHAR[] (nullable) | 기본 태그 목록 (PostgreSQL array) |
| is_active | BOOLEAN (default true) | 비활성 시 새 문서 생성에서 제외, 기존 참조 유지 |
| created_by | UUID | 생성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `category`는 앱 레벨에서 허용 값을 검증한다 (확장 가능성을 고려하여 CHECK 제약 대신 앱 검증)
- `content_blocks`는 NOT NULL — 빈 배열(`[]`)이라도 유효한 JSON이어야 한다

#### 설계 결정

**불변(immutable) 원칙**
— 템플릿은 생성 후 수정 불가. 변경이 필요하면 clone하여 새 템플릿을 생성한다. 이미 이 템플릿으로 작성된 문서가 사후 영향을 받지 않도록 보장한다. `updated_at`은 비활성 처리 등 메타 변경 추적용이다.

**독립 엔티티**
— 템플릿은 게시판에 직접 종속되지 않는다. 여러 게시판에서 재사용 가능하며, `Board.default_template_id`로 게시판별 기본 템플릿을 지정한다.

**템플릿 선택은 항상 선택적**
— 문서 생성 시 템플릿 지정은 필수가 아니다. 빈 문서로 자유 작성이 가능하다. Document.template_id는 nullable이다.

**승인 정책과 완전 분리**
— 템플릿은 본문 구조 프리셋 역할만 수행한다. 승인 필요 여부는 `Board.approval_required` 및 `Board.mandatory_approval_config` / `Board.default_approval_template_id`가 담당하며 템플릿과 무관하다.

**content_blocks 블록 잠금**
— 각 블록의 `attrs`에 편집 불가(`locked`) 여부를 포함할 수 있다. Tiptap 노드 `attrs` 표준을 따르며, 운영 정책에서 블록 잠금을 허용한 경우에만 해석한다. 비허용 시 `attrs.locked`가 존재해도 무시한다.

```json
{
  "type": "heading",
  "attrs": { "level": 1, "locked": true },
  "content": [{ "type": "text", "text": "면책 조항" }]
}
```

> `attrs.locked: boolean` — `true`이면 해당 블록은 문서 작성 시 편집/삭제 불가(면책 조항, 필수 안내 문구 등). `false` 또는 미지정이면 편집 가능.

**name 유니크 제약 없음**
— `template.name`에 유니크 제약을 적용하지 않는다. 동명 템플릿을 허용하여 복제(clone) 시 이름 충돌 없이 빠르게 생성할 수 있다. 관리자 목록에서는 생성일(`created_at`)과 ID로 구분한다.

**category 필드 — ENUM 미사용**
— 템플릿 분류는 고객사마다 다를 수 있으므로 PostgreSQL ENUM 대신 VARCHAR + 앱 레벨 검증을 사용한다 ([rdb.md §3.4 ENUM 처리 방식](../../02-architecture/data/aicm/rdb.md#34-enum-처리-방식) 참조).

**default_tags (PostgreSQL Array)**
— 템플릿에서 미리 지정한 태그 목록. 문서 생성 시 자동으로 부착되며, 작성자가 추가/삭제할 수 있다.

---

## 3. DDL 및 인덱스

### 3.1 Template

```sql
CREATE TABLE template (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name            VARCHAR(200) NOT NULL,
  description     TEXT,
  category        VARCHAR(50),
  content_blocks  JSONB NOT NULL,
  default_tags    VARCHAR[],
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_by      UUID NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_template_active
  ON template (is_active)
  WHERE is_active = true;

CREATE INDEX idx_template_category
  ON template (category)
  WHERE category IS NOT NULL;
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [document.md](../document/data.md) — Document.template_id (Template을 참조)
- [board.md](../board/data.md) — Board.default_template_id
