# Template 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | TemplateModule |
| 문서 코드 | MS-TPL |
| 상태 | `draft` |
| 기능정의서 | [FD-DOC-문서관리 §4](../../01-requirements/features/FD-DOC-문서관리.md) |
| 데이터 모델 | [template-module.md](./data.md) |
| 프로세스 흐름 | — |

---

## 모듈 책임

TemplateModule은 AICM의 **문서 보일러플레이트(초기 본문 구조) 관리 단위**를 담당하는 독립 모듈(Layer 1)이다. 다른 도메인 모듈에 대한 DI 의존이 없으며, DocumentModule이 문서 생성 시 이 모듈을 읽기 참조한다.

| 영역 | 설명 |
|------|------|
| 템플릿 CRUD | 템플릿 생성·조회·비활성 처리 — 수정(update)은 불변 원칙에 의해 미제공 |
| 복제(clone) | 기존 템플릿의 내용을 복사하여 새 템플릿 생성 — 변경이 필요할 때 clone으로 대체 |
| 비활성 처리 | `is_active = false` — 새 문서 생성 시 선택 목록에서 제외, 기존 문서 참조 유지 |
| 보일러플레이트 관리 | `content_blocks`(Tiptap 블록 JSON 배열)와 `default_tags`를 통한 문서 초기 구조 제공 |
| 카테고리 검증 | SOP, FAQ, 체크리스트, 공지, 장애대응 등 앱 레벨 카테고리 값 검증 (`SystemConfig` `pm:template.allowed_categories`로 관리 — [SystemConfigModule](../system-config/README.md) 경유 읽기 전용 조회) |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — template-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **Template** | 문서 초기 본문 구조(보일러플레이트). **불변(immutable)** — 생성 후 수정 불가, 변경 시 clone. name, description, category, content_blocks(JSONB), default_tags(VARCHAR[]), is_active, created_by. 게시판에 직접 종속되지 않고 여러 게시판에서 재사용 가능. 승인 정책과 완전 분리 |

> **설계 결정**: 템플릿은 불변 엔티티이다. `content_blocks`가 변경되면 사실상 다른 템플릿이므로, 버전 관리 대신 clone이 개념적으로 정확하고 구현 복잡도가 낮다. `updated_at`은 비활성 처리 등 메타 변경 추적용이다.

---

## 의존 관계

```mermaid
graph LR
    Tmpl["<b>TemplateModule</b>"]

    Doc["DocumentModule"] -->|"읽기"| Tmpl
    Board["BoardModule<br/>(default_template_id)"] -.->|"FK 참조"| Tmpl
    Search["SearchModule<br/>(TemplateChunkingRule)"] -.->|"FK 참조"| Tmpl

    classDef hub fill:#dcfce7,stroke:#16a34a,stroke-width:2px
    classDef consumer fill:#f3f4f6,stroke:#6b7280

    class Tmpl hub
    class Doc,Board,Search consumer
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Doc → Template | DocumentModule | 읽기 | 문서 생성 시 보일러플레이트 블록 구조 조회 + 기본 템플릿 활성 여부 검증 ([BR-TPL-014](rules.md#br-tpl-014-비활성-기본-템플릿-처리)) |
| Board → Template | BoardModule | FK 참조 | `Board.default_template_id` — 게시판별 기본 템플릿 지정 |
| Search → Template | SearchModule | FK 참조 | `TemplateChunkingRule.template_id` — 템플릿별 청킹 전략 분기(파싱·청킹 고급 옵션 활성 시) |

> **독립 모듈**: TemplateModule은 다른 도메인 모듈에 대한 DI 의존이 없다. `pm:template.allowed_categories` 등 시스템 설정값은 Layer 1 독립 모듈인 [SystemConfigModule](../system-config/README.md)을 통해 읽기 전용으로 조회한다. SystemConfigModule 자체가 도메인 모듈이 아닌 독립 모듈이므로, TemplateModule의 Layer 1 원칙(도메인 모듈 간 DI 의존 없음)을 유지한다.

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | Template |
| SystemConfigModule | ● | `pm:template.allowed_categories` 읽기 전용 조회 ([cache 전략](../system-config/cache.md)) |
| Redis / BullMQ | — | |
| Elasticsearch | — | |
| MinIO | — | |
| EventBus | — | |
| 외부 서비스 클라이언트 | — | |

---

## 내부 서비스 API (export)

TemplateModule이 소비 모듈에 export하는 서비스 메서드. DocumentModule 등이 TemplateModule을 DI로 import할 때 호출 가능한 public API이다.

```typescript
interface TemplateService {
  /**
   * 활성 템플릿 단건 조회 — 문서 생성 시 보일러플레이트 조회 용도.
   * 비활성 또는 존재하지 않는 템플릿의 경우 `null`을 반환한다. 예외를 던지지 않는다.
   */
  findActiveById(id: string): Promise<Template | null>;

  /** 템플릿 단건 조회 (활성/비활성 무관) — 기존 문서의 원본 템플릿 정보 확인 용도 */
  findById(id: string): Promise<Template | null>;

  /**
   * 템플릿 존재 + 활성 여부 확인 — 문서 생성 시 기본 템플릿 유효성 검증 용도.
   * 해당 ID 레코드가 존재하고 `is_active = true`일 때만 `true`. 존재하지 않거나 비활성이면 `false`. 예외를 던지지 않는다.
   */
  existsAndActive(id: string): Promise<boolean>;
}
```

> DocumentModule은 문서 생성 시 `findActiveById`로 보일러플레이트를 조회하고, `existsAndActive`로 게시판 기본 템플릿의 활성 여부를 검증한다.

---

## 이벤트 / 비동기 설계

TemplateModule은 이벤트 발행·소비 및 BullMQ 큐를 **사용하지 않는다**. 이는 의도적인 설계 결정이다.

- **소규모 동기 CRUD만으로 충분**: 템플릿은 수십~수백 건의 관리 데이터이며, 생성·복제·비활성화 모두 단일 트랜잭션 내 동기 처리로 완결된다
- **감사 로그는 인터셉터가 처리**: 감사 대상 액션(`template.created`, `template.cloned` 등)은 NestJS 전역 Interceptor([AuditLogModule](../../02-architecture/07-cross-cutting-concerns.md))가 자동 기록하므로, 별도 이벤트 발행이 불필요하다
- **모듈 독립성 유지**: 비활성화 시 영향받는 게시판 확인은 프론트엔드가 별도 Board API로 조회하며, TemplateModule은 BoardModule에 대한 의존을 만들지 않는다

---

## 운영 정책에 따른 블록 잠금

블록 잠금(`locked`)은 운영 정책에서 허용한 경우에만 적용한다. 비허용 시 `content_blocks`의 `locked` 속성은 무시된다.

---

## 감사 로그 및 운영 고려사항

### 감사 대상 액션

템플릿 관련 ADMIN 액션은 [횡단 관심사 §8.1](../../02-architecture/07-cross-cutting-concerns.md)의 "관리자 액션" 감사 대상에 해당한다.

| 액션 | 감사 이벤트 | 기록 항목 |
|------|------------|-----------|
| 템플릿 생성 | `template.created` | template_id, name, category, created_by |
| 템플릿 복제 | `template.cloned` | template_id, source_template_id, name, created_by |
| 템플릿 비활성화 | `template.deactivated` | template_id, deactivated_by |
| 템플릿 활성화 | `template.activated` | template_id, activated_by |

### 설계 결정

**물리 삭제 불가** — 템플릿은 삭제 API를 제공하지 않는다. `Document.template_id`와 `Board.default_template_id`의 FK 참조 무결성을 구조적으로 보장하기 위함이다. 더 이상 사용하지 않는 템플릿은 비활성화([BR-TPL-015](rules.md#br-tpl-015-물리-삭제-불가--비활성화로-대체))로 처리한다.

**규모 예상** — 템플릿은 소규모 관리 데이터(수십~수백 건)로 예상된다. 별도 수량 제한(`lm:template.max_count`)은 현재 불필요하며, 대량 생성이 감지되면 향후 도입을 검토한다.

### 모니터링 지표

| 지표 | 수집 방법 | 용도 |
|------|----------|------|
| 템플릿 생성 빈도 | 감사 로그(`template.created`) 집계 | 비정상 대량 생성 감지 |
| 비활성화 빈도 | 감사 로그(`template.deactivated`) 집계 | 템플릿 운영 주기 파악 |
| 활성/비활성 비율 | `SELECT is_active, COUNT(*) FROM template GROUP BY is_active` | 비활성 템플릿 누적 모니터링 |
| 카테고리 검증 실패 빈도 | 에러 로그(`TPL_INVALID_CATEGORY`) 집계 | 허용 카테고리 목록 확장 필요 여부 판단 |

### 로깅 가이드

| 상황 | 레벨 | 포함 정보 |
|------|------|----------|
| 템플릿 생성/복제/활성화/비활성화 성공 | `INFO` | template_id, action, actor |
| 카테고리 검증 실패 | `WARN` | 요청 category 값, 허용 목록, actor |
| 비활성화 성공 | `INFO` | template_id, deactivated_by |
| 템플릿 조회 실패 (NOT_FOUND) | `DEBUG` | 요청 template_id |

### 설정값 관리

| 설정 키 | 기본값 | 변경 반영 | 비고 |
|---------|--------|----------|------|
| `pm:template.allowed_categories` | `['SOP', 'FAQ', '체크리스트', '공지', '장애대응']` | SystemConfigModule 캐시 경유. 설정 변경 시 이벤트 기반 캐시 무효화로 다음 조회부터 즉시 반영 | 변경 시 기존 템플릿의 category 값은 영향 없음 — 신규 생성/복제 시에만 검증 |
| `lm:template.max_content_blocks_bytes` | `1048576` (1 MB) | 런타임 즉시 반영 | `content_blocks` JSON 직렬화 크기 상한. 초과 시 422 반환 ([BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증)) |

### 초기 시드 데이터

새 테넌트 온보딩 시 기본 템플릿을 시드로 제공하지 않는다. 고객사별 카테고리·문서 구조가 상이하여 범용 시드 템플릿이 무의미하다. 최초 설정은 고객사 온보딩 과정에서 직접 생성한다. 카테고리 값(`pm:template.allowed_categories`)은 `SystemConfig` 시드에 포함한다.

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-DOC-문서관리 §4](../../01-requirements/features/FD-DOC-문서관리.md) | 기능정의서 — 문서 템플릿 (입력 원본) |
| [template-module.md](./data.md) | RDB 엔티티/DDL |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 3계층 권한 모델 — ADMIN(`manage_templates`) 권한 |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 모듈 분류 |
