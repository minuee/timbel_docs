# Template 비즈니스 규칙

> 기능정의서: [FD-DOC-문서관리 §4](../../01-requirements/features/FD-DOC-문서관리.md)
> API 스펙: [api.md](api.md)

> **API 경로 표기**: 글로벌 `/api` prefix는 배포 환경에서 리버스 프록시로 부여되며, 모듈 스펙에서는 prefix 없이 기술한다.

---

## 1. 상태 전이

Template 엔티티는 라이프사이클 status를 갖지 않는다. **불변(immutable) 원칙**에 따라 생성 후 콘텐츠 수정이 불가하며, `is_active` 플래그로 운영 상태를 관리한다.

```mermaid
stateDiagram-v2
    [*] --> active: 템플릿 생성 [BR-TPL-001]

    active --> inactive: 비활성화 [BR-TPL-004]
    inactive --> active: 활성화 [BR-TPL-008]

    active --> active: 복제(clone) → 새 템플릿 생성 [BR-TPL-003]

    note right of active
        불변 원칙 [BR-TPL-002]
        content_blocks 수정 불가
        변경 시 clone으로 대체
    end note
```

---

## 2. 규칙 카탈로그

### 템플릿 생성

#### BR-TPL-001: 템플릿 생성

- **트리거**: `POST /templates`
- **조건**: 요청자가 `manage_templates` 어드민 권한 보유. `content_blocks`가 유효한 JSON 배열 [BR-TPL-006]. `category` 지정 시 허용 값 검증 [BR-TPL-005]
- **동작**:
  1. Template 레코드 생성 (`is_active = true`)
  2. `content_blocks`를 그대로 저장 (빈 배열 `[]` 허용)
  3. `default_tags` 지정 시 함께 저장
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_templates 권한 없음 |
  | TPL_INVALID_CATEGORY | 422 | 허용되지 않는 카테고리 값 |
- **근거**: FD-DOC §4 — 관리자가 블록 에디터에서 직접 템플릿 본문을 작성하고 저장

---

### 불변 원칙

#### BR-TPL-002: [설계 원칙] 템플릿 불변(immutable) 원칙

- **트리거**: 템플릿 수정 시도 시 (해당 API 자체가 미제공)
- **조건**: —
- **동작**: 생성된 템플릿의 `name`, `description`, `category`, `content_blocks`, `default_tags` 필드는 수정할 수 없다. 변경이 필요하면 복제(clone)하여 새 템플릿을 생성한다. `is_active` 전환과 같은 메타 변경만 허용된다
- **위반 시**: —
- **근거**: FD-DOC §4 — 템플릿 본문이 변경되면 사실상 다른 템플릿이므로, 버전 관리 대신 clone이 개념적으로 정확하고 구현 복잡도가 낮음. 이미 이 템플릿으로 작성된 문서가 사후 영향을 받지 않도록 보장

---

### 템플릿 복제

#### BR-TPL-003: 템플릿 복제(clone)

- **트리거**: `POST /templates/:id/clone`
- **조건**: 요청자가 `manage_templates` 어드민 권한 보유. 원본 템플릿이 존재 (활성/비활성 무관) — 존재 확인은 [BR-TPL-012](#br-tpl-012-템플릿-존재-확인)
- **동작**:
  1. `content_blocks` 결정: 요청에서 `contentBlocks`를 생략(undefined)하면 원본 전체 복사, 빈 배열 `[]`을 명시하면 빈 본문으로 저장([BR-TPL-006](#br-tpl-006-content_blocks-not-null-및-크기-검증)), 그 외 지정 값이 있으면 해당 값 사용
  2. 새 UUID 발급, `is_active = true`
  3. `name`은 요청에서 필수 지정, `description`/`category`/`contentBlocks`/`default_tags`는 미지정 시 원본 값 복사
  4. `created_by`는 복제 요청자로 설정
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_templates 권한 없음 |
  | TPL_TEMPLATE_NOT_FOUND | 404 | 원본 템플릿을 찾을 수 없습니다 |
  | TPL_INVALID_CATEGORY | 422 | 허용되지 않는 카테고리 값 |
- **근거**: FD-DOC §4 — 복제 흐름: 기존 템플릿 선택 → "복제" → 기존 내용이 복사된 새 템플릿 생성

  > **설계 결정 — `cloned_from` 미포함**: 복제 시 원본 템플릿 ID를 기록하는 `cloned_from` 필드는 현재 데이터 아키텍처(data.md)에 포함되어 있지 않다. 현재 시점에서 템플릿 계보 추적에 대한 비즈니스 요구가 확인되지 않았고, 감사 로그(`template.cloned` 이벤트의 `source_template_id`)에서 복제 이력이 기록되므로 사후 추적이 가능하다. 향후 계보 추적이 정식 요구사항으로 확인되면 data.md에 `cloned_from UUID REFERENCES template(id) NULL` 추가를 검토한다. **현재는 data.md를 SSoT로 삼는다.**

---

### 비활성 처리

#### BR-TPL-004: 템플릿 비활성화

- **트리거**: `PATCH /templates/:id/deactivate`
- **조건**: 요청자가 `manage_templates` 어드민 권한 보유. 대상 템플릿이 존재([BR-TPL-012](#br-tpl-012-템플릿-존재-확인)). 대상 템플릿이 현재 활성 상태 (`is_active = true`)
- **동작**:
  1. `Template.is_active` → `false`
  2. `updated_at` 갱신
  3. 새 문서 생성 시 이 템플릿은 선택 목록에서 제외
  4. 기존 문서의 `template_id` 참조는 유지 — 이미 생성된 문서에 영향 없음
  5. 해당 템플릿을 `default_template_id`로 참조하는 게시판이 있더라도 `Board.default_template_id`를 직접 변경하지 않는다 — BoardModule 소관 ([BR-TPL-014](#br-tpl-014-비활성-기본-템플릿-처리)). 영향받는 게시판 확인은 프론트엔드가 별도 Board API로 조회한다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_templates 권한 없음 |
  | TPL_TEMPLATE_NOT_FOUND | 404 | 템플릿을 찾을 수 없습니다 |
  | TPL_ALREADY_INACTIVE | 409 | 이미 비활성 상태입니다 |
- **근거**: FD-DOC §4 — 더 이상 사용하지 않는 기존 템플릿은 비활성 처리 (`is_active: false`), 기존 문서 참조 유지

---

### 데이터 검증

#### BR-TPL-005: category 앱 레벨 검증

- **트리거**: 템플릿 생성 또는 복제 시 `category` 값이 지정된 경우
- **조건**: `category` 값이 허용 목록에 포함되어야 함
- **동작**: 허용 카테고리 값 검증. 허용 목록은 `SystemConfig`의 `pm:template.allowed_categories` 키로 관리하며, 고객사별로 확장 가능. 기본값: `['SOP', 'FAQ', '체크리스트', '공지', '장애대응']`. 카테고리 검증은 SystemConfigModule의 캐시를 경유하여 값을 조회한다
- **설정 접근 패턴**: TemplateModule은 Layer 1 독립 모듈인 [SystemConfigModule](../system-config/README.md)을 통해 `pm:template.allowed_categories` 값을 읽기 전용 조회한다. SystemConfigModule은 캐시를 경유하여 값을 제공하며, 설정 변경 시 이벤트 기반 캐시 무효화로 다음 조회부터 즉시 반영한다. SystemConfigModule은 도메인 모듈이 아닌 독립 모듈이므로, TemplateModule의 Layer 1 원칙(도메인 모듈 간 DI 의존 없음)을 유지한다. 캐싱 전략 상세는 [SystemConfigModule cache.md](../system-config/cache.md) 참조
- **위반 시**: `TPL_INVALID_CATEGORY` (422) — 허용되지 않는 카테고리 값입니다: {category}
- **근거**: 데이터 아키텍처 §2.1 제약 조건 — 확장 가능성을 고려하여 CHECK 제약 대신 앱 레벨 검증

#### BR-TPL-006: content_blocks NOT NULL 및 크기 검증

- **트리거**: 템플릿 생성 또는 복제 시
- **조건**: `content_blocks`가 NOT NULL이고 유효한 JSON 배열이며, JSON 직렬화 크기가 `lm:template.max_content_blocks_bytes`(기본 1 MB = 1048576) 이하
- **동작**: 빈 배열 `[]`은 허용하되 `null`은 거부. JSON 배열 파싱 가능 여부를 먼저 확인한 뒤, `content_blocks`의 JSON 직렬화 크기가 `lm:template.max_content_blocks_bytes`를 초과하면 422를 반환한다. Tiptap 블록 스키마(`type` 필드 필수, 허용 블록 타입, 중첩 깊이 등)의 구조적 유효성 검증은 프론트엔드(에디터) 책임이다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | VALIDATION_ERROR | 400 | content_blocks는 유효한 JSON 배열이어야 합니다 |
  | TPL_CONTENT_TOO_LARGE | 422 | content_blocks 크기가 허용 상한({maxBytes} bytes)을 초과합니다 |

- **근거**: 데이터 아키텍처 §2.1 제약 조건 — content_blocks NOT NULL. 비정상적으로 큰 블록 데이터가 저장되어 DB 성능에 영향을 미치는 것을 방지

---

### 설계 원칙

#### BR-TPL-007: [설계 원칙] 승인 정책과 완전 분리

- **트리거**: —
- **조건**: —
- **동작**: 템플릿은 순수하게 본문 구조 프리셋 역할만 담당한다. 승인 필요 여부는 `Board.approval_required` 및 `Board.mandatory_approval_config` / `Board.default_approval_template_id`가 담당하며 템플릿과 무관하다. 템플릿에 결재라인 오버라이드를 부여하지 않는다
- **위반 시**: —
- **근거**: FD-DOC §4 — 승인 정책과 완전 분리. 템플릿은 본문 구조 프리셋, 승인 정책은 게시판 단위로만 관리

#### BR-TPL-009: [설계 원칙] 템플릿 선택은 항상 선택적

- **트리거**: DocumentModule에서 문서 생성 시
- **조건**: —
- **동작**: 문서 생성 시 템플릿 지정은 필수가 아니다. 빈 문서로 자유 작성이 가능하다. `Document.template_id`는 nullable이다
- **위반 시**: —
- **근거**: FD-DOC §4 — 템플릿은 "쓰면 편한 시작점"이지 강제 사항이 아님

#### BR-TPL-010: [설계 원칙] 독립 엔티티 — 게시판 비종속

- **트리거**: —
- **조건**: —
- **동작**: 템플릿은 게시판에 직접 종속되지 않는다. 여러 게시판에서 재사용 가능하며, 게시판별 기본 템플릿(`Board.default_template_id`)은 BoardModule 소관이다. 문서 생성 시 활성 템플릿 전체 목록에서 선택 가능하며, 게시판별 허용 목록 제한은 없다
- **위반 시**: —
- **근거**: FD-DOC §4 — 독립 엔티티로 관리, 여러 게시판에서 재사용 가능

---

### 활성화

#### BR-TPL-008: 템플릿 활성화

- **트리거**: `PATCH /templates/:id/activate`
- **조건**: 요청자가 `manage_templates` 어드민 권한 보유. 대상 템플릿이 존재([BR-TPL-012](#br-tpl-012-템플릿-존재-확인)). 대상 템플릿이 현재 비활성 상태 (`is_active = false`)
- **동작**:
  1. `Template.is_active` → `true`
  2. `updated_at` 갱신
  3. 새 문서 생성 시 선택 목록에 복원
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_templates 권한 없음 |
  | TPL_TEMPLATE_NOT_FOUND | 404 | 템플릿을 찾을 수 없습니다 |
  | TPL_ALREADY_ACTIVE | 409 | 이미 활성 상태입니다 |
- **근거**: 비활성 처리된 템플릿도 필요 시 복원 가능해야 함

---

### default_tags 적용

#### BR-TPL-011: default_tags 자동 부착

- **트리거**: DocumentModule에서 템플릿을 지정하여 문서 생성 시
- **조건**: 선택한 템플릿에 `default_tags`가 설정되어 있는 경우
- **동작**: 문서 생성 시 `default_tags`를 문서 태그로 자동 부착. 작성자가 추가/삭제 가능. 문서당 태그 수 제한([BR-DOC-002](../document/rules.md#br-doc-002-문서당-태그-수-제한))은 DocumentModule에서 검증
- **위반 시**: —
- **근거**: FD-DOC §4 — 기본 태그 목록, 문서 생성 시 자동으로 부착되며, 작성자가 추가/삭제 가능

---

### 목록 조회 필터

#### BR-TPL-013: 비활성 템플릿 조회 권한

- **트리거**: `GET /templates` 요청 시 `isActive=false` 지정
- **조건**: 요청자가 `manage_templates` 어드민 권한 보유
- **동작**: 비활성 템플릿을 포함한 전체 목록 반환. 비관리자가 `isActive=false`를 지정하면 해당 파라미터를 무시하고 활성 템플릿만 반환 (에러 아님)
- **위반 시**: — (에러 없이 필터 무시)
- **근거**: 비활성 템플릿은 관리 영역이므로 일반 사용자에게 노출하지 않되, 명시적 에러 대신 graceful 처리

---

### 템플릿 존재 확인

#### BR-TPL-012: 템플릿 존재 확인

- **트리거**: 템플릿 ID를 경로 파라미터 등으로 참조하는 API 호출 시 (예: `GET /templates/:id`, `POST /templates/:id/clone`, `PATCH /templates/:id/deactivate`, `PATCH /templates/:id/activate`)
- **조건**: 해당 ID의 Template 레코드가 존재해야 함
- **동작**: 비즈니스 처리 전 DB 등에서 존재 여부를 확인한다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | TPL_TEMPLATE_NOT_FOUND | 404 | 템플릿을 찾을 수 없습니다 |

- **근거**: 템플릿 ID 참조 API의 공통 선행 검증. 복제([BR-TPL-003](#br-tpl-003-템플릿-복제clone))·비활성화([BR-TPL-004](#br-tpl-004-템플릿-비활성화))·활성화([BR-TPL-008](#br-tpl-008-템플릿-활성화))는 본 규칙을 선행 만족한 뒤 각 규칙의 추가 조건을 평가한다

---

### 비활성 기본 템플릿 처리

#### BR-TPL-014: [설계 원칙] 비활성 기본 템플릿 처리

- **트리거**: DocumentModule에서 문서 생성 시 게시판의 `default_template_id`가 비활성 템플릿을 가리키는 경우
- **조건**: —
- **동작**: 비활성 템플릿은 기본 템플릿으로 자동 선택하지 않는다. DocumentModule은 게시판에서 `default_template_id`를 읽은 뒤 `TemplateService.existsAndActive(id)`(또는 동등하게 `findActiveById(id)`가 non-null인지 확인)로 방어적 검증을 수행한다 — `false`/`null`이면 해당 기본값을 적용하지 않고 템플릿 미선택(빈 문서) 흐름으로 진행한다. `default_template_id`가 비활성 템플릿을 참조하면 Board 레코드를 바꾸지 않고 위와 같이 무시한다. TemplateModule은 `Board.default_template_id`를 직접 변경하지 않는다 — BoardModule 소관. 영향받는 게시판 확인은 프론트엔드가 별도 Board API로 조회한다
- **위반 시**: —
- **근거**: TemplateModule은 Layer 1 독립 모듈이므로 BoardModule에 직접 쓰기 의존을 만들지 않는다. DocumentModule이 문서 생성 시점에 템플릿 활성 여부를 확인하는 방식으로 런타임 안전성을 보장한다

---

### 물리 삭제 불가

#### BR-TPL-015: [설계 원칙] 물리 삭제 불가 — 비활성화로 대체

- **트리거**: —
- **조건**: —
- **동작**: 템플릿은 물리 삭제 API를 제공하지 않는다. 더 이상 사용하지 않는 템플릿은 비활성화([BR-TPL-004](#br-tpl-004-템플릿-비활성화))로 처리한다. `Document.template_id`와 `Board.default_template_id`의 FK 참조 무결성을 구조적으로 보장하기 위함이다. 비활성 템플릿이 누적되더라도 소규모 관리 데이터이므로 성능 영향은 미미하다
- **위반 시**: —
- **근거**: 템플릿은 소규모 관리 데이터(수십~수백 건)로 예상된다. FK 참조 무결성을 보장하면서 운영 복잡도를 최소화한다

---

### 비활성 템플릿 상세 조회 제한

#### BR-TPL-016: 비활성 템플릿 상세 조회 제한

- **트리거**: `GET /templates/:id` 요청 시 대상 템플릿이 비활성(`is_active = false`)인 경우
- **조건**: 요청자가 `manage_templates` 어드민 권한 **미보유**
- **동작**: 비활성 템플릿은 관리 영역이므로, 비관리자에게는 `TPL_TEMPLATE_NOT_FOUND` (404)를 반환한다. ADMIN 권한 보유자는 비활성 템플릿도 정상 조회 가능하다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | TPL_TEMPLATE_NOT_FOUND | 404 | 템플릿을 찾을 수 없습니다 |

- **근거**: 목록 조회([BR-TPL-013](#br-tpl-013-비활성-템플릿-조회-권한))와 일관된 접근 정책. 비활성 템플릿은 관리 영역이므로 상세 조회에서도 비관리자에게 숨긴다. 보안·정보 노출 최소화를 위해 비관리자에게는 존재하지 않음과 동일하게 404로 응답하여, ID 열거·추측을 통한 비활성 리소스 존재 여부를 은닉한다

---

## 3. 에러 코드 카탈로그

> 전역 에러 코드 (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

| 에러 코드 | HTTP | 발생 규칙 | 메시지 템플릿 |
|-----------|------|----------|--------------|
| TPL_ALREADY_ACTIVE | 409 | BR-TPL-008 | 이미 활성 상태입니다 |
| TPL_ALREADY_INACTIVE | 409 | BR-TPL-004 | 이미 비활성 상태입니다 |
| TPL_CONTENT_TOO_LARGE | 422 | BR-TPL-006 | content_blocks 크기가 허용 상한({maxBytes} bytes)을 초과합니다 |
| TPL_INVALID_CATEGORY | 422 | BR-TPL-005 | 허용되지 않는 카테고리 값입니다: {category} |
| TPL_TEMPLATE_NOT_FOUND | 404 | BR-TPL-012, BR-TPL-016 | 템플릿을 찾을 수 없습니다 |

---

## 4. 규칙 요약 매트릭스

| 규칙 ID | 이름 | 주요 트리거 | 에러 코드 |
|---------|------|-----------|-----------|
| BR-TPL-001 | 템플릿 생성 | POST /templates | FORBIDDEN, TPL_INVALID_CATEGORY, VALIDATION_ERROR |
| BR-TPL-002 | [설계 원칙] 불변(immutable) 원칙 | — | — |
| BR-TPL-003 | 템플릿 복제(clone) | POST /templates/:id/clone | FORBIDDEN, TPL_TEMPLATE_NOT_FOUND, TPL_INVALID_CATEGORY |
| BR-TPL-004 | 템플릿 비활성화 | PATCH /templates/:id/deactivate | FORBIDDEN, TPL_TEMPLATE_NOT_FOUND, TPL_ALREADY_INACTIVE |
| BR-TPL-005 | category 앱 레벨 검증 | 템플릿 생성/복제 시 category 지정 | TPL_INVALID_CATEGORY |
| BR-TPL-006 | content_blocks NOT NULL 및 크기 검증 | 템플릿 생성/복제 시 | VALIDATION_ERROR, TPL_CONTENT_TOO_LARGE |
| BR-TPL-007 | [설계 원칙] 승인 정책과 완전 분리 | — | — |
| BR-TPL-008 | 템플릿 활성화 | PATCH /templates/:id/activate | FORBIDDEN, TPL_TEMPLATE_NOT_FOUND, TPL_ALREADY_ACTIVE |
| BR-TPL-009 | [설계 원칙] 템플릿 선택은 항상 선택적 | DocumentModule 문서 생성 시 | — |
| BR-TPL-010 | [설계 원칙] 독립 엔티티 — 게시판 비종속 | — | — |
| BR-TPL-011 | default_tags 자동 부착 | DocumentModule 문서 생성 시 | — |
| BR-TPL-012 | 템플릿 존재 확인 | 템플릿 ID 참조 API | TPL_TEMPLATE_NOT_FOUND |
| BR-TPL-013 | 비활성 템플릿 조회 권한 | GET /templates (isActive=false) | — |
| BR-TPL-014 | [설계 원칙] 비활성 기본 템플릿 처리 | DocumentModule 문서 생성 시 | — |
| BR-TPL-015 | [설계 원칙] 물리 삭제 불가 | — | — |
| BR-TPL-016 | 비활성 템플릿 상세 조회 제한 | GET /templates/:id | TPL_TEMPLATE_NOT_FOUND |
