# Template API 스펙

> 기능정의서: [FD-DOC-문서관리 §4](../../01-requirements/features/FD-DOC-문서관리.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [template-module.md](./data.md)

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| POST | /templates | 템플릿 생성 | ADMIN (`manage_templates`) |
| GET | /templates | 템플릿 목록 조회 | 인증 필요 |
| GET | /templates/:id | 템플릿 상세 조회 | 인증 필요 |
| POST | /templates/:id/clone | 템플릿 복제 | ADMIN (`manage_templates`) |
| PATCH | /templates/:id/deactivate | 템플릿 비활성화 | ADMIN (`manage_templates`) |
| PATCH | /templates/:id/activate | 템플릿 활성화 | ADMIN (`manage_templates`) |

> **수정(PATCH /templates/:id) 엔드포인트는 없다** — 불변 원칙. 변경이 필요하면 복제(clone) 후 새 템플릿을 생성한다.

> **응답 형식**: 모든 응답은 [횡단 관심사 §8.4](../../02-architecture/07-cross-cutting-concerns.md)의 공통 래퍼 `{ data, meta, pagination }` 형식을 따른다.

---

## 상세 API

### `POST` /templates

**설명**: 새 템플릿을 생성한다. 관리자가 블록 에디터에서 직접 작성한 보일러플레이트를 저장한다.

**권한**: ADMIN (`manage_templates`)

**Request**:

- Body:

```typescript
interface CreateTemplateDto {
  name: string;                      // 필수 — 템플릿명 (max 200자)
  description?: string;              // 선택 — 템플릿 설명
  category?: string;                 // 선택 — 분류 ('SOP', 'FAQ', '체크리스트', '공지', '장애대응' 등)
  contentBlocks: Record<string, any>[]; // 필수 — Tiptap 블록 JSON 배열 (빈 배열 허용)
  defaultTags?: string[];            // 선택 — 기본 태그 목록
}
```

**Request 예시**:

```json
{
  "name": "SOP 표준 템플릿",
  "description": "표준 운영 절차 작성용",
  "category": "SOP",
  "contentBlocks": [
    { "type": "heading", "attrs": { "level": 1 }, "content": [{ "type": "text", "text": "목적" }] },
    { "type": "paragraph", "content": [{ "type": "text", "text": "이 문서의 목적을 작성하세요." }] },
    { "type": "heading", "attrs": { "level": 1 }, "content": [{ "type": "text", "text": "절차" }] },
    { "type": "bulletList", "content": [{ "type": "listItem", "content": [{ "type": "paragraph", "content": [{ "type": "text", "text": "단계를 작성하세요." }] }] }] },
    { "type": "callout", "attrs": { "variant": "info" }, "content": [{ "type": "paragraph", "content": [{ "type": "text", "text": "참고 사항을 작성하세요." }] }] }
  ],
  "defaultTags": ["SOP", "운영절차"]
}
```

**Response** (`201`):

```typescript
interface TemplateResponse {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  contentBlocks: Record<string, any>[];
  defaultTags: string[] | null;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
```

**비즈니스 규칙 참조**: [BR-TPL-001](rules.md#br-tpl-001-템플릿-생성), [BR-TPL-005](rules.md#br-tpl-005-category-앱-레벨-검증), [BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| VALIDATION_ERROR | 400 | [BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증) |
| FORBIDDEN | 403 | [BR-TPL-001](rules.md#br-tpl-001-템플릿-생성) |
| TPL_INVALID_CATEGORY | 422 | [BR-TPL-005](rules.md#br-tpl-005-category-앱-레벨-검증) |
| TPL_CONTENT_TOO_LARGE | 422 | [BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증) |

---

### `GET` /templates

**설명**: 템플릿 목록을 조회한다. 기본적으로 활성 템플릿만 반환한다.

**권한**: 인증 필요 (문서 생성 시 템플릿 선택 목록 — 인증된 사용자 누구나 조회 가능)

**비즈니스 규칙 참조**: [BR-TPL-013](rules.md#br-tpl-013-비활성-템플릿-조회-권한) — `isActive=false` 지정 시 ADMIN 권한 확인

**Request**:

- Query params:

```typescript
interface ListTemplatesQuery {
  category?: string;               // 카테고리 필터
  isActive?: boolean;              // 활성 상태 필터 (기본 true — false 지정 시 ADMIN 권한 필요, 비관리자는 활성 템플릿만 조회)
  search?: string;                 // 템플릿명 LIKE 검색
  sort?: 'name' | 'createdAt' | 'category';  // 기본값: 'createdAt'
  order?: 'ASC' | 'DESC';                    // 기본값: 'DESC'
  cursor?: string;                 // 커서 (이전 응답의 nextCursor)
  limit?: number;                  // 기본 20, 최대 100
}
```

> **커서 인코딩 전략**: `cursor`는 `{sort_field_value}:{id}` 형태의 composite 값을 Base64 인코딩한 문자열이다. `sort` 파라미터에 따라 커서의 첫 번째 요소가 달라진다 (예: `sort=name`이면 `{name}:{id}`, `sort=createdAt`이면 `{createdAt}:{id}`). 동일 정렬 값의 안정 정렬을 위해 `id`를 tiebreaker로 사용한다. 프로젝트 공통 커서 페이지네이션 패턴은 [횡단 관심사](../../02-architecture/07-cross-cutting-concerns.md)를 참조한다.

**Response** (`200`):

```typescript
interface CursorPaginatedResponse<T> {
  data: T[];
  pagination: {
    nextCursor: string | null;
    hasMore: boolean;
    limit: number;
  };
}

interface TemplateListItem {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  defaultTags: string[] | null;
  isActive: boolean;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}
```

> `TemplateListItem`에서 `contentBlocks`는 목록 조회 시 응답 크기 최적화를 위해 제외한다. 상세 조회(`GET /templates/:id`)에서만 반환한다.

---

### `GET` /templates/:id

**설명**: 템플릿 상세 정보를 조회한다. `content_blocks` 전체를 포함한다.

**권한**: 인증 필요 — 비활성 템플릿은 ADMIN(`manage_templates`) 권한 필요 ([BR-TPL-016](rules.md#br-tpl-016-비활성-템플릿-상세-조회-제한))

> **비활성 템플릿 상세 조회 제한**: 비관리자가 비활성 템플릿의 ID로 직접 접근하면 404를 반환한다. 비활성 템플릿은 관리 영역이므로, 목록 조회(`GET /templates`)뿐 아니라 상세 조회에서도 비관리자에게 숨긴다.

**Request**:

- Path params: `id` — 템플릿 UUID

**Response** (`200`): `TemplateResponse`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| TPL_TEMPLATE_NOT_FOUND | 404 | [BR-TPL-012](rules.md#br-tpl-012-템플릿-존재-확인), [BR-TPL-016](rules.md#br-tpl-016-비활성-템플릿-상세-조회-제한) |

---

### `POST` /templates/:id/clone

**설명**: 기존 템플릿을 복제하여 새 템플릿을 생성한다. 원본의 `description`, `category`, `content_blocks`, `default_tags`가 복사되며, 각 필드를 오버라이드할 수 있다. 이름은 필수로 지정해야 한다.

**권한**: ADMIN (`manage_templates`)

**Request**:

- Path params: `id` — 원본 템플릿 UUID
- Body:

```typescript
interface CloneTemplateDto {
  name: string;                      // 필수 — 새 템플릿명 (max 200자)
  description?: string;              // 선택 — 미지정 시 원본 설명 복사
  category?: string;                 // 선택 — 미지정 시 원본 카테고리 복사
  contentBlocks?: Record<string, any>[]; // 선택 — 미지정 시 원본 블록 복사. 지정 시 원본 대신 해당 값 사용
  defaultTags?: string[];            // 선택 — 미지정 시 원본 기본 태그 복사
}
```

> **`contentBlocks` 분기**: 필드를 생략(undefined)하면 원본 `content_blocks`를 복사한다. 빈 배열 `[]`을 명시하면 원본 복사가 아니라 빈 본문으로 저장한다([BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증)).

**Response** (`201`): `TemplateResponse`

**비즈니스 규칙 참조**: [BR-TPL-003](rules.md#br-tpl-003-템플릿-복제clone)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| VALIDATION_ERROR | 400 | [BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증) |
| FORBIDDEN | 403 | [BR-TPL-003](rules.md#br-tpl-003-템플릿-복제clone) |
| TPL_TEMPLATE_NOT_FOUND | 404 | [BR-TPL-003](rules.md#br-tpl-003-템플릿-복제clone) |
| TPL_INVALID_CATEGORY | 422 | [BR-TPL-005](rules.md#br-tpl-005-category-앱-레벨-검증) |
| TPL_CONTENT_TOO_LARGE | 422 | [BR-TPL-006](rules.md#br-tpl-006-content_blocks-not-null-및-크기-검증) |

---

### `PATCH` /templates/:id/deactivate

**설명**: 템플릿을 비활성화한다. 새 문서 생성 시 선택 목록에서 제외되며, 기존 문서 참조는 유지된다.

**권한**: ADMIN (`manage_templates`)

> **비활성화 전 영향 확인**: 프론트엔드는 비활성화 요청 전에 `GET /boards?defaultTemplateId={id}` 등으로 영향 게시판을 사전 확인할 것을 권장한다. Layer 1 독립 원칙에 따라 TemplateModule은 BoardModule에 직접 의존하지 않는다.

**Request**:

- Path params: `id` — 템플릿 UUID

**Response** (`200`): `TemplateStatusResponse`

**비즈니스 규칙 참조**: [BR-TPL-004](rules.md#br-tpl-004-템플릿-비활성화), [BR-TPL-014](rules.md#br-tpl-014-비활성-기본-템플릿-처리)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-TPL-004](rules.md#br-tpl-004-템플릿-비활성화) |
| TPL_TEMPLATE_NOT_FOUND | 404 | [BR-TPL-012](rules.md#br-tpl-012-템플릿-존재-확인) |
| TPL_ALREADY_INACTIVE | 409 | [BR-TPL-004](rules.md#br-tpl-004-템플릿-비활성화) |

---

### `PATCH` /templates/:id/activate

**설명**: 비활성 템플릿을 다시 활성화한다. 새 문서 생성 시 선택 목록에 복원된다.

**권한**: ADMIN (`manage_templates`)

**Request**:

- Path params: `id` — 템플릿 UUID

**Response** (`200`): `TemplateStatusResponse`

**비즈니스 규칙 참조**: [BR-TPL-008](rules.md#br-tpl-008-템플릿-활성화)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-TPL-008](rules.md#br-tpl-008-템플릿-활성화) |
| TPL_TEMPLATE_NOT_FOUND | 404 | [BR-TPL-012](rules.md#br-tpl-012-템플릿-존재-확인) |
| TPL_ALREADY_ACTIVE | 409 | [BR-TPL-008](rules.md#br-tpl-008-템플릿-활성화) |

---

## 공통 응답 타입

```typescript
interface TemplateStatusResponse {
  id: string;
  isActive: boolean;
  updatedAt: string;
}
```

> deactivate, activate 모두 동일한 `TemplateStatusResponse`를 반환한다.

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **Template 도메인 에러** 전체 목록은 [rules.md §3 에러 코드 카탈로그](rules.md#3-에러-코드-카탈로그) 참조
