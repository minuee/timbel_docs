# AICM 모듈별 상세 설계

| 항목 | 값 |
|------|---|
| 제품 | AICM (KMS) |
| 버전 | 1.0 |
| 작성일 | 2026-03-26 |
| 목적 | 기능정의서(FD)의 요구사항을 모듈 단위로 분리하여 API 스펙, 비즈니스 규칙, 이벤트/큐 연동까지 구현 가능한 수준으로 상세화 |

---

## 문서 구조 안내

각 모듈 폴더는 최대 7개 파일로 구성된다.

| 파일 | 역할 | 내용 |
|------|------|------|
| **README.md** | 모듈 개요 | 모듈 책임, 핵심 엔티티, 의존 관계, 인프라 사용 요약 |
| **api.md** | API 스펙 | REST 엔드포인트, Request/Response DTO, 에러 코드, 권한 |
| **rules.md** | 비즈니스 규칙 + 에러 정의 | 상태 전이 다이어그램, 규칙 카탈로그 (ID 부여, 트리거/조건/동작/위반시), **§4 에러 코드 카탈로그** (도메인 에러의 SSoT — 전역 에러는 [횡단 관심사 §8.2](../02-architecture/07-cross-cutting-concerns.md) 참조) |
| **data.md** | RDB 엔티티 | ERD, 엔티티 필드 정의, DDL, 인덱스 전략 |
| **events.md** | 이벤트/큐/부수효과 | 발행/소비 이벤트, BullMQ 큐, 외부 서비스 호출 (이벤트가 없는 모듈은 생략) |
| **cache.md** | 캐시 전략 | 캐시 대상, 전략(cache-aside/buffer-flush/lock 등), 키 패턴, TTL, 무효화 트리거 (캐시가 없는 모듈은 생략) |
| **schedule.md** | 스케줄/배치 작업 | cron 스케줄, 배치 작업 정의, 주기, 설정 키 (스케줄 작업이 없는 모듈은 생략) |

### 기존 문서와의 관계

- **[기능정의서 (02-features/)](../01-requirements/features/)**: 기능 요구사항 (What/Why) — 이 문서군의 입력 원본
- **[데이터 아키텍처](../02-architecture/data/)**: 엔티티 필드, ERD, DDL — 링크로 참조
- **[프로세스 흐름도 (03-flows/)](../01-requirements/flows/)**: 시퀀스 다이어그램, 상태 전이도 — 링크로 참조
- **[모듈 아키텍처 (architecture/02-module-architecture.md)](../02-architecture/02-module-architecture.md)**: 모듈 분류, 의존성 규칙, Provider 패턴

---

## 모듈 목록 및 작성 상태

### 도메인 모듈

| 모듈 | 폴더 | 기능정의서 | README | api | rules | data | events | cache | schedule | 상태 |
|------|------|-----------|:------:|:---:|:-----:|:----:|:------:|:-----:|:--------:|------|
| DocumentModule | [document/](document/) | [FD-DOC](../01-requirements/features/FD-DOC-문서관리.md) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | `draft` |
| ApprovalModule | [approval/](approval/) | [FD-APR](../01-requirements/features/FD-APR-승인워크플로.md) | - | - | - | ✅ | - | — | ✅ | `미착수` |
| SearchModule | [search/](search/) | [FD-SCH](../01-requirements/features/FD-SCH-검색.md) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | `draft` |
| ParsingModule | [parsing/](parsing/) | [FD-SCH](../01-requirements/features/FD-SCH-검색.md) (§3~§5 파싱/청킹) | ✅ | ✅ | ✅ | ✅ | ✅ | — | — | `draft` |
| BoardModule | [board/](board/) | [FD-DOC §7](../01-requirements/features/FD-DOC-문서관리.md) | ✅ | ✅ | ✅ | ✅ | — | ✅ | — | `draft` |
| TemplateModule | [template/](template/) | [FD-DOC §4](../01-requirements/features/FD-DOC-문서관리.md) | ✅ | ✅ | ✅ | ✅ | — | — | — | `draft` |
| SharedContentModule | [shared-content/](shared-content/) | [FD-DOC §5](../01-requirements/features/FD-DOC-문서관리.md) | - | - | - | ✅ | - | — | — | `미착수` |
| CommunityModule | [community/](community/) | [FD-COM](../01-requirements/features/FD-COM-커뮤니티.md) | - | - | - | ✅ | - | - | — | `미착수` |
| NotificationModule | [notification/](notification/) | [FD-NTF](../01-requirements/features/FD-NTF-알림.md) | - | - | - | ✅ | - | — | ✅ | `미착수` |
| AggregationModule | [aggregation/](aggregation/) | [FD-AGG](../01-requirements/features/FD-AGG-집계피드.md) | - | - | - | ✅ | - | - | ✅ | `미착수` |
| AuditLogModule | [audit-log/](audit-log/) | [FD-AUD](../01-requirements/features/FD-AUD-감사로그.md) | - | - | - | ✅ | — | — | ✅ | `미착수` |
| AdminModule | [admin/](admin/) | [FD-ADM](../01-requirements/features/FD-ADM-관리자.md) | - | - | - | - | — | — | — | `미착수` |
| ExportModule | [export/](export/) | [FD-COM §7](../01-requirements/features/FD-COM-커뮤니티.md) | - | - | - | - | — | — | — | `미착수` |
| AI 어시스턴트 | [ai-assistant/](ai-assistant/) | [FD-AI](../01-requirements/features/FD-AI-AI어시스턴트.md) (§1~2 AI 기능, §3 프롬프트), [FD-EMB](../01-requirements/features/FD-EMB-임베딩파이프라인.md) | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ | `draft` |

### 공통 모듈

| 모듈 | 폴더 | 기능정의서 | README | api | rules | data | events | cache | schedule | 상태 |
|------|------|-----------|:------:|:---:|:-----:|:----:|:------:|:-----:|:--------:|------|
| AuthModule + PermissionModule + TenantModule | [auth/](auth/) | [FD-ACL](../01-requirements/features/FD-ACL-권한체계.md) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | `draft` |

### 시스템 설정

| 모듈 | 폴더 | 기능정의서 | README | api | rules | data | events | cache | schedule | 상태 |
|------|------|-----------|:------:|:---:|:-----:|:----:|:------:|:-----:|:--------:|------|
| SystemConfig | [system-config/](system-config/) | [FD-SYS](../01-requirements/features/FD-SYS-시스템설정.md) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | — | `draft` |

> **상태 정의**: `미착수` 양식만 배치 / `draft` 내용 작성 중 / `complete` 작성 완료 / `reviewed` 검수 완료

---

## 모듈 간 의존성

> 상세: [모듈 아키텍처 §3.3](../02-architecture/02-module-architecture.md)

### DI 의존 관계 요약

```mermaid
graph TD
    subgraph layer1 ["1. 데이터 제공 (독립)"]
        direction LR
        Board["BoardModule"]
        Tmpl["TemplateModule"]
    end

    subgraph layer_shared ["공통 모듈 (독립)"]
        direction LR
        Auth["AuthModule"]
        SysCfg["SystemConfigModule"]
    end

    Doc["<b>DocumentModule</b><br/>의존 허브"]

    subgraph layer3a ["3. 워크플로우 (DI 쓰기)"]
        direction LR
        Appr["ApprovalModule"]
        Parse["ParsingModule"]
    end

    subgraph layer3b ["4. DI 읽기"]
        direction LR
        SC["SharedContentModule"]
        Search["SearchModule"]
        Comm["CommunityModule"]
        Export["ExportModule"]
    end

    subgraph layer4 ["5. AI 어시스턴트"]
        direction LR
        AI["AI AssistantModule"]
    end

    Admin["AdminModule"]

    subgraph layer5 ["6. EventBus 소비 전용"]
        direction LR
        Notif["NotificationModule"]
        Agg["AggregationModule"]
        Audit["AuditLogModule"]
    end

    Doc --> Board
    Doc --> Tmpl

    Appr ==>|"Critical tx"| Doc
    Appr --> Board
    Parse -->|write| Doc

    SC --> Doc
    Search --> Doc
    Comm --> Doc
    Export --> Doc

    Admin --> Doc
    Admin --> Board
    Admin --> AI

    EB(("EventBus"))
    Doc -.-> EB
    Appr -.-> EB
    Comm -.-> EB
    AI -.-> EB
    EB -.-> Notif
    EB -.-> Agg
    EB -.-> Audit
```

> **범례**: 실선(→) DI 읽기 / 이중선(=>) Critical 트랜잭션 / 점선(-.->) 비동기(EventBus/BullMQ)

### DI 의존 매트릭스

| 소비자 (import) | 제공자 (export) | 접근 유형 | 용도 |
|---|---|---|---|
| DocumentModule | BoardModule | 읽기 | 게시판 설정(승인 정책, 허용 템플릿) 조회 |
| DocumentModule | TemplateModule | 읽기 | 템플릿 구조 조회 (문서 생성 시) |
| ApprovalModule | DocumentModule | **쓰기 (Critical)** | 승인 완료 시 `transitionToPublished()` — 동일 트랜잭션 |
| ApprovalModule | BoardModule | 읽기 | 게시판 승인 정책 조회 |
| SharedContentModule | DocumentModule | 읽기 | 참조 문서·블록 추적 |
| ParsingModule | DocumentModule | 쓰기 | ParsedBlock → Block 변환·저장 |
| SearchModule | DocumentModule | 읽기 | 검색 결과 메타데이터 보강 |
| CommunityModule | DocumentModule | 읽기 | 댓글·좋아요 대상 문서 존재 확인 |
| AggregationModule | DocumentModule | 읽기 | 집계 대상 문서 정보 조회 |
| AdminModule | DocumentModule | 읽기 | 관리자 통계용 문서 데이터 조회 |
| AdminModule | BoardModule | 읽기 | 관리자 통계용 게시판 데이터 조회 |
| AdminModule | AI AssistantModule | 읽기 | 관리자 대시보드에서 프롬프트 통계 조회 |
| ExportModule | DocumentModule | 읽기 | 내보내기 대상 문서·블록 데이터 조회 |
| NotificationModule | DocumentModule | 읽기 | 알림 컨텍스트(문서 제목, 작성자) 조회 |

### 작성 순서 가이드

의존성 기준 **아래에서 위로** 작성한다. 먼저 작성한 모듈의 인터페이스를 나중 모듈이 참조한다.

| 라운드 | 모듈 | 근거 | data | events | cache | schedule |
|:---:|------|------|:----:|:---:|:---:|:---:|
| **1** | board/ | 독립 — Document가 읽기 참조 | ✅ | — | ✅ | — |
| **1** | template/ | 독립 — Document가 읽기 참조 | ✅ | — | — | — |
| **1** | system-config/ | 독립 — 시스템 설정 | ✅ | — | ✅ | — |
| **1** | auth/ | 독립 — Auth + Permission + Tenant | ✅ | — | ✅ | — |
| **2** | document/ | Board·Template 읽기 참조, 이후 모듈의 의존 허브 | ✅ | ✅ | ✅ | ✅ |
| **3** | approval/ | Document에 Critical tx 의존 | ✅ | ✅ | — | ✅ |
| **3** | shared-content/ | Document 읽기 의존 | ✅ | ✅ | — | — |
| **3** | community/ | Document 읽기 의존, EventBus 발행 | ✅ | ✅ | ✅ | — |
| **3** | export/ | Document 읽기 의존 | - | — | — | — |
| **4** | search/ | Document 읽기 의존, 외부 서비스 연동 | ✅ | ✅ | ✅ | ✅ |
| **4** | parsing/ | Document 쓰기 의존, 파싱 파이프라인 | ✅ | ✅ | — | — |
| **4** | ai-assistant/ | LLM/임베딩 파이프라인 + 프롬프트 슬롯/버전 관리 | ✅ | ✅ | — | ✅ |
| **5** | notification/ | EventBus 소비 전용 | ✅ | ✅ | — | ✅ |
| **5** | aggregation/ | EventBus 소비 전용 | ✅ | ✅ | ✅ | ✅ |
| **5** | audit-log/ | Interceptor 기반, EventBus 소비 | ✅ | — | — | ✅ |
| **5** | admin/ | 여러 모듈 읽기 의존 (Doc, Board, Prompt) | - | — | — | — |

> **검수 타이밍**: 각 라운드 종료 시 `cross-module-validator`로 해당 라운드까지 완성된 모듈 조합을 교차 검증한다.

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [기능정의서](../01-requirements/features/README.md) | FD 문서 목록, 도메인별 기능 요약, 교차 참조 |
| [모듈 아키텍처](../02-architecture/02-module-architecture.md) | 모듈 분류, 의존성 규칙 |
| [데이터 아키텍처](../02-architecture/data/README.md) | 서비스별 데이터 설계 |
| [비동기 이벤트 아키텍처](../02-architecture/04-async-event-architecture.md) | BullMQ 큐, 이벤트 흐름 |
