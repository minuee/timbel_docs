# Export 모듈 — API 설계

| 항목 | 값 |
|------|---|
| 모듈명 | ExportModule |
| 기능정의서 | [FD-EXP-내보내기 §5](../../01-requirements/features/FD-EXP-내보내기.md) |

---

## 엔드포인트 요약

| # | Method | Path | 인증 | 설명 |
|---|--------|------|------|------|
| 1 | POST | `/api/documents/{documentId}/export` | Board VIEW | 문서 내보내기 요청 (동기/비동기 자동 분기) |
| 2 | GET | `/api/export-jobs/{jobId}` | 본인 | 내보내기 작업 상태 조회 |
| 3 | GET | `/api/export-jobs/{jobId}/download` | 본인 | 완료된 파일 다운로드 (프리사인드 URL 리다이렉트) |
| 4 | GET | `/api/export-jobs` | 본인 | 본인 내보내기 이력 조회 |
| 5 | GET | `/api/admin/export-jobs` | Admin | [관리자] 전체 내보내기 이력 조회 |
| 6 | POST | `/api/admin/documents/bulk-export` | Admin | [관리자] 일괄 내보내기 |

---

## 1. POST `/api/documents/{documentId}/export`

문서 내보내기를 요청한다. 문서의 블록 수가 `lm:export.async_threshold` 이하이면 **동기** 처리하여 즉시 파일 다운로드 URL을 반환하고, 초과 시 **비동기** 처리하여 ExportJob을 생성한 뒤 `202 Accepted`를 반환한다.

### 인가 조건

- 요청자가 해당 Board에 대해 `VIEW` 이상의 grant를 보유해야 한다 [BR-EXP-002]
- 보드별 내보내기 통제가 켜져 있으면 해당 보드의 내보내기 허용 여부를 추가로 검사한다 [BR-EXP-003]
- 문서 상태가 `published`여야 한다 [BR-EXP-001]

### Request

**Path Parameters**

| 파라미터 | 타입 | 필수 | 설명 |
|---------|------|:----:|------|
| documentId | `string (UUID)` | ✔ | 내보내기 대상 문서 ID |

**Body**

```typescript
interface ExportRequest {
  format: 'pdf' | 'docx' | 'html' | 'markdown';
  options?: {
    includeComments?: boolean;       // 기본값: false
    includeMetadata?: boolean;       // 기본값: true (제목, 작성자, 일시)
    watermark?: boolean;             // 워터마크 옵션이 활성일 때만 유효, 기본값: true
    pageSize?: 'A4' | 'Letter';     // PDF 전용, 기본값: 'A4'
  };
}
```

### Response

**동기 처리 — 200 OK** (블록 수 ≤ `lm:export.async_threshold`)

```typescript
interface ExportSyncResponse {
  downloadUrl: string;     // 프리사인드 URL (만료: lm:export.file_ttl_hours)
  format: string;
  fileSizeBytes: number;    // bytes (FD-EXP·data.md `file_size_bytes`와 동일 의미)
  expiresAt: string;       // ISO 8601
}
```

**비동기 처리 — 202 Accepted** (블록 수 > `lm:export.async_threshold`)

```typescript
interface ExportAsyncResponse {
  jobId: string;           // ExportJob UUID
  status: 'pending';
  estimatedWaitSeconds?: number;
  pollUrl: string;         // GET /api/export-jobs/{jobId}
}
```

### 에러

| HTTP | 코드 | 설명 | BR |
|------|------|------|----|
| 400 | `EXP_UNSUPPORTED_FORMAT` | 요청 포맷이 허용된 내보내기 포맷 목록에 포함되지 않음 | BR-EXP-004 |
| 403 | `EXP_BOARD_EXPORT_DISABLED` | 보드별 내보내기 통제가 켜진 상태에서 해당 보드의 내보내기가 비허용 | BR-EXP-003 |
| 404 | `EXP_DOCUMENT_NOT_FOUND` | 대상 문서가 존재하지 않음 | — |
| 409 | `EXP_DOCUMENT_NOT_EXPORTABLE` | 문서 상태가 `published`가 아님 | BR-EXP-001 |
| 413 | `EXP_FILE_SIZE_EXCEEDED` | 예상 파일 크기가 `lm:export.max_file_size_mb` 초과 | BR-EXP-065 |
| 429 | `EXP_DUPLICATE_JOB` | 동일 문서+포맷에 대해 이미 `pending`/`processing` 중인 Job 존재 | BR-EXP-064 |

---

## 2. GET `/api/export-jobs/{jobId}`

비동기 내보내기 작업의 현재 상태를 조회한다.

### 인가 조건

- `ExportJob.requested_by`가 요청자 본인이어야 한다

### Request

**Path Parameters**

| 파라미터 | 타입 | 필수 | 설명 |
|---------|------|:----:|------|
| jobId | `string (UUID)` | ✔ | ExportJob ID |

### Response — 200 OK

```typescript
interface ExportJobResponse {
  id: string;
  documentId: string;
  format: 'pdf' | 'docx' | 'html' | 'markdown';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  fileUrl?: string;           // status === 'completed'일 때만
  fileSizeBytes?: number;     // bytes
  errorMessage?: string;      // status === 'failed'일 때만
  expiresAt?: string;         // status === 'completed'일 때만, ISO 8601
  createdAt: string;          // ISO 8601
  completedAt?: string;       // ISO 8601
}
```

### 에러

| HTTP | 코드 | 설명 | BR |
|------|------|------|----|
| 404 | `EXP_JOB_NOT_FOUND` | 해당 Job이 존재하지 않거나 본인 소유가 아님 | — |

---

## 3. GET `/api/export-jobs/{jobId}/download`

완료된 내보내기 파일을 다운로드한다. 프리사인드 URL로 **302 Redirect**한다.

### 인가 조건

- `ExportJob.requested_by`가 요청자 본인이어야 한다
- `ExportJob.status === 'completed'`이고 `expires_at`이 미경과여야 한다

### Request

**Path Parameters**

| 파라미터 | 타입 | 필수 | 설명 |
|---------|------|:----:|------|
| jobId | `string (UUID)` | ✔ | ExportJob ID |

### Response — 302 Found

`Location` 헤더에 MinIO 프리사인드 URL을 설정하여 리다이렉트한다.

### 에러

| HTTP | 코드 | 설명 | BR |
|------|------|------|----|
| 404 | `EXP_JOB_NOT_FOUND` | 해당 Job이 존재하지 않거나 본인 소유가 아님 | — |
| 410 | `EXP_FILE_EXPIRED` | 파일 TTL이 만료되어 다운로드 불가 | BR-EXP-063 |
| 409 | `EXP_JOB_NOT_COMPLETED` | Job이 아직 `completed` 상태가 아님 | — |

---

## 4. GET `/api/export-jobs`

본인의 내보내기 이력을 페이지네이션으로 조회한다.

### Request

**Query Parameters**

| 파라미터 | 타입 | 필수 | 기본값 | 설명 |
|---------|------|:----:|--------|------|
| page | `number` | | 1 | 페이지 번호 |
| limit | `number` | | 20 | 페이지당 건수 (최대 100) |
| status | `string` | | | 필터: `pending`, `processing`, `completed`, `failed` |
| format | `string` | | | 필터: `pdf`, `docx`, `html`, `markdown` |

### Response — 200 OK

```typescript
interface ExportJobListResponse {
  items: ExportJobResponse[];
  meta: {
    page: number;
    limit: number;
    totalCount: number;
    totalPages: number;
  };
}
```

---

## 5. GET `/api/admin/export-jobs`

관리자가 전체 사용자의 내보내기 이력을 조회한다.

### 인가 조건

- `Admin` 역할 필수

### Request

**Query Parameters**

| 파라미터 | 타입 | 필수 | 기본값 | 설명 |
|---------|------|:----:|--------|------|
| page | `number` | | 1 | 페이지 번호 |
| limit | `number` | | 20 | 페이지당 건수 (최대 100) |
| status | `string` | | | 필터: `pending`, `processing`, `completed`, `failed` |
| format | `string` | | | 필터: `pdf`, `docx`, `html`, `markdown` |
| requestedBy | `string (UUID)` | | | 필터: 특정 사용자 ID |
| documentId | `string (UUID)` | | | 필터: 특정 문서 ID |

### Response — 200 OK

```typescript
interface AdminExportJobListResponse {
  items: (ExportJobResponse & { requestedBy: string })[];
  meta: {
    page: number;
    limit: number;
    totalCount: number;
    totalPages: number;
  };
}
```

---

## 6. POST `/api/admin/documents/bulk-export`

관리자가 여러 문서를 일괄 내보내기(ZIP)한다. **항상 비동기** 처리된다.

### 인가 조건

- `Admin` 역할 필수

### Request

**Body**

```typescript
interface BulkExportRequest {
  documentIds: string[];           // UUID 배열 (최대 50건)
  format: 'pdf' | 'docx' | 'html' | 'markdown';
  options?: {
    includeComments?: boolean;
    includeMetadata?: boolean;
    watermark?: boolean;
    pageSize?: 'A4' | 'Letter';
  };
}
```

### Response — 202 Accepted

```typescript
interface BulkExportResponse {
  jobId: string;           // 일괄 ExportJob UUID
  status: 'pending';
  documentCount: number;
  pollUrl: string;         // GET /api/admin/export-jobs (jobId 필터)
}
```

### 에러

| HTTP | 코드 | 설명 | BR |
|------|------|------|----|
| 400 | `EXP_UNSUPPORTED_FORMAT` | 요청 포맷이 미지원 | BR-EXP-004 |
| 400 | `EXP_BULK_LIMIT_EXCEEDED` | `documentIds`가 50건 초과 | — |

---

## 공통 에러 코드

> FD-EXP §6 기반. 모든 에러 응답은 아래 형식을 따른다.

```typescript
interface ErrorResponse {
  statusCode: number;
  code: string;           // EXP_ 접두사
  message: string;
  timestamp: string;      // ISO 8601
}
```

| HTTP | 코드 | 설명 | 관련 BR |
|------|------|------|---------|
| 409 | `EXP_DOCUMENT_NOT_EXPORTABLE` | 문서 상태가 `published`가 아니므로 내보내기 불가 | BR-EXP-001 |
| 403 | `EXP_NO_VIEW_PERMISSION` | 요청자에게 Board VIEW 권한 없음 | BR-EXP-002 |
| 403 | `EXP_BOARD_EXPORT_DISABLED` | 보드별 내보내기 통제가 켜진 상태에서 해당 보드의 내보내기가 비허용 | BR-EXP-003 |
| 400 | `EXP_UNSUPPORTED_FORMAT` | 허용된 내보내기 포맷 목록에 포함되지 않은 포맷 | BR-EXP-004 |
| 404 | `EXP_DOCUMENT_NOT_FOUND` | 대상 문서를 찾을 수 없음 | — |
| 404 | `EXP_JOB_NOT_FOUND` | ExportJob을 찾을 수 없음(또는 타인 소유) | — |
| 413 | `EXP_FILE_SIZE_EXCEEDED` | 예상 파일 크기가 `lm:export.max_file_size_mb` 초과 | BR-EXP-065 |
| 429 | `EXP_DUPLICATE_JOB` | 동일 문서+포맷으로 이미 진행 중인 Job 존재 | BR-EXP-064 |
| 410 | `EXP_FILE_EXPIRED` | 파일 TTL 만료로 다운로드 불가 | BR-EXP-063 |

### FD-EXP §6 에러 코드 매핑

> [FD-EXP-내보내기 §6](../../01-requirements/features/FD-EXP-내보내기.md) 카탈로그와 모듈 스펙 응답의 대응. 구현·프론트는 **모듈 스펙 열**을 따른다.

| FD-EXP §6 `code` | 모듈 스펙 `code` | FD HTTP | 모듈 HTTP | 비고 |
|------------------|------------------|---------|-----------|------|
| `EXP_DOCUMENT_NOT_EXPORTABLE` | `EXP_DOCUMENT_NOT_EXPORTABLE` | 403 | 409 | 모듈 스펙은 상태 불일치를 409 Conflict로 통일 |
| `EXP_PERMISSION_DENIED` | `EXP_NO_VIEW_PERMISSION` | 403 | 403 | 명칭만 세분화 |
| `EXP_BOARD_EXPORT_DISABLED` | `EXP_BOARD_EXPORT_DISABLED` | 403 | 403 | 동일 |
| `EXP_FORMAT_NOT_AVAILABLE` | `EXP_UNSUPPORTED_FORMAT` | 400 | 400 | 명칭만 세분화 |
| `EXP_JOB_DUPLICATE` | `EXP_DUPLICATE_JOB` | 409 | 429 | 모듈 스펙은 Too Many Requests(429)로 통일 |
| `EXP_FILE_SIZE_EXCEEDED` | `EXP_FILE_SIZE_EXCEEDED` | 413 | 413 | 동일 |
| `EXP_JOB_NOT_FOUND` | `EXP_JOB_NOT_FOUND` | 404 | 404 | 동일 |
| `EXP_FILE_EXPIRED` | `EXP_FILE_EXPIRED` | 410 | 410 | 동일 |
| `EXP_RENDER_FAILED` | *(미정의)* | 500 | — | 동기 경로 렌더 실패 시 모듈 스펙에 코드 추가 검토; 비동기는 Job `failed` 처리 |
