# Export 모듈 — 이벤트 설계

| 항목 | 값 |
|------|---|
| 모듈명 | ExportModule |
| 기능정의서 | [FD-EXP-내보내기 §7](../../01-requirements/features/FD-EXP-내보내기.md) |

---

## 이벤트 요약

| 이벤트 | 방향 | 신뢰성 티어 | 전달 방식 | 설명 |
|--------|------|:----------:|----------|------|
| `export.job.created` | 발행 | Best-effort | EventBus | 비동기 내보내기 Job 생성 알림 |
| `export.job.completed` | 발행 | Important | BullMQ(`export`) | 내보내기 완료, 파일 다운로드 가능 |
| `export.job.failed` | 발행 | Important | BullMQ(`export`) | 내보내기 최종 실패 (재시도 소진 또는 타임아웃) |
| `export.file.expired` | 발행 | Best-effort | EventBus | 파일 TTL 만료, 스토리지 파일 삭제됨 |

> ExportModule은 **외부 이벤트를 소비하지 않는다**. 내보내기 요청은 항상 REST API로 시작된다.

---

## BullMQ `export` 큐 설정

> 참조: [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md)

| 항목 | 값 | 설명 |
|------|----|------|
| 큐 이름 | `export` | 비동기 내보내기 처리 전용 |
| 우선순위 | normal | |
| 동시 실행 | 3 | Worker concurrency |
| 재시도 횟수 | 3 | |
| 백오프 전략 | 지수(exponential) | 30s → 60s → 120s |
| Job 타임아웃 | 300,000ms (5분) | 단일 Job 처리 제한 시간 |
| DLQ | `export-dlq` | 재시도 소진 후 이동 |
| pending 타임아웃 | `lm:export.job_max_wait_minutes` (기본 30분) | `pending` 상태 장기 체류 시 `failed` 전이 — [rules.md](./rules.md) **BR-EXP-073** (FD-EXP와 동일 번호) |
| Stalled Interval | 30,000ms | stalled job 감지 간격 |

---

## 페이로드 공통 컨텍스트 (AsyncJobContext)

> [비동기 이벤트 아키텍처 §6.5 이벤트 페이로드 보안 컨텍스트](../../02-architecture/05-async-event-architecture.md)와 동일. BullMQ Job 데이터와 EventBus 이벤트 `payload` 모두에 포함한다. `actorId`는 내보내기를 요청한 사용자 ID이다.

```typescript
interface AsyncJobContext {
  actorId: string;       // 작업 트리거 사용자 ID (UUID)
  orgId: string;         // 테넌트/조직 ID (UUID)
  traceId: string;       // OpenTelemetry 분산 추적 ID
  triggeredAt: string;   // ISO 8601
  sourceModule?: string; // 예: 'ExportModule'
}
```

---

## 발행 이벤트 상세

### 1. `export.job.created`

| 항목 | 내용 |
|------|------|
| **신뢰성 티어** | Best-effort (EventBus) |
| **트리거** | 비동기 내보내기 ExportJob이 `pending` 상태로 생성된 직후 |
| **비고** | — (내보내기가 활성이면 항상 발행) |
| **멱등성 키** | `export.job.created:{jobId}` |

**페이로드**

```typescript
interface ExportJobCreatedPayload extends AsyncJobContext {
  jobId: string;              // ExportJob UUID
  documentId: string;
  format: 'pdf' | 'docx' | 'html' | 'markdown';
  options: Record<string, unknown>;
}

interface ExportJobCreatedEvent {
  eventType: 'export.job.created';
  timestamp: string;          // ISO 8601 (페이로드의 triggeredAt과 별도일 수 있음)
  payload: ExportJobCreatedPayload;
}
```

**소비자**

| 소비자 | 용도 |
|--------|------|
| (현재 등록된 소비자 없음) | 향후 알림 모듈 연동 시 활용 가능 |

---

### 2. `export.job.completed`

| 항목 | 내용 |
|------|------|
| **신뢰성 티어** | Important (BullMQ `export` 큐 Worker 완료 콜백) |
| **트리거** | BullMQ Worker에서 파일 생성·저장이 성공하고 ExportJob.status가 `completed`로 전이된 직후 |
| **비고** | — |
| **멱등성 키** | `export.job.completed:{jobId}` |

**페이로드**

```typescript
interface ExportJobCompletedPayload extends AsyncJobContext {
  jobId: string;
  documentId: string;
  format: string;
  fileUrl: string;            // MinIO 프리사인드 URL
  fileSizeBytes: number;
  expiresAt: string;          // ISO 8601
  durationMs: number;         // 처리 소요 시간
}

interface ExportJobCompletedEvent {
  eventType: 'export.job.completed';
  timestamp: string;
  payload: ExportJobCompletedPayload;
}
```

**소비자**

| 소비자 | 용도 |
|--------|------|
| NotificationModule | 요청자에게 내보내기 완료 알림 전송 |
| AuditModule | 내보내기 완료 감사 로그 기록 |

---

### 3. `export.job.failed`

| 항목 | 내용 |
|------|------|
| **신뢰성 티어** | Important (BullMQ `export` 큐 Worker 실패 콜백) |
| **트리거** | 재시도 3회 소진 후 DLQ 이동 시, 또는 `pending` 타임아웃(`lm:export.job_max_wait_minutes`) 초과 시 |
| **비고** | — |
| **멱등성 키** | `export.job.failed:{jobId}` |

**페이로드**

```typescript
interface ExportJobFailedPayload extends AsyncJobContext {
  jobId: string;
  documentId: string;
  format: string;
  errorMessage: string;
  retryCount: number;         // 실행된 재시도 횟수
  failReason: 'max_retries_exceeded' | 'timeout' | 'file_size_exceeded' | 'unknown';
}

interface ExportJobFailedEvent {
  eventType: 'export.job.failed';
  timestamp: string;
  payload: ExportJobFailedPayload;
}
```

**소비자**

| 소비자 | 용도 |
|--------|------|
| NotificationModule | 요청자에게 내보내기 실패 알림 전송 |
| AuditModule | 내보내기 실패 감사 로그 기록 |
| MonitoringModule | 실패 메트릭 수집, 알림 임계값 판별 |

---

### 4. `export.file.expired`

| 항목 | 내용 |
|------|------|
| **신뢰성 티어** | Best-effort (EventBus) |
| **트리거** | 파일 TTL 만료 스케줄러(cron)가 `expires_at < NOW()`인 ExportJob의 MinIO 파일을 삭제한 후 |
| **비고** | — |
| **멱등성 키** | `export.file.expired:{jobId}` |

**페이로드**

```typescript
interface ExportFileExpiredPayload extends AsyncJobContext {
  jobId: string;
  documentId: string;
  format: string;
  originalFileUrl: string;   // 삭제 전 URL (로깅용)
  expiredAt: string;          // ISO 8601, expires_at 값
}

interface ExportFileExpiredEvent {
  eventType: 'export.file.expired';
  timestamp: string;
  payload: ExportFileExpiredPayload;
}
```

**소비자**

| 소비자 | 용도 |
|--------|------|
| AuditModule | 파일 만료/삭제 감사 로그 기록 |

---

## 소비 이벤트

> ExportModule은 외부 도메인 이벤트를 소비하지 않는다. 모든 내보내기 작업은 REST API 호출로 시작된다.

---

## 외부 서비스 호출

| 대상 | 용도 | 실패 시 처리 |
|------|------|-------------|
| DocumentModule | 문서·블록 데이터 조회 (공통 컨텐츠 인라인 치환 완료 상태) | Job `failed` 처리, 재시도 대상 |
| MinIO | 파일 저장, 프리사인드 URL 생성, 파일 삭제 (TTL 만료) | Job `failed` 처리, 재시도 대상 |
