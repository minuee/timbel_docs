# Export 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | ExportModule |
| 문서 코드 | MS-EXP |
| 상태 | `draft` |
| 기능정의서 | [FD-EXP-내보내기](../../01-requirements/features/FD-EXP-내보내기.md) |
| 데이터 모델 | [data.md](./data.md) |

---

## 모듈 책임

ExportModule은 `published` 상태 문서의 블록 콘텐츠를 외부 파일 형식(PDF/DOCX/HTML/Markdown)으로 변환하여 다운로드를 제공하는 모듈이다.

| 영역 | 설명 |
|------|------|
| 문서 블록 조회 | DocumentModule을 통해 대상 문서의 블록 데이터를 조회한다. 공통 컨텐츠 인라인 치환이 완료된 블록을 수신한다 (ADR-011 D-2) |
| 블록 전처리 | 숨김 블록 제외(`visible = false`), 접근 제한 블록 처리(`restricted = true`), `embeddable` 플래그 처리, 공통 컨텐츠 치환 결과 수신 [BR-EXP-030, BR-EXP-040~042] |
| 블록 타입별 포맷 변환 | 14종 블록 타입 × 4개 포맷(PDF/DOCX/HTML/Markdown)에 대한 변환 규칙 적용 [BR-EXP-010~022] |
| 후처리 | PDF 워터마크 삽입(t:export.watermark 활성 시) [BR-EXP-050~054], 문서 메타데이터(제목, 작성자, 내보내기 일시) 삽입 [BR-EXP-100](rules.md) |
| 파일 생성 및 저장 | 변환된 파일을 오브젝트 스토리지(MinIO)에 임시 저장, 프리사인드 URL 생성 |
| 동기/비동기 분기 | 블록 수가 `lm:export.async_threshold` 이하이면 동기 처리(즉시 다운로드), 초과 시 비동기 처리(BullMQ `export` 큐) [BR-EXP-060~061]. 동기 경로는 ExportJob 행을 생성하지 않으며 감사 추적은 AuditLog Interceptor 등 횡단 관심사에 의존한다 |
| ExportJob 상태 관리 | 비동기 내보내기 작업의 `pending` → `processing` → `completed`/`failed` 상태 전이, 이력 관리 |
| 파일 TTL 자동 삭제 | `lm:export.file_ttl_hours` 경과 후 스토리지 파일 자동 삭제, ExportJob 행은 감사 이력으로 보존 [BR-EXP-063, BR-EXP-075] |
| 일괄 내보내기 | 관리자 전용 다중 문서 일괄 내보내기(ZIP), 항상 비동기 처리 |

### 현재 범위 제외 기능

| 기능 | FD 참조 | 제외 사유 | 향후 계획 |
|------|---------|----------|----------|
| PDF 렌더링 엔진 선정 | OPEN-EXP-01 | 기술 벤치마크(Puppeteer vs wkhtmltopdf) 미완료 | Phase 1 구현 착수 전 결정 |
| DOCX 변환 라이브러리 선정 | OPEN-EXP-02 | docx(npm) vs Pandoc 비교 필요 | Phase 1 구현 착수 전 결정 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — data.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **ExportJob** | 비동기 내보내기 작업의 상태 추적 엔티티. `pending` → `processing` → `completed`/`failed` 상태 전이, 파일 URL, 파일 크기, 에러 메시지, 만료 시각 등을 관리한다 (FD-EXP §3) |

---

## 의존 관계

```mermaid
graph LR
    Export["<b>ExportModule</b>"]

    Doc["DocumentModule"]
    MinIO["MinIO<br/>(파일 저장)"]
    BullMQ["BullMQ<br/>(export 큐)"]
    EB(("EventBus"))

    Export -->|"읽기<br/>(치환된 블록 포함)"| Doc
    Export -->|"파일 저장<br/>프리사인드 URL"| MinIO
    Export -->|"비동기 내보내기"| BullMQ
    Export -->|"이벤트 발행"| EB

    classDef hub fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef infra fill:#f3f4f6,stroke:#6b7280

    class Export hub
    class Doc,MinIO,BullMQ,EB infra
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Export → Document | DocumentModule | 읽기 | 내보내기 대상 문서·블록 데이터 조회. 공통 컨텐츠 인라인 치환이 완료된 블록을 수신한다 (ADR-011 D-2) |
| Export → MinIO | MinIOModule | 인프라 | 생성된 파일 임시 저장, 프리사인드 URL 생성 |
| Export → BullMQ | RedisModule | 인프라 | `export` 큐를 통한 비동기 내보내기 처리 |
| Export → EventBus | EventBusModule | 인프라 발행 | `export.job.created/completed/failed`, `export.file.expired` 이벤트 발행 |

> **SharedContent 직접 의존 없음**: 공통 컨텐츠 인라인 치환은 Document 모듈이 블록 조회 시 수행하여 "소비자가 바로 사용할 수 있는 블록"을 반환한다. Export는 순수 변환 로직에 집중한다 (ADR-011 D-2).

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | ExportJob 엔티티 (비동기 작업 상태 추적, 이력 조회, 감사 연동) |
| Redis / BullMQ | ● | `export` 큐 (비동기 내보내기 처리), `export-dlq` (DLQ) |
| Elasticsearch | — | |
| MinIO | ● | 생성된 내보내기 파일 임시 저장, 프리사인드 URL 다운로드 |
| EventBus | ● 발행 | `export.job.created`, `export.job.completed`, `export.job.failed`, `export.file.expired` |
| 외부 서비스 클라이언트 | — | |

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `export.job_count` | 시간당 내보내기 요청 건수 | API 미들웨어 카운터 |
| `export.queue_lag` | `export` 큐 대기 Job 수 | BullMQ Dashboard |
| `export.failure_rate` | 내보내기 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `export.sync_latency_ms` | 동기 내보내기 평균 응답 시간 | API 미들웨어 |
| `export.async_duration_ms` | 비동기 내보내기 평균 처리 시간 | BullMQ Job duration |
| `export.file_size_bytes` | 생성된 파일 평균 크기 | ExportJob 완료 시 기록 |
| `export.expired_file_count` | TTL 만료 파일 삭제 건수 (일간) | cron 배치 카운터 |

---

## 모니터링 알림 임계값

| 대상 | 조건 | 심각도 | 채널 |
|------|------|--------|------|
| export 큐 지연 | `export.queue_lag > 50` (5분 이상 지속) | WARNING | Slack + 대시보드 |
| export 실패율 | `export.failure_rate > 30%` (최근 1시간) | CRITICAL | Slack + PagerDuty |
| 동기 내보내기 지연 | `export.sync_latency_ms > 5000` (5분 평균) | WARNING | 대시보드 |
| DLQ 적재 | `export-dlq` 적재 > 10건 | WARNING | Slack |
| 파일 만료 삭제 실패 | 만료 대상 파일 삭제 실패 > 0건 (연속 3회) | WARNING | Slack |

---

## 미결 사항

> FD-EXP 미결 사항을 모듈 스펙 레벨에서 추적한다.

| ID | 항목 | 설명 | 영향 범위 |
|----|------|------|----------|
| OPEN-EXP-01 | PDF 렌더링 엔진 | Puppeteer(Headless Chrome) vs wkhtmltopdf vs 전용 라이브러리 — 성능/품질/라이선스 비교 필요 | rules.md BR-EXP-010~022의 PDF 변환 구현 |
| OPEN-EXP-02 | DOCX 변환 라이브러리 | docx(npm) vs Pandoc — Tiptap JSON → DOCX 변환 파이프라인 기술 선정 필요 | rules.md BR-EXP-010~022의 DOCX 변환 구현 |
| OPEN-EXP-03 | FD-SYS 설정 키 동기화 | `lm:export.async_threshold`, `lm:export.file_ttl_hours`, `lm:export.max_file_size_mb`, `lm:export.job_max_wait_minutes`가 FD-SYS §3.6에 미등록 | SystemConfig 시딩 |
| OPEN-EXP-04 | 일괄 내보내기 상세 | 여러 문서 일괄 ZIP 내보내기의 오류 처리 및 부분 실패 시나리오 구체화 필요 | api.md 관리자 일괄 내보내기 API |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-EXP-내보내기](../../01-requirements/features/FD-EXP-내보내기.md) | 기능정의서 (입력 원본) |
| [data.md](./data.md) | ExportJob RDB 엔티티/DDL |
| [ADR-011](../../adr/011-round3-module-design-decisions.md) §D | Export 모듈 설계 결정 (D-1: PostgreSQL, D-2: Document 경유 치환) |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 이벤트 신뢰성 티어 |
| [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md) | BullMQ 큐 설계, DLQ 전략 |
| [FD-SYS-시스템설정](../../01-requirements/features/FD-SYS-시스템설정.md) | 내보내기 관련 `lm:`/`pm:` 키 |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | VIEW 권한 기반 내보내기 접근 제어 |
