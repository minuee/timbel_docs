# Export 모듈 — 데이터 아키텍처

| 항목 | 값 |
|------|---|
| 모듈명 | ExportModule |
| 기능정의서 | [FD-EXP-내보내기 §3](../../01-requirements/features/FD-EXP-내보내기.md) |
| ADR | [ADR-011 §D-1](../../adr/011-round3-module-design-decisions.md) — ExportJob PostgreSQL 관리 |

---

## ER 다이어그램

```mermaid
erDiagram
    EXPORT_JOBS {
        uuid id PK
        uuid document_id FK
        int document_version_number
        uuid requested_by FK
        varchar format
        varchar status
        jsonb options
        varchar file_url
        bigint file_size_bytes
        text error_message
        timestamptz expires_at
        timestamptz created_at
        timestamptz completed_at
    }
```

---

## 엔티티 상세

### ExportJob (`export_jobs`)

> FD-EXP §3 기반. 비동기 내보내기 작업의 상태 추적, 이력 조회, 감사 연동을 위해 PostgreSQL에서 관리한다 (ADR-011 D-1).

| # | 컬럼 | 타입 | NULL | 기본값 | 설명 |
|---|------|------|:----:|--------|------|
| 1 | `id` | `UUID` | ✘ | `gen_random_uuid()` | PK |
| 2 | `document_id` | `UUID` | ✘ | | 내보내기 대상 문서 ID (documents.id FK) |
| 3 | `document_version_number` | `INTEGER` | ✘ | | 내보내기 시점의 문서 버전 번호 |
| 4 | `requested_by` | `UUID` | ✘ | | 내보내기 요청자 사용자 ID |
| 5 | `format` | `VARCHAR(20)` | ✘ | | 내보내기 포맷: `pdf`, `docx`, `html`, `markdown` |
| 6 | `status` | `VARCHAR(20)` | ✘ | `'pending'` | 작업 상태: `pending`, `processing`, `completed`, `failed` |
| 7 | `options` | `JSONB` | ✔ | `'{}'` | 내보내기 옵션 (includeComments, includeMetadata, watermark, pageSize 등) |
| 8 | `file_url` | `VARCHAR(2048)` | ✔ | | MinIO 프리사인드 URL. `completed` 시 설정, TTL 만료 시 `NULL`로 갱신 |
| 9 | `file_size_bytes` | `BIGINT` | ✔ | | 생성된 파일 크기 (bytes) |
| 10 | `error_message` | `TEXT` | ✔ | | `failed` 상태일 때 에러 사유 |
| 11 | `expires_at` | `TIMESTAMPTZ` | ✔ | | 파일 만료 시각. `completed_at + lm:export.file_ttl_hours` |
| 12 | `created_at` | `TIMESTAMPTZ` | ✘ | `NOW()` | Job 생성 시각 |
| 13 | `completed_at` | `TIMESTAMPTZ` | ✔ | | Job 완료(성공 또는 최종 실패) 시각 |

### 설계 결정

| 결정 | 근거 |
|------|------|
| **PostgreSQL 저장** (ADR-011 D-1) | 감사 추적(AuditModule 연동)과 이력 조회(관리자 대시보드)가 요구사항이므로 Redis/BullMQ 만으로는 부족. ACID 트랜잭션과 복합 인덱스 활용 필요 |
| **`file_url` nullable** | 동기 처리에서는 ExportJob 행을 생성하지 않음. 비동기 처리에서도 `pending`/`processing` 단계에서는 파일 미존재. TTL 만료 시 `NULL`로 갱신 |
| **`options` JSONB** | 포맷별 옵션이 상이하고 향후 확장 가능성이 높아 고정 컬럼 대신 JSONB 사용 |
| **`document_version_number`** | 내보내기 시점의 문서 버전을 기록하여 감사 시 어떤 버전이 내보내기되었는지 추적 가능 |
| **completed Job 보존** | `expires_at` 경과 후 `file_url`만 `NULL`로 갱신하고 행은 보존. 감사 이력 및 통계 분석 활용 [BR-EXP-075] |

### 제약 조건

| 유형 | 대상 | 설명 |
|------|------|------|
| PK | `id` | |
| FK | `document_id` → `documents(id)` | ON DELETE RESTRICT |
| CHECK | `format` | `IN ('pdf', 'docx', 'html', 'markdown')` |
| CHECK | `status` | `IN ('pending', 'processing', 'completed', 'failed')` |
| UNIQUE | `(document_id, format, requested_by)` WHERE `status IN ('pending', 'processing')` | 동일 문서+포맷+사용자에 대해 진행 중인 Job 중복 방지 [BR-EXP-064]. Partial unique index |

---

## DDL

```sql
-- Export Job 테이블
CREATE TABLE export_jobs (
    id                      UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id             UUID            NOT NULL REFERENCES documents(id) ON DELETE RESTRICT,
    document_version_number INTEGER         NOT NULL,
    requested_by            UUID            NOT NULL,
    format                  VARCHAR(20)     NOT NULL CHECK (format IN ('pdf', 'docx', 'html', 'markdown')),
    status                  VARCHAR(20)     NOT NULL DEFAULT 'pending'
                                            CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    options                 JSONB           DEFAULT '{}',
    file_url                VARCHAR(2048),
    file_size_bytes         BIGINT,
    error_message           TEXT,
    expires_at              TIMESTAMPTZ,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    completed_at            TIMESTAMPTZ
);

COMMENT ON TABLE export_jobs IS '비동기 내보내기 작업 상태 추적 (ADR-011 D-1)';
COMMENT ON COLUMN export_jobs.options IS '포맷별 내보내기 옵션 (includeComments, watermark, pageSize 등)';
COMMENT ON COLUMN export_jobs.file_url IS 'MinIO 프리사인드 URL. TTL 만료 시 NULL로 갱신';
COMMENT ON COLUMN export_jobs.expires_at IS 'completed_at + lm:export.file_ttl_hours';
```

---

## 인덱스 전략

```sql
-- 1. 사용자별 이력 조회 (GET /api/export-jobs)
CREATE INDEX idx_export_jobs_requested_by_created
    ON export_jobs (requested_by, created_at DESC);

-- 2. 문서별 내보내기 이력
CREATE INDEX idx_export_jobs_document_id_created
    ON export_jobs (document_id, created_at DESC);

-- 3. 상태별 조회 (관리자 대시보드, 큐 모니터링)
CREATE INDEX idx_export_jobs_status
    ON export_jobs (status)
    WHERE status IN ('pending', 'processing');

-- 4. 중복 Job 방지 (BR-EXP-064) — Partial unique index
CREATE UNIQUE INDEX uq_export_jobs_active_job
    ON export_jobs (document_id, format, requested_by)
    WHERE status IN ('pending', 'processing');

-- 5. 파일 TTL 만료 대상 조회 (BR-EXP-063)
CREATE INDEX idx_export_jobs_expires_at
    ON export_jobs (expires_at)
    WHERE status = 'completed' AND file_url IS NOT NULL;

-- 6. 관리자 전체 이력 (GET /api/admin/export-jobs)
CREATE INDEX idx_export_jobs_created_at_desc
    ON export_jobs (created_at DESC);
```

### 인덱스 설계 근거

| # | 인덱스 | 대상 쿼리 | 근거 |
|---|--------|----------|------|
| 1 | `idx_export_jobs_requested_by_created` | 본인 이력 조회 | 사용자별 최신순 페이지네이션 |
| 2 | `idx_export_jobs_document_id_created` | 문서별 이력 | 특정 문서의 내보내기 이력 추적 |
| 3 | `idx_export_jobs_status` | 큐 모니터링 | `pending`/`processing` 상태만 필터링하는 부분 인덱스로 인덱스 크기 최소화 |
| 4 | `uq_export_jobs_active_job` | 중복 방지 | DB 레벨 UNIQUE 보장. `completed`/`failed` Job은 제외하여 재요청 허용 |
| 5 | `idx_export_jobs_expires_at` | TTL 만료 배치 | cron 스케줄러가 만료 대상을 효율적으로 조회 |
| 6 | `idx_export_jobs_created_at_desc` | 관리자 전체 조회 | 전체 이력의 최신순 페이지네이션 |
