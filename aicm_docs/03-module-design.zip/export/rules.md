# Export 모듈 — 비즈니스 규칙

| 항목 | 값 |
|------|---|
| 모듈명 | ExportModule |
| 기능정의서 | [FD-EXP-내보내기 §2](../../01-requirements/features/FD-EXP-내보내기.md) |

---

## ExportJob 상태 전이

```mermaid
stateDiagram-v2
    [*] --> pending : 내보내기 요청<br/>(비동기 경로)

    pending --> processing : Worker 할당
    processing --> completed : 파일 생성 성공
    processing --> failed : 변환/저장 실패

    failed --> pending : BullMQ Worker<br/>자동 재시도 (최대 3회)<br/>지수 백오프 30s→60s→120s

    pending --> failed : lm:export.job_max_wait_minutes<br/>초과 (타임아웃)

    completed --> [*]
    failed --> [*] : DLQ 이동<br/>(재시도 소진)
```

> **사용자 재시도([BR-EXP-074])**: API로 실패 건을 다시 요청할 때는 위 전이와 달리 **기존 `failed` 행을 재사용하지 않고** 신규 ExportJob 행을 생성한다. BullMQ Worker의 자동 재시도는 동일 Job·동일 ExportJob 행을 유지한다.

---

## 규칙 카탈로그

### 내보내기 대상 적격성

#### BR-EXP-001 — 문서 상태 검증

| 항목 | 내용 |
|------|------|
| **트리거** | `POST /api/documents/{documentId}/export` 호출 시 |
| **조건** | `Document.status === 'published'` |
| **조치** | 조건 불충족 시 `409 EXP_DOCUMENT_NOT_EXPORTABLE` 반환 |
| **위반** | `EXP_DOCUMENT_NOT_EXPORTABLE` |

#### BR-EXP-002 — 권한 검증

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 요청 시 |
| **조건** | 요청자가 해당 Board에 대해 `VIEW` 이상의 Grant를 보유 |
| **조치** | 조건 불충족 시 `403 EXP_NO_VIEW_PERMISSION` 반환 |
| **위반** | `EXP_NO_VIEW_PERMISSION` |

#### BR-EXP-003 — 보드별 내보내기 제어

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 요청 시 |
| **조건** | 보드별 내보내기 통제가 켜진 경우, 해당 보드의 내보내기 허용 플래그가 `true` |
| **조치** | 통제가 꺼져 있으면 이 규칙을 건너뜀. 켜져 있고 보드 내보내기가 비허용이면 `403 EXP_BOARD_EXPORT_DISABLED` 반환 |
| **위반** | `EXP_BOARD_EXPORT_DISABLED` |

#### BR-EXP-004 — 포맷 지원 검증

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 요청 시 |
| **조건** | 요청 포맷이 허용된 내보내기 포맷 목록(SystemConfig 등)에 포함 |
| **조치** | 미포함 시 `400 EXP_UNSUPPORTED_FORMAT` 반환 |
| **위반** | `EXP_UNSUPPORTED_FORMAT` |

---

### 블록 타입별 변환 규칙 (BR-EXP-010 ~ BR-EXP-022)

> FD-EXP §2.2 기반. 각 블록 타입은 4개 포맷(PDF, DOCX, HTML, Markdown)에 대해 변환 규칙이 존재한다.

#### BR-EXP-010 — 텍스트(paragraph) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | 변환 파이프라인에서 `paragraph` 타입 블록 처리 시 |
| **조건** | — |
| **조치** | 인라인 마크(bold, italic, underline, strikethrough, code, link) 보존. 각 포맷의 네이티브 스타일로 매핑 |

#### BR-EXP-011 — 제목(heading) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `heading` 타입 블록 처리 시 |
| **조건** | `level` 속성 (1~6) |
| **조치** | PDF: 대응 폰트 크기/굵기 적용, DOCX: `Heading1`~`Heading6` 스타일, HTML: `<h1>`~`<h6>`, Markdown: `#`~`######` |

#### BR-EXP-012 — 목록(list) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `bulletList` / `orderedList` / `taskList` 타입 블록 처리 시 |
| **조건** | 중첩 레벨, 체크박스 상태(`taskList`) |
| **조치** | 중첩 들여쓰기 보존. `taskList`의 경우 PDF/DOCX: ☑/☐ 유니코드 문자, HTML: `<input type="checkbox">`, Markdown: `- [x]`/`- [ ]` |

#### BR-EXP-013 — 이미지(image) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `image` 타입 블록 처리 시 |
| **조건** | `src` URL 유효성 |
| **조치** | 이미지 다운로드 후 내장. PDF/DOCX: 인라인 이미지, HTML: `<img>` 태그(Base64 또는 원본 URL), Markdown: `![alt](url)`. 다운로드 실패 시 플레이스홀더 텍스트 삽입 |

#### BR-EXP-014 — 테이블(table) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `table` 타입 블록 처리 시 |
| **조건** | 행/열 구조, 셀 병합 |
| **조치** | PDF: 테이블 렌더링(셀 병합 포함), DOCX: 네이티브 테이블, HTML: `<table>`, Markdown: GFM 테이블(병합 미지원 시 별도 주석) |

#### BR-EXP-015 — 코드(codeBlock) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `codeBlock` 타입 블록 처리 시 |
| **조건** | `language` 속성 |
| **조치** | PDF: 모노스페이스 폰트 + 배경색, DOCX: 고정폭 스타일, HTML: `<pre><code>` + 언어 클래스, Markdown: 펜스드 코드 블록(``` + language) |

#### BR-EXP-016 — 인용(blockquote) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `blockquote` 타입 블록 처리 시 |
| **조건** | — |
| **조치** | PDF: 왼쪽 세로선 + 들여쓰기, DOCX: 인용 스타일, HTML: `<blockquote>`, Markdown: `>` |

#### BR-EXP-017 — 구분선(divider) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `divider` 타입 블록 처리 시 |
| **조건** | — |
| **조치** | PDF: 가로선, DOCX: 가로선 단락, HTML: `<hr>`, Markdown: `---` |

#### BR-EXP-018 — 파일(file) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `file` 타입 블록 처리 시 |
| **조건** | — |
| **조치** | 모든 포맷: 파일명 + 다운로드 링크 텍스트로 변환. 파일 자체는 내보내기 파일에 포함하지 않음 |

#### BR-EXP-019 — 임베드(embed) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `embed` 타입 블록 처리 시 |
| **조건** | — |
| **조치** | PDF/DOCX: "임베드 콘텐츠: [URL]" 텍스트로 대체, HTML: `<iframe>` 또는 링크, Markdown: URL 링크 |

#### BR-EXP-020 — 콜아웃(callout) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `callout` 타입 블록 처리 시 |
| **조건** | `type` (info, warning, danger, success) |
| **조치** | PDF: 색상 배경 박스 + 아이콘 텍스트, DOCX: 강조 스타일, HTML: `<div class="callout callout-{type}">`, Markdown: `> **{Type}:** 내용` |

#### BR-EXP-021 — 토글(toggle) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `toggle` 타입 블록 처리 시 |
| **조건** | — |
| **조치** | 토글을 **펼친 상태**로 변환. PDF/DOCX: 토글 제목(굵게) + 하위 블록 들여쓰기, HTML: `<details><summary>`, Markdown: 제목 + 하위 블록 |

#### BR-EXP-022 — 수식(math) 블록

| 항목 | 내용 |
|------|------|
| **트리거** | `math` 타입 블록 처리 시 |
| **조건** | LaTeX 수식 문자열 |
| **조치** | PDF: LaTeX 렌더링, DOCX: OMML 또는 이미지 삽입, HTML: MathJax/KaTeX 스크립트 포함, Markdown: `$$...$$` |

---

### 공통 컨텐츠 및 특수 블록 처리 (BR-EXP-030 ~ BR-EXP-042)

> **FD-EXP BR-EXP-031~032**: 공통 컨텐츠 비활성(`is_active = false`) 처리 및 조회 실패 시 플레이스홀더 삽입은 **DocumentModule**의 인라인 치환 단계 책임이다 ([ADR-011](../../adr/011-round3-module-design-decisions.md) D-2). ExportModule은 치환·경고 라벨이 반영된 블록만 수신한다.

#### BR-EXP-030 — 공통 컨텐츠 인라인 치환

| 항목 | 내용 |
|------|------|
| **트리거** | DocumentModule로부터 블록 데이터 수신 시 |
| **조건** | — |
| **조치** | 공통 컨텐츠 블록은 DocumentModule이 인라인 치환하여 제공한다. ExportModule은 치환된 결과를 그대로 사용한다 (ADR-011 D-2). ExportModule → SharedContentModule 직접 의존 없음 |

#### BR-EXP-040 — 숨김 블록 제외

| 항목 | 내용 |
|------|------|
| **트리거** | 블록 전처리 단계 |
| **조건** | `Block.visible === false` |
| **조치** | 내보내기 결과물에서 해당 블록을 완전히 제외 |

#### BR-EXP-041 — 접근 제한 블록 처리

| 항목 | 내용 |
|------|------|
| **트리거** | 블록 전처리 단계 |
| **조건** | `Block.restricted === true`이고 요청자가 해당 블록에 대한 VIEW 권한 없음 |
| **조치** | 해당 블록 위치에 `[접근 권한이 없는 콘텐츠입니다]` 플레이스홀더를 삽입 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-041) |

#### BR-EXP-042 — embeddable 플래그와 내보내기

| 항목 | 내용 |
|------|------|
| **트리거** | 블록 전처리 단계 |
| **조건** | `embeddable === false`인 블록 |
| **조치** | **내보내기 대상에 포함한다.** `embeddable`은 RAG 임베딩 제어용 플래그이며, 내보내기 제외 조건이 아니다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-042) |

---

### 워터마크 규칙 (BR-EXP-050 ~ BR-EXP-054)

#### BR-EXP-050 — 워터마크 기본 규칙

| 항목 | 내용 |
|------|------|
| **트리거** | PDF 파일 생성 후처리 단계 |
| **조건** | 워터마크 옵션이 활성이고, 사용자 요청에서 `options.watermark !== false` |
| **조치** | 워터마크가 켜진 환경에서 PDF 내보내기 시 **워터마크를 자동 삽입**한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-050) |

#### BR-EXP-051 — 워터마크 텍스트 구성

| 항목 | 내용 |
|------|------|
| **트리거** | 워터마크 삽입 시 |
| **조건** | — |
| **조치** | 워터마크 텍스트 기본값은 `pm:export.watermark_text`이며, 관리자가 [FD-SYS](../../01-requirements/features/FD-SYS-시스템설정.md) §3.6에서 변경할 수 있다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-051). 구현상 `pm` 미설정 시 애플리케이션 기본 문자열(예: `CONFIDENTIAL`)을 둘 수 있다 |

#### BR-EXP-052 — 요청자 이름·내보내기 일시 자동 포함

| 항목 | 내용 |
|------|------|
| **트리거** | 워터마크 삽입 시(BR-EXP-050 조건 충족) |
| **조건** | — |
| **조치** | 워터마크에는 텍스트와 함께 **요청자 이름**, **내보내기 일시**(형식 `YYYY-MM-DD HH:mm`)가 자동으로 포함된다. 인쇄 워터마크([FD-DOC](../../01-requirements/features/FD-DOC-문서관리.md) §1.6 BR-DOC-017)와 동일한 정보 구성을 목표로 한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-052) |

#### BR-EXP-053 — 워터마크 표시 방식

| 항목 | 내용 |
|------|------|
| **트리거** | 워터마크 삽입 시 |
| **조건** | — |
| **조치** | 워터마크는 각 페이지에 **대각선 방향으로 반투명**하게 표시한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-053) |

#### BR-EXP-054 — 비PDF 포맷 워터마크 미적용

| 항목 | 내용 |
|------|------|
| **트리거** | DOCX, HTML, Markdown 내보내기 파일 생성 시 |
| **조건** | — |
| **조치** | DOCX, HTML, Markdown 포맷에는 워터마크를 적용하지 않는다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-054) |

---

### 후처리(모듈 전용) — 문서 메타데이터 삽입 (BR-EXP-100)

> FD-EXP에 별도 BR 번호가 없다. [FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) §2 파이프라인의 메타데이터 삽입 단계를 모듈에서 `options.includeMetadata`([api.md](./api.md))와 연계하여 구현한다.

#### BR-EXP-100 — 메타데이터 삽입

| 항목 | 내용 |
|------|------|
| **트리거** | 파일 생성 후처리 단계 |
| **조건** | `options.includeMetadata !== false` |
| **조치** | 파일 시작부에 문서 제목, 작성자, 내보내기 일시를 삽입한다. PDF: 헤더/푸터, DOCX: 문서 속성, HTML: `<meta>` + 상단 블록, Markdown: YAML frontmatter |

---

### 동기/비동기 분기 규칙 (BR-EXP-060 ~ BR-EXP-061)

#### BR-EXP-060 — 동기 처리 조건

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 요청 처리 시 |
| **조건** | 대상 문서의 블록 수 ≤ `lm:export.async_threshold` |
| **조치** | 동기적으로 파일 변환 수행. ExportJob 행을 생성하지 않고 즉시 프리사인드 URL을 포함한 `200 OK`를 반환 |

#### BR-EXP-061 — 비동기 처리 조건

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 요청 처리 시 |
| **조건** | 대상 문서의 블록 수 > `lm:export.async_threshold` |
| **조치** | ExportJob 행을 `pending` 상태로 생성하고 BullMQ `export` 큐에 Job을 추가한 뒤 `202 Accepted`를 반환 |

---

### 비동기 UX·저장·중복·파일 크기 (BR-EXP-062 ~ BR-EXP-065)

#### BR-EXP-062 — 비동기 처리 시 사용자 안내

| 항목 | 내용 |
|------|------|
| **트리거** | 비동기 내보내기 경로로 요청이 수락된 직후 및 완료 시 |
| **조건** | — |
| **조치** | 사용자에게 "내보내기를 준비 중입니다" 안내를 표시하고, 완료 시 인앱 알림으로 다운로드 링크를 제공한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-062) |

#### BR-EXP-063 — 임시 저장 및 TTL 기반 삭제

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 파일 생성 완료 시, 스케줄러(cron), 다운로드 요청 시점 |
| **조건** | — |
| **조치** | 생성된 내보내기 파일은 오브젝트 스토리지(S3/MinIO)에 임시 저장하며, `lm:export.file_ttl_hours` 경과 후 자동 삭제한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-063). 구현: `expires_at` 설정 후 경과 시 MinIO에서 파일 삭제, ExportJob 행은 감사 이력으로 보존하되 `file_url`을 `null`로 갱신. 다운로드 요청 시 `410 EXP_FILE_EXPIRED` 반환 및 `export.file.expired` 이벤트 발행 |

#### BR-EXP-064 — 중복 Job 방지

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 요청 시 |
| **조건** | 동일 사용자가 동일 문서에 대해 동일 포맷으로 `pending` 또는 `processing` 상태의 ExportJob이 이미 존재(구현 표현: 동일 `document_id` + `format` + `requested_by`) |
| **조치** | `429 EXP_DUPLICATE_JOB` 반환. 기존 Job의 `jobId`를 응답에 포함한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-064) |

#### BR-EXP-065 — 파일 크기 제한

| 항목 | 내용 |
|------|------|
| **트리거** | 내보내기 파일 생성 시(또는 사전 예측 시) |
| **조건** | 내보내기 파일 크기가 `lm:export.max_file_size_mb`를 초과할 것으로 예상되거나 실제 초과 |
| **조치** |내보내기를 거부하고 사유를 안내한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-065). 동기 처리: `413 EXP_FILE_SIZE_EXCEEDED` 반환. 비동기 처리: Job을 `failed`로 전이하고 `error_message`에 사유 기록 |

---

### 비동기 큐·재시도·DLQ·보존 (BR-EXP-070 ~ BR-EXP-075)

#### BR-EXP-070 — BullMQ 전용 큐

| 항목 | 내용 |
|------|------|
| **트리거** | 비동기 내보내기 Job 등록 시 |
| **조건** | — |
| **조치** | 비동기 내보내기는 BullMQ 전용 큐(`export`)에서 처리한다. 큐명 접두사·동시성·DLQ·재시도·Job 타임아웃·pending 타임아웃·Stalled Interval은 [events.md](./events.md)와 본 섹션 후속 BR과 일치시킨다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-070) |

#### BR-EXP-071 — Worker 자동 재시도

| 항목 | 내용 |
|------|------|
| **트리거** | BullMQ Worker에서 Job 처리 실패 시 |
| **조건** | 재시도 횟수 < 3 |
| **조치** | 워커 실패 시 **최대 3회** 자동 재시도한다. 재시도 간격은 지수 백오프(30초, 60초, 120초)를 적용한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-071). 동일 BullMQ Job·동일 ExportJob 행을 유지하며 `ExportJob.status`를 `failed` → `pending`으로 복원하고 `retry_count`를 증가시킨다. 상태 전이는 감사·디버깅을 위해 로깅한다 |

#### BR-EXP-072 — DLQ 이동

| 항목 | 내용 |
|------|------|
| **트리거** | 3회 재시도 후에도 실패 |
| **조건** | — |
| **조치** | `status = 'failed'`로 전환하고 해당 Job은 **DLQ(Dead Letter Queue)**(`export-dlq`)로 이동한다. ExportJob.status를 `failed`로 확정한다. `export.job.failed` 이벤트를 발행한다. DLQ Job은 관리자 모니터링 대시보드에서 확인할 수 있다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-072) |

#### BR-EXP-073 — `pending` 장기 체류 타임아웃

| 항목 | 내용 |
|------|------|
| **트리거** | 스케줄러 또는 BullMQ stalled check |
| **조건** | ExportJob이 `pending` 상태에서 `lm:export.job_max_wait_minutes`(기본 30분)이 경과 |
| **조치** | 자동으로 `failed`로 전환하고 **"처리 시간 초과"** 사유를 기록한다. `export.job.failed` 이벤트를 발행한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-073) |

#### BR-EXP-074 — 사용자 재시도 시 신규 ExportJob 행

| 항목 | 내용 |
|------|------|
| **트리거** | API로 이전에 실패한 내보내기를 사용자가 다시 요청할 때 |
| **조건** | — |
| **조치** | 사용자 재시도 요청 시 **새 ExportJob 행을 생성**한다. 기존 failed Job 행은 감사 추적을 위해 보존한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-074). BullMQ Worker의 자동 재시도(BR-EXP-071)와 구분한다 — Worker 재시도는 동일 Job·동일 ExportJob 행을 유지한다 |
| **위반 시** | 기존 `failed` 행을 `pending`으로 되돌리거나 동일 행을 재사용하면 감사 이력([FD-AUD](../../01-requirements/features/FD-AUD-감사로그.md))과 불일치·추적 단절이 발생할 수 있다 |

#### BR-EXP-075 — `completed` Job 행 보존

| 항목 | 내용 |
|------|------|
| **트리거** | 파일 TTL 만료 처리 시 |
| **조건** | ExportJob.status === `completed`이고 `expires_at` 경과 |
| **조치** | `completed` 상태의 ExportJob 행은 파일 만료 후에도 **삭제하지 않는다** — 파일(스토리지 객체)만 삭제하고 Job 행은 감사 이력으로 보관한다. `file_url`만 `null`로 갱신한다 ([FD-EXP](../../01-requirements/features/FD-EXP-내보내기.md) BR-EXP-075, BR-EXP-063 연계). Job 행 보관 기간은 감사 로그 보관 정책([FD-AUD](../../01-requirements/features/FD-AUD-감사로그.md))을 따른다 |

---

## 에러 코드 카탈로그

| 에러 코드 | HTTP | 설명 | 관련 BR |
|-----------|------|------|---------|
| `EXP_DOCUMENT_NOT_EXPORTABLE` | 409 | 문서 상태가 `published`가 아님 | BR-EXP-001 |
| `EXP_NO_VIEW_PERMISSION` | 403 | Board VIEW 권한 없음 | BR-EXP-002 |
| `EXP_BOARD_EXPORT_DISABLED` | 403 | 보드 내보내기 비허용 | BR-EXP-003 |
| `EXP_UNSUPPORTED_FORMAT` | 400 | 미지원 포맷 | BR-EXP-004 |
| `EXP_DOCUMENT_NOT_FOUND` | 404 | 문서 없음 | — |
| `EXP_JOB_NOT_FOUND` | 404 | Job 없음 / 타인 소유 | — |
| `EXP_FILE_SIZE_EXCEEDED` | 413 | 파일 크기 초과 | BR-EXP-065 |
| `EXP_DUPLICATE_JOB` | 429 | 중복 Job | BR-EXP-064 |
| `EXP_FILE_EXPIRED` | 410 | 파일 TTL 만료 | BR-EXP-063 |

---

## FD-EXP ↔ 모듈 스펙 BR 매핑 참고

| FD-EXP BR-ID | FD 요지 | 본 문서 위치·비고 |
|--------------|---------|-------------------|
| BR-EXP-031 | 비활성 공통 컨텐츠 치환·경고 | DocumentModule 인라인 치환 ([ADR-011](../../adr/011-round3-module-design-decisions.md) D-2). `rules.md` 상단 블록 인용 |
| BR-EXP-032 | 공통 컨텐츠 조회 실패 플레이스홀더 | 위와 동일 (DocumentModule) |
| BR-EXP-050 ~ 054 | PDF 워터마크·비PDF 미적용 | `rules.md` §워터마크 규칙 — FD와 동일 번호 |
| BR-EXP-060 ~ 061 | 동기/비동기 분기 | `rules.md` §동기/비동기 분기 규칙 |
| BR-EXP-062 ~ 065 | 비동기 UX·저장·중복·파일 크기 | `rules.md` §비동기 UX·저장·중복·파일 크기 |
| BR-EXP-070 ~ 075 | BullMQ 큐·재시도·DLQ·pending 타임아웃·사용자 재시도·completed 보존 | `rules.md` §비동기 큐·재시도·DLQ·보존, `events.md` BullMQ 표 |
| BR-EXP-100 | (FD 미부여) 메타데이터 삽입 | `rules.md` §후처리(모듈 전용) — 파이프라인 단계만 FD §2에 존재 |
