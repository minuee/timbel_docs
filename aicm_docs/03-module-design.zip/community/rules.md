# CommunityModule — 비즈니스 규칙

> 댓글, 좋아요, 신고, 북마크에 대한 비즈니스 규칙 카탈로그
> 기능정의서: [FD-COM-커뮤니티](../../01-requirements/features/FD-COM-커뮤니티.md)

**BR-ID 표기**: 본 문서의 `BR-COM-xxx`는 모듈 스펙 구현용 카탈로그 번호이다. FD-COM §1~§6에서 동일 접두 `BR-COM-xxx`가 쓰이나 **번호 체계가 다르므로** 1:1로 동일 규칙을 의미하지 않는다. 교차 참조 시 혼동을 줄이기 위한 주요 대응: FD BR-COM-017(댓글 수정) → 본 문서 BR-COM-006·007·017; FD BR-COM-042(중복 신고) → BR-COM-042; FD BR-COM-030(1인 1좋아요) → BR-COM-030.

---

## 1. 상태 전이

### 1.1 댓글 상태 전이

```mermaid
stateDiagram-v2
    [*] --> open : 댓글 작성
    open --> resolved : resolve (문서 작성자)
    resolved --> open : reopen (댓글 작성자)
    open --> deleted : 삭제 (본인/관리자)
    resolved --> deleted : 삭제 (본인/관리자)
    deleted --> [*]
```

| 전이 | 행위자 | 조건 | 참조 |
|------|--------|------|------|
| open → resolved | 문서 작성자 | `is_resolved = false` | BR-COM-020 |
| resolved → open | 댓글 작성자 | `is_resolved = true` | BR-COM-022 |
| open/resolved → deleted | 본인 또는 관리자 | `deleted_at IS NULL` | BR-COM-008 |

### 1.2 신고 상태 전이

```mermaid
stateDiagram-v2
    [*] --> pending : 신고 접수
    pending --> reviewing : 관리자 검토 시작
    reviewing --> resolved : 조치 완료
    resolved --> [*]
```

| 전이 | 행위자 | 조건 | 참조 |
|------|--------|------|------|
| pending → reviewing | 관리자 | status = 'pending' | BR-COM-046 |
| reviewing → resolved | 관리자 | action_type 필수 | BR-COM-047 |

> resolved 이후 상태 재변경은 불가하다. `dismissed`는 `action_type = 'dismissed'` + `status = 'resolved'`로 표현한다 (ADR-011 B-4).

---

## 2. 규칙 카탈로그

### 2.0 횡단 관심사 (FD-COM §2.1)

다음 FD-COM 비즈니스 규칙은 **CommunityModule 단일 서비스 메서드**에만 국한되지 않으며, 클라이언트·공통 파이프라인·정책 레이어와 함께 다룬다. 구현 시 처리 주체를 아래와 같이 본다.

| FD-COM BR | 내용 | 처리 주체 / 레이어 |
|-----------|------|-------------------|
| BR-COM-013 | 등록 버튼 연타에 따른 중복 요청 방지 | 클라이언트(UI 비활성화·디바운스) 및 API 멱등·중복 억제 패턴 — [07-cross-cutting-concerns.md](../../02-architecture/07-cross-cutting-concerns.md) 참조 |
| BR-COM-015 | 민감정보 패턴 감지·경고 | 횡단 관심사(입력 검증·경고 응답); 응답 계약은 FD-COM §8 `COM_COMMENT_SENSITIVE_INFO` 등 준수 |
| BR-COM-016 | 부적절 콘텐츠(금칙어 등) 감지 | 시스템 운영 설정 기반 정책; 차단 수준은 등록 거부(`COM_COMMENT_BLOCKED_CONTENT`) |

CommunityModule **RDB 제약**으로 직접 보장하는 중복 방지: 신고 `UNIQUE(target_type, target_id, reporter_id)` (BR-COM-042), 좋아요 `UNIQUE(document_id, user_id)` (BR-COM-030).

### 2.1 댓글 — 작성

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-001 | 댓글 작성 권한 | 댓글 작성 요청 | 문서 읽기 권한 이상 | 댓글 생성 | 403 Forbidden | 읽기 가능 → 댓글 가능 |
| BR-COM-002 | 댓글 내용 길이 | 댓글 작성/수정 | `content.length ≤ lm:community.comment_max_length` | 통과 | COM_COMMENT_CONTENT_TOO_LONG | 과도한 댓글 방지 |
| BR-COM-003 | 1depth 대댓글 | 답글 작성 | `parent.parent_comment_id IS NULL` | 답글 생성 | COM_COMMENT_DEPTH_EXCEEDED | UI 복잡도 제한 |
| BR-COM-004 | 동일 문서 댓글만 참조 | 답글 작성 | `parent.document_id = target.document_id` | 통과 | COM_COMMENT_NOT_FOUND | 교차 문서 답글 방지 |
| BR-COM-005 | 삭제된 댓글에 답글 불가 | 답글 작성 | `parent.deleted_at IS NULL` | 답글 생성 | COM_COMMENT_DELETED | 삭제 댓글 답글 방지 |

### 2.2 댓글 — 수정

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-006 | 본인만 수정 | 댓글 수정 요청 | `comment.author_id = currentUser.id` | 수정 허용 | COM_COMMENT_NOT_OWNER | 작성자 보호 |
| BR-COM-007 | 삭제된 댓글 수정 불가 | 댓글 수정 요청 | `comment.deleted_at IS NULL` | 수정 허용 | COM_COMMENT_DELETED | 삭제 상태 보호 |
| BR-COM-017 | 수정 허용 시간 창 | 댓글 수정 요청 | `now - comment.created_at ≤ comment_edit_window_minutes` (SystemConfig, 분 단위, **기본 30분**) | 수정 허용 | COM_COMMENT_EDIT_EXPIRED | ADR-011 E-3, FD-COM BR-COM-017 |

### 2.3 댓글 — 삭제

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-008 | 삭제 권한 | 댓글 삭제 요청 | 본인 또는 관리자 | 소프트 딜리트 (`deleted_at = now()`) | COM_COMMENT_NOT_OWNER | 본인/관리자만 삭제 |
| BR-COM-009 | 삭제 시 답글 유지 | 댓글 삭제 | 답글이 존재 | "삭제된 댓글입니다" 표시, 구조 유지 | — | 스레드 구조 보호 |

### 2.4 댓글 — 목록 조회

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-010 | 조회 권한 | 목록 조회 | 문서 읽기 권한 이상 | 조회 허용 | 403 Forbidden | 문서 접근 가능 = 댓글 조회 가능 |
| BR-COM-011 | 삭제 댓글 표시 | 목록 조회 | `deleted_at IS NOT NULL` | content를 "삭제된 댓글입니다"로 치환, 답글은 정상 표시 | — | 스레드 구조 유지 |
| BR-COM-012 | 정렬 기준 | 목록 조회 | — | 최상위 댓글: `created_at ASC`, 답글: `created_at ASC` | — | 시간순 표시 |

### 2.5 댓글 — 해결/재개

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-020 | 해결 권한 | resolve 요청 | `currentUser.id = document.author_id` | `is_resolved=true`, `resolved_by`, `resolved_at` 설정 | COM_COMMENT_RESOLVE_FORBIDDEN | 문서 작성자만 해결 표시 |
| BR-COM-021 | 이미 해결된 댓글 | resolve 요청 | `is_resolved = false` | 해결 처리 | COM_COMMENT_ALREADY_RESOLVED | 중복 해결 방지 |
| BR-COM-022 | 재개 권한 | reopen 요청 | `currentUser.id = comment.author_id` AND `is_resolved = true` | `is_resolved=false`, `resolved_by=null`, `resolved_at=null` | COM_COMMENT_REOPEN_FORBIDDEN / COM_COMMENT_NOT_RESOLVED | 댓글 작성자만 재개 |

### 2.6 댓글 — 댓글 수 카운터

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-013 | 댓글 수 증가 | 댓글 작성 완료 | — | Redis INCR `community:comment_count:{documentId}` | — | 실시간 카운터 |
| BR-COM-014 | 댓글 수 감소 | 댓글 삭제 완료 | — | Redis DECR `community:comment_count:{documentId}` | — | 실시간 카운터 |
| BR-COM-015 | 캐시 미스 폴백 | 카운터 조회 시 miss | — | DB COUNT 쿼리로 복구 후 Redis SET | — | 데이터 정합성 |

---

### 2.7 좋아요

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-030 | 좋아요 토글 | 토글 요청 | 좋아요 미존재 | INSERT + Redis INCR | — | 1인 1좋아요 |
| BR-COM-031 | 좋아요 취소 | 토글 요청 | 좋아요 존재 | DELETE + Redis DECR | — | 토글 방식 |
| BR-COM-032 | 본인 문서 좋아요 허용 | 토글 요청 | — | 본인 문서에도 좋아요 가능 | — | FD-COM 제한 없음 |
| BR-COM-033 | 좋아요 수 응답 | 토글 완료 | — | 갱신된 Redis 카운터 값 반환 | — | 실시간 피드백 |
| BR-COM-034 | 좋아요 상태 조회 | 조회 요청 | — | `liked: boolean` + `likeCount: number` 반환 | — | 초기 렌더링 |
| BR-COM-035 | 캐시 미스 폴백 | 카운터 조회 시 miss | — | DB COUNT 쿼리로 복구 후 Redis SET | — | 데이터 정합성 |

---

### 2.8 신고 — 접수

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-040 | 신고 사유 검증 | 신고 접수 | `reason_type IN ('spam','inappropriate','copyright','privacy','other')` | 통과 | 400 Bad Request | 5종 사유 제한 |
| BR-COM-041 | 기타 사유 상세 필수 | 신고 접수 | `reason_type='other'` → `reason_detail IS NOT NULL` | 통과 | COM_REPORT_DETAIL_REQUIRED | 사유 투명성 |
| BR-COM-042 | 중복 신고 방지 | 신고 접수 | `UNIQUE(target_type, target_id, reporter_id)` | 거부 | COM_REPORT_DUPLICATE | 어뷰징 방지 |
| BR-COM-043 | 본인 콘텐츠 신고 불가 | 신고 접수 | `target.author_id ≠ currentUser.id` | 통과 | COM_REPORT_SELF | 자기 신고 방지 |
| BR-COM-044 | 대상 존재 확인 | 신고 접수 | target_type에 해당하는 엔티티 존재 | 통과 | COM_REPORT_TARGET_NOT_FOUND | 유효성 검증 |

### 2.9 신고 — 처리

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-045 | 관리자 전용 | 신고 목록/처리 | 관리자 역할 | 접근 허용 | 403 Forbidden | 관리자 전용 |
| BR-COM-046 | 검토 시작 | 상태 변경 | `pending → reviewing` | `reviewed_by` 설정 | COM_REPORT_ALREADY_RESOLVED | 순차 전이 |
| BR-COM-047 | 조치 완료 | 상태 변경 | `reviewing → resolved` + `action_type` 필수 | `reviewed_at` 설정, 조치 반영 | COM_REPORT_ACTION_REQUIRED | 조치 기록 |
| BR-COM-048 | 삭제 조치 시 블라인드 | `action_type = 'deleted'` | resolved | 대상 콘텐츠 블라인드 처리 | — | 유해 콘텐츠 제거 |

### 2.10 신고 — 자동 블라인드

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-049 | 누적 자동 블라인드 | 신고 접수 | 동일 대상 `pending/reviewing` 신고 수 ≥ `lm:community.report_auto_hide_threshold` | 대상 즉시 블라인드 + `community.report.auto_blinded` 이벤트 | — | 컴플라이언스 |

---

### 2.11 북마크

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-050 | 북마크 추가 | 추가 요청 | 문서 존재 + 폴더 존재 | 북마크 생성, 폴더 미지정 시 기본 폴더 | COM_DOCUMENT_NOT_FOUND / COM_FOLDER_NOT_FOUND | |
| BR-COM-051 | 폴더 간 이동/복제 | 이동 요청 | 대상 폴더에 동일 문서 없음 | folder_id 변경 | COM_BOOKMARK_DUPLICATE | 폴더 간 중복 방지 |
| BR-COM-052 | 기본 폴더 삭제 불가 | 폴더 삭제 | `is_default = false` | 삭제 허용 | COM_FOLDER_DEFAULT_DELETE | 기본 폴더 보호 |
| BR-COM-053 | 북마크 삭제 | 삭제 요청 | 본인 소유 | 물리 삭제 | COM_BOOKMARK_NOT_FOUND | |
| BR-COM-054 | 북마크 수 제한 | 북마크 추가 | `count ≤ lm:community.bookmark_max_count` | 추가 허용 | COM_BOOKMARK_LIMIT | 자원 보호 |
| BR-COM-055 | 폴더 수 제한 | 폴더 생성 | `count ≤ lm:community.bookmark_folder_max_count` | 생성 허용 | COM_FOLDER_LIMIT | 자원 보호 |
| BR-COM-056 | 폴더명 중복 금지 | 폴더 생성/수정 | 동일 사용자 내 이름 유일 | 통과 | COM_FOLDER_NAME_DUPLICATE | UX |
| BR-COM-057 | 업데이트 배지 판정 | 북마크 목록 조회 | `document.version > bookmark.last_seen_version` | `hasUpdate = true` | — | 문서 변경 감지 |
| BR-COM-058 | 폴더 삭제 시 이동 | 폴더 삭제 | 소속 북마크 존재 | 기본 "미분류" 폴더로 이동 | — | 데이터 보호 |
| BR-COM-059 | 열람 시 버전 갱신 | 북마크 문서 열람 | — | `last_seen_version = document.version` | — | 배지 리셋 |
| BR-COM-060 | 기본 폴더 자동 생성 | 최초 북마크 추가 | 사용자에게 폴더 없음 | `is_default=true` "미분류" 폴더 생성 | — | 최초 경험 |

---

### 2.12 읽음 확인 (NoticeReadConfirmation)

> 읽음 확인의 비즈니스 규칙 상세는 [FD-NTC-공지사항](../../01-requirements/features/FD-NTC-공지사항.md) §4에서 정의한다. 아래는 CommunityModule이 직접 보장하는 데이터 무결성 규칙이다.

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-080 | 확인 대상 중복 방지 | 확인 레코드 생성 | `UNIQUE(document_id, user_id)` | 거부 | COM_NOTICE_CONFIRMATION_DUPLICATE | 동일 사용자 중복 방지 |
| BR-COM-081 | 확인 처리 멱등 | 확인 요청 | `confirmed_at IS NOT NULL` | 무시 (이미 확인됨) | — | 중복 확인 방지 |
| BR-COM-082 | 확인 기한 읽기 전용 | 사용자 확인 요청 | — | `confirmation_deadline` 변경 불가 (관리자/시스템만) | — | 데이터 무결성 |

---

### 2.13 공통 규칙

| ID | 규칙 | 트리거 | 조건 | 행위 | 위반 시 | 근거 |
|----|------|--------|------|------|---------|------|
| BR-COM-070 | 감사 로그 | 모든 CUD 작업 | — | AuditLog 이벤트 발행 | — | 컴플라이언스 |
| BR-COM-071 | 소프트 딜리트 | Comment 삭제 | — | `deleted_at` 설정 (물리 삭제 아님) | — | 스레드 보호 |
| BR-COM-072 | 블라인드 처리 | Report 조치 `deleted` / 자동 블라인드 | — | 대상 콘텐츠 블라인드 (Document → `is_hidden=true`, Comment → `deleted_at` 설정) | — | 유해 콘텐츠 |
| BR-COM-073 | 문서 삭제 연쇄 | Document CASCADE DELETE | — | 관련 Comment, Like, Bookmark 자동 삭제 | — | 참조 무결성 |
| BR-COM-074 | SystemConfig 제한값 | 모든 `lm:community.*` 참조 | — | SystemConfig에서 값 로드, 기본값 사용 | — | 설정 가능성 |

---

## 3. 설정 가능 항목

| 키 | 설명 | 기본값 | 근거 |
|----|------|--------|------|
| `lm:community.comment_max_length` | 댓글 최대 글자 수 | 2000 | BR-COM-002 |
| `comment_edit_window_minutes` | 댓글 수정 허용 시간(작성 시각 기준, 분) | 30 | BR-COM-017 — SystemConfig 키, 조직별 조정 (ADR-011 E-3). FD-COM §11의 `lm:community.comment_edit_window_hours`와 병행 시 스펙은 본 키(분)를 정본으로 한다 |
| `lm:community.report_auto_hide_threshold` | 자동 블라인드 신고 누적 수 | 5 | BR-COM-049 |
| `lm:community.bookmark_max_count` | 사용자당 최대 북마크 수 | 500 | BR-COM-054 |
| `lm:community.bookmark_folder_max_count` | 사용자당 최대 폴더 수 | 20 | BR-COM-055 |

---

## 4. 관련 문서

- [data.md](data.md) — 엔티티 정의, 제약 조건
- [api.md](api.md) — API 스펙, 에러 코드
- [events.md](events.md) — 이벤트 발행 (CUD 감사 로그)
- [cache.md](cache.md) — Redis 카운터 (좋아요/댓글 수)
- [FD-COM](../../01-requirements/features/FD-COM-커뮤니티.md) — 비즈니스 규칙 원천
- [ADR-011 §B·§E](../../adr/011-round3-module-design-decisions.md) — Community 결정사항 (B-1~B-6, E-3·E-4)
- [07-cross-cutting-concerns.md](../../02-architecture/07-cross-cutting-concerns.md) — 횡단 관심사
