# CommunityModule — 캐시 전략

> 좋아요 수, 댓글 수 Redis 카운터 및 캐시 전략
> 기능정의서: [FD-COM-커뮤니티](../../01-requirements/features/FD-COM-커뮤니티.md)

---

## 0. 캐시 개요

CommunityModule은 Redis를 **실시간 카운터**로 사용한다 (ADR-011 B-6).

| 캐시 대상 | 패턴 | 용도 |
|-----------|------|------|
| 좋아요 수 | INCR / DECR | 문서별 좋아요 수 실시간 반영 |
| 댓글 수 | INCR / DECR | 문서별 댓글 수 실시간 반영 |

> AggregationModule의 대시보드/피드 집계와 별개로, CommunityModule이 Redis 카운터를 직접 관리하는 이유: 좋아요 토글 API 응답에 즉시 갱신된 카운트를 반환해야 하며, AggregationModule 경유 시 지연이 발생한다.

---

## 1. 좋아요 수 카운터

### 1.1 키 패턴

```
{tenant_id}:community:like_count:{documentId}
```

- **타입**: STRING (Redis INCR/DECR 대상)
- **값**: 0 이상의 정수
- **TTL**: 없음 (영구). 문서 삭제 시 키 제거

### 1.2 연산 흐름

| 동작 | Redis 명령 | DB 연산 | 시점 |
|------|-----------|---------|------|
| 좋아요 추가 | `INCR {tenant_id}:community:like_count:{documentId}` | INSERT INTO "like" | 동시 (트랜잭션 내) |
| 좋아요 취소 | `DECR {tenant_id}:community:like_count:{documentId}` | DELETE FROM "like" | 동시 (트랜잭션 내) |
| 조회 | `GET {tenant_id}:community:like_count:{documentId}` | — | API 응답 시 |

### 1.3 원자성 보장

```typescript
// 의사 코드
async toggleLike(documentId: string, userId: string): Promise<LikeToggleResponse> {
  const existing = await this.likeRepo.findOne({ documentId, userId });

  if (existing) {
    await this.likeRepo.delete(existing.id);
    const count = await this.redis.decr(`${this.tenantId}:community:like_count:${documentId}`);
    return { liked: false, likeCount: Math.max(0, count) };
  } else {
    await this.likeRepo.insert({ documentId, userId });
    const count = await this.redis.incr(`${this.tenantId}:community:like_count:${documentId}`);
    return { liked: true, likeCount: count };
  }
}
```

- DB 쓰기와 Redis 카운터 변경을 **동일 요청 내에서 순차 수행**한다
- DB 쓰기 실패 시 Redis 변경은 수행하지 않는다
- Redis 명령 실패 시 — DB 레코드가 원천이므로 다음 폴백에서 보정된다

### 1.4 캐시 미스 폴백

키가 존재하지 않으면 DB에서 카운트를 조회하여 Redis에 SET한다.

```typescript
async getLikeCount(documentId: string): Promise<number> {
  const cached = await this.redis.get(`${this.tenantId}:community:like_count:${documentId}`);
  if (cached !== null) return parseInt(cached, 10);

  const count = await this.likeRepo.count({ where: { documentId } });
  await this.redis.set(`${this.tenantId}:community:like_count:${documentId}`, count);
  return count;
}
```

### 1.5 무효화 트리거

| 트리거 | 행위 |
|--------|------|
| 문서 삭제 (CASCADE) | `DEL {tenant_id}:community:like_count:{documentId}` |
| 주기적 보정 (Cron) | DB COUNT와 Redis 값 비교, 차이 시 Redis 갱신 |

### 1.6 안전 규칙

- DECR 결과가 0 미만이면 0으로 보정한다 (`Math.max(0, count)`)
- INCR/DECR은 Redis 원자적 명령이므로 동시성 문제 없음
- DB가 원천(source of truth)이다 — Redis는 성능 캐시
- **Redis 명령 타임아웃**: `ioredis` 등 클라이언트의 연결·명령 타임아웃 기본값(환경에 따라 통상 수천 ms)을 따른다. CommunityModule은 필요 시 Redis 모듈 설정에서 명시적으로 재정의할 수 있다 — 장시간 블로킹 시 API 지연이 커지므로 운영에서 모니터링한다

---

## 2. 댓글 수 카운터

### 2.1 키 패턴

```
{tenant_id}:community:comment_count:{documentId}
```

- **타입**: STRING (Redis INCR/DECR 대상)
- **값**: 0 이상의 정수 (삭제되지 않은 댓글 수)
- **TTL**: 없음 (영구). 문서 삭제 시 키 제거

### 2.2 연산 흐름

| 동작 | Redis 명령 | DB 연산 | 시점 |
|------|-----------|---------|------|
| 댓글 작성 | `INCR {tenant_id}:community:comment_count:{documentId}` | INSERT INTO comment | 동시 |
| 댓글 삭제 | `DECR {tenant_id}:community:comment_count:{documentId}` | UPDATE comment SET deleted_at | 동시 |
| 조회 | `GET {tenant_id}:community:comment_count:{documentId}` | — | API 응답 시 |

### 2.3 캐시 미스 폴백

```typescript
async getCommentCount(documentId: string): Promise<number> {
  const cached = await this.redis.get(`${this.tenantId}:community:comment_count:${documentId}`);
  if (cached !== null) return parseInt(cached, 10);

  const count = await this.commentRepo.count({
    where: { documentId, deletedAt: IsNull() }
  });
  await this.redis.set(`${this.tenantId}:community:comment_count:${documentId}`, count);
  return count;
}
```

### 2.4 무효화 트리거

| 트리거 | 행위 |
|--------|------|
| 문서 삭제 (CASCADE) | `DEL {tenant_id}:community:comment_count:{documentId}` |
| 주기적 보정 (Cron) | DB COUNT와 Redis 값 비교, 차이 시 Redis 갱신 |

### 2.5 안전 규칙

- 좋아요 수 카운터와 동일: DECR 하한 0 보정, DB 원천
- Redis 명령 타임아웃: §1.6과 동일

---

## 3. DB 동기화 전략

### 3.1 주기적 보정 (Write-behind Reconciliation)

```typescript
// Cron: 매 5분 실행
@Cron('*/5 * * * *')
async reconcileCounters(): Promise<void> {
  const documentIds = await this.getActiveDocumentIds();

  for (const docId of documentIds) {
    const dbLikeCount = await this.likeRepo.count({ where: { documentId: docId } });
    const dbCommentCount = await this.commentRepo.count({
      where: { documentId: docId, deletedAt: IsNull() }
    });

    const redisLikeCount = await this.getLikeCount(docId);
    const redisCommentCount = await this.getCommentCount(docId);

    if (dbLikeCount !== redisLikeCount) {
      await this.redis.set(`${this.tenantId}:community:like_count:${docId}`, dbLikeCount);
      this.logger.warn(`좋아요 카운터 보정: doc=${docId}, redis=${redisLikeCount}, db=${dbLikeCount}`);
    }
    if (dbCommentCount !== redisCommentCount) {
      await this.redis.set(`${this.tenantId}:community:comment_count:${docId}`, dbCommentCount);
      this.logger.warn(`댓글 카운터 보정: doc=${docId}, redis=${redisCommentCount}, db=${dbCommentCount}`);
    }
  }
}
```

### 3.2 보정 대상 선정

- **활성 문서**: 최근 24시간 내 좋아요/댓글 활동이 있는 문서
- 전체 문서를 매번 보정하지 않으며, 활성 문서 위주로 처리하여 DB 부하를 최소화

### 3.3 Redis 장애 시 폴백

- Redis 연결 실패 시 DB 직접 조회로 폴백
- API 응답 지연은 발생하지만 데이터 정합성은 유지
- Redis 복구 후 첫 조회 시 캐시 미스 폴백으로 자연 복구

---

## 4. 모니터링

| 메트릭 | 설명 | 알림 임계값 |
|--------|------|-------------|
| `community.cache.hit_rate` | 카운터 캐시 히트율 | < 90% → 경고 |
| `community.cache.reconcile_diff` | 보정 시 Redis-DB 차이 건수 | > 10건/5분 → 경고 |
| `community.cache.redis_error_rate` | Redis 명령 실패율 | > 1% → 경고 |

---

## 5. 관련 문서

- [data.md](data.md) — Like, Comment 엔티티 (카운터 원천)
- [rules.md](rules.md) — BR-COM-013~015 (댓글 수 카운터), BR-COM-030~035 (좋아요)
- [events.md](events.md) — 카운터 변경 시 이벤트 발행
- [ADR-011 §B-6](../../adr/011-round3-module-design-decisions.md) — Redis INCR/DECR 결정 근거
