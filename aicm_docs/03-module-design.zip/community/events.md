# CommunityModule — 이벤트 스펙

> CommunityModule이 발행하는 이벤트 목록 및 소비 관계
> 기능정의서: [FD-COM-커뮤니티](../../01-requirements/features/FD-COM-커뮤니티.md)

---

## 0. 이벤트 채널

CommunityModule의 모든 이벤트는 **EventBus Best-effort** 계층으로 발행한다 (ADR-011 B-1).

- **전송 방식**: NestJS EventEmitter (in-process)
- **신뢰도**: Best-effort — 간헐적 유실 허용
- **적합 용도**: 알림, 캐시 무효화, 감사 로그, 집계 트리거
- **재시도**: 없음 (EventEmitter 특성). 실패 시 소비자 측에서 다음 주기에 보정

> FD-COM §7에서 BullMQ 큐를 정의하였으나, ADR-011 B-1에서 CommunityModule은 EventBus Best-effort로 결정하였다. 이유: 댓글/좋아요/신고/북마크는 즉시성이 중요하지만, 유실 시 사용자 경험에 치명적이지 않으며 DB 레코드가 원천이므로 보정 가능하다.

**이벤트명 네임스페이스 (ADR-011 E-4)**: 모든 발행 이벤트 채널명에 `community.` 접두사를 붙인다. 타 모듈 이벤트와의 충돌 방지 및 모듈 아키텍처 §3.3.1 `{module}.{entity}.{action}` 관례에 맞춘다. `report.reviewed`는 상태값 `resolved`와 정합하도록 `community.report.resolved`로 명명한다.

---

## 1. 발행 이벤트

### 1.1 이벤트 요약

| # | 이벤트명 | 트리거 | 주요 소비자 |
|---|----------|--------|-------------|
| 1 | `community.comment.created` | 댓글 작성 | NotificationModule, AggregationModule, AuditLogModule |
| 2 | `community.comment.updated` | 댓글 수정 | AuditLogModule |
| 3 | `community.comment.deleted` | 댓글 삭제 (소프트) | AggregationModule, AuditLogModule |
| 4 | `community.comment.resolved` | 댓글 해결 표시 | NotificationModule, AuditLogModule |
| 5 | `community.comment.reopened` | 댓글 해결 취소 | NotificationModule, AuditLogModule |
| 6 | `community.like.toggled` | 좋아요 토글 | AggregationModule, AuditLogModule |
| 7 | `community.report.created` | 신고 접수 | NotificationModule (관리자 알림), AuditLogModule |
| 8 | `community.report.resolved` | 신고 처리 완료 (`status = resolved`) | NotificationModule (신고자 알림), AuditLogModule |
| 9 | `community.report.auto_blinded` | 누적 자동 블라인드 | NotificationModule (관리자 알림), AuditLogModule |
| 10 | `community.bookmark.created` | 북마크 추가 | AuditLogModule |
| 11 | `community.bookmark.deleted` | 북마크 삭제 | AuditLogModule |

---

### 1.2 이벤트 페이로드

#### community.comment.created

```typescript
interface CommentCreatedEvent {
  eventId: string;             // UUID v4
  timestamp: string;           // ISO 8601
  commentId: string;
  documentId: string;
  parentCommentId: string | null;
  authorId: string;
  contentPreview: string;      // 앞 100자
  isReply: boolean;
}
```

**멱등성 키**: `community.comment.created:{commentId}`
**소비자 행위**:
- NotificationModule → 문서 작성자 + 부모 댓글 작성자에게 알림
- AggregationModule → 문서 댓글 수 집계 갱신
- AuditLogModule → 감사 로그 기록

---

#### community.comment.updated

```typescript
interface CommentUpdatedEvent {
  eventId: string;
  timestamp: string;
  commentId: string;
  documentId: string;
  authorId: string;
  updatedFields: string[];     // ['content']
}
```

**멱등성 키**: `community.comment.updated:{commentId}:{timestamp}`
**소비자 행위**:
- AuditLogModule → 감사 로그 기록

---

#### community.comment.deleted

```typescript
interface CommentDeletedEvent {
  eventId: string;
  timestamp: string;
  commentId: string;
  documentId: string;
  deletedBy: string;           // 삭제 수행자 (본인 또는 관리자)
  isAdminAction: boolean;
}
```

**멱등성 키**: `community.comment.deleted:{commentId}`
**소비자 행위**:
- AggregationModule → 문서 댓글 수 집계 갱신
- AuditLogModule → 감사 로그 기록

---

#### community.comment.resolved

```typescript
interface CommentResolvedEvent {
  eventId: string;
  timestamp: string;
  commentId: string;
  documentId: string;
  authorId: string;            // 댓글 작성자
  resolvedBy: string;          // 문서 작성자
}
```

**멱등성 키**: `community.comment.resolved:{commentId}`
**소비자 행위**:
- NotificationModule → 댓글 작성자에게 "댓글이 해결됨" 알림
- AuditLogModule → 감사 로그 기록

---

#### community.comment.reopened

```typescript
interface CommentReopenedEvent {
  eventId: string;
  timestamp: string;
  commentId: string;
  documentId: string;
  reopenedBy: string;          // 댓글 작성자
}
```

**멱등성 키**: `community.comment.reopened:{commentId}:{timestamp}`
**소비자 행위**:
- NotificationModule → 문서 작성자에게 "댓글이 재개됨" 알림
- AuditLogModule → 감사 로그 기록

---

#### community.like.toggled

```typescript
interface LikeToggledEvent {
  eventId: string;
  timestamp: string;
  documentId: string;
  userId: string;
  action: 'liked' | 'unliked';
  currentCount: number;        // 토글 후 Redis 카운터 값
}
```

**멱등성 키**: `community.like.toggled:{documentId}:{userId}:{timestamp}`
**소비자 행위**:
- AggregationModule → 좋아요 수 집계 갱신 (대시보드/피드 용)
- AuditLogModule → 감사 로그 기록

---

#### community.report.created

```typescript
interface ReportCreatedEvent {
  eventId: string;
  timestamp: string;
  reportId: string;
  targetType: 'document' | 'comment';
  targetId: string;
  reporterId: string;
  reasonType: string;
  pendingCount: number;        // 동일 대상의 pending/reviewing 신고 수
}
```

**멱등성 키**: `community.report.created:{reportId}`
**소비자 행위**:
- NotificationModule → 관리자에게 "새 신고 접수" 알림
- AuditLogModule → 감사 로그 기록

---

#### community.report.resolved

```typescript
interface ReportResolvedEvent {
  eventId: string;
  timestamp: string;
  reportId: string;
  targetType: 'document' | 'comment';
  targetId: string;
  reporterId: string;
  status: 'resolved';
  actionType: 'deleted' | 'dismissed' | 'warned';
  reviewedBy: string;
}
```

**멱등성 키**: `community.report.resolved:{reportId}`
**소비자 행위**:
- NotificationModule → 신고자에게 "신고 처리 완료" 알림
- AuditLogModule → 감사 로그 기록

---

#### community.report.auto_blinded

```typescript
interface ReportAutoBlindedEvent {
  eventId: string;
  timestamp: string;
  targetType: 'document' | 'comment';
  targetId: string;
  pendingCount: number;
  threshold: number;           // lm:community.report_auto_hide_threshold
}
```

**멱등성 키**: `community.report.auto_blinded:{targetType}:{targetId}`
**소비자 행위**:
- NotificationModule → 관리자에게 "자동 블라인드 발생" 긴급 알림
- AuditLogModule → 감사 로그 기록

---

#### community.bookmark.created

```typescript
interface BookmarkCreatedEvent {
  eventId: string;
  timestamp: string;
  bookmarkId: string;
  documentId: string;
  userId: string;
  folderId: string;
}
```

**멱등성 키**: `community.bookmark.created:{bookmarkId}`
**소비자 행위**:
- AuditLogModule → 감사 로그 기록

---

#### community.bookmark.deleted

```typescript
interface BookmarkDeletedEvent {
  eventId: string;
  timestamp: string;
  bookmarkId: string;
  documentId: string;
  userId: string;
}
```

**멱등성 키**: `community.bookmark.deleted:{bookmarkId}`
**소비자 행위**:
- AuditLogModule → 감사 로그 기록

---

## 2. 소비 이벤트

CommunityModule이 다른 모듈에서 발행한 이벤트를 구독하는 목록이다.

| 이벤트 | 발행 모듈 | CommunityModule 행위 |
|--------|-----------|---------------------|
| `document.version.created` | DocumentModule | 해당 문서를 북마크한 사용자들의 `last_seen_version` < 새 버전이 되므로 "업데이트 배지"가 자동 활성화됨. **별도 처리 불필요** — 조회 시 비교 로직으로 판단 (BR-COM-057) |
| `document.deleted` | DocumentModule | CASCADE DELETE로 Comment, Like, Bookmark 자동 정리. **별도 이벤트 처리 불필요** — DB FK CASCADE로 처리 |

> CommunityModule은 EventBus 이벤트를 능동적으로 소비하지 않는다. 문서 변경 감지는 조회 시 version 비교로, 문서 삭제는 DB CASCADE로 처리한다.

---

## 3. 외부 서비스 호출

CommunityModule은 외부 서비스(LLM, 파일 스토리지 등)를 직접 호출하지 않는다.

---

## 4. 관련 문서

- [data.md](data.md) — 엔티티 정의
- [rules.md](rules.md) — 이벤트 발행 트리거가 되는 비즈니스 규칙
- [cache.md](cache.md) — Redis 카운터 (이벤트 소비자가 갱신)
- [모듈 아키텍처](../../02-architecture/02-module-architecture.md) — EventBus Best-effort 계층 정의
- [비동기 이벤트 아키텍처](../../02-architecture/05-async-event-architecture.md) — 이벤트 버전·페이로드 규칙
- [ADR-011 §B-1·§E-4](../../adr/011-round3-module-design-decisions.md) — EventBus 선택 근거, 이벤트명 접두사
