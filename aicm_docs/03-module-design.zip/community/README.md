# CommunityModule

> 문서에 대한 소셜 인터랙션 — 댓글, 좋아요, 신고, 북마크
> 기능정의서: [FD-COM-커뮤니티](../../01-requirements/features/FD-COM-커뮤니티.md)

---

## 1. 모듈 책임

CommunityModule은 **문서(Document)에 대한 사용자 소셜 인터랙션**을 담당한다.

| 기능 | 설명 |
|------|------|
| 댓글 (Comment) | 문서에 대한 피드백, 질문, 1depth 답글. 해결/재개 상태 관리 포함 |
| 좋아요 (Like) | 문서 평가 (1인 1좋아요 토글) |
| 신고 (Report) | 문서/댓글 신고 접수, 관리자 검토/조치, 누적 자동 블라인드 |
| 북마크 (Bookmark) | 개인 문서 북마크, 폴더 분류, 업데이트 배지 |
| 읽음 확인 (NoticeReadConfirmation) | 공지 읽음 확인 기록·리마인더 추적. [FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md) §4 참조 |

### 스코프 외

- **자유게시판 게시글 CRUD는 BoardModule/DocumentModule 소관이다** (ADR-011 B-2). CommunityModule은 게시글 본문의 생성·수정·삭제·조회를 수행하지 않으며, 게시글에 대한 댓글·좋아요·신고·북마크 등 소셜 인터랙션만 처리한다.
- 댓글에 대한 좋아요는 지원하지 않는다.
- 내보내기(Export)는 ExportModule 소관이다.

---

## 2. 핵심 엔티티

| 엔티티 | 설명 | 상세 |
|--------|------|------|
| Comment | 문서 댓글 (1depth 답글, 소프트 딜리트, 해결 상태) | [data.md §2.1](data.md) |
| Like | 문서 좋아요 (INSERT/DELETE 토글) | [data.md §2.2](data.md) |
| Report | 문서/댓글 신고 (polymorphic, 3단계 상태) | [data.md §2.3](data.md) |
| BookmarkFolder | 북마크 폴더 (평탄 구조, 기본 "미분류") | [data.md §2.4](data.md) |
| Bookmark | 문서 북마크 (버전 기반 업데이트 배지) | [data.md §2.5](data.md) |
| NoticeReadConfirmation | 공지 읽음 확인 (confirmed_at nullable 패턴, 리마인더 추적) | [data.md §2.6](data.md) |

---

## 3. 의존 관계

### 3.1 의존하는 모듈 (Community →)

| 대상 모듈 | 의존 방식 | 용도 |
|-----------|-----------|------|
| DocumentModule | DI (읽기 전용) | 문서 존재 확인, 문서 작성자 조회, 문서 버전 조회 — 구현 시 호출 예: `DocumentService.findById()`, 문서 작성자·현재 버전 조회용 공개 읽기 메서드(실제 시그니처는 [document/api.md](../document/api.md) 및 Document 모듈 서비스 계약 따름) |
| SystemConfigModule | DI (읽기 전용) | `lm:community.*`, `comment_edit_window_minutes` 등 설정값 로드 |

### 3.2 의존받는 모듈 (→ Community)

| 요청 모듈 | 의존 방식 | 용도 |
|-----------|-----------|------|
| NotificationModule | EventBus 구독 | `community.*` 도메인 이벤트 — 댓글 작성/해결/재개, 신고 접수·처리 완료(`community.report.resolved`)·자동 블라인드 알림 |
| AggregationModule | EventBus 구독 | 좋아요/댓글 수 대시보드 집계 |
| AuditLogModule | EventBus 구독 | 모든 CUD 작업 감사 로그 |

### 3.3 의존 다이어그램

```mermaid
graph LR
  Community -->|DI read| Document
  Community -->|DI read| SystemConfig
  Community -.->|EventBus| Notification
  Community -.->|EventBus| Aggregation
  Community -.->|EventBus| AuditLog
```

---

## 4. 인프라 사용 요약

| 인프라 | 사용 | 상세 |
|--------|------|------|
| PostgreSQL | ● | Comment, Like, Report, BookmarkFolder, Bookmark 테이블 |
| Redis | ● | 좋아요 수/댓글 수 INCR/DECR 카운터 ([cache.md](cache.md)) |
| EventBus | ● 발행 | 11개 이벤트 Best-effort 발행 ([events.md](events.md)) |
| BullMQ | — | 사용하지 않음 (ADR-011 B-1) |
| S3/파일 | — | 사용하지 않음 |
| LLM | — | 사용하지 않음 |

---

## 5. 모니터링

기본 북마크 폴더("미분류", BR-COM-060)는 **배포 시 DB 시딩으로 일괄 생성하지 않는다.** 사용자가 최초로 북마크를 추가할 때 해당 사용자에 대해 런타임에 자동 생성된다.

### 5.1 주요 메트릭

| 메트릭 | 설명 |
|--------|------|
| `community.comment.created_total` | 댓글 생성 총 수 |
| `community.like.toggled_total` | 좋아요 토글 총 수 |
| `community.report.created_total` | 신고 접수 총 수 |
| `community.report.pending_count` | 미처리 신고 수 (게이지) |
| `community.report.auto_blinded_total` | 자동 블라인드 발생 수 |
| `community.bookmark.created_total` | 북마크 추가 총 수 |
| `community.cache.hit_rate` | Redis 카운터 캐시 히트율 |
| `community.cache.reconcile_diff` | 보정 시 Redis-DB 차이 건수 |

### 5.2 알림 임계값

| 조건 | 수준 | 대응 |
|------|------|------|
| `report.pending_count > 50` | Warning | 관리자 미처리 신고 누적 — 대시보드 확인 |
| `report.auto_blinded_total` 급증 | Critical | 스팸 공격 가능성 — 차단 정책 검토 |
| `cache.hit_rate < 90%` | Warning | Redis 키 누락 — 보정 Cron 확인 |
| `cache.reconcile_diff > 10/5min` | Warning | Redis-DB 불일치 빈발 — 동시성 이슈 점검 |
| `cache.redis_error_rate > 1%` | Warning | Redis 연결 문제 — 인프라 점검 |

### 5.3 로깅

| 수준 | 대상 |
|------|------|
| INFO | 댓글/좋아요/신고/북마크 CUD 작업 |
| WARN | Redis 카운터 보정 발생, 캐시 미스 폴백 |
| ERROR | Redis 연결 실패, DB 트랜잭션 실패 |

---

## 6. 운영 제한값 (SystemConfig)

CommunityModule 기능은 KMS 핵심 소셜 기능으로 기본 활성이다. 개별 기능의 **제한값**은 `lm:community.*` 키로 SystemConfig에서 관리한다 (테넌트·규제 요구에 맞게 조정).

| 키 | 설명 |
|----|------|
| `lm:community.comment_max_length` | 댓글 최대 길이 |
| `lm:community.report_auto_hide_threshold` | 신고 누적 시 자동 비공개 임계 |
| `lm:community.bookmark_max_count` | 사용자당 북마크 상한 |
| `lm:community.bookmark_folder_max_count` | 북마크 폴더 수 상한 |

> Community API는 제한값만 달라질 뿐 `503 Service Unavailable`로 기능 전체를 끄지 않는다.

---

## 7. 관련 문서

| 문서 | 설명 |
|------|------|
| [data.md](data.md) | RDB 엔티티 정의, DDL, 인덱스 |
| [api.md](api.md) | REST API 스펙 19개 엔드포인트 |
| [rules.md](rules.md) | 비즈니스 규칙 BR-COM-001~074 |
| [events.md](events.md) | EventBus 이벤트 11개 |
| [cache.md](cache.md) | Redis INCR/DECR 카운터 전략 |
| [FD-COM](../../01-requirements/features/FD-COM-커뮤니티.md) | 기능정의서 원천 |
| [ADR-011 §B·§E](../../adr/011-round3-module-design-decisions.md) | Community 설계 결정 (B-1~B-6, E-3·E-4) |
| [모듈 아키텍처](../../02-architecture/02-module-architecture.md) | 모듈 분류, 의존 규칙 |
