# CommunityModule — RDB 엔티티

> 댓글, 좋아요, 신고, 북마크, 읽음 확인 — 문서에 대한 사용자 상호작용
> 기능정의서: [FD-COM-커뮤니티](../../01-requirements/features/FD-COM-커뮤니티.md)

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    Comment ||--o{ Comment : "reply (1depth)"

    Document ||--o{ Comment : "1:N"
    Document ||--o{ Like : "1:N"
    Report
    Document ||--o{ Bookmark : "1:N"
    Document ||--o{ NoticeReadConfirmation : "1:N"

    BookmarkFolder ||--o{ Bookmark : "1:N"

    %% 외부 모듈 참조
    %% Document는 DocumentModule 소유 엔티티
    %% Report는 target_type + target_id로 Document 또는 Comment를 참조 (polymorphic, FK 없음)
```

---

## 2. 엔티티 필드

### 2.1 Comment

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 소속 문서 |
| parent_comment_id | UUID (FK → Comment, nullable) | 부모 댓글. null이면 최상위, not null이면 답글 |
| author_id | UUID | 작성자 |
| content | TEXT | 댓글 본문 |
| is_resolved | BOOLEAN (NOT NULL, DEFAULT false) | 해결 표시 여부 |
| resolved_by | UUID (nullable) | 해결 처리자 (문서 작성자) |
| resolved_at | TIMESTAMPTZ (nullable) | 해결 처리 시각 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |
| deleted_at | TIMESTAMPTZ (nullable) | 소프트 딜리트 |

#### 제약 조건

- `parent_comment_id`가 null이면 최상위 댓글, not null이면 답글 (대댓글)
- 대댓글은 **1depth만 지원** — parent의 parent_comment_id는 반드시 null이어야 한다 (앱 레벨 검증)
- `parent_comment_id`는 동일 `document_id`에 속한 댓글만 참조 가능 (앱 레벨 검증)
- `is_resolved = true`이면 `resolved_by`, `resolved_at`이 NOT NULL (앱 레벨 검증)
- `content` 최대 길이: `lm:community.comment_max_length`
- 댓글 좋아요 미지원 — 댓글은 순수 피드백/질문 용도로만 사용

#### 설계 결정

**1depth 대댓글만 지원**
— `parent_comment_id`가 null인 최상위 댓글에만 답글을 달 수 있다. 2depth 이상 중첩을 허용하면 UI 렌더링이 복잡해지고, 댓글 스레드 추적이 어려워진다. 앱 레벨에서 `parent.parent_comment_id IS NOT NULL`이면 요청을 거부한다. DB CHECK 제약으로 강제하지 않는 이유는 self-referencing FK에서 부모 행을 조회해야 하므로 단순 CHECK로 불가능하기 때문이다.

**소프트 딜리트**
— `deleted_at IS NOT NULL`인 댓글은 "삭제된 댓글입니다"로 표시하되, 답글이 존재하면 구조를 유지하기 위해 물리 삭제하지 않는다. 답글이 없는 삭제 댓글은 배치로 물리 삭제할 수 있다.

**댓글 해결 상태**
— 문서 작성자(지식 관리자)가 댓글의 지적 사항을 문서에 반영한 후 "해결됨" 표시를 한다. `is_resolved` boolean + `resolved_by` + `resolved_at`으로 추적하며, 댓글 작성자가 "재개" 버튼으로 미해결 상태로 되돌릴 수 있다 (BR-COM-020~022).

**필드명 FD 정렬**
— FD-COM §2.2의 필드명을 채택한다: `parent_comment_id` (역할이 명확), `author_id` (작성자 의미 명시). `parent_id`, `created_by`는 범용적이지만 Comment 컨텍스트에서 `parent_comment_id`가 "부모 댓글"임을 즉시 전달한다.

---

### 2.2 Like

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 좋아요 대상 문서 |
| user_id | UUID | 좋아요 누른 사용자 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(document_id, user_id)` — 1인 1좋아요

#### 설계 결정

**토글 방식**
— INSERT로 좋아요, DELETE로 취소한다. UPDATE가 아닌 INSERT/DELETE 패턴을 사용하여 상태 관리를 단순화한다.

**좋아요 수 집계**
— CommunityModule에서 Redis INCR/DECR 카운터를 직접 관리한다 (ADR-011 B-6). 좋아요 토글 API 응답에 즉시 갱신된 카운트를 반환하기 위해 동일 모듈 내 Redis 접근이 필수이다. AggregationModule은 대시보드/피드용 집계이지 실시간 카운터 용도가 아니다. 상세: [cache.md](cache.md)

---

### 2.3 Report

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| target_type | VARCHAR(20) | 신고 대상 유형: `document`, `comment` |
| target_id | UUID | 신고 대상 ID (Document 또는 Comment의 UUID) |
| reporter_id | UUID | 신고자 |
| reason_type | VARCHAR(30) | 신고 사유: `spam`, `inappropriate`, `copyright`, `privacy`, `other` |
| reason_detail | TEXT (nullable) | 상세 사유 (`reason_type = 'other'`일 때 필수) |
| status | VARCHAR(20) | 처리 상태: `pending`, `reviewing`, `resolved` (기본값 `pending`) |
| action_type | VARCHAR(20) (nullable) | 조치 유형: `deleted`, `dismissed`, `warned` (`resolved` 시 필수) |
| action_reason | TEXT (nullable) | 조치 사유 |
| reviewed_by | UUID (nullable) | 검토 관리자 |
| reviewed_at | TIMESTAMPTZ (nullable) | 검토 완료 시각 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `CHECK (target_type IN ('document', 'comment'))` — 허용된 신고 대상 유형만
- `CHECK (reason_type IN ('spam', 'inappropriate', 'copyright', 'privacy', 'other'))` — 5종
- `CHECK (status IN ('pending', 'reviewing', 'resolved'))`
- `CHECK (action_type IN ('deleted', 'dismissed', 'warned'))` — action_type은 nullable이므로 NULL 허용
- `UNIQUE(target_type, target_id, reporter_id)` — 동일 대상 중복 신고 방지 (BR-COM-042)
- `target_id`에 FK 제약 없음 — `target_type`에 따라 참조 테이블이 달라지므로 앱 레벨에서 존재 검증
- `status = 'resolved'`이면 `action_type`, `reviewed_by`, `reviewed_at`이 NOT NULL (앱 레벨 검증)
- `reason_type = 'other'`이면 `reason_detail`이 NOT NULL (앱 레벨 검증)

#### 설계 결정

**Polymorphic Reference (target_type + target_id)**
— 문서와 댓글 모두 신고 대상이다 (FD-COM §4). `target_type`으로 대상 종류를 구분하고 `target_id`로 대상을 식별한다. FK를 걸지 않는 이유는 단일 FK로 Document와 Comment 테이블을 동시에 참조할 수 없기 때문이다.

**신고 사유 5종 (FD-COM BR-COM-040)**
— `spam`, `inappropriate`, `copyright`, `privacy`, `other`. 금융권 KMS 컴플라이언스 요건으로 개인정보 노출(`privacy`) 사유가 필수이다.

**상태 전이: pending → reviewing → resolved (ADR-011 B-4)**
— `reviewing` 상태가 있어야 관리자 대시보드에서 "처리 중" 신고를 필터링할 수 있다. `dismissed`는 `action_type = 'dismissed'` + `status = 'resolved'`로 표현하여 상태 전이를 단순화하면서도 조치를 세분화한다. FD-COM §4.3 상태 전이 다이어그램 준수.

**중복 신고 방지**
— `UNIQUE(target_type, target_id, reporter_id)` 제약으로 같은 사용자가 같은 대상에 대해 중복 신고를 할 수 없다 (BR-COM-042).

**신고 누적 자동 블라인드**
— 동일 대상에 대한 `pending`/`reviewing` 상태 신고 수가 `lm:community.report_auto_hide_threshold`에 도달하면 대상 콘텐츠를 즉시 블라인드 처리한다. 개별 Report의 `status`는 변경되지 않으며, 관리자가 순차 검토한다.

---

### 2.4 BookmarkFolder

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID | 폴더 소유자 |
| name | VARCHAR(100) | 폴더명 |
| sort_order | INT (NOT NULL, DEFAULT 0) | 표시 순서 (드래그 앤 드롭 정렬) |
| is_default | BOOLEAN (NOT NULL, DEFAULT false) | 기본 "미분류" 폴더 여부. 삭제 불가 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- 사용자당 `is_default = true`인 폴더는 정확히 1개 (앱 레벨 검증)
- `is_default = true`인 폴더는 삭제 불가 (앱 레벨 검증, BR-COM-052)
- 사용자당 폴더 수 ≤ `lm:community.bookmark_folder_max_count` (앱 레벨 검증, BR-COM-055)

#### 설계 결정

**평탄 폴더 구조 — parent_id 제거 (ADR-011 B-5)**
— FD-COM §5.2 BookmarkFolder에 `parent_id` 필드가 없고, BR-COM-050~060에 하위 폴더 요구사항이 없다. YAGNI 원칙에 따라 `parent_id`와 `sort_order`를 제거하지 않되, `parent_id`만 제거한다. `sort_order`는 폴더 순서 정렬(BR-COM-056)에 필요하므로 유지한다. 향후 계층 폴더가 필요하면 non-breaking migration으로 `parent_id`를 추가할 수 있다.

**폴더명 길이 VARCHAR(100)**
— FD-COM §5.2에서 VARCHAR(100)으로 정의. 폴더명은 사이드바 UI에 표시되므로 100자가 충분하다.

**기본 "미분류" 폴더**
— 사용자 최초 북마크 시 기본 폴더("미분류")를 자동 생성한다. `is_default = true`로 설정되며, 이름 변경은 가능하지만 삭제는 불가하다. 폴더 지정 없이 북마크하면 기본 폴더에 저장된다.

---

### 2.5 Bookmark

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID | 북마크한 사용자 |
| document_id | UUID (FK → Document) | 북마크 대상 문서 |
| folder_id | UUID (FK → BookmarkFolder) | 소속 폴더 |
| last_seen_version | INTEGER (NOT NULL, DEFAULT 0) | 마지막 확인 문서 버전 번호. 0이면 북마크 후 한 번도 열람하지 않음 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(user_id, document_id, folder_id)` — 동일 문서를 같은 폴더에 중복 저장 방지
- 동일 문서를 다른 폴더에는 저장 가능 (복제, BR-COM-051)
- 사용자당 총 북마크 수 ≤ `lm:community.bookmark_max_count` (앱 레벨 검증, BR-COM-054)

#### 설계 결정

**좋아요와 북마크의 역할 분리**
— 좋아요(Like)는 문서 평가(공개적), 북마크(Bookmark)는 개인 빠른 접근(비공개)이다. 사용 목적이 다르므로 별도 엔티티로 분리한다.

**last_seen_version INTEGER — 버전 기반 업데이트 배지 (ADR-011 B-3)**
— `last_seen_version`과 `Document.version`을 비교하여 "업데이트됨" 배지를 판단한다 (BR-COM-057). Document.version은 모든 수정 시 자동 증가하므로 비관리 게시판에서도 동작한다. 버전 번호 비교가 타임스탬프보다 정확하고 결정적(deterministic)이다. 사용자가 북마크된 문서를 열람할 때 `last_seen_version = Document.version`으로 갱신한다.

**UNIQUE(user_id, document_id, folder_id) — 폴더 간 복제 허용**
— BR-COM-051에서 "폴더 간 북마크 이동/복제 가능"으로 명시. `UNIQUE(user_id, document_id)` 제약은 같은 문서를 다른 폴더에 복제하는 것을 차단하므로, folder_id를 UNIQUE 조합에 포함하여 복제를 허용한다.

---

### 2.6 NoticeReadConfirmation

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 대상 공지 문서 |
| user_id | UUID | 확인한 사용자 (외부 UserService, FK 없음) |
| confirmed_at | TIMESTAMPTZ (nullable) | 확인 시각. null이면 미확인 |
| confirmation_deadline | TIMESTAMPTZ (nullable) | 확인 기한. null이면 기한 없음 |
| reminder_sent_count | INT (default 0) | 리마인더 발송 횟수 |
| last_reminder_at | TIMESTAMPTZ (nullable) | 마지막 리마인더 발송 시각 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(document_id, user_id)` — 동일 문서에 같은 사용자 중복 확인 방지

#### 설계 결정

**CommunityModule 소속**
— 읽음 확인은 문서의 속성이 아니라 "문서에 대한 사용자 액션"이다. Comment, Like, Bookmark과 동일한 패턴(Document FK + user_id)을 따르므로 CommunityModule에 배치한다. [FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md) §4 참조.

**confirmed_at nullable 패턴**
— 공지 게시 시 대상 사용자에게 `confirmed_at = NULL` 레코드를 일괄 생성하고, 사용자가 "확인" 버튼을 클릭하면 `confirmed_at = now()`로 갱신한다. 별도 status 필드 없이 `confirmed_at IS NOT NULL`로 확인 완료를 판정.

**updated_at 없음**
— Like, Bookmark과 동일하게 `confirmed_at` 갱신만 존재하므로 별도 updated_at 불필요.

---

## 3. DDL 및 인덱스

### 3.1 Comment

```sql
CREATE TABLE comment (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id        UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  parent_comment_id  UUID REFERENCES comment(id) ON DELETE CASCADE,
  author_id          UUID NOT NULL,
  content            TEXT NOT NULL,
  is_resolved        BOOLEAN NOT NULL DEFAULT false,
  resolved_by        UUID,
  resolved_at        TIMESTAMPTZ,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at         TIMESTAMPTZ
);

CREATE INDEX idx_comment_document_created
  ON comment (document_id, created_at);

CREATE INDEX idx_comment_parent
  ON comment (parent_comment_id)
  WHERE parent_comment_id IS NOT NULL;

CREATE INDEX idx_comment_deleted_at
  ON comment (deleted_at)
  WHERE deleted_at IS NOT NULL;

CREATE INDEX idx_comment_unresolved
  ON comment (document_id, is_resolved)
  WHERE is_resolved = false AND deleted_at IS NULL;
```

### 3.2 Like

```sql
CREATE TABLE "like" (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id  UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  user_id      UUID NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_like_document_user UNIQUE (document_id, user_id)
);

CREATE INDEX idx_like_user
  ON "like" (user_id);
```

### 3.3 Report

```sql
CREATE TABLE report (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  target_type   VARCHAR(20) NOT NULL,
  target_id     UUID NOT NULL,
  reporter_id   UUID NOT NULL,
  reason_type   VARCHAR(30) NOT NULL,
  reason_detail TEXT,
  status        VARCHAR(20) NOT NULL DEFAULT 'pending',
  action_type   VARCHAR(20),
  action_reason TEXT,
  reviewed_by   UUID,
  reviewed_at   TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_report_target_type
    CHECK (target_type IN ('document', 'comment')),
  CONSTRAINT chk_report_reason_type
    CHECK (reason_type IN ('spam', 'inappropriate', 'copyright', 'privacy', 'other')),
  CONSTRAINT chk_report_status
    CHECK (status IN ('pending', 'reviewing', 'resolved')),
  CONSTRAINT chk_report_action_type
    CHECK (action_type IN ('deleted', 'dismissed', 'warned')),
  CONSTRAINT uq_report_target_reporter
    UNIQUE (target_type, target_id, reporter_id)
);

CREATE INDEX idx_report_pending
  ON report (status)
  WHERE status IN ('pending', 'reviewing');

CREATE INDEX idx_report_target
  ON report (target_type, target_id);
```

### 3.4 BookmarkFolder

```sql
CREATE TABLE bookmark_folder (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL,
  name        VARCHAR(100) NOT NULL,
  sort_order  INT NOT NULL DEFAULT 0,
  is_default  BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_bookmark_folder_user_sort
  ON bookmark_folder (user_id, sort_order);
```

### 3.5 Bookmark

```sql
CREATE TABLE bookmark (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id           UUID NOT NULL,
  document_id       UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  folder_id         UUID NOT NULL REFERENCES bookmark_folder(id) ON DELETE CASCADE,
  last_seen_version INTEGER NOT NULL DEFAULT 0,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_bookmark_user_document_folder UNIQUE (user_id, document_id, folder_id)
);

CREATE INDEX idx_bookmark_folder
  ON bookmark (folder_id);

CREATE INDEX idx_bookmark_user
  ON bookmark (user_id);
```

### 3.6 NoticeReadConfirmation

```sql
CREATE TABLE notice_read_confirmation (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id           UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  user_id               UUID NOT NULL,
  confirmed_at          TIMESTAMPTZ,
  confirmation_deadline TIMESTAMPTZ,
  reminder_sent_count   INT NOT NULL DEFAULT 0,
  last_reminder_at      TIMESTAMPTZ,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_notice_read_confirmation UNIQUE (document_id, user_id)
);

CREATE INDEX idx_notice_read_doc
  ON notice_read_confirmation (document_id);

CREATE INDEX idx_notice_read_user
  ON notice_read_confirmation (user_id, confirmed_at DESC);

CREATE INDEX idx_notice_read_unconfirmed
  ON notice_read_confirmation (document_id, confirmation_deadline)
  WHERE confirmed_at IS NULL;
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [document.md](../document/data.md) — Document (Comment, Like, Report, Bookmark가 참조)
- [notification.md](../notification/data.md) — NotificationModule (댓글 작성 시 알림 이벤트)
- [aggregation.md](../aggregation/data.md) — AggregationModule (좋아요 수 캐시 집계)
- [system-config.md](../system-config/data.md) — SystemConfig (신고 임계값 설정)
- [ADR-011](../../adr/011-round3-module-design-decisions.md) — §B Community 모듈 설계 결정 6건
