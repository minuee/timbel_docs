# CommunityModule — API 스펙

> 문서에 대한 소셜 인터랙션(댓글, 좋아요, 신고, 북마크) API
> 기능정의서: [FD-COM-커뮤니티](../../01-requirements/features/FD-COM-커뮤니티.md)

---

## 0. 스코프

CommunityModule은 **소셜 인터랙션(댓글, 좋아요, 신고, 북마크)만** 담당한다.
자유게시판 게시글 CRUD는 **BoardModule/DocumentModule** 소관이다 (ADR-011 B-2).

---

## 1. 엔드포인트 요약

| # | 메서드 | 경로 | 설명 | 권한 |
|---|--------|------|------|------|
| **댓글** | | | | |
| 1 | POST | `/api/documents/:documentId/comments` | 댓글 작성 | 문서 읽기 이상 |
| 2 | GET | `/api/documents/:documentId/comments` | 댓글 목록 조회 | 문서 읽기 이상 |
| 3 | PATCH | `/api/comments/:commentId` | 댓글 수정 | 본인만 |
| 4 | DELETE | `/api/comments/:commentId` | 댓글 삭제 | 본인 또는 관리자 |
| 5 | POST | `/api/comments/:commentId/resolve` | 댓글 해결 표시 | 문서 작성자 |
| 6 | POST | `/api/comments/:commentId/reopen` | 댓글 해결 취소 | 댓글 작성자 |
| **좋아요** | | | | |
| 7 | POST | `/api/documents/:documentId/likes/toggle` | 좋아요 토글 | 문서 읽기 이상 |
| 8 | GET | `/api/documents/:documentId/likes/status` | 좋아요 상태 조회 | 문서 읽기 이상 |
| **신고** | | | | |
| 9 | POST | `/api/reports` | 신고 접수 | 인증 사용자 |
| 10 | GET | `/api/admin/reports` | 신고 목록 조회 (관리자) | 관리자 |
| 11 | PATCH | `/api/admin/reports/:reportId` | 신고 처리 (관리자) | 관리자 |
| **북마크** | | | | |
| 12 | POST | `/api/bookmarks` | 북마크 추가 | 인증 사용자 |
| 13 | DELETE | `/api/bookmarks/:bookmarkId` | 북마크 삭제 | 본인만 |
| 14 | PATCH | `/api/bookmarks/:bookmarkId/move` | 북마크 폴더 이동 | 본인만 |
| 15 | GET | `/api/bookmarks` | 북마크 목록 조회 | 본인만 |
| **북마크 폴더** | | | | |
| 16 | POST | `/api/bookmark-folders` | 폴더 생성 | 인증 사용자 |
| 17 | PATCH | `/api/bookmark-folders/:folderId` | 폴더 수정 | 본인만 |
| 18 | DELETE | `/api/bookmark-folders/:folderId` | 폴더 삭제 | 본인만 |
| 19 | GET | `/api/bookmark-folders` | 폴더 목록 조회 | 본인만 |

---

## 2. 상세 API

### 2.1 댓글 작성

```
POST /api/documents/:documentId/comments
```

**요청 DTO**

```typescript
interface CreateCommentRequest {
  content: string;              // 1~lm:community.comment_max_length 글자
  parentCommentId?: string;     // 답글 시 부모 댓글 UUID
}
```

**응답 DTO (201 Created)**

```typescript
interface CommentResponse {
  id: string;
  documentId: string;
  parentCommentId: string | null;
  authorId: string;
  authorName: string;
  content: string;
  isResolved: boolean;
  resolvedBy: string | null;
  resolvedAt: string | null;
  createdAt: string;
  updatedAt: string;
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_COMMENT_NOT_FOUND | 404 | parentCommentId에 해당하는 댓글이 없음 |
| COM_COMMENT_DEPTH_EXCEEDED | 400 | 대댓글에 답글 시도 (1depth 초과) |
| COM_COMMENT_CONTENT_TOO_LONG | 400 | content가 최대 길이 초과 |
| COM_DOCUMENT_NOT_FOUND | 404 | 문서를 찾을 수 없음 |

**관련 규칙**: BR-COM-001~005

---

### 2.2 댓글 목록 조회

```
GET /api/documents/:documentId/comments
```

**쿼리 파라미터**

| 파라미터 | 타입 | 기본값 | 설명 |
|----------|------|--------|------|
| cursor | string | - | 페이지네이션 커서 (마지막 댓글 ID) |
| limit | number | 20 | 페이지 크기 (최대 50) |
| resolved | boolean | - | 해결/미해결 필터 (생략 시 전체) |

**응답 DTO (200 OK)**

```typescript
interface CommentListResponse {
  items: CommentWithRepliesResponse[];
  nextCursor: string | null;
  totalCount: number;
}

interface CommentWithRepliesResponse extends CommentResponse {
  replies: CommentResponse[];   // 답글 목록 (created_at ASC)
  replyCount: number;
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_DOCUMENT_NOT_FOUND | 404 | 문서를 찾을 수 없음 |

**관련 규칙**: BR-COM-010~012

---

### 2.3 댓글 수정

```
PATCH /api/comments/:commentId
```

**요청 DTO**

```typescript
interface UpdateCommentRequest {
  content: string;              // 1~lm:community.comment_max_length 글자
}
```

**응답 DTO (200 OK)**

```typescript
// CommentResponse (2.1과 동일)
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_COMMENT_NOT_FOUND | 404 | 댓글을 찾을 수 없음 |
| COM_COMMENT_NOT_OWNER | 403 | 본인 댓글이 아님 |
| COM_COMMENT_DELETED | 400 | 삭제된 댓글 수정 시도 |
| COM_COMMENT_EDIT_EXPIRED | 403 | 댓글 작성 후 허용 시간(`comment_edit_window_minutes`, 기본 30분) 초과 — 수정 불가 (ADR-011 E-3, BR-COM-017) |
| COM_COMMENT_CONTENT_TOO_LONG | 400 | content가 최대 길이 초과 |

**관련 규칙**: BR-COM-006~007, BR-COM-017

---

### 2.4 댓글 삭제

```
DELETE /api/comments/:commentId
```

**응답 (200 OK)**

```typescript
interface DeleteCommentResponse {
  id: string;
  deletedAt: string;
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_COMMENT_NOT_FOUND | 404 | 댓글을 찾을 수 없음 |
| COM_COMMENT_NOT_OWNER | 403 | 본인 댓글이 아니고 관리자도 아님 |

**관련 규칙**: BR-COM-008~009

---

### 2.5 댓글 해결 표시

```
POST /api/comments/:commentId/resolve
```

**요청**: 본문 없음

**응답 DTO (200 OK)**

```typescript
// CommentResponse (2.1과 동일, isResolved=true, resolvedBy/resolvedAt 포함)
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_COMMENT_NOT_FOUND | 404 | 댓글을 찾을 수 없음 |
| COM_COMMENT_ALREADY_RESOLVED | 400 | 이미 해결 표시된 댓글 |
| COM_COMMENT_RESOLVE_FORBIDDEN | 403 | 문서 작성자가 아님 |

**관련 규칙**: BR-COM-020~021

---

### 2.6 댓글 해결 취소

```
POST /api/comments/:commentId/reopen
```

**요청**: 본문 없음

**응답 DTO (200 OK)**

```typescript
// CommentResponse (2.1과 동일, isResolved=false)
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_COMMENT_NOT_FOUND | 404 | 댓글을 찾을 수 없음 |
| COM_COMMENT_NOT_RESOLVED | 400 | 해결 상태가 아닌 댓글 |
| COM_COMMENT_REOPEN_FORBIDDEN | 403 | 댓글 작성자가 아님 |

**관련 규칙**: BR-COM-022

---

### 2.7 좋아요 토글

```
POST /api/documents/:documentId/likes/toggle
```

**요청**: 본문 없음

**응답 DTO (200 OK)**

```typescript
interface LikeToggleResponse {
  liked: boolean;              // true=좋아요 추가, false=좋아요 취소
  likeCount: number;           // 갱신된 좋아요 수 (Redis 카운터)
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_DOCUMENT_NOT_FOUND | 404 | 문서를 찾을 수 없음 |

**관련 규칙**: BR-COM-030~033

---

### 2.8 좋아요 상태 조회

```
GET /api/documents/:documentId/likes/status
```

**응답 DTO (200 OK)**

```typescript
interface LikeStatusResponse {
  liked: boolean;              // 현재 사용자의 좋아요 여부
  likeCount: number;           // 총 좋아요 수 (Redis 카운터)
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_DOCUMENT_NOT_FOUND | 404 | 문서를 찾을 수 없음 |

**관련 규칙**: BR-COM-034

---

### 2.9 신고 접수

```
POST /api/reports
```

**요청 DTO**

```typescript
interface CreateReportRequest {
  targetType: 'document' | 'comment';
  targetId: string;
  reasonType: 'spam' | 'inappropriate' | 'copyright' | 'privacy' | 'other';
  reasonDetail?: string;       // reasonType='other' 시 필수
}
```

**응답 DTO (201 Created)**

```typescript
interface ReportResponse {
  id: string;
  targetType: string;
  targetId: string;
  reasonType: string;
  reasonDetail: string | null;
  status: string;
  createdAt: string;
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_REPORT_DUPLICATE | 409 | 동일 대상 중복 신고 |
| COM_REPORT_SELF | 400 | 본인 콘텐츠 신고 불가 |
| COM_REPORT_DETAIL_REQUIRED | 400 | reasonType=other인데 reasonDetail 누락 |
| COM_REPORT_TARGET_NOT_FOUND | 404 | 신고 대상을 찾을 수 없음 |

**관련 규칙**: BR-COM-040~044

---

### 2.10 신고 목록 조회 (관리자)

```
GET /api/admin/reports
```

**쿼리 파라미터**

| 파라미터 | 타입 | 기본값 | 설명 |
|----------|------|--------|------|
| cursor | string | - | 페이지네이션 커서 |
| limit | number | 20 | 페이지 크기 (최대 50) |
| status | string | - | 상태 필터: `pending`, `reviewing`, `resolved` |
| targetType | string | - | 대상 유형 필터: `document`, `comment` |

**응답 DTO (200 OK)**

```typescript
interface ReportListResponse {
  items: ReportAdminResponse[];
  nextCursor: string | null;
  totalCount: number;
}

interface ReportAdminResponse extends ReportResponse {
  reporterName: string;
  actionType: string | null;
  actionReason: string | null;
  reviewedBy: string | null;
  reviewedAt: string | null;
}
```

**에러**: 관리자 권한 미달 시 `403 Forbidden`

**관련 규칙**: BR-COM-045

---

### 2.11 신고 처리 (관리자)

```
PATCH /api/admin/reports/:reportId
```

**요청 DTO**

```typescript
interface ProcessReportRequest {
  status: 'reviewing' | 'resolved';
  actionType?: 'deleted' | 'dismissed' | 'warned';  // status=resolved 시 필수
  actionReason?: string;
}
```

**응답 DTO (200 OK)**

```typescript
// ReportAdminResponse (2.10과 동일)
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_REPORT_NOT_FOUND | 404 | 신고를 찾을 수 없음 |
| COM_REPORT_ALREADY_RESOLVED | 400 | 이미 처리 완료된 신고 |
| COM_REPORT_ACTION_REQUIRED | 400 | status=resolved인데 actionType 누락 |

**관련 규칙**: BR-COM-046~048

---

### 2.12 북마크 추가

```
POST /api/bookmarks
```

**요청 DTO**

```typescript
interface CreateBookmarkRequest {
  documentId: string;
  folderId?: string;           // 미지정 시 기본 "미분류" 폴더
}
```

**응답 DTO (201 Created)**

```typescript
interface BookmarkResponse {
  id: string;
  documentId: string;
  folderId: string;
  folderName: string;
  lastSeenVersion: number;
  createdAt: string;
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_BOOKMARK_DUPLICATE | 409 | 동일 폴더에 이미 북마크됨 |
| COM_BOOKMARK_LIMIT | 400 | 북마크 수 상한 초과 |
| COM_DOCUMENT_NOT_FOUND | 404 | 문서를 찾을 수 없음 |
| COM_FOLDER_NOT_FOUND | 404 | 폴더를 찾을 수 없음 |

**관련 규칙**: BR-COM-050~055

---

### 2.13 북마크 삭제

```
DELETE /api/bookmarks/:bookmarkId
```

**응답 (204 No Content)**

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_BOOKMARK_NOT_FOUND | 404 | 북마크를 찾을 수 없음 |

**관련 규칙**: BR-COM-053

---

### 2.14 북마크 폴더 이동

```
PATCH /api/bookmarks/:bookmarkId/move
```

**요청 DTO**

```typescript
interface MoveBookmarkRequest {
  targetFolderId: string;
}
```

**응답 DTO (200 OK)**

```typescript
// BookmarkResponse (2.12와 동일)
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_BOOKMARK_NOT_FOUND | 404 | 북마크를 찾을 수 없음 |
| COM_BOOKMARK_DUPLICATE | 409 | 대상 폴더에 이미 동일 문서 북마크 존재 |
| COM_FOLDER_NOT_FOUND | 404 | 대상 폴더를 찾을 수 없음 |

**관련 규칙**: BR-COM-051

---

### 2.15 북마크 목록 조회

```
GET /api/bookmarks
```

**쿼리 파라미터**

| 파라미터 | 타입 | 기본값 | 설명 |
|----------|------|--------|------|
| folderId | string | - | 특정 폴더 필터 (미지정 시 전체) |
| cursor | string | - | 페이지네이션 커서 |
| limit | number | 20 | 페이지 크기 (최대 50) |
| hasUpdate | boolean | - | 업데이트 배지 필터 |

**응답 DTO (200 OK)**

```typescript
interface BookmarkListResponse {
  items: BookmarkDetailResponse[];
  nextCursor: string | null;
  totalCount: number;
}

interface BookmarkDetailResponse extends BookmarkResponse {
  documentTitle: string;
  documentVersion: number;
  hasUpdate: boolean;          // documentVersion > lastSeenVersion
}
```

**관련 규칙**: BR-COM-057

---

### 2.16 폴더 생성

```
POST /api/bookmark-folders
```

**요청 DTO**

```typescript
interface CreateBookmarkFolderRequest {
  name: string;                // 1~100자
}
```

**응답 DTO (201 Created)**

```typescript
interface BookmarkFolderResponse {
  id: string;
  name: string;
  sortOrder: number;
  isDefault: boolean;
  bookmarkCount: number;
  createdAt: string;
  updatedAt: string;
}
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_FOLDER_LIMIT | 400 | 폴더 수 상한 초과 |
| COM_FOLDER_NAME_DUPLICATE | 409 | 동일 이름 폴더 존재 |

**관련 규칙**: BR-COM-055~056

---

### 2.17 폴더 수정

```
PATCH /api/bookmark-folders/:folderId
```

**요청 DTO**

```typescript
interface UpdateBookmarkFolderRequest {
  name?: string;               // 1~100자
  sortOrder?: number;
}
```

**응답 DTO (200 OK)**

```typescript
// BookmarkFolderResponse (2.16과 동일)
```

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_FOLDER_NOT_FOUND | 404 | 폴더를 찾을 수 없음 |
| COM_FOLDER_NAME_DUPLICATE | 409 | 동일 이름 폴더 존재 |

**관련 규칙**: BR-COM-056

---

### 2.18 폴더 삭제

```
DELETE /api/bookmark-folders/:folderId
```

**응답 (204 No Content)**

폴더 삭제 시 소속 북마크는 기본 "미분류" 폴더로 이동한다 (BR-COM-058).

**에러**

| 코드 | 상태 | 설명 |
|------|------|------|
| COM_FOLDER_NOT_FOUND | 404 | 폴더를 찾을 수 없음 |
| COM_FOLDER_DEFAULT_DELETE | 400 | 기본 "미분류" 폴더 삭제 시도 |

**관련 규칙**: BR-COM-052, BR-COM-058

---

### 2.19 폴더 목록 조회

```
GET /api/bookmark-folders
```

**응답 DTO (200 OK)**

```typescript
interface BookmarkFolderListResponse {
  items: BookmarkFolderResponse[];
}
```

폴더 목록은 `sortOrder` ASC로 정렬하며, 기본 "미분류" 폴더가 항상 첫 번째이다.

**관련 규칙**: BR-COM-056

---

## 3. 에러 코드 카탈로그

| 코드 | HTTP | 설명 |
|------|------|------|
| COM_DOCUMENT_NOT_FOUND | 404 | 대상 문서를 찾을 수 없음 |
| COM_COMMENT_NOT_FOUND | 404 | 댓글을 찾을 수 없음 |
| COM_COMMENT_NOT_OWNER | 403 | 댓글 소유자가 아님 |
| COM_COMMENT_DELETED | 400 | 삭제된 댓글에 대한 작업 |
| COM_COMMENT_DEPTH_EXCEEDED | 400 | 대댓글 깊이 제한 초과 |
| COM_COMMENT_CONTENT_TOO_LONG | 400 | 댓글 내용 길이 제한 초과 |
| COM_COMMENT_EDIT_EXPIRED | 403 | 댓글 수정 허용 시간 초과 (BR-COM-017) |
| COM_COMMENT_ALREADY_RESOLVED | 400 | 이미 해결된 댓글 |
| COM_COMMENT_NOT_RESOLVED | 400 | 미해결 상태 댓글에 reopen 시도 |
| COM_COMMENT_RESOLVE_FORBIDDEN | 403 | 해결 권한 없음 (문서 작성자만) |
| COM_COMMENT_REOPEN_FORBIDDEN | 403 | 재개 권한 없음 (댓글 작성자만) |
| COM_REPORT_DUPLICATE | 409 | 동일 대상 중복 신고 |
| COM_REPORT_SELF | 400 | 본인 콘텐츠 신고 |
| COM_REPORT_DETAIL_REQUIRED | 400 | 기타 사유 상세 누락 |
| COM_REPORT_TARGET_NOT_FOUND | 404 | 신고 대상을 찾을 수 없음 |
| COM_REPORT_NOT_FOUND | 404 | 신고를 찾을 수 없음 |
| COM_REPORT_ALREADY_RESOLVED | 400 | 이미 처리된 신고 |
| COM_REPORT_ACTION_REQUIRED | 400 | 처리 완료 시 조치 유형 누락 |
| COM_BOOKMARK_DUPLICATE | 409 | 동일 폴더 내 중복 북마크 |
| COM_BOOKMARK_LIMIT | 400 | 북마크 수 상한 초과 |
| COM_BOOKMARK_NOT_FOUND | 404 | 북마크를 찾을 수 없음 |
| COM_FOLDER_NOT_FOUND | 404 | 폴더를 찾을 수 없음 |
| COM_FOLDER_LIMIT | 400 | 폴더 수 상한 초과 |
| COM_FOLDER_NAME_DUPLICATE | 409 | 동일 이름 폴더 존재 |
| COM_FOLDER_DEFAULT_DELETE | 400 | 기본 폴더 삭제 시도 |

---

## 4. 관련 문서

- [data.md](data.md) — Comment, Like, Report, Bookmark, BookmarkFolder 엔티티
- [rules.md](rules.md) — BR-COM-001~074 비즈니스 규칙
- [events.md](events.md) — 이벤트 발행 목록
- [cache.md](cache.md) — Redis 카운터 (좋아요/댓글 수)
- [FD-COM §부록A](../../01-requirements/features/FD-COM-커뮤니티.md) — API 원천 정의
