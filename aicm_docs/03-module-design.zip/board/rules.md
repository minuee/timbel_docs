# Board 비즈니스 규칙

> 기능정의서: [FD-DOC-문서관리 §7](../../01-requirements/features/FD-DOC-문서관리.md)
> API 스펙: [api.md](api.md)

> **API 경로 표기**: 글로벌 `/api` prefix는 배포 환경에서 리버스 프록시로 부여되며, 모듈 스펙에서는 prefix 없이 기술한다.

---

## 1. 상태 전이

Board 엔티티는 라이프사이클 status를 갖지 않는다. `is_active`(활성 여부)와 `deleted_at`(소프트 삭제) 플래그로 운영 상태를 관리한다.

```mermaid
stateDiagram-v2
    [*] --> active: 게시판 생성 [BR-BRD-001]

    active --> inactive: 비활성화 [BR-BRD-013]
    inactive --> active: 활성화 [BR-BRD-013]

    active --> soft_deleted: 소프트 삭제 [BR-BRD-004]
    inactive --> soft_deleted: 소프트 삭제 [BR-BRD-004]
    soft_deleted --> active: 복구 (삭제 전 active) [BR-BRD-012]
    soft_deleted --> inactive: 복구 (삭제 전 inactive) [BR-BRD-012]

    note right of soft_deleted
        하위 게시판 존재 시
        재귀적 소프트 삭제 [BR-BRD-010]
    end note
```

---

## 2. 규칙 카탈로그

### 게시판 생성

#### BR-BRD-001: 게시판 생성

- **트리거**: `POST /boards`
- **조건**: 요청자가 `manage_boards` 어드민 권한 보유. `slug`가 기존 게시판과 중복되지 않음 [BR-BRD-009]. `parentId` 지정 시 해당 게시판이 존재하고 삭제되지 않음
- **동작**:
  1. Board 레코드 생성 (`is_active = true`, `deleted_at = null`)
  2. `board_type`에 따른 초기 설정 시드 적용 [BR-BRD-005]
  3. `parentId`가 지정되면 해당 게시판의 자식으로 배치
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_boards 권한 없음 |
  | BRD_PARENT_NOT_FOUND | 404 | 상위 게시판 미존재 또는 삭제됨 |
  | BRD_SLUG_DUPLICATE | 409 | 이미 사용 중인 slug |
- **근거**: FD-DOC §7 — 게시판 트리 CRUD는 관리자 권한

---

### 게시판 트리

#### BR-BRD-002: 순환 참조 방지

- **트리거**: 게시판 생성 시 `parentId` 지정, 또는 `PATCH /boards/:id/move`
- **조건**: 새 `parent_id`가 자기 자신이 아니며, 자신의 하위 트리에 속하는 게시판도 아님
- **동작**: `parent_id` 설정/변경 허용
- **위반 시**: `BRD_CIRCULAR_REFERENCE` (409) — 순환 참조가 발생합니다. 자기 자신 또는 자신의 하위 게시판을 부모로 지정할 수 없습니다
- **근거**: 데이터 아키텍처 §2.1 — `parent_id`는 자기 자신을 참조할 수 없다 (앱 레벨 검증 — 순환 참조 방지)

#### BR-BRD-003: [설계 원칙] 게시판 간 권한 비상속

- **트리거**: PermissionModule 권한 평가 시 (BoardPermission 조회, 크로스보드 하위 게시판 조회 등)
- **조건**: —
- **동작**: 각 게시판의 BoardPermission은 완전히 독립적으로 평가한다. 부모 게시판의 권한은 자식 게시판에 상속되지 않으며, 부모에 권한이 없어도 자식에 접근 가능하다. 트리 구조는 UI 네비게이션(사이드바) 용도일 뿐 권한 계산에 영향을 주지 않는다
- **위반 시**: —
- **근거**: FD-DOC §7 — 게시판 간 권한 비상속, 인증/인가 아키텍처 §5.3

---

### 게시판 삭제

#### BR-BRD-004: 게시판 소프트 삭제 정책

- **트리거**: `DELETE /boards/:id`
- **조건**: 요청자가 `manage_boards` 어드민 권한 보유
- **동작**: `Board.deleted_at = now()` — 소프트 삭제. 하위 게시판이 존재하면 재귀적으로 소프트 삭제한다 [BR-BRD-010]. 소속 문서의 가시성은 BoardModule이 관여하지 않는다 — DocumentModule이 문서 조회 시 `board.deleted_at`을 확인하여 자체 처리한다 (Board 독립 모듈 원칙 유지)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_boards 권한 없음 |
- **근거**: 데이터 아키텍처 §2.1 — 소프트 삭제 정책 (하위 재귀 소프트 삭제). `ON DELETE RESTRICT`는 물리 삭제(하드 딜리트)만 차단

#### BR-BRD-010: 소프트 삭제 시 하위 재귀 처리

- **트리거**: 게시판 소프트 삭제 실행 시 (BR-BRD-004의 후속 동작)
- **조건**: 소프트 삭제 대상 게시판에 하위 게시판이 존재하는 경우
- **동작**: 하위 게시판을 재귀적으로 소프트 삭제한다 (`deleted_at = now()`). 문서 가시성 처리는 BR-BRD-004와 동일한 원칙을 따른다
- **위반 시**: —
- **근거**: 데이터 아키텍처 §2.1 — 소프트 딜리트 시 하위 재귀 소프트 딜리트

---

### 게시판 타입

#### BR-BRD-005: board_type 초기 설정 시드

- **트리거**: 게시판 생성 시 (`POST /boards`)
- **조건**: 요청 본문에서 생략된 필드에만 아래 시드가 적용된다(전달된 필드는 그대로 사용)
- **동작**:
  - `knowledge` 타입: `approval_required = true`, `versioning_enabled = true`(시드 기본). `default_approval_template_id`에 시스템 기본 결재라인 템플릿을 자동 설정. 기본값은 SystemConfig의 `default_approval_template_id` 키로 결정한다 ([FD-SYS](../../01-requirements/features/FD-SYS-시스템설정.md) §3 참조). 값이 미설정이거나 해당 `approval_line_template` 행이 비활성·삭제된 경우 `default_approval_template_id = NULL`로 폴백할 수 있으나 `approval_required = true`는 유지(관리자가 템플릿·`mandatory_approval_config`를 보완해야 승인 플로가 완성)
  - `community` 타입: `approval_required = false`, `versioning_enabled = false`, `default_approval_template_id = NULL`, `mandatory_approval_config`는 NULL 또는 빈 구성
  - `notice` 타입: `approval_required = false`, `versioning_enabled = false`, `default_approval_template_id = NULL` (즉시 게시). `board_config.notice`에 시스템 기본값 적용
  - `custom` 타입: `approvalRequired`·`versioningEnabled`를 요청 본문으로 명시 (미지정 시 `approval_required = false`, `versioning_enabled = false` 등 시드 기본)
  - 하위 게시판 생성 시: `approval_required`·`versioning_enabled`·`mandatory_approval_config`를 생략하거나 null로 두면 컬럼에 null 저장 후 상위 게시판 설정을 상속한다. boolean·JSON 객체를 명시하면 해당 게시판에서 오버라이드한다
  - 생성 후 관리자는 **각 게시판**에서 `approval_required`·`versioning_enabled`·`mandatory_approval_config`·`default_approval_template_id` 등을 변경할 수 있다(상속 모델은 데이터 아키텍처 §2.1). `approval_required = true`로 두는 경우 BR-BRD-006의 필수 조건(유효한 템플릿 또는 구성)을 만족해야 문서 제출이 가능하다
- **위반 시**: —
- **근거**: 데이터 아키텍처 §2.1 설계 결정 — board_type에 따른 초기 설정 시드, `approval_required`·`versioning_enabled`·`mandatory_approval_config`의 nullable 상속·오버라이드

#### BR-BRD-018: 크로스보드 배너 표시

- **트리거**: 게시판 조회 시 배너 표시 여부 판단, 또는 `board_config.banner` 설정 변경 시
- **조건**: `board_config.banner` 및 공지(Notice) 정책에 따름
- **동작**: 설정된 규칙에 따라 크로스보드 배너를 노출하거나 생략한다
- **위반 시**: —
- **근거**: [FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md), FD-DOC §7

---

### 게시판 복구

#### BR-BRD-012: 게시판 복구

- **트리거**: `POST /boards/:id/restore`
- **조건**: 요청자가 `manage_boards` 어드민 권한 보유. 대상 게시판이 소프트 삭제 상태 (`deleted_at IS NOT NULL`)
- **동작**: `Board.deleted_at = null` — 소프트 삭제 복구. 하위 게시판도 재귀적으로 복구한다. `deleted_at` 해제 시 DocumentModule이 `board.deleted_at`을 조회하여 소속 문서가 자동으로 가시 상태로 복귀한다. 삭제 전 `is_active` 상태를 보존한다 — 삭제 전 `inactive`였던 게시판은 복구 시에도 `inactive`로 복귀한다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | BRD_NOT_DELETED | 409 | 삭제되지 않은 게시판은 복구할 수 없습니다 |
  | FORBIDDEN | 403 | manage_boards 권한 없음 |
- **근거**: 데이터 아키텍처 Board.deleted_at 소프트 삭제 설계 기반 — 관리자 운영 복구

---

### 게시판 활성/비활성

#### BR-BRD-013: 게시판 활성/비활성 전환

- **트리거**: `PATCH /boards/:id` (`isActive` 필드 변경 시)
- **조건**: 요청자가 `manage_boards` 어드민 권한 보유
- **동작**: `Board.is_active` 값을 토글한다. 비활성 게시판은 일반 사용자 목록 조회에서 제외
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | manage_boards 권한 없음 |
- **근거**: 데이터 아키텍처 Board.is_active 필드 기반 — 게시판 운영 관리

---

### 승인·결재라인·버전

#### BR-BRD-006: 승인·결재라인·버전 규칙

- **트리거**: 임의의 게시판에 대해 `approval_required`, `versioning_enabled`, `mandatory_approval_config`, `default_approval_template_id` 설정/변경 시(해당 필드가 요청에 포함된 경우)
- **조건**: `approval_required`·`versioning_enabled`·`mandatory_approval_config`는 컬럼이 null이면 상위 게시판 체인을 따라 상속되고, 명시값이 있으면 해당 게시판에서 오버라이드한다(데이터 아키텍처 §2.1). API·소비자는 유효값 해석 후 동작한다. `default_approval_template_id`는 게시판별 nullable FK로 저장된다.
- **동작**:
  - `approval_required`와 `versioning_enabled`는 **서로 독립**이다. 승인 없이 게시하면서 버전 이력만 켜거나, 승인은 켜고 버전만 끄는 등의 조합이 스키마상 가능하며, 실제 허용 조합은 제품 정책·문서 모듈과의 정합으로 보완한다.
  - `approval_required = true`인 경우(유효값 기준) 문서 제출·승인 플로는 `mandatory_approval_config` 및 `default_approval_template_id`(및 ApprovalModule 규칙)에 따른다. 구체적 필수 조건은 데이터 모듈 스펙과 FD를 따른다.

  **in-flight 문서가 있을 때 차단하는 변경** (`pending_review` 문서 수를 응답에 포함). 검사 범위는 **변경 대상 게시판 및 그 모든 하위 게시판**에 소속된 문서이다:

  | 변경 유형 | 조건 | 동작 |
  |-----------|------|------|
  | `approval_required`: true → false | 해당 범위에 `pending_review` **없음** | 허용 |
  | `approval_required`: true → false | 해당 범위에 `pending_review` **있음** | 차단 — 관리자가 먼저 승인/반려 완료 |
  | `mandatory_approval_config` 또는 `default_approval_template_id` 변경 | 유효 `approval_required = true`이고 `pending_review` **없음** | 허용 |
  | `mandatory_approval_config` 또는 `default_approval_template_id` 변경 | 유효 `approval_required = true`이고 `pending_review` **있음** | 차단 — 진행 중인 승인은 기존 설정으로 완료해야 함 |
  | `versioning_enabled`만 변경 | — | `pending_review`와 무관하게 허용(다른 모듈 제약이 없다면) |

  전환 차단 시 응답에 `pending_review` 문서 수를 포함하여 관리자가 상황을 파악할 수 있도록 한다.

- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | BRD_MODE_TRANSITION_BLOCKED | 409 | 승인 대기 중인 문서가 {n}건 있어 설정을 변경할 수 없습니다. 먼저 승인 또는 반려를 완료해주세요 |

- **근거**: 데이터 아키텍처 §2.1 설계 결정. 승인 진행 중인 문서가 있는 상태에서 승인 관련 설정을 바꾸면 해당 문서가 불일치 상태로 방치될 수 있으므로, 관리자가 먼저 승인/반려를 완료하도록 차단한다
- **구현 패턴 (Layer 1 독립 유지)**: BoardModule은 DocumentModule을 직접 DI 의존하지 않는다. `pending_review` 문서 존재 여부 확인은 **Controller 레벨 오케스트레이션**으로 처리한다:

  ```
  PATCH /boards/:id 핸들러 (BoardController):
  1. dto에 approvalRequired, versioningEnabled, mandatoryApprovalConfig, defaultApprovalTemplateId 변경이 포함되어 있는지 확인
  2. 대상 boardId 및 BoardService.getDescendantIds로 하위 게시판 ID 집합을 구한다
  3. approval_required true→false 전환 시 → 대상 게시판 및 모든 하위 게시판 ID에 대해 DocumentService로 `pending_review` 건수를 집계(단건 `countByBoardAndStatus` 반복 또는 DocumentModule이 제공하는 배치 집계)
  4. count > 0 → BRD_MODE_TRANSITION_BLOCKED (409) + pendingCount 반환
  5. 유효 approval_required=true 유지 상태에서 mandatory_approval_config·default_approval_template_id 변경 시에도 동일 집계 범위로 pending_review 검사
  6. 검증 통과 → BoardService.update(id, dto) 실행
  ```

  > BoardService 코어 레이어는 DocumentModule을 알지 못한다. Controller가 두 서비스를 조율하여 Board의 Layer 1 독립 원칙을 유지한다.
  > 하위 포함 집계는 `BoardService.getDescendantIds`로 ID 목록을 만든 뒤 DocumentModule이 export하는 내부 서비스(예: `countByBoardAndStatus`)로 건별 합산하거나, 동등한 배치 집계로 구현한다([document/api.md](../document/api.md) — 내부 서비스 참조).

---

### 권한 매핑

#### BR-BRD-007: Role-Board-Action 3원 매핑

- **트리거**: `PUT /boards/:id/permissions`
- **조건**: `roleId`가 유효한 Role UUID, `action`이 `VIEW`/`EDIT`/`APPROVE` 중 하나. 동일 `(board_id, role_id, action)` 조합이 중복되지 않음
- **동작**: BoardPermission 레코드 생성. 기존 매핑 전체 삭제 후 새 매핑으로 교체 (PUT 시맨틱)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | BRD_ROLE_NOT_FOUND | 404 | 역할을 찾을 수 없습니다 |
  | BRD_DUPLICATE_PERMISSION | 409 | 동일한 Role-Action 조합이 중복됩니다 |
- **근거**: 데이터 아키텍처 §2.2 — `UNIQUE(board_id, role_id, action)`, 인증/인가 아키텍처 §5.3

---

### 게시판 이동

#### BR-BRD-008: 게시판 이동

- **트리거**: `PATCH /boards/:id/move`
- **조건**: 새 `parentId`가 유효하고 순환 참조가 발생하지 않음 [BR-BRD-002]
- **동작**: `Board.parent_id` 변경. 기존 BoardPermission은 변경되지 않음 — 이동 전후 권한에 영향 없음
- **위반 시**: BR-BRD-002 참조
- **근거**: FD-DOC §7 — 게시판 이동 시 권한 변화 없음

---

### Slug 관리

#### BR-BRD-009: slug 고유성

- **트리거**: 게시판 생성 또는 slug 수정 시
- **조건**: `slug`가 삭제되지 않은(`deleted_at IS NULL`) 게시판 범위 내에서 유일함 (`UNIQUE(slug) WHERE deleted_at IS NULL` partial unique 제약). `slug`는 `[a-z0-9-]` 문자만 허용하며, 입력값은 소문자 정규화 후 저장한다
- **동작**: slug 설정 허용. 소프트 삭제된 게시판의 slug는 재사용 가능하다
- **위반 시**: `BRD_SLUG_DUPLICATE` (409) — 이미 사용 중인 slug입니다
- **근거**: 데이터 아키텍처 §2.1 — `UNIQUE(slug) WHERE deleted_at IS NULL` partial unique 제약, URL 경로 충돌 방지. 소프트 삭제된 게시판은 URL로 접근할 수 없으므로 slug 충돌이 발생하지 않는다

---

### 게시판 타입 불변

#### BR-BRD-014: board_type 불변 규칙

- **트리거**: `PATCH /boards/:id` 요청 본문에 `boardType` 필드가 포함된 경우(클라이언트가 전송한 경우)
- **조건**: —
- **동작**: `board_type`은 게시판 생성 시에만 지정 가능하며, 생성 이후 변경을 허용하지 않는다. `knowledge`, `community`, `notice`, `custom` 모든 타입이 불변이다. 타입 전환 시 프리셋 템플릿·에디터 프로파일·기존 문서 블록 호환성에 미치는 영향이 크므로 불변으로 관리한다
- **구현**: `UpdateBoardDto`에 `boardType` 필드를 정의하지 않는다. [횡단 관심사 §8.8.1](../../02-architecture/07-cross-cutting-concerns.md#881-입력-검증)의 글로벌 ValidationPipe가 `forbidNonWhitelisted: true`로 설정되어 있으므로, 클라이언트가 `boardType`을 전송하면 **400 Bad Request(VALIDATION_ERROR)**가 반환된다. 본 규칙은 모듈 레벨에서 `boardType` 변경을 허용하지 않는다는 의도를 기술하며, 실제 차단 동작은 글로벌 ValidationPipe 설정에 따른다
- **위반 시**: — (HTTP 레벨에서 board_type 변경을 거부하는 전용 에러는 발생하지 않음)
- **근거**: 게시판 타입은 프리셋 템플릿·에디터 프로파일과 초기 설정 시드를 결정하는 핵심 속성이며, 전환 시 기존 문서의 블록 호환성 문제가 발생할 수 있다

---

### 낙관적 동시성 제어

#### BR-BRD-015: 낙관적 동시성 제어 (OCC)

- **트리거**: `PATCH /boards/:id` — `expectedUpdatedAt` 필드가 전달된 경우
- **조건**: 요청의 `expectedUpdatedAt`과 DB의 `Board.updated_at`이 일치
- **동작**: `UPDATE board SET ... WHERE id = :id AND updated_at = :expectedUpdatedAt` 실행. 영향 행이 1이면 정상 반환. `expectedUpdatedAt` 미전달 시 OCC 검증을 건너뛴다 (하위 호환)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | BRD_CONCURRENT_MODIFICATION | 409 | 다른 관리자가 이미 이 게시판을 수정했습니다. 최신 데이터를 다시 조회한 후 수정해주세요 |

- **근거**: 게시판 수정은 관리자 전용 저빈도 작업이므로 낙관적 동시성 제어로 충분하다. 비관적 락(SELECT FOR UPDATE)의 오버헤드는 불필요하다

---

### 게시판별 개별 설정

#### BR-BRD-017: board_config 검증

- **트리거**: 게시판 생성 (`POST /boards`) 또는 수정 (`PATCH /boards/:id`) 시 `boardConfig` 필드가 포함된 경우
- **조건**: `boardConfig` 값이 유효한 JSON 객체이며, 허용된 스키마를 준수
- **동작**:
  1. 최상위 키는 `comment`, `display`, `attachment`, `notification`, `posting`, `notice`, `banner` 중 하나여야 한다. 미인식 키는 무시하지 않고 거부한다 (스키마 엄격 모드)
  2. 각 그룹 내 필드 값이 허용 범위 내에 있어야 한다:
     - `comment.maxDepth`: 0~10 정수
     - `display.listStyle`: `'table'` | `'card'` | `'gallery'`
     - `display.itemsPerPage`: 10~100 정수
     - `attachment.maxFileSizeMb`: 1 이상 정수
     - `attachment.maxTotalSizeMb`: `maxFileSizeMb` 이상 정수
     - `posting.categories`: 문자열 배열, 최대 50개, 각 항목 최대 30자
     - `banner.showCrossBoardBanner`: boolean
     - `banner.maxBannerCount`: 1~10 정수
     - `notice.maxPinnedCount`: 1~20 정수
     - `notice.defaultPopupFrequency`: `'once'` | `'every_login'` | `'daily'`
     - `notice.allowedNotificationChannels`: 문자열 배열(허용 값은 구현과 FD-NTC 정합)
  3. 수정 시 `boardConfig`는 **최상위 키 단위 deep-merge**로 동작한다 — 전달된 그룹만 기존 값에 병합하고 미전달 그룹은 유지
  4. 생성 시 `boardConfig` 미전달이면 빈 객체(`{}`)로 저장 — 모든 설정이 앱 레벨 기본값으로 동작
  5. `board_config.notice` 키는 **`board_type = 'notice'`인 게시판에서만** 의미가 있다. 다른 `board_type`에서 `notice` 그룹을 두어도 스키마 검증을 통과하면 JSON은 그대로 저장되며, **읽기·런타임·기능 소비자는 해당 그룹을 적용하지 않는다(무시)**. 저장 거부가 아닌 적용 범위 제한이다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | BRD_INVALID_BOARD_CONFIG | 400 | 게시판 설정이 유효하지 않습니다: {상세 사유} |

- **근거**: 데이터 아키텍처 §2.1 설계 결정 — board_config JSONB. DB 레벨에서 참조 무결성을 보장하지 못하므로 앱 레벨에서 스키마를 엄격하게 검증한다. 미인식 키를 허용하면 오타/잘못된 설정이 무시되어 운영 혼란을 야기할 수 있으므로 거부한다

---

### 결재라인 템플릿 삭제 시 불완전 승인 설정

#### BR-BRD-016: 기본 결재라인 템플릿 삭제 시 불완전 승인 설정

- **트리거**: 참조 중인 ApprovalLineTemplate(`approval_line_template`) 행이 삭제될 때 (DB `ON DELETE SET NULL` 동작)
- **조건**: `Board.default_approval_template_id`가 삭제 대상 템플릿을 참조하는 경우
- **동작**: `default_approval_template_id`가 `ON DELETE SET NULL`에 의해 NULL이 되지만, `approval_required`는 그대로 true일 수 있다. 이 상태에서는 기본 결재라인이 없어 **문서 제출(submit)이 차단**될 수 있다. 관리자가 다른 `approval_line_template`를 지정하거나 `mandatory_approval_config`를 보완해야 한다. 기존 `published` 문서에는 영향 없음
- **위반 시**: —
- **근거**: DDL `ON DELETE SET NULL`은 `default_approval_template_id`만 NULL로 설정하며 `approval_required`는 변경하지 않음. 승인 필요 플래그 해제는 관리자의 명시적 변경으로만 수행되어야 하며, 외부 이벤트(템플릿 삭제)에 의한 암묵적 해제는 의도하지 않음

---

## 3. 에러 코드 카탈로그

> 전역 에러 코드 (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

| 에러 코드 | HTTP | 발생 규칙 | 메시지 템플릿 |
|-----------|------|----------|--------------|
| BRD_BOARD_NOT_FOUND | 404 | — | 게시판을 찾을 수 없습니다 |
| BRD_CIRCULAR_REFERENCE | 409 | BR-BRD-002 | 순환 참조가 발생합니다 |
| BRD_CONCURRENT_MODIFICATION | 409 | BR-BRD-015 | 다른 관리자가 이미 이 게시판을 수정했습니다 |
| BRD_DUPLICATE_PERMISSION | 409 | BR-BRD-007 | 동일한 Role-Action 조합이 중복됩니다 |
| BRD_INVALID_BOARD_CONFIG | 400 | BR-BRD-017 | 게시판 설정이 유효하지 않습니다: {상세 사유} |
| BRD_MODE_TRANSITION_BLOCKED | 409 | BR-BRD-006 | 승인 대기 중인 문서가 {n}건 있어 설정을 변경할 수 없습니다 |
| BRD_NOT_DELETED | 409 | BR-BRD-012 | 삭제되지 않은 게시판은 복구할 수 없습니다 |
| BRD_PARENT_NOT_FOUND | 404 | BR-BRD-001, BR-BRD-002 | 상위 게시판을 찾을 수 없습니다 |
| BRD_ROLE_NOT_FOUND | 404 | BR-BRD-007 | 역할을 찾을 수 없습니다 |
| BRD_SLUG_DUPLICATE | 409 | BR-BRD-009 | 이미 사용 중인 slug입니다 |

---

## 4. 규칙 요약 매트릭스

| 규칙 ID | 이름 | 주요 트리거 | 에러 코드 |
|---------|------|-----------|-----------|
| BR-BRD-001 | 게시판 생성 | POST /boards | FORBIDDEN, BRD_PARENT_NOT_FOUND, BRD_SLUG_DUPLICATE |
| BR-BRD-002 | 순환 참조 방지 | 게시판 생성/이동 시 parentId 검증 | BRD_CIRCULAR_REFERENCE, BRD_PARENT_NOT_FOUND |
| BR-BRD-003 | [설계 원칙] 게시판 간 권한 비상속 | PermissionModule 권한 평가 시 | — |
| BR-BRD-004 | 게시판 소프트 삭제 정책 | DELETE /boards/:id | FORBIDDEN |
| BR-BRD-005 | board_type 초기 설정 시드 | POST /boards | — |
| BR-BRD-006 | 승인·결재라인·버전 규칙 | approval_required·버전·필수 승인·기본 템플릿 변경 시(하위 트리 pending_review 검사) | BRD_MODE_TRANSITION_BLOCKED |
| BR-BRD-007 | Role-Board-Action 3원 매핑 | PUT /boards/:id/permissions | BRD_ROLE_NOT_FOUND, BRD_DUPLICATE_PERMISSION |
| BR-BRD-008 | 게시판 이동 | PATCH /boards/:id/move | BR-BRD-002 참조 |
| BR-BRD-009 | slug 고유성 | 게시판 생성/수정 시 | BRD_SLUG_DUPLICATE |
| BR-BRD-010 | 소프트 삭제 시 하위 재귀 처리 | BR-BRD-004 후속 | — |
| BR-BRD-012 | 게시판 복구 | POST /boards/:id/restore | BRD_NOT_DELETED, FORBIDDEN |
| BR-BRD-013 | 게시판 활성/비활성 전환 | PATCH /boards/:id (isActive 변경) | FORBIDDEN |
| BR-BRD-014 | board_type 불변 규칙 | PATCH /boards/:id (boardType 전달 시, ValidationPipe에 의해 거부 — 400) | — |
| BR-BRD-015 | 낙관적 동시성 제어 (OCC) | PATCH /boards/:id (expectedUpdatedAt 전달 시) | BRD_CONCURRENT_MODIFICATION |
| BR-BRD-016 | 기본 결재라인 템플릿 삭제 시 불완전 승인 설정 | ApprovalLineTemplate 삭제 (ON DELETE SET NULL) | — |
| BR-BRD-017 | board_config 검증 | POST /boards, PATCH /boards/:id (boardConfig 전달 시) | BRD_INVALID_BOARD_CONFIG |
| BR-BRD-018 | 크로스보드 배너 표시 | 게시판 조회 시 배너 표시 여부 판단, board_config.banner 설정 변경 시 | — |
