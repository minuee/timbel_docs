# Board 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | BoardModule |
| 문서 코드 | MS-BRD |
| 상태 | `draft` |
| 기능정의서 | [FD-DOC-문서관리 §7](../../01-requirements/features/FD-DOC-문서관리.md) |
| 데이터 모델 | [board-module.md](./data.md) |
| 프로세스 흐름 | — |

---

## 모듈 책임

BoardModule은 AICM의 **문서 분류 및 운영 정책 단위**를 관리하는 모듈이다. 서비스 레이어는 독립적이며, Controller에서 DocumentService를 주입받아 승인·결재라인 설정 변경 시 in-flight 문서 검사 등 오케스트레이션을 수행한다. DocumentModule·ApprovalModule·CommunityModule·AdminModule 등이 이 모듈을 읽기 참조한다.

| 영역 | 설명 |
|------|------|
| 게시판 CRUD | 게시판 생성·조회·수정·소프트 삭제, slug 기반 URL 경로 식별 |
| 게시판 트리 구조 | 재귀 `parent_id` 기반 무한 뎁스 트리, 최상위 게시판이 기존 Category 역할을 겸함 |
| 게시판 타입 관리 | `knowledge` / `community` / `notice` / `custom` 타입에 따른 양식/템플릿 프리셋 분류 및 에디터 프로파일 분기 |
| 승인·버전 플래그 | `approval_required`, `versioning_enabled`(nullable boolean) — 루트 게시판에서는 반드시 명시(NOT NULL). 하위 게시판은 컬럼을 `null`로 두면 상위 게시판 설정을 상속하고, 명시값을 두면 해당 게시판에서 오버라이드한다. 두 플래그는 서로 독립 (`approval_required=false`일 때 직접 발행·덮어쓰기 등 승인 없이 게시하는 동작, `versioning_enabled`는 버전 이력 적용 여부) |
| 운영 설정 관리 | 필수 승인 구성(`mandatory_approval_config` JSONB), 기본 결재라인 템플릿(`default_approval_template_id`), 기본 문서 템플릿(`default_template_id`), 기본 보존 정책(`default_retention_policy_id`) — 템플릿·보존은 nullable FK, 결재 구성은 JSONB ([ADR-010](../../adr/010-board-policy-binding-removal.md)) |
| 게시판별 개별 설정 | `board_config`(JSONB) — 댓글, 표시, 첨부파일, 알림, 글 작성, 배너 수신 등 게시판 종속적인 세부 설정을 키-값으로 관리. FK 정책과 달리 변경 빈도가 높고 게시판별 독립 |
| 승인·버전·결재라인 | `approval_required`가 true이면 승인 워크플로 적용(필수 구성·템플릿은 BR-BRD-005/006). `versioning_enabled`는 승인과 무관하게 버전 이력 적용 여부를 제어. 모든 게시판에서 컬럼 단위로 설정 가능하며, `null`이면 상위 체인을 따라 상속한다 |
| 게시판별 권한 매핑 | BoardPermission — Role-Board-Action 3원 매핑 (VIEW/EDIT/APPROVE) |
| 크로스보드 지원 | 상위 게시판의 하위 트리 전체 board_id 수집 (DocumentModule 등이 검색/필터에 활용) |

> **문서 삭제 연동 방침**: 게시판 소프트 삭제 시 소속 문서의 가시성 처리는 BoardModule이 관여하지 않는다. DocumentModule이 문서 조회 시 `board.deleted_at`을 확인하여 삭제된 게시판의 문서를 자체적으로 필터링한다. 게시판 복구(`deleted_at` 해제) 시 소속 문서도 자동 복귀된다. 이 방식은 Board의 Layer 1 독립 모듈 원칙을 유지하면서 기존 Doc→Board 단방향 읽기 의존만으로 정합성을 확보한다.

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — board-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **Board** | 게시판 메타데이터 + 재귀 트리(`parent_id`). `mandatory_approval_config`(JSONB), `default_approval_template_id`, `default_template_id`, `default_retention_policy_id`로 운영 설정 보유. `board_config`(JSONB)로 게시판별 개별 설정(댓글·표시·첨부파일·알림·글작성·공지 등) 관리. `board_type`(knowledge/community/notice/custom)에 따라 양식/템플릿 프리셋 및 에디터 프로파일 결정. `approval_required`·`versioning_enabled`·`mandatory_approval_config`는 nullable로 상위 상속 또는 명시 오버라이드. 소프트 삭제(`deleted_at`) 지원 |
| **BoardPermission** | Role-Board-Action 3원 매핑. `UNIQUE(board_id, role_id, action)` 제약. action은 `VIEW`/`EDIT`/`APPROVE`. 게시판 간 권한 비상속 — 각 게시판의 BoardPermission은 완전 독립 |

> **설계 결정**: 기본 문서 템플릿·기본 보존 정책·기본 결재라인 템플릿은 Board 엔티티의 nullable FK로 보유하고, 필수 승인 규칙은 `mandatory_approval_config` JSONB로 관리한다. [ADR-010](../../adr/010-board-policy-binding-removal.md) — Board 직접 바인딩 패턴 참조. 게시판 종속적인 세부 설정(댓글, 표시, 첨부파일, 알림, 글 작성)은 `board_config` JSONB 컬럼으로 관리한다 — FK 정책과 달리 변경 빈도가 높고 게시판별 독립적이므로 JSONB가 적합하다.

---

## 의존 관계

```mermaid
graph LR
    Board["<b>BoardModule</b>"]

    Doc["DocumentModule"] -->|"읽기"| Board
    Board -->|"읽기 (Controller 오케스트레이션)"| Doc
    Appr["ApprovalModule"] -->|"읽기"| Board
    Com["CommunityModule"] -->|"읽기"| Board
    Admin["AdminModule"] -->|"읽기"| Board
    Perm["PermissionModule"] -->|"읽기"| Board

    classDef hub fill:#dcfce7,stroke:#16a34a,stroke-width:2px
    classDef consumer fill:#f3f4f6,stroke:#6b7280

    class Board hub
    class Doc,Appr,Com,Admin,Perm consumer
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Board → Doc | DocumentModule | 읽기 (Controller) | BR-BRD-006에 해당하는 변경 시 `pending_review` 문서 존재 확인 (Controller 레벨 오케스트레이션) |
| Doc → Board | DocumentModule | 읽기 | 게시판 설정 조회 (필수 승인 구성, 기본 결재라인 템플릿, 게시판 타입, 기본 템플릿, 기본 보존 정책). `getBoardConfig` — 문서 작성·목록·표시, 첨부/알림 정책 등 게시판별 JSON 설정 |
| Approval → Board | ApprovalModule | 읽기 | 게시판 결재라인 템플릿·승인 설정 조회. `getBoardConfig` — 게시판별 알림·표시 등 연동 시 |
| Com → Board | CommunityModule | 읽기 | 커뮤니티·댓글 정책. `getBoardConfig` — 댓글 깊이, 익명 허용, 글 작성 규칙 등 |
| Admin → Board | AdminModule | 읽기 | 관리자 통계용 게시판 데이터 조회 |
| Permission → Board | PermissionModule | 읽기 | BoardPermission 기반 권한 평가 (Board Grant 계층) |

> **서비스 레이어 독립**: BoardService는 다른 도메인 모듈에 대한 DI 의존이 없다. Controller에서 DocumentService를 주입받아 승인·결재라인 관련 변경 시 오케스트레이션(pending_review 문서 확인)을 수행하며, 서비스 레이어의 독립성을 유지한다.
>
> <!-- 반영 완료: 02-module-architecture.md §3.3.1 표A에 Board→Document 의존 등록됨 -->

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | Board, BoardPermission |
| Redis / BullMQ | ● | 게시판 트리 캐시 (`cache:board:tree`, TTL 1h). BullMQ `board.events` 큐로 `board.permissions_updated` 이벤트 전달 → AuthModule 권한 캐시 무효화 |
| Elasticsearch | — | |
| MinIO | — | |
| EventBus | — | |
| 외부 서비스 클라이언트 | — | |

---

## 운영 가이드

### 트리 깊이 제한

게시판 트리는 기술적으로 무한 뎁스가 가능하나, 운영 안정성을 위해 아래 가이드라인을 따른다:

| 항목 | 권장값 | 출처 | 근거 |
|------|--------|------|------|
| 최대 깊이 | 10 | 코드 하드코딩 | PostgreSQL WITH RECURSIVE CTE의 실용적 성능 한계, UI 사이드바 렌더링. 게시판 수 100개 이하 규모에서 성능 문제 없으므로 설정값 외부화 불필요 |
| CTE safeguard | `depth < 20` | 코드 하드코딩 | 최대 깊이(10)의 2배로 설정하여, 데이터 오염 시에도 무한 루프를 방지하는 안전 장치. 절대 한계이므로 운영 중 변경할 필요 없음 |
| UI 깊이 제한 | 프론트엔드 설정값 | 프론트엔드 환경 변수 | 사이드바 들여쓰기 가독성. 백엔드와 독립 제어 |

### 동시성 제어

게시판 CRUD는 관리자 전용 저빈도 작업이므로 PostgreSQL 기본 격리 수준(Read Committed)으로 충분하다. 아래 시나리오별 전략을 따른다:

| 시나리오 | 제어 방식 | 근거 |
|----------|----------|------|
| 동일 게시판 동시 수정 | DB `updated_at` 기반 낙관적 동시성 제어 (OCC) | 관리자 간 충돌 빈도 극히 낮으므로 비관적 락 불필요 |
| 재귀 소프트 삭제 중 복구 요청 | 단일 트랜잭션 내 CTE 실행으로 원자성 보장 | CTE UPDATE가 단일 문으로 실행되므로 중간 상태 불가 |
| 게시판 이동과 삭제 동시 발생 | DB FK 제약 + `deleted_at` 필터 조건으로 자연 방어 | 삭제된 게시판으로의 이동은 `BRD_PARENT_NOT_FOUND`로 거부 |

> **OCC 패턴**: `UPDATE board SET ... WHERE id = :id AND updated_at = :expectedUpdatedAt`. 영향 행이 0이면 `409 Conflict` 반환.

### Redis 장애 시 폴백 (트리 캐시·큐)

게시판 트리 캐시와 BullMQ enqueue 모두 Redis에 의존한다. 상세 키·TTL·서킷브레이커·타임아웃은 [cache.md](./cache.md) §2.1·§3.6을 따른다.

| 구분 | 동작 |
|------|------|
| 트리 캐시 읽기 실패 | DB에서 `WITH RECURSIVE`로 트리를 직접 구축해 응답. 캐시 쓰기는 생략 가능 |
| 트리 캐시 무효화(DEL) 실패 | 최대 TTL(1h) 동안 stale 가능 — [cache.md](./cache.md) §2.1. 저빈도 관리자 작업이면 자연 만료로 수렴 |
| BullMQ enqueue 실패 | 작업은 DB에 반영된 뒤 큐 적재만 실패할 수 있음 — 아래 **이벤트 발행 보정** 참조 |

### 이벤트 발행 실패 시 보정

DB 커밋과 BullMQ enqueue는 동일 분산 트랜잭션이 아니므로, 커밋 성공 후 enqueue 실패 시 구독자(감사·검색·다운스트림)가 이벤트를 놓칠 수 있다.

**Phase 1·2 운영 결정**: Phase 1에서는 **보정 배치 패턴**을 채택한다. **5분 주기**로 워터마크(`updated_at`, 삭제·복구 시각 등) 기준을 스캔하여 BullMQ에 **누락된 `board.*` 이벤트**를 재발행한다. **Outbox 패턴**은 Phase 2에서 도입 여부를 검토한다. **감사 로그**는 도메인 트랜잭션 내 RDB에 직접 기록하므로 enqueue 실패와 무관하게 **손실 없이** 남는다.

| 패턴 | 설명 |
|------|------|
| Outbox | `board` 변경과 동일 트랜잭션에 outbox 행 기록 → 워커가 폴링·전송 후 ACK. At-least-once 전달에 맞춰 소비자 멱등성 유지 — **Phase 2 검토** |
| 보정 배치 (**Phase 1 채택**) | **5분 주기** 배치가 워터마크 이후 변경된 게시판을 스캔해, 누락된 `board.*` 이벤트를 재발행. [api.md](./api.md)의 이벤트 페이로드·멱등성 키 규약과 동일하게 enqueue |
| 권한 전용 이벤트 | `board.permissions_updated`는 Auth 캐시 TTL로 수렴 가능 — [cache.md](./cache.md) §3.4. 라이프사이클·설정 동기화가 엄격한 소비자는 Phase 2 Outbox 또는 동일 보정 배치 스캔 범위에 포함한다 |

이벤트 스키마·멱등성·재시도는 [api.md](./api.md)의 «BullMQ 이벤트 (`board.events`)» 절을 따른다.

---

### 감사 로그 대상

| 작업 | 감사 로그 | 비고 |
|------|:---------:|------|
| 게시판 생성 | ● | `board.created` |
| 게시판 수정 | ● | `board.updated` — 운영 설정 변경(필수 승인 구성, 기본 결재라인 템플릿, 기본 문서 템플릿) 포함 |
| 게시판 삭제 | ● | `board.deleted` — 재귀 삭제된 하위 게시판도 개별 기록 |
| 게시판 복구 | ● | `board.restored` |
| 게시판 이동 | ● | `board.moved` — 이전/이후 parent_id 기록 |
| 권한 변경 | ● | `board.permissions_updated` |
| 활성/비활성 전환 | ● | `board.toggled` |

### 주요 메트릭

| 메트릭 | 설명 | 용도 |
|--------|------|------|
| `board.active_count` | 활성 게시판 수 | 시스템 규모 파악 |
| `board.tree_max_depth` | 트리 최대 깊이 | 성능 모니터링 |
| `board.tree_avg_children` | 평균 자식 게시판 수 | 트리 균형도 확인 |
| `board.cache_hit_rate` | 게시판 트리 캐시 히트율 | 캐시 효율성 |
| `board.events.dlq_count` | `board.events-dlq` 큐 적재 메시지 수 | 이벤트 전달 실패 감지. `> 0`이면 WARN 알림 |

---

## 내부 서비스 인터페이스 (export)

소비 모듈(Document, Approval, Community, Permission, Admin)이 BoardModule을 import하여 사용하는 메서드 시그니처를 정의한다.

```typescript
interface BoardExportService {
  /** 게시판 단건 조회 (미존재 시 null). soft-deleted 게시판은 기본 제외. 필요 시 `{ includeDeleted?: boolean }` 옵션 파라미터 도입 검토 */
  findById(boardId: string): Promise<Board | null>;

  /** 게시판 단건 조회 (미존재 시 예외) */
  findByIdOrFail(boardId: string): Promise<Board>;

  /** 테넌트의 전체 게시판 트리 조회 */
  getTree(tenantId: string): Promise<BoardTreeNode[]>;

  /** 특정 게시판의 하위 게시판 ID 목록 조회 (재귀) */
  getDescendantIds(boardId: string): Promise<string[]>;

  /** 게시판의 필수 승인 구성 조회 — 해당 행이 null이면 상위 체인을 따라 상속 탐색. 루트까지 모두 null이면 null */
  getMandatoryApprovalConfig(boardId: string): Promise<Record<string, unknown> | null>;

  /** 게시판에 승인 필요 여부 — 해당 행이 null이면 상위 체인을 따라 상속하여 유효 boolean 산출 */
  isApprovalRequired(boardId: string): Promise<boolean>;

  /** 게시판에 버전 관리 활성 여부 — 해당 행이 null이면 상위 체인을 따라 상속하여 유효 boolean 산출 */
  isVersioningEnabled(boardId: string): Promise<boolean>;

  /** 게시판별 개별 설정 조회 (앱 레벨 기본값 병합 후 반환) */
  getBoardConfig(boardId: string): Promise<BoardConfig>;
}
```

**`getBoardConfig` 소비 모듈**: 아래 모듈이 export 메서드 `getBoardConfig`를 호출해 게시판별 `board_config`(댓글·표시·첨부·알림·글작성·공지 UX 등)를 조회한다. 그 외 모듈(예: 공지·배너 크로스보드 연동)이 동일 설정이 필요하면 동일 API를 재사용한다.

| 소비 모듈 | 주요 용도 |
|-----------|-----------|
| DocumentModule | 문서 작성·목록·상세 UI, 첨부/알림 한도, 카테고리 요구 여부 등 |
| ApprovalModule | 승인 흐름과 연계된 게시판 알림·표시 옵션 |
| CommunityModule | 댓글 활성화, 익명, maxDepth, 커뮤니티 글쓰기 규칙 |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-DOC-문서관리 §7](../../01-requirements/features/FD-DOC-문서관리.md) | 기능정의서 — 게시판 트리 (입력 원본) |
| [board-module.md](./data.md) | RDB 엔티티/DDL |
| [cache.md](./cache.md) | 캐시 전략 — 트리 캐시 + 권한 캐시 무효화 이벤트 |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 3계층 권한 모델, Board Grant, BoardPermission, §9.3 캐시 무효화 |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 모듈 분류 |
| [ADR-010](../../adr/010-board-policy-binding-removal.md) | BoardPolicyBinding 제거 및 Board 직접 FK 전환 의사결정 |
| [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md) | 전역 에러 코드 카탈로그, 에러 응답 공통 포맷 |

---

## § 아키텍처 정합 이력

아래 항목은 [02-module-architecture.md](../../02-architecture/02-module-architecture.md)에 반영 완료되었다.

- ✅ §3.3.1 표A — Board→Document(읽기, Controller 오케스트레이션) 등록 완료
- ✅ §3.3.1 표C — `board.events` BullMQ 큐 등록 완료
