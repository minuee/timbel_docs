# Board 캐시 전략

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 캐시 개요

| 캐시 대상 | 전략 | 저장소 | 키 패턴 | TTL | 무효화 트리거 |
|-----------|------|--------|---------|-----|-------------|
| 게시판 트리 | cache-aside | Redis String | `{tenant_id}:cache:board:tree` | 1h | 게시판 CRUD 시 무효화 |

---

## 2. 캐시 상세

### 2.1 게시판 트리 캐시

#### 기본 정보

- **전략**: cache-aside
- **키 패턴**: `{tenant_id}:cache:board:tree`
- **TTL**: 1시간
- **직렬화**: JSON (트리 구조 전체)

#### 무효화

아래 비즈니스 규칙 발동 시 캐시를 무효화한다:

| 트리거 | 규칙 | 무효화 방식 |
|--------|------|-------------|
| 게시판 생성 | BR-BRD-001 | DEL → lazy-load |
| 게시판 이동 | BR-BRD-008 | DEL → lazy-load |
| 게시판 소프트 삭제 | BR-BRD-004 | DEL → lazy-load |
| 게시판 복구 | BR-BRD-012 | DEL → lazy-load |
| 활성/비활성 전환 | BR-BRD-013 | DEL → lazy-load |
| 게시판 수정 (이름, 정렬 순서 등) | — | DEL → lazy-load |

**전략**: DEL 후 lazy-load (다음 조회 시 DB에서 재구축). 즉시 재구축(eager rebuild)은 불필요 — 게시판 변경은 관리자 전용 저빈도 작업이므로, 다음 사용자 요청 시 1회 cold miss를 감수한다.

#### Warm-up / Fallback

**Cold Start**:
- 서비스 시작 시 preload **하지 않는다** — 첫 조회 시 lazy-load로 충분
- 게시판 트리 전체 구축 쿼리: `WITH RECURSIVE` CTE 1회 (data.md §3.3 참조)
- 예상 비용: 게시판 수 100개 이하 기준 < 10ms

**Redis 장애 시 Fallback**:
- Redis 조회 실패 시 DB에서 직접 트리 구축하여 반환
- 캐시 쓰기는 스킵 (Redis 복구 후 자연스럽게 재캐싱)
- 에러 로그 기록: `WARN` 레벨, `board.cache.redis_fallback` 태그

**캐시 무효화(DEL) 실패 시 보정**:
- 무효화 DEL이 Redis 장애로 실패하면, 최대 TTL(1시간) 동안 stale 트리가 응답될 수 있다
- 게시판 CRUD는 관리자 전용 저빈도 작업이므로 1시간 내 자연 만료로 보정되며, 보정 배치는 불필요
- 즉시 반영이 필요한 경우 관리자가 수동으로 캐시를 클리어할 수 있다 (관리자 대시보드 캐시 관리 기능 또는 Redis CLI `DEL {tenant_id}:cache:board:tree`)

#### 서킷브레이커

Redis 연속 장애 시 불필요한 연결 시도를 억제하여 응답 지연을 방지한다.

| 상태 | 전이 조건 | 동작 |
|------|-----------|------|
| **CLOSED** (정상) | — | Redis 정상 호출. 실패 카운터 유지 |
| **OPEN** (차단) | 3회 연속 실패 | Redis 호출을 건너뛰고 즉시 DB Fallback. 30초 유지 후 HALF-OPEN 전이 |
| **HALF-OPEN** (탐색) | OPEN 30초 경과 | 단건 Redis 호출 시도 |
| → CLOSED | HALF-OPEN에서 1건 성공 | 실패 카운터 초기화, 정상 복귀 |
| → OPEN | HALF-OPEN에서 실패 | 다시 30초 OPEN |

> 서킷브레이커 상태 전이 시 `INFO` 로그를 기록한다 (`board.cache.circuit_breaker` 태그).

---

### 2.2 documentCount 집계 전략

게시판 트리/목록 API 응답의 `documentCount` 필드 집계 방식:

| 방식 | 적용 대상 | 근거 |
|------|-----------|------|
| LEFT JOIN 서브쿼리 | `GET /boards` (목록) | 페이지네이션 범위 내 게시판만 집계하므로 비용 한정적 |
| 캐시 트리에 포함 | `GET /boards/tree` (트리) | 트리 캐시 구축 시 함께 집계하여 저장. 무효화 시 함께 갱신 |

> **주의**: 문서 생성/삭제 시 트리 캐시의 documentCount가 stale될 수 있다. 트리 캐시 TTL(1h) 내에서 정확도보다 성능을 우선한다. 정확한 수치가 필요한 관리자는 Admin API를 경유하여 DB 직접 조회로 실시간 수치를 확인할 수 있다 (`GET /admin/boards/:id/stats` — AdminModule 소관).

---

## 3. 권한 캐시 무효화 (BoardPermission → AuthModule)

BoardPermission 변경 시 AuthModule의 권한 캐시가 stale 상태가 되므로, BullMQ `board.events` 큐에 `board.permissions_updated` 작업을 enqueue하여 무효화를 트리거한다.

### 3.1 이벤트 정의

| 이벤트명 | 트리거 | 페이로드 | 소비자 |
|----------|--------|----------|--------|
| `board.permissions_updated` | `PUT /boards/:id/permissions` 완료 시 | `{ boardId, affectedRoleIds, schemaVersion }` | AuthModule (PermissionModule) |

### 3.2 소비자 동작

AuthModule은 `board.permissions_updated` 이벤트를 수신하면:

1. `affectedRoleIds`에 해당하는 Role을 보유한 사용자 목록을 **RDB에서 직접 조회** (캐시 기반 탐색은 stale 위험)
2. 해당 사용자의 `{tenant_id}:cache:auth:accessible-boards:{user_id}:*` 캐시 키를 삭제

> [인증/인가 아키텍처 §9.3](../../02-architecture/03-auth-architecture.md) 무효화 전략을 따른다. 영향받는 사용자 탐색은 캐시가 아닌 RDB 직접 조회이다.

### 3.3 전달 계약

| 항목 | 값 |
|------|-----|
| 큐 | `board.events` |
| 재시도 | 3회, 지수 백오프 (초기 1초, 배율 ×2, 최대 30초) — 프로젝트 기본(5초)보다 짧은 초기 지연은 권한 캐시 무효화의 사용자 체감 지연을 최소화하기 위한 의도적 오버라이드 |
| DLQ | `board.events-dlq` |
| 멱등성 키 | `boardId:timestamp` |
| 스키마 버전 | `schemaVersion: 1` |

### 3.4 장애 시나리오 및 보정

| 시나리오 | 영향 | 보정 전략 |
|----------|------|-----------|
| 이벤트 유실 (Worker 장애 등) | AuthModule의 `cache:auth:accessible-boards` 캐시가 stale 상태 | auth 캐시 TTL(5분)이 자연 만료되어 **최대 5분 내 정합성 자동 복구**. 별도 보정 배치 불필요 |
| DLQ 적재 | 재시도 3회 실패 → `board.events-dlq`에 적재 | DLQ 메시지 존재 시 운영자가 수동 재처리 또는 원인 분석. auth 캐시 TTL 자연 만료로 실질적 영향은 제한적 |
| Redis 장애 (트리 캐시) | 트리 캐시 조회 실패 | DB에서 직접 트리 구축하여 반환. 캐시 쓰기 스킵. WARN 로그 기록 (`board.cache.redis_fallback` 태그) |
| BullMQ enqueue 실패 (Redis 장애) | `board.permissions_updated` 이벤트가 AuthModule에 전달되지 않음 | auth 캐시 TTL(5분) 자연 만료로 보정. 별도 처리 불필요 — auth 캐시가 자연 만료되면 RDB에서 최신 권한을 재조회하므로 최대 5분 내 정합성 자동 복구 |

> **이벤트 신뢰성 티어** ([모듈 아키텍처 §3.3 규칙 3](../../02-architecture/02-module-architecture.md#33-모듈-간-의존성-규칙)): `board.permissions_updated`는 **Important** 티어로 분류한다. 전달 방식은 EventBus(Best-effort)가 아니라 **BullMQ `board.events` 큐 직접 enqueue**이며, 아래 §3.3 전달 계약의 재시도·DLQ로 전달 신뢰성을 확보한다. Auth 쪽 최종 정합성은 **auth 캐시 TTL(5분) 자연 만료** 시 RDB 재조회로 보정되므로, 큐 지연·일시 유실 시에도 최대 5분 내에 수렴한다. 별도 보정 배치(reconciliation)는 구현하지 않는다.

### 3.5 DLQ 모니터링

| 메트릭 | 설명 | 알림 조건 |
|--------|------|-----------|
| `board.events.dlq_count` | `board.events-dlq` 큐 적재 메시지 수 | `> 0`이면 WARN 알림 발송 |

> DLQ 모니터링은 [횡단 관심사 §8](../../02-architecture/07-cross-cutting-concerns.md)의 BullMQ 공통 모니터링 패턴을 따른다.

### 3.6 Redis 타임아웃

| 작업 | 타임아웃 | 폴백 |
|------|----------|------|
| 트리 캐시 읽기 | 200ms | DB 직접 조회 |
| 트리 캐시 쓰기 | 200ms | 쓰기 스킵 (다음 조회 시 재시도) |

---

## 4. 키 패턴 요약

> `redis.md`와 일치를 보장한다.

| 키 패턴 | 타입 | TTL | 용도 |
|---------|------|-----|------|
| `{tenant_id}:cache:board:tree` | String | 1h | 게시판 트리 구조 캐시 |

> AuthModule의 `{tenant_id}:cache:auth:accessible-boards:{user_id}:*` 키는 AuthModule이 소유한다. BoardModule은 이벤트 발행만 담당하며, 캐시 키를 직접 조작하지 않는다.
