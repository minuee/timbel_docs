# BoardModule — RDB 엔티티

> 게시판 CRUD, 운영 설정, 승인 정책, 권한 매핑

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    Board ||--o{ BoardPermission : "1:N"
    Board ||--o{ Board : "self-ref 트리 (parent_id)"

    %% 외부 모듈 참조
    Board }o--o| ApprovalLineTemplate : "default_approval_template_id (ApprovalModule)"
    Role ||--o{ BoardPermission : "1:N (AuthModule)"
    Board ||--o{ Document : "1:N (DocumentModule)"
    Board }o--o| Template : "default_template_id (TemplateModule)"
    Board }o--o| RetentionPolicy : "default_retention_policy_id (DocumentModule)"
```

---

## 2. 엔티티 필드

### 2.1 Board

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(200) | 게시판명 |
| slug | VARCHAR(200) | URL 경로용 식별자 |
| description | TEXT (nullable) | 게시판 설명 |
| board_type | VARCHAR(20) (default 'knowledge') | 게시판 타입: `knowledge`, `community`, `notice`, `custom` (양식·템플릿 분류). CHECK (board_type IN ('knowledge', 'community', 'notice', 'custom')) |
| approval_required | BOOLEAN (nullable) | 승인 필요 여부. null이면 상위 게시판 설정을 상속. 루트 게시판에서는 NOT NULL (기본 false). 하위 게시판은 null(상속) 또는 명시값(오버라이드) |
| versioning_enabled | BOOLEAN (nullable) | 문서 버전 관리 활성화. null이면 상위 게시판 설정을 상속. 승인과 독립적으로 설정 가능 |
| parent_id | UUID (FK → Board, nullable) | 상위 게시판. null이면 최상위 (루트) |
| sort_order | INT (default 0) | 게시판 목록 정렬 순서 |
| is_active | BOOLEAN (default true) | 활성 여부 |
| mandatory_approval_config | JSONB (nullable) | 게시판 필수 승인자 설정. 필수 승인 단계, 자기승인차단, SLA 등을 포함. null이면 상위 게시판 설정 상속. JSON 스키마는 하단 참조 |
| default_approval_template_id | UUID (FK → ApprovalLineTemplate, nullable, ON DELETE SET NULL) | 기본 결재라인 템플릿. 기안자가 승인 요청 시 초기 결재라인으로 제공 |
| default_template_id | UUID (FK → Template, nullable) | 기본 문서 템플릿 |
| default_retention_policy_id | UUID (FK → RetentionPolicy, nullable) | 기본 보존 정책. 설정 시 해당 게시판에 생성되는 문서에 보존 정책 자동 적용 |
| board_config | JSONB (default '{}') | 게시판별 개별 설정. 댓글, 표시, 첨부파일, 알림 등 게시판 운영에 필요한 다양한 설정을 키-값으로 관리. JSON 스키마는 하단 참조 |
| created_by | UUID | 생성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |
| deleted_at | TIMESTAMPTZ (nullable) | 소프트 딜리트 |

#### 제약 조건

- `UNIQUE(slug) WHERE deleted_at IS NULL` — 활성(미삭제) 게시판 내 URL 경로 충돌 방지. 소프트 삭제된 게시판의 slug는 재사용 가능. `slug`는 `[a-z0-9-]` 문자만 허용 (앱 레벨 검증)
- `CHECK (board_type IN ('knowledge', 'community', 'notice', 'custom'))` — 허용된 게시판 타입만
- `CHECK (parent_id IS NOT NULL OR approval_required IS NOT NULL)` — 루트 게시판은 approval_required 필수 (null = 상속이므로 루트는 명시 필요)
- `CHECK (parent_id IS NOT NULL OR versioning_enabled IS NOT NULL)` — 루트 게시판은 versioning_enabled 필수
- `deleted_at`으로 소프트 딜리트 지원 — 소속 문서의 가시성은 BoardModule이 관여하지 않으며, DocumentModule이 `board.deleted_at`을 확인하여 자체 필터링한다
- `parent_id`는 자기 자신을 참조할 수 없다 (앱 레벨 검증 — 순환 참조 방지)
- `ON DELETE RESTRICT` — 하위 게시판이 존재하면 삭제 차단

#### 설계 결정

**운영 설정 직접 FK 패턴 — Board에 정책/설정 FK 통합** ([ADR-010](../../adr/010-board-policy-binding-removal.md))
— Board에 연결되는 정책/설정은 모두 nullable FK로 직접 보유한다. 중간 바인딩 테이블이나 polymorphic 연결 테이블을 사용하지 않는다.

| FK / 필드 | 대상 | 역할 |
|----|------|------|
| `default_approval_template_id` | ApprovalLineTemplate | 기본 결재라인 템플릿 — 기안자 승인 요청 시 초기 결재라인 제공 |
| `default_template_id` | Template | 기본 문서 템플릿 |
| `default_retention_policy_id` | RetentionPolicy | 기본 보존 정책 |

FK가 동일한 패턴(nullable 직접 FK)을 따르므로 구조가 일관된다. 대안 검토 결과는 [ADR-010](../../adr/010-board-policy-binding-removal.md) §4를 참조한다.

**승인/버전 독립 설정**
— 승인(`approval_required`)과 버전 관리(`versioning_enabled`)는 **독립적으로** 설정한다. 4가지 조합 모두 유효한 운영 모드이다.

| approval_required | versioning_enabled | 모드 | 유즈케이스 |
|:---:|:---:|------|------|
| true | true | 승인 + 버전 관리 | 금융권 규정문서 등 엄격한 관리 |
| true | false | 승인만 (게이트 역할) | 일반 공지 관리자 검수, 커뮤니티 검수 |
| false | true | 자유 발행 + 버전 이력 | 위키형 지식베이스 |
| false | false | 완전 자유 | 자유 게시판, 커뮤니티 |

**승인/버전 설정 상속 및 오버라이드**
— 모든 게시판(루트·하위)에서 `approval_required`, `versioning_enabled`, `mandatory_approval_config`를 개별 설정할 수 있다. 하위 게시판의 해당 필드가 null이면 상위 게시판의 설정을 상속한다. 명시적으로 값을 설정하면 상위 설정을 오버라이드한다.

```
function isApprovalRequired(boardId):
  board = Board.find(boardId)
  if board.approval_required is not null:
    return board.approval_required        // 자체 설정 (오버라이드)
  if board.parent_id is null:
    return false                          // 루트인데 null이면 기본값
  return isApprovalRequired(board.parent_id)  // 상위 상속

function isVersioningEnabled(boardId):
  board = Board.find(boardId)
  if board.versioning_enabled is not null:
    return board.versioning_enabled
  if board.parent_id is null:
    return false
  return isVersioningEnabled(board.parent_id)

function getMandatoryApprovalConfig(boardId):
  board = Board.find(boardId)
  if board.mandatory_approval_config is not null:
    return board.mandatory_approval_config  // 오버라이드 (replace, 병합 아님)
  if board.parent_id is null:
    return null
  return getMandatoryApprovalConfig(board.parent_id)
```

**board_type에 따른 초기 설정 시드**
— `board_type`은 게시판 생성 시 기본 설정의 시드 값으로 사용된다. `knowledge` 생성 시 `approval_required = true`, `versioning_enabled = true`. `community` 생성 시 `approval_required = false`, `versioning_enabled = false`. `notice` 생성 시 `approval_required = false`, `versioning_enabled = false`. `custom` 생성 시 사용자가 명시적으로 지정(미지정 시 모두 `false`). 하위 게시판 생성 시 `approval_required = null`, `versioning_enabled = null`(상위 상속). 생성 후에는 관리자가 개별 게시판에서 자유롭게 변경할 수 있다.

**board_type에 따른 에디터 프로파일** *(프론트엔드 참조용)*
— 동일한 블록 에디터 엔진을 사용하되, `board_type`에 따라 프론트엔드에서 노출하는 기능 세트(에디터 프로파일)가 달라진다. DB 스키마 변경 없이 `board_type`에서 파생되는 프론트엔드 설정이므로 별도 컬럼이 불필요하다. 아래 테이블은 **aicm-web 프론트엔드 구현 시 참조**하며, 백엔드 API/DB 스키마에 영향을 주지 않는다.

| 설정 항목 | knowledge | community | notice | custom |
|-----------|-----------|-----------|--------|--------|
| 사용 가능 블록 | 전체 (텍스트, 제목, 목록, 이미지, 표, 코드, 강조 박스, 파일 첨부, 공통 컨텐츠) | 기본 (텍스트, 제목, 목록, 이미지, 파일 첨부) | 전체 (텍스트, 제목, 목록, 이미지, 표, 코드, 강조 박스, 파일 첨부, 공통 컨텐츠) | `board_config`에 따라 동적 결정 |
| `/` 명령 범위 | 전체 블록 + `/공통` 명령 | 기본 블록만 | 전체 블록 + `/공통` 명령 | `board_config`에 따라 동적 결정 |
| AI 글쓰기 개선 | 사용 가능 | 사용 불가 | 사용 가능 | `board_config`에 따라 동적 결정 |
| 문서 양식(템플릿) | 사용 가능 (프리셋 제공) | 사용 불가 | 사용 가능 (프리셋 제공) | 프리셋 없음. 커스텀 템플릿 직접 생성 가능 |
| 승인 + 버전 관리 | `approval_required = true`, `versioning_enabled = true` (기본) | `approval_required = false`, `versioning_enabled = false` (기본) | `approval_required = false`, `versioning_enabled = false` (기본) | 사용자가 개별 지정 (미지정 시 모두 `false`) |
| 태그 | `lm:document.max_tags` 설정값 적용 (standard 기본 10) | `lm:document.max_tags` 설정값 적용 (basic 기본 5) | `lm:document.max_tags` 설정값 적용 (standard 기본 10) | `lm:document.max_tags` 설정값 적용 |
| 유효기간 설정 | 사용 가능 | 사용 불가 | 사용 가능 | `board_config`에 따라 동적 결정 |
| AI 요약 자동 생성 | 사용 가능 | 사용 불가 | 사용 가능 | board_config에서 개별 설정 |

`custom` 타입은 프리셋 에디터 프로파일이 없으며, `board_config`에 따라 동적으로 결정된다. 향후 새로운 `board_type`이 추가되면(예: `qna`) 해당 타입의 에디터 프로파일을 정의하여 대응한다.

**sort_order 필드**
— 관리자가 게시판 목록의 표시 순서를 제어한다. 값이 작을수록 상단에 표시된다. **동일 부모 내 정렬**로 동작한다 — 같은 parent_id를 가진 게시판들 사이의 표시 순서를 제어한다.

**재귀 트리 구조 (parent_id)**
— Board는 재귀 트리 구조를 가진다. `parent_id = NULL`이면 최상위 게시판이며, 기존 Category 역할을 대체한다. 무한 뎁스가 가능하나 앱 레벨에서 UI 표시 깊이를 제한할 수 있다.

**게시판 간 권한 비상속 (BoardPermission)**
— Board 트리에서 부모 게시판의 **BoardPermission**은 자식 게시판에 상속되지 않는다. 각 게시판의 BoardPermission은 완전히 독립적이다. 부모에 권한이 없어도 자식에 접근 가능하며, 트리 구조는 UI 네비게이션(사이드바) 용도일 뿐 권한 계산에 영향을 주지 않는다. 단, `approval_required`, `versioning_enabled`, `mandatory_approval_config`는 null일 때 상위에서 상속된다 (§ 승인/버전 설정 상속 참조).

**게시판 삭제 정책**
— 하위 게시판이 존재하면 물리 삭제(하드 딜리트)를 차단한다(`ON DELETE RESTRICT`). 소프트 딜리트(`deleted_at` 설정) 시에는 하위 게시판도 재귀적으로 소프트 딜리트한다. 게시판 이동(`parent_id` 변경)은 권한에 영향을 주지 않는다.

**default_retention_policy_id (기본 보존 정책)**
— 게시판에 기본 보존 정책을 지정하면 해당 게시판에 생성되는 문서에 `retention_policy_id`가 자동 적용된다 ([FD-DOC](../../01-requirements/features/FD-DOC-문서관리.md) §9). RetentionPolicy·보존 정책 기능이 도입·활성화된 테넌트에서 의미 있다. RetentionPolicy 엔티티는 DocumentModule에서 정의한다 ([document-module.md](../document/data.md) §2.11).

**board_config (게시판별 개별 설정 — JSONB)**
— 게시판마다 운영 방식을 다르게 가져가기 위한 유연한 설정 저장소. FK로 관리하는 정책(승인·템플릿·보존)과 달리, 빈번하게 변경되거나 게시판 유형별로 달라지는 세부 설정을 JSONB로 관리한다. 키가 누락되면 애플리케이션 레벨의 기본값을 사용한다(아래 기본값 참조).

**board_config JSON 스키마**

```jsonc
{
  // ── 댓글 설정 ──
  "comment": {
    "enabled": true,              // 댓글 기능 활성화 여부 (기본: true)
    "anonymous_allowed": false,   // 익명 댓글 허용 여부 (기본: false)
    "max_depth": 3                // 대댓글 최대 깊이 (기본: 3, 0이면 대댓글 불가)
  },

  // ── 게시판 표시 설정 ──
  "display": {
    "list_style": "table",        // 목록 표시 형태: "table" | "card" | "gallery" (기본: "table")
    "items_per_page": 20,         // 페이지당 항목 수 (기본: 20, 범위: 10~100)
    "show_thumbnail": false       // 목록에서 썸네일 표시 여부 (기본: false)
  },

  // ── 첨부파일 설정 ──
  "attachment": {
    "max_file_size_mb": 50,       // 단일 파일 최대 크기 MB (기본: 50)
    "max_total_size_mb": 200,     // 문서당 총 첨부 용량 MB (기본: 200)
    "allowed_extensions": []      // 허용 확장자 (빈 배열이면 시스템 기본 정책 적용)
  },

  // ── 알림 설정 ──
  "notification": {
    "on_new_post": true,          // 새 글 작성 시 알림 (기본: true)
    "on_comment": true            // 댓글 작성 시 알림 (기본: true)
  },

  // ── 글 작성 설정 ──
  "posting": {
    "require_category": false,    // 카테고리(말머리) 필수 여부 (기본: false)
    "categories": [],             // 사용 가능한 카테고리 목록 (예: ["공지", "질문", "자료"])
    "allow_anonymous": false      // 익명 게시 허용 여부 (기본: false)
  },

  // ── 공지 전용 설정 ──
  "notice": {
    "default_popup": false,                  // 새 공지 작성 시 팝업 표시 기본값 (기본: false)
    "default_popup_frequency": "once",       // 팝업 기본 빈도: "once" | "every_login" | "daily" (기본: "once")
    "default_confirmation_required": false,   // 읽음 확인 필수 기본값 (기본: false)
    "default_confirmation_deadline_days": null, // 읽음 확인 기한 기본값 (null이면 기한 없음)
    "max_pinned_count": 5,                   // 게시판당 고정 문서 최대 수 (기본: 5, 범위: 1~20)
    "reminder_days_before": [3, 1],          // 확인 기한 전 리마인더 일수 (기본: [3, 1])
    "overdue_reminder_interval_hours": 24,   // 기한 초과 리마인더 간격 시간 (기본: 24)
    "allowed_notification_channels": ["inapp", "email"], // 허용 알림 채널 (기본: ["inapp", "email"])
    "include_in_rag": false                  // AI 답변 검색 포함 여부 (기본: false)
  },

  // ── 크로스보드 공지 배너 수신 (모든 board_type에서 유효, FD-NTC §1.3) ──
  "banner": {
    "show_cross_board_banner": true,        // 이 게시판에서 크로스보드 공지 배너 표시 여부 (기본: true)
    "max_banner_count": 3                   // 동시 표시 배너 최대 건수 (기본: 3, 범위: 1~10)
  }
}
```

**`notice` 그룹 적용 범위** — `board_config.notice`는 `board_type = 'notice'`인 게시판에서만 동작에 반영된다. `knowledge`·`community`·`custom` 등 다른 타입에서는 동일 키가 있어도 **저장은 허용**(유효한 JSON·스키마 통과 시)하되, 런타임에서는 **무시**한다. 비즈니스 규칙: [BR-BRD-017](rules.md#br-brd-017-board_config-검증) 동작 5항.

모든 키는 선택적(optional)이다. 설정하지 않은 키는 앱 레벨에서 위 기본값을 적용한다. `board_config = '{}'`이면 모든 항목이 기본값으로 동작한다.

**mandatory_approval_config (게시판 필수 승인자 설정 — JSONB)**
— `approval_required = true`인 게시판에서 모든 승인 건에 반드시 포함되어야 하는 승인자/단계와 승인 정책 옵션을 설정한다. null이면 상위 게시판 설정 상속 (오버라이드 시 상위를 대체). 기안자는 필수 승인자를 제거하거나 변경할 수 없다.

```jsonc
{
  // ── 필수 승인 단계 ──
  "mandatory_steps": [
    {
      "name": "팀장 승인",                    // 단계 이름
      "approver_source": "ROLE",              // USER | ROLE | TEAM
      "approver_target": "team_leader",       // 역할명, 팀ID, 또는 사용자 UUID 배열
      "approval_type": "ANY",                 // ANY | ALL | COUNT
      "required_count": null,                 // COUNT일 때 정족수
      "position": "FIRST"                     // FIRST: 반드시 첫 단계, LAST: 반드시 마지막, ANY: 위치 자유
    },
    {
      "name": "준법감시 승인",
      "approver_source": "USER",
      "approver_target": ["uuid-준법감시관"],
      "approval_type": "ALL",
      "required_count": null,
      "position": "LAST"
    }
  ],

  // ── 승인 정책 옵션 ──
  "self_approve_blocked": true,               // 자기 승인 차단 (기본: true)
  "delegation_allowed": true,                 // 위임 허용 (기본: true)
  "sla_hours": null,                          // 승인 처리 기한 시간 (null이면 기한 없음)
  "auto_reject_grace_hours": 24,              // SLA 초과 유예 시간 (기본: 24)

  // ── 기안자 결재라인 제약 ──
  "min_steps": 1,                             // 기안자 결재라인 최소 단계 수 (기본: 1)
  "max_steps": 5                              // 기안자 결재라인 최대 단계 수 (null이면 무제한, 기본: null)
}
```

**board_config 접근 패턴**

```
function getCommentConfig(board):
  defaults = { enabled: true, anonymous_allowed: false, max_depth: 3 }
  return merge(defaults, board.board_config?.comment ?? {})
```

**board_config vs FK 정책 구분 기준**

| 구분 | FK (직접 참조) | board_config (JSONB) |
|------|---------------|---------------------|
| 대상 | 독립 엔티티로 관리되는 정책 (승인·템플릿·보존) | 게시판 종속적인 운영 세부 설정 |
| 참조 무결성 | DB 레벨 보장 | 앱 레벨 검증 |
| 변경 빈도 | 낮음 (정책 전환) | 높음 (운영 중 수시 조정) |
| 공유 | 여러 게시판이 동일 정책 참조 가능 | 게시판별 독립 |

---

### 2.2 BoardPermission

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| board_id | UUID (FK → Board) | 대상 게시판 |
| role_id | UUID (FK → Role) | 대상 역할 |
| action | VARCHAR(10) | 허용 액션: `VIEW`, `EDIT`, `APPROVE` |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(board_id, role_id, action)` — 동일 Role-Board-Action 조합 중복 방지
- `CHECK (action IN ('VIEW', 'EDIT', 'APPROVE'))` — 허용된 액션만

#### 설계 결정

**Role-Board-Action 3원 매핑**
— 게시판에 Role 단위로 action을 할당한다. VIEW=열람, EDIT=작성/수정/삭제, APPROVE=타인이 작성한 문서의 승인/반려. 규모: 게시판 10 × Role 10 × action 3 = 약 300건.

**updated_at 없음**
— UserRole과 동일하게 추가/삭제만 존재하며 수정 개념이 없다.

---

## 3. DDL 및 인덱스

### 3.1 Board

```sql
CREATE TABLE board (
  id                          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                        VARCHAR(200) NOT NULL,
  slug                        VARCHAR(200) NOT NULL,
  description                 TEXT,
  board_type                  VARCHAR(20) NOT NULL DEFAULT 'knowledge',
  approval_required           BOOLEAN,
  versioning_enabled          BOOLEAN,
  parent_id                   UUID REFERENCES board(id) ON DELETE RESTRICT,
  sort_order                  INT NOT NULL DEFAULT 0,
  is_active                   BOOLEAN NOT NULL DEFAULT true,
  mandatory_approval_config   JSONB,
  default_approval_template_id UUID REFERENCES approval_line_template(id) ON DELETE SET NULL,
  default_template_id         UUID REFERENCES template(id) ON DELETE SET NULL,
  default_retention_policy_id UUID REFERENCES retention_policy(id) ON DELETE SET NULL,
  board_config                JSONB NOT NULL DEFAULT '{}',
  created_by                  UUID NOT NULL,
  created_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at                  TIMESTAMPTZ,

  CONSTRAINT chk_board_type CHECK (board_type IN ('knowledge', 'community', 'notice', 'custom')),
  CONSTRAINT chk_root_approval_required CHECK (parent_id IS NOT NULL OR approval_required IS NOT NULL),
  CONSTRAINT chk_root_versioning_enabled CHECK (parent_id IS NOT NULL OR versioning_enabled IS NOT NULL)
);

-- 소프트 삭제된 게시판의 slug 재사용을 허용하기 위해 partial unique index 사용
CREATE UNIQUE INDEX uq_board_slug_active
  ON board (slug)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_board_active
  ON board (is_active, sort_order)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_board_parent
  ON board (parent_id, sort_order)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_board_approval_template
  ON board (default_approval_template_id)
  WHERE default_approval_template_id IS NOT NULL;

CREATE INDEX idx_board_retention
  ON board (default_retention_policy_id)
  WHERE default_retention_policy_id IS NOT NULL;

CREATE INDEX idx_board_config
  ON board USING GIN (board_config jsonb_path_ops)
  WHERE deleted_at IS NULL;
```

### 3.2 BoardPermission

```sql
CREATE TABLE board_permission (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id   UUID NOT NULL REFERENCES board(id) ON DELETE CASCADE,
  role_id    UUID NOT NULL REFERENCES role(id) ON DELETE CASCADE,
  action     VARCHAR(10) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_board_permission UNIQUE (board_id, role_id, action),
  CONSTRAINT chk_permission_action CHECK (action IN ('VIEW', 'EDIT', 'APPROVE'))
);

CREATE INDEX idx_board_permission_board
  ON board_permission (board_id);

CREATE INDEX idx_board_permission_role
  ON board_permission (role_id);
```

### 3.3 재귀 CTE 쿼리 패턴

게시판 트리 연산에 사용하는 PostgreSQL `WITH RECURSIVE` 패턴.

#### 하위 게시판 전체 조회 (descendants)

```sql
WITH RECURSIVE descendants AS (
  SELECT id, parent_id, name, 1 AS depth
  FROM board
  WHERE id = :boardId AND deleted_at IS NULL

  UNION ALL

  SELECT b.id, b.parent_id, b.name, d.depth + 1
  FROM board b
  INNER JOIN descendants d ON b.parent_id = d.id
  WHERE b.deleted_at IS NULL AND d.depth < 20  -- safeguard
)
SELECT id FROM descendants;
```

#### 재귀 소프트 삭제

```sql
WITH RECURSIVE target_boards AS (
  SELECT id, 1 AS depth FROM board WHERE id = :boardId

  UNION ALL

  SELECT b.id, t.depth + 1
  FROM board b
  INNER JOIN target_boards t ON b.parent_id = t.id
  WHERE b.deleted_at IS NULL AND t.depth < 20  -- safeguard: 무한 루프 방지
)
UPDATE board SET deleted_at = now()
WHERE id IN (SELECT id FROM target_boards);
```

> **safeguard**: descendants CTE와 동일하게 `depth < 20` 조건을 포함하여, 데이터 오염(순환 참조)이 발생해도 무한 루프에 빠지지 않도록 한다. 운영 권장 최대 깊이는 10이다.

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [auth-module.md](../auth/data.md) — Role, UserRole, AdminPermission, Team, TeamRole (BoardPermission이 참조)
- [document-module.md](../document/data.md) — Document (Board가 소유), RetentionPolicy (Board.default_retention_policy_id가 참조)
- [template-module.md](../template/data.md) — Template (Board.default_template_id가 참조)
- [approval-module.md](../approval/data.md) — ApprovalLineTemplate (Board.default_approval_template_id가 참조)
- [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) — 3계층 권한 모델
- [ADR-010](../../adr/010-board-policy-binding-removal.md) — BoardPolicyBinding 제거 및 Board 직접 FK 전환 의사결정
