# Board API 스펙

> 기능정의서: [FD-DOC-문서관리 §7](../../01-requirements/features/FD-DOC-문서관리.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [board-module.md](./data.md)

> 에러 응답은 [횡단 관심사 §8.2.1](../../02-architecture/07-cross-cutting-concerns.md)의 공통 에러 응답 포맷(`{ error, message, details? }`)을 따른다. 도메인 에러 코드(`BRD_*`)는 `error` 필드에 포함된다.

> **응답 형식**: 모든 응답은 [횡단 관심사 §8.4](../../02-architecture/07-cross-cutting-concerns.md)의 공통 래퍼 `{ data, meta, pagination }` 형식을 따른다. 본 문서의 DTO 인터페이스(`PaginatedResponse` 등)는 래퍼의 `data` 필드 내부 구조만 기술한다 — 래퍼 자체는 전역 ResponseInterceptor가 자동 적용하므로 모듈 스펙에서는 비즈니스 데이터 구조에 집중한다.

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| POST | /boards | 게시판 생성 | ADMIN (`manage_boards`) |
| GET | /boards | 게시판 목록 조회 | 인증 필요 |
| GET | /boards/tree | 게시판 트리 조회 | 인증 필요 |
| GET | /boards/:id | 게시판 상세 조회 | 인증 필요 |
| PATCH | /boards/:id | 게시판 수정 | ADMIN (`manage_boards`) |
| DELETE | /boards/:id | 게시판 삭제 | ADMIN (`manage_boards`) |
| POST | /boards/:id/restore | 삭제 복구 | ADMIN (`manage_boards`) |
| PATCH | /boards/:id/move | 게시판 이동 (parent 변경) | ADMIN (`manage_boards`) |
| GET | /boards/:id/permissions | 게시판 권한 목록 조회 | ADMIN (`manage_boards`) |
| PUT | /boards/:id/permissions | 게시판 권한 설정 (전체 교체) | ADMIN (`manage_boards`) |
| GET | /boards/:id/descendants | 하위 게시판 ID 목록 조회 | VIEW |

---

## 상세 API

### `POST` /boards

**설명**: 새 게시판을 생성한다. `board_type`에 따라 초기 설정이 시드된다.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Body:

```typescript
interface CreateBoardDto {
  name: string;                          // 필수 — 게시판명 (max 200자)
  slug: string;                          // 필수 — URL 경로용 식별자 (max 200자, unique). 허용 문자: [a-z0-9-] (소문자 영문, 숫자, 하이픈). 입력값은 소문자 정규화 후 저장
  description?: string;                  // 선택 — 게시판 설명
  boardType?: BoardType;                 // 선택 — 기본 'knowledge'
  approvalRequired?: boolean | null;     // 선택 — 모든 깊이에서 설정 가능. null 또는 미지정 시 컬럼 null 저장 후 상위 상속(하위). 루트는 DB 제약상 반드시 명시값으로 저장되며, 미지정 시 board_type 시드 기본값 적용
  versioningEnabled?: boolean | null;    // 선택 — 동일. `approvalRequired`와 독립
  parentId?: string;                     // 선택 — 상위 게시판 UUID (null이면 최상위)
  sortOrder?: number;                    // 선택 — 정렬 순서 (기본 0)
  mandatoryApprovalConfig?: Record<string, unknown> | null;  // 선택 — 필수 승인 구성(JSON). null 또는 미지정 시 컬럼 null 저장 후 상위 상속. 루트는 시드·본문 값 적용
  defaultApprovalTemplateId?: string | null;  // 선택 — 기본 결재라인 템플릿 UUID (미지정 시 board_type 기본값)
  defaultTemplateId?: string;            // 선택 — 기본 템플릿 UUID
  defaultRetentionPolicyId?: string;     // 선택 — 기본 보존 정책 UUID
  boardConfig?: BoardConfig;             // 선택 — 게시판별 개별 설정 (미지정 시 빈 객체 {})
}
```

**Response** (`201`):

```typescript
interface BoardResponse {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  boardType: BoardType;
  /** DB 저장 원본 — `null`이면 이 행에서는 상위 체인 상속(컬럼 미오버라이드). 목록·트리 DTO에는 본 필드 없이 유효값만 반환 */
  approvalRequired: boolean | null;
  /** 상속 체인 해석 후 실제 적용되는 승인 필요 여부 — 목록(`BoardListItem`)·트리(`BoardTreeNode`)의 `approvalRequired`는 본 필드와 동일 의미(유효값만) */
  effectiveApprovalRequired: boolean;
  /** DB 저장 원본 — `null`이면 상위 상속. `approvalRequired`와 동일 패턴 */
  versioningEnabled: boolean | null;
  /** 상속 해석 후 유효값 — 목록·트리의 `versioningEnabled`는 본 필드와 동일 의미 */
  effectiveVersioningEnabled: boolean;
  parentId: string | null;
  sortOrder: number;
  isActive: boolean;
  mandatoryApprovalConfig: Record<string, unknown> | null;
  defaultApprovalTemplateId: string | null;
  defaultTemplateId: string | null;
  defaultRetentionPolicyId: string | null;
  boardConfig: BoardConfig;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
}
```

**비즈니스 규칙 참조**: [BR-BRD-001](rules.md#br-brd-001-게시판-생성), [BR-BRD-005](rules.md#br-brd-005-board_type-초기-설정-시드), [BR-BRD-017](rules.md#br-brd-017-board_config-검증)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-BRD-001](rules.md#br-brd-001-게시판-생성) |
| BRD_SLUG_DUPLICATE | 409 | [BR-BRD-009](rules.md#br-brd-009-slug-고유성) |
| BRD_PARENT_NOT_FOUND | 404 | [BR-BRD-001](rules.md#br-brd-001-게시판-생성) |
| BRD_INVALID_BOARD_CONFIG | 400 | [BR-BRD-017](rules.md#br-brd-017-board_config-검증) |

---

### `GET` /boards

**설명**: 게시판 목록을 조회한다. 삭제되지 않은 활성 게시판만 반환. 게시판 목록은 테넌트당 100개 이하로 운영되며, 오프셋 기반 페이지네이션이 실무적으로 적합하다. 프로젝트 표준(커서 기반)의 의식적 예외이다.

**권한**: 인증된 테넌트 사용자만 접근 가능 (VIEW 불필요 — 게시판 목록 자체는 인증된 사용자에게 공개, 문서 접근 시 BoardPermission 평가)

**Request**:

- Query params:

```typescript
interface ListBoardsQuery {
  parentId?: string | 'root';      // 미전달: 전체 게시판 반환, 'root': 최상위(parent_id IS NULL)만, UUID: 해당 부모의 직계 자식만
  boardType?: BoardType;                   // 타입 필터
  isActive?: boolean;              // 활성 상태 필터
  defaultTemplateId?: string;      // 특정 템플릿을 기본 템플릿으로 사용하는 게시판 필터링
  includeDeleted?: boolean;        // 관리자 전용 — 삭제된 게시판 포함
  sort?: 'sortOrder' | 'name' | 'createdAt';
  order?: 'ASC' | 'DESC';
  page?: number;                   // 기본 1
  limit?: number;                  // 기본 50, 최대 200
}
```

> **parentId 의미론**: 쿼리 파라미터 미전달 시 전체 게시판을 반환한다. `parentId=root`는 최상위 게시판(parent_id IS NULL)만 반환하며, UUID 값 전달 시 해당 부모의 직계 자식만 반환한다.

**Response** (`200`):

```typescript
// 목록 응답 — 래퍼의 data 필드 내부 구조 (공통 래퍼 적용 후: { data: PaginatedResponse<BoardListItem>, meta, pagination })
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

// 목록용 — 경량 + 집계 필드 (상세 조회의 운영 설정·관리 필드 제외)
interface BoardListItem {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  boardType: BoardType;
  approvalRequired: boolean;         // 유효값(상속 해석 후)
  versioningEnabled: boolean;        // 유효값(상속 해석 후)
  parentId: string | null;
  sortOrder: number;
  isActive: boolean;
  defaultApprovalTemplateId: string | null;
  documentCount: number;
  childCount: number;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;         // includeDeleted=true 시 소프트 삭제된 게시판 포함. 미삭제 게시판은 null
}
```

---

### `GET` /boards/tree

**설명**: 전체 게시판을 트리 구조로 조회한다. 사이드바 네비게이션용.

**권한**: 인증 필요

**Request**:

- Query params:

```typescript
interface BoardTreeQuery {
  rootId?: string;               // 특정 게시판을 루트로 한 서브트리 (미지정 시 전체)
  maxDepth?: number;             // 최대 깊이 제한 (미지정 시 서버 기본값 10). 서버 최대 깊이(10)를 초과하는 값은 10으로 클램핑
  includeInactive?: boolean;     // 비활성 게시판 포함 (관리자 전용)
}
```

> **maxDepth 클램핑**: `maxDepth` 값이 서버 측 최대 깊이(10)를 초과하면 별도 에러 없이 10으로 클램핑한다. CTE safeguard(20)와는 별개이며, 운영 권장 깊이 내에서 응답을 보장하기 위한 조치이다.

**Response** (`200`):

```typescript
interface BoardTreeNode {
  id: string;
  name: string;
  slug: string;
  boardType: BoardType;
  approvalRequired: boolean;         // 유효값(상속 해석 후)
  versioningEnabled: boolean;        // 유효값(상속 해석 후)
  parentId: string | null;
  sortOrder: number;
  isActive: boolean;
  defaultApprovalTemplateId: string | null;
  documentCount: number;
  children: BoardTreeNode[];
}
```

---

### `GET` /boards/:id

**설명**: 게시판 상세 정보를 조회한다. **소프트 삭제**(`deleted_at` 설정)된 게시판은 기본적으로 존재하지 않는 것으로 보아 **`404`**(`BRD_BOARD_NOT_FOUND`)를 반환한다. **ADMIN**(`manage_boards`) 역할일 때만 쿼리 **`?includeDeleted=true`** 를 주면 삭제된 게시판도 조회할 수 있다(복구·감사 UI 등).

**권한**: 인증 필요

**Request**:

- Path params: `id` — 게시판 UUID
- Query params:

```typescript
interface GetBoardByIdQuery {
  /** true이면 소프트 삭제된 행도 반환 — ADMIN(`manage_boards`) 전용 */
  includeDeleted?: boolean;
}
```

**Response** (`200`): `BoardResponse` — 상세 응답은 `approvalRequired`·`versioningEnabled`(원본, `null`=상속)와 `effectiveApprovalRequired`·`effectiveVersioningEnabled`(유효값)를 **모두** 포함한다. 목록·트리는 유효값만(`BoardListItem`·`BoardTreeNode`의 boolean 필드) 노출한다.

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| BRD_BOARD_NOT_FOUND | 404 | 존재하지 않음 또는 소프트 삭제(비관리자·`includeDeleted` 미사용) |

---

### `PATCH` /boards/:id

**설명**: 게시판 정보를 수정한다. 운영 설정(필수 승인 구성, 기본 결재라인 템플릿, 기본 문서 템플릿, 기본 보존 정책) 변경을 포함한다.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Body:

```typescript
interface UpdateBoardDto {
  name?: string;                          // max 200자
  slug?: string;                          // max 200자, unique. 허용 문자: [a-z0-9-]
  description?: string | null;
  sortOrder?: number;
  isActive?: boolean;
  approvalRequired?: boolean | null;      // 모든 게시판 — boolean은 오버라이드, null은 상위 상속으로 되돌림(컬럼 null 저장)
  versioningEnabled?: boolean | null;     // 모든 게시판 — 동일
  mandatoryApprovalConfig?: Record<string, unknown> | null;  // null 저장 시 상위 상속으로 되돌림
  defaultApprovalTemplateId?: string | null;
  defaultTemplateId?: string | null;
  defaultRetentionPolicyId?: string | null;
  boardConfig?: BoardConfig;              // 부분 업데이트 — 전달된 최상위 키만 deep-merge. 예: { comment: { enabled: false } }는 comment 그룹만 병합하고 나머지 그룹은 유지
  expectedUpdatedAt?: string;             // OCC용 — 클라이언트가 마지막으로 조회한 updatedAt. 불일치 시 409 BRD_CONCURRENT_MODIFICATION 반환
}
```

**Response** (`200`): `BoardResponse`

**비즈니스 규칙 참조**: [BR-BRD-006](rules.md#br-brd-006-승인결재라인버전-규칙) — `approvalRequired` 해제·`mandatoryApprovalConfig`·`defaultApprovalTemplateId` 변경 시 in-flight 문서 차단 등, [BR-BRD-009](rules.md#br-brd-009-slug-고유성), [BR-BRD-013](rules.md#br-brd-013-게시판-활성비활성-전환) — `isActive` 변경 시. 데이터 아키텍처 Board.is_active 필드 기반, [BR-BRD-014](rules.md#br-brd-014-board_type-불변-규칙), [BR-BRD-017](rules.md#br-brd-017-board_config-검증) — `boardConfig` 변경 시 스키마 검증

**오케스트레이션 (승인·결재라인 설정 변경 시)**: BoardModule은 Layer 1 독립 모듈이므로 DocumentModule을 직접 DI 의존하지 않는다. `approvalRequired`를 false로 바꾸거나 `mandatoryApprovalConfig`·`defaultApprovalTemplateId`를 바꿀 때 등 BR-BRD-006이 요구하는 경우 pending_review 문서 확인은 Controller 레벨에서 오케스트레이션한다:

```mermaid
sequenceDiagram
    participant Admin as 관리자
    participant BC as BoardController
    participant DS as DocumentService
    participant BS as BoardService
    participant Cache as Redis

    Admin->>BC: PATCH /boards/:id { approvalRequired, mandatoryApprovalConfig, defaultApprovalTemplateId, ... }
    BC->>BC: BR-BRD-006 해당 변경 감지
    BC->>DS: pending_review 집계(대상 게시판 + 하위 board id)
    DS-->>BC: pendingCount
    alt pendingCount > 0
        BC-->>Admin: 409 BRD_MODE_TRANSITION_BLOCKED { pendingCount }
    else pendingCount == 0
        BC->>BS: update(id, dto)
        BS->>Cache: DEL board:tree 캐시
        BS-->>BC: updatedBoard
        BC-->>Admin: 200 BoardResponse
    end
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| BRD_BOARD_NOT_FOUND | 404 | — |
| BRD_SLUG_DUPLICATE | 409 | [BR-BRD-009](rules.md#br-brd-009-slug-고유성) |
| BRD_MODE_TRANSITION_BLOCKED | 409 | [BR-BRD-006](rules.md#br-brd-006-승인결재라인버전-규칙) |
| BRD_CONCURRENT_MODIFICATION | 409 | [BR-BRD-015](rules.md#br-brd-015-낙관적-동시성-제어) |
| BRD_INVALID_BOARD_CONFIG | 400 | [BR-BRD-017](rules.md#br-brd-017-board_config-검증) |

**`BRD_MODE_TRANSITION_BLOCKED` 에러 응답 본문**:

```typescript
interface ModeTransitionBlockedError {
  statusCode: 409;
  errorCode: 'BRD_MODE_TRANSITION_BLOCKED';
  message: string;
  details: {
    pendingCount: number;
    boardId: string;
  };
}
```

---

### `DELETE` /boards/:id

**설명**: 게시판을 소프트 삭제한다. 소프트 삭제 시 하위 게시판도 재귀적으로 소프트 삭제된다.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Path params: `id` — 게시판 UUID

**Response** (`200`):

> 소프트 삭제이므로 `deletedAt` 정보를 반환하기 위해 200 + body를 사용한다. 물리 삭제가 아닌 상태 변경 특성상 204 No Content보다 클라이언트에 유의미한 응답을 제공한다.

```typescript
interface DeleteBoardResponse {
  id: string;
  deletedAt: string;
  deletedDescendantCount: number;  // 재귀 삭제된 하위 게시판 수
}
```

**비즈니스 규칙 참조**: [BR-BRD-004](rules.md#br-brd-004-게시판-소프트-삭제-정책), [BR-BRD-010](rules.md#br-brd-010-소프트-삭제-시-하위-재귀-처리)

**재귀 삭제 흐름**:

```mermaid
sequenceDiagram
    participant Admin as 관리자
    participant BC as BoardController
    participant BS as BoardService
    participant DB as PostgreSQL
    participant Cache as Redis

    Admin->>BC: DELETE /boards/:id
    BC->>BS: softDelete(id)
    BS->>DB: WITH RECURSIVE CTE<br/>하위 게시판 재귀 탐색 + UPDATE deleted_at
    DB-->>BS: affectedCount
    BS->>Cache: DEL board:tree 캐시
    BS-->>BC: { id, deletedAt, deletedDescendantCount }
    BC-->>Admin: 200 DeleteBoardResponse
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| BRD_BOARD_NOT_FOUND | 404 | — |

---

### `POST` /boards/:id/restore

**설명**: 소프트 삭제된 게시판을 복구한다. 하위 게시판도 재귀적으로 복구된다. 데이터 아키텍처 Board.deleted_at 소프트 삭제 설계 기반.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Path params: `id` — 게시판 UUID

**Response** (`200`): `BoardResponse`

**비즈니스 규칙 참조**: [BR-BRD-012](rules.md#br-brd-012-게시판-복구)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-BRD-012](rules.md#br-brd-012-게시판-복구) |
| BRD_BOARD_NOT_FOUND | 404 | — |
| BRD_NOT_DELETED | 409 | [BR-BRD-012](rules.md#br-brd-012-게시판-복구) |

---

### `PATCH` /boards/:id/move

**설명**: 게시판을 다른 부모 아래로 이동한다. 권한에 영향 없음.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Body:

```typescript
interface MoveBoardDto {
  parentId: string | null;        // 필수 — 새 부모 게시판 UUID (null이면 최상위로 이동)
  sortOrder?: number;             // 선택 — 이동 후 정렬 순서
}
```

**Response** (`200`): `BoardResponse`

**비즈니스 규칙 참조**: [BR-BRD-002](rules.md#br-brd-002-순환-참조-방지), [BR-BRD-008](rules.md#br-brd-008-게시판-이동)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| BRD_BOARD_NOT_FOUND | 404 | — |
| BRD_PARENT_NOT_FOUND | 404 | [BR-BRD-002](rules.md#br-brd-002-순환-참조-방지) |
| BRD_CIRCULAR_REFERENCE | 409 | [BR-BRD-002](rules.md#br-brd-002-순환-참조-방지) |

---

### `GET` /boards/:id/permissions

**설명**: 게시판의 Role-Action 권한 매핑 목록을 조회한다.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Path params: `id` — 게시판 UUID

**Response** (`200`):

```typescript
interface BoardPermissionResponse {
  id: string;
  boardId: string;
  roleId: string;
  roleName: string;
  action: 'VIEW' | 'EDIT' | 'APPROVE';
  createdAt: string;
}
```

---

### `PUT` /boards/:id/permissions

**설명**: 게시판의 권한 매핑을 설정한다 (전체 교체). 기존 매핑을 삭제하고 새 매핑으로 대체.

**권한**: ADMIN (`manage_boards`)

**Request**:

- Body:

```typescript
interface SetBoardPermissionsDto {
  permissions: BoardPermissionEntry[];
}

interface BoardPermissionEntry {
  roleId: string;                        // 역할 UUID
  action: 'VIEW' | 'EDIT' | 'APPROVE';  // 허용 액션
}
```

**Response** (`200`): `BoardPermissionResponse[]`

**비즈니스 규칙 참조**: [BR-BRD-007](rules.md#br-brd-007-role-board-action-3원-매핑)

**권한 전체 교체 + 캐시 무효화 흐름**:

```mermaid
sequenceDiagram
    participant Admin as 관리자
    participant BC as BoardController
    participant BS as BoardService
    participant DB as PostgreSQL
    participant BQ as "BullMQ board.events 큐"
    participant Auth as AuthModule

    Admin->>BC: PUT /boards/:id/permissions
    BC->>BS: setPermissions(id, permissions)
    BS->>DB: BEGIN TX
    BS->>DB: DELETE FROM board_permission WHERE board_id = :id
    BS->>DB: INSERT board_permission (bulk)
    BS->>DB: COMMIT
    BS->>BQ: enqueue board.permissions_updated
    BS-->>BC: BoardPermissionResponse[]
    BC-->>Admin: 200

    Note over BQ,Auth: 비동기 처리
    BQ->>Auth: consume → board.permissions_updated
    Auth->>DB: 영향받는 사용자 목록 조회 (RDB 직접)
    Auth->>Auth: cache:auth:accessible-boards 캐시 무효화
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| BRD_BOARD_NOT_FOUND | 404 | — |
| BRD_ROLE_NOT_FOUND | 404 | [BR-BRD-007](rules.md#br-brd-007-role-board-action-3원-매핑) |
| BRD_DUPLICATE_PERMISSION | 409 | [BR-BRD-007](rules.md#br-brd-007-role-board-action-3원-매핑) |

---

### `GET` /boards/:id/descendants

**설명**: 특정 게시판의 하위 트리에 속한 모든 게시판 ID를 반환한다. 크로스보드 문서 조회 시 검색 필터용으로 DocumentModule 등이 호출한다.

**권한**: VIEW (해당 게시판에 대한 VIEW 권한)

**비즈니스 규칙 참조**: [BR-BRD-003](rules.md#br-brd-003-설계-원칙-게시판-간-권한-비상속) — 하위 게시판 ID 반환 시 각 게시판의 권한은 독립 평가

**Request**:

- Path params: `id` — 기준 게시판 UUID
- Query params:

```typescript
interface GetDescendantsQuery {
  includeRoot?: boolean;          // 기준 게시판 자신을 포함할지 (기본 true)
  activeOnly?: boolean;           // 활성 게시판만 (기본 true)
}
```

**Response** (`200`):

```typescript
interface DescendantBoardIdsResponse {
  boardIds: string[];
}
```

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **Board 도메인 에러** 전체 목록은 [rules.md §3 에러 코드 카탈로그](rules.md#3-에러-코드-카탈로그) 참조

---

## 공통 타입

```typescript
type BoardType = 'knowledge' | 'community' | 'notice' | 'custom';
type BoardAction = 'VIEW' | 'EDIT' | 'APPROVE';

interface BoardConfig {
  comment?: {
    enabled?: boolean;              // 기본: true
    anonymousAllowed?: boolean;     // 기본: false
    maxDepth?: number;              // 기본: 3 (0이면 대댓글 불가, 범위: 0~10)
  };
  display?: {
    listStyle?: 'table' | 'card' | 'gallery';  // 기본: 'table'
    itemsPerPage?: number;          // 기본: 20 (범위: 10~100)
    showThumbnail?: boolean;        // 기본: false
  };
  attachment?: {
    maxFileSizeMb?: number;         // 기본: 50
    maxTotalSizeMb?: number;        // 기본: 200
    allowedExtensions?: string[];   // 빈 배열이면 시스템 기본 정책 적용
  };
  notification?: {
    onNewPost?: boolean;            // 기본: true
    onComment?: boolean;            // 기본: true
  };
  posting?: {
    requireCategory?: boolean;      // 기본: false
    categories?: string[];          // 사용 가능한 카테고리 목록
    allowAnonymous?: boolean;       // 기본: false
  };
  /** 공지 게시판·공지 문서 UX (board_type notice 등) — [data.md](./data.md) board_config JSON 스키마와 동일 의미 */
  notice?: {
    defaultPopup?: boolean;                    // 기본: false
    defaultPopupFrequency?: 'once' | 'every_login' | 'daily';  // 기본: 'once'
    defaultConfirmationRequired?: boolean;     // 기본: false
    defaultConfirmationDeadlineDays?: number | null;  // null이면 기한 없음
    maxPinnedCount?: number;                   // 기본: 5, 범위: 1~20
    reminderDaysBefore?: number[];             // 기본: [3, 1]
    overdueReminderIntervalHours?: number;     // 기본: 24
    allowedNotificationChannels?: string[];    // 기본: ['inapp', 'email']
    includeInRag?: boolean;                    // 기본: false
  };
  banner?: {
    showCrossBoardBanner?: boolean;   // 기본: true — 이 게시판에서 크로스보드 공지 배너를 표시할지 여부
    maxBannerCount?: number;          // 기본: 3 (범위: 1~10) — 동시에 표시할 배너 최대 건수
  };
}
```

---

## BullMQ 이벤트 (`board.events`)

> 권한 무효화 전용 `board.permissions_updated` 계약은 [cache.md](./cache.md) §3과 동일하다. 본 절은 게시판 라이프사이클·설정 동기화용 이벤트를 정의한다.

### 전달·운영 공통

| 항목 | 값 |
|------|-----|
| 큐 | `board.events` |
| DLQ | `board.events-dlq` |
| 재시도 | 기본 3회, 지수 백오프(초기 1초, 배율 ×2, 상한 30초) — [cache.md](./cache.md) §3.3과 동일 |
| 멱등성 | 소비자는 아래 **멱등성 키**로 중복 처리 방지. 동일 키 재전달은 no-op 또는 동일 결과로 처리 |

### 감사 로그 매핑 ([audit-log/data.md](../audit-log/data.md) §2.1)

BullMQ `board.events`의 `eventType`과 감사 로그 `AuditLog.action`의 대응이다. RDB `action` 값은 data.md «관리자 액션 도메인»을 따른다. 네임스페이스 구분·대시보드 표기용으로 동일 계열을 `admin.board.*`로 지칭하기도 한다.

| `eventType` | `AuditLog.action` | 별칭(참고) | 비고 |
|-------------|-------------------|------------|------|
| `board.created` | `board.created` | `admin.board.created` | — |
| `board.updated` | `board.updated` | `admin.board.updated` | 일반 메타/설정 PATCH |
| `board.deleted` | `board.deleted` | `admin.board.deleted` | — |
| `board.restored` | `board.restored` | `admin.board.restored` | `POST /boards/:id/restore` 커밋 후 enqueue |
| `board.moved` | `board.updated` | `admin.board.updated` | **동일 감사 액션** — 페이로드 `changedFields`에 **`parent_id`** 포함(이동은 parent 변경으로 기록) |
| `board.toggled` | `board.updated` | `admin.board.updated` | **동일 감사 액션** — `changedFields`에 **`is_active`** 포함(활성/비활성 전환) |
| `board.permissions_updated` | `board.permissions_updated` | `admin.board.permissions_updated` | **별도 이벤트·별도 감사 액션** — `board.config_updated`에 **포함하지 않음**(권한은 `board_config` JSONB와 무관) |

> 구현 선택: BullMQ에서 `board.moved` / `board.toggled`를 **독립 `eventType`으로 enqueue**하되, 감사 로그 소비자는 위와 같이 `board.updated` 계열로 정규화하거나, 동일 스키마의 `board.updated` 한 종류만 쓰고 `changedFields`로만 구분해도 된다.

### 공통 래퍼 (모든 작업)

```typescript
interface BoardEventEnvelope<T extends string, P> {
  eventType: T;
  /** 발행 시각(ISO-8601) */
  occurredAt: string;
  tenantId: string;
  boardId: string;
  /** 멱등성 키 — 소비자 유일 처리 기준 */
  idempotencyKey: string;
  schemaVersion: 1;
  payload: P;
}
```

멱등성 키 권장 형식: `` `${eventType}:${boardId}:${correlationId}` `` — `correlationId`는 해당 상태 전이당 1회 발급되는 UUID(요청 단위) 또는 DB `updated_at`의 서버 고유 시각 문자열(단일 필드 변경과 1:1일 때).

### `board.created`

- **트리거**: `POST /boards` 커밋 성공 직후
- **멱등성 키**: `board.created:{boardId}:{createdAt}` (`createdAt`은 응답의 `createdAt`과 동일)

```typescript
type BoardCreatedPayload = {
  parentId: string | null;
  boardType: BoardType;
  slug: string;
  createdBy: string;
};
```

### `board.updated`

- **트리거**: `PATCH /boards/:id` 등으로 `board_config` **제외** 컬럼이 변경되어 커밋 성공한 경우(이름·slug·승인 플래그·FK·활성 등)
- **멱등성 키**: `board.updated:{boardId}:{updatedAt}` (커밋 후 행의 `updated_at`)

```typescript
type BoardUpdatedPayload = {
  /** 변경된 필드 키 목록(스냅샷 전체가 아닌 변경 힌트). 소비자는 필요 시 GET 재조회 */
  changedFields: string[];
  updatedBy: string;
};
```

### `board.config_updated`

- **트리거**: `board_config`만 변경되거나, 동일 요청에서 메타와 함께 변경된 경우 **추가로** 발행(메타 변경은 `board.updated`와 병행 가능)
- **멱등성 키**: `board.config_updated:{boardId}:{updatedAt}`

```typescript
type BoardConfigUpdatedPayload = {
  /** 기본 구현: 변경 전·후 **전체** `board_config` 스냅샷을 모두 포함한다(소비자는 diff 계산 없이 동기화 가능). 민감도·대용량 이슈 시 정책 협의 하에 해시-only 등 축약 구현은 예외로 둔다 */
  previousBoardConfig: BoardConfig;
  /** deep-merge 반영 후(변경 후) 전체 스냅샷 */
  boardConfig: BoardConfig;
  /** 선택 — 변경된 키 경로 힌트(예: `comment`, `display.itemsPerPage`). 정본은 위 스냅샷이며, 본 배열은 필터링·재색인 최적화용 */
  changedKeys?: string[];
};
```

### `board.deleted`

- **트리거**: `DELETE /boards/:id` 소프트 삭제 커밋 성공 직후(하위 재귀 삭제 포함 시 1회 또는 노드별 — 구현은 1 메시지에 `affectedBoardIds` 배열로 묶는 방식 권장)
- **멱등성 키**: `board.deleted:{rootBoardId}:{deletedAt}` (`deletedAt`은 삭제 시각)

```typescript
type BoardDeletedPayload = {
  deletedAt: string;
  /** 재귀 삭제 시 포함된 모든 board id (루트 포함) */
  affectedBoardIds: string[];
};
```

### `board.restored`

- **트리거**: `POST /boards/:id/restore` 소프트 삭제 복구 커밋 성공 직후(Admin이 삭제된 게시판을 복구할 때). 하위 재귀 복구가 동반되면 `affectedBoardIds`로 묶어 발행하는 방식 권장(`board.deleted`와 대칭)
- **멱등성 키**: `board.restored:{boardId}:{restoredAt}` (`restoredAt`은 복구 시각)

```typescript
type BoardRestoredPayload = {
  boardId: string;
  restoredBy: string;
  restoredAt: string;
  /** 재귀 복구 시 포함된 모든 board id (루트 포함) — 단일 노드만 복구 시 해당 id 한 건만 담은 배열 */
  affectedBoardIds: string[];
};
```

> **원자성**: 위 이벤트는 DB 트랜잭션 커밋 이후 enqueue한다. 커밋·enqueue 불일치 보정은 [README.md](./README.md) 운영 가이드의 이벤트 발행 보정 패턴을 따른다.
