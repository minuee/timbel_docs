# AggregationModule — RDB 엔티티

> 집계 캐시 (인기/트렌딩/최신 문서, 통계), 홈 대시보드 위젯 카탈로그/개인 레이아웃

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    %% AggregationCache는 완전 독립 — 다른 테이블과 FK 없음.
    %% cache_key로 집계 대상(게시판, 카테고리 등)을 논리적으로 참조한다.

    AggregationCache {
        UUID id PK
        VARCHAR cache_key
        JSONB cache_value
        TIMESTAMPTZ expires_at
    }

    WidgetCatalog {
        UUID id PK
        VARCHAR widget_key UK
        VARCHAR name
        VARCHAR_ARRAY target_roles
        VARCHAR data_source_type
        BOOLEAN is_active
    }

    UserWidgetLayout {
        UUID id PK
        UUID user_id UK
        JSONB layout
    }
```

---

## 2. 엔티티 필드

### 2.1 AggregationCache

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| cache_key | VARCHAR(200) (UNIQUE) | 캐시 키 (예: `popular_daily_board_{id}`, `trending_24h`, `stats_board_{id}`) |
| cache_value | JSONB | 집계 결과 데이터 |
| expires_at | TIMESTAMPTZ | 만료 시간 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(cache_key)` — 캐시 키 중복 방지

#### 설계 결정

**배치/캐시 기반 처리**
— 집계 데이터는 실시간이 아닌 배치/캐시 기반으로 처리한다. Redis 캐시의 RDB 백업 겸 배치 결과 영구 저장소 역할을 한다.

**갱신 주기**
— 트렌딩/인기 문서: 1시간 주기. 통계 대시보드: 1일 주기. EventBus `document.published` / `document.deleted` 이벤트로 캐시 무효화를 트리거한다.

**인기 스코어 산출**
— `score = (조회수 × W1) + (좋아요 × W2) + (댓글 × W3)`. 가중치(W1, W2, W3)는 SystemConfig(`aggregation.popular_weights`)에서 관리하여 운영 중 조정 가능하다.

**트렌딩 기준**
— 최근 24시간 조회수 증가율이 이전 대비 200% 이상(`aggregation.trending_threshold`) + 최소 조회수 10건(`aggregation.trending_min_views`). 임계값은 SystemConfig에서 관리한다.

**expires_at 활용**
— 만료된 캐시는 배치 스케줄러가 주기적으로 정리한다. 조회 시 `expires_at > now()` 조건으로 유효한 캐시만 반환한다.

---

### 2.2 WidgetCatalog

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| widget_key | VARCHAR(100) (UNIQUE) | 위젯 고유 식별자 (예: `my_drafts`, `approval_pending`, `popular_top5`) |
| name | VARCHAR(200) | 위젯 표시명 |
| description | TEXT (nullable) | 위젯 설명 |
| target_roles | VARCHAR[] | 노출 대상 역할 목록 (예: `{NORMAL, APPROVE, ADMIN}`) |
| data_source_type | VARCHAR(20) | 데이터 원천: `realtime`, `batch` |
| sort_order | INT (default 0) | 기본 정렬 순서 |
| is_active | BOOLEAN (default true) | 활성 여부 — 비활성 시 개인 레이아웃에 있어도 미표시 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(widget_key)` — 위젯 키 중복 방지
- `CHECK (data_source_type IN ('realtime', 'batch'))` — 허용된 데이터 원천 유형만

#### 설계 결정

**관리 자원으로서의 위젯 카탈로그**
— 위젯 카탈로그는 관리 자원이며, ADMIN + `manage_system` 권한을 가진 사용자만 변경할 수 있다 ([FD-AGG](../../01-requirements/features/FD-AGG-집계피드.md) §3.5). 카탈로그에서 비활성화된 위젯은 사용자 개인 레이아웃에 기존 설정이 있더라도 화면에 표시하지 않는다. 카탈로그 변경은 감사 대상이다.

**target_roles (PostgreSQL Array)**
— 위젯별 노출 대상 역할을 배열로 관리한다. 별도 매핑 테이블 대신 `VARCHAR[]`을 사용한다 — 역할 수가 소규모(3~5개)이고 항상 전체 읽기/쓰기하므로 array가 더 효율적이다.

**역할별 기본 위젯 프리셋**
— 역할에 따라 기본 위젯 구성이 다르다. 최초 로그인 시 UserWidgetLayout이 없으면 역할별 프리셋을 앱 레벨에서 생성한다. 프리셋 정의는 앱 코드에서 관리한다 (DB 시딩 대상이 아님).

---

### 2.3 UserWidgetLayout

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| user_id | UUID (UNIQUE) | 사용자당 1건 (외부 UserService의 userId, FK 없음) |
| layout | JSONB (default '[]') | 위젯 배치 정보: `[{ "widget_key": "...", "sort_order": 1, "visible": true }]` |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(user_id)` — 사용자당 레이아웃 레코드 1건

#### 설계 결정

**개인 자원**
— 개인에게 귀속되는 자원이다. 본인만 수정 가능하며, ADMIN은 VIEW만 바이패스한다. 브라우저/기기 간 동기화를 위해 서버에 저장한다.

**JSONB 단일 필드 방식**
— NotificationSetting과 동일한 패턴. 위젯 배열을 JSONB에 저장하여 스키마 변경 없이 위젯 추가/제거에 대응한다. 위젯 카탈로그에서 비활성화된 위젯은 layout에 존재하더라도 앱 레벨에서 필터링하여 미표시한다.

---

## 3. DDL 및 인덱스

### 3.1 AggregationCache

```sql
CREATE TABLE aggregation_cache (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cache_key   VARCHAR(200) NOT NULL,
  cache_value JSONB NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_aggregation_cache_key UNIQUE (cache_key)
);

-- 만료 대상 조회/정리: 배치 스케줄러가 주기적으로 만료 캐시 삭제
CREATE INDEX idx_aggregation_cache_expires
  ON aggregation_cache (expires_at);
```

### 3.2 WidgetCatalog

```sql
CREATE TABLE widget_catalog (
  id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  widget_key        VARCHAR(100) NOT NULL,
  name              VARCHAR(200) NOT NULL,
  description       TEXT,
  target_roles      VARCHAR[] NOT NULL,
  data_source_type  VARCHAR(20) NOT NULL,
  sort_order        INT NOT NULL DEFAULT 0,
  is_active         BOOLEAN NOT NULL DEFAULT true,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_widget_catalog_key UNIQUE (widget_key),
  CONSTRAINT chk_data_source_type
    CHECK (data_source_type IN ('realtime', 'batch'))
);

CREATE INDEX idx_widget_catalog_active
  ON widget_catalog (is_active, sort_order)
  WHERE is_active = true;
```

### 3.3 UserWidgetLayout

```sql
CREATE TABLE user_widget_layout (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL,
  layout      JSONB NOT NULL DEFAULT '[]',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_user_widget_layout_user UNIQUE (user_id)
);
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [system-config.md](../system-config/data.md) — SystemConfig (인기 스코어 가중치, 트렌딩 임계값)
- [community.md](../community/data.md) — Like, Comment (집계 원천 데이터)
- [document.md](../document/data.md) — Document (집계 대상)
- [Redis 전략](../../02-architecture/data/aicm/redis.md) — Redis 캐시 (1차 캐시, AggregationCache는 2차 백업)
