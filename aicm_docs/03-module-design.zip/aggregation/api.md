# Aggregation API 스펙

> 기능정의서: [FD-AGG-집계피드](../../01-requirements/features/FD-AGG-집계피드.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 엔드포인트 요약

<!-- TODO: 인기 문서, 트렌딩, 피드, 홈 대시보드 위젯 -->

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| | | | |

---

## 상세 API

### `{METHOD}` /api/aggregation/{path}

**설명**:

**권한**:

**Request**:

- Path params:
- Query params:
- Body:

```typescript
// TODO: Request DTO
```

**Response** (`200`):

```typescript
// TODO: Response DTO
```

**에러 코드**:

| HTTP | 코드 | 설명 |
|------|------|------|
| | | |

**비즈니스 규칙 참조**: BR-AGG-xxx
