# Aggregation 캐시 전략

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 데이터 아키텍처: [data.md](data.md)

---

## 1. 캐시 개요

| 캐시 대상 | 전략 | 저장소 | 키 패턴 | TTL | 무효화 트리거 |
|-----------|------|--------|---------|-----|-------------|
| 집계 캐시 (인기/트렌딩/최신) | cache-aside (2계층) | Redis(1차) + PG AggregationCache(2차) | `{tenant_id}:cache:agg:{type}` | 1h | EventBus `document.published` / `document.deleted` / `document.expired` |

---

## 2. 캐시 상세

### 2.1 집계 캐시 (Aggregation Cache)

#### 기본 정보

- **전략**: cache-aside (2계층 — Redis 1차 캐시 + PG AggregationCache 2차 백업)
- **키 패턴**: `{tenant_id}:cache:agg:{type}`
- **TTL**: 1시간
- **직렬화**: JSON

#### 무효화

<!-- TODO: EventBus 이벤트(document.published, document.deleted, document.expired) 수신 시 무효화 상세 -->
<!-- TODO: 즉시 무효화 vs lazy 재계산 판단 — 배치 주기와의 관계 -->
<!-- TODO: PG AggregationCache.expires_at과 Redis TTL 동기화 전략 -->

#### Warm-up / Fallback

<!-- TODO: Redis miss 시 PG AggregationCache 조회 (2차 캐시) → DB miss 시 실시간 집계 쿼리 -->
<!-- TODO: 서비스 시작 시 preload 여부 -->
<!-- TODO: 배치 갱신 주기 — 트렌딩/인기: 1시간, 통계: 1일 -->

---

## 3. 키 패턴 요약

> `redis.md`와 일치를 보장한다.

| 키 패턴 | 타입 | TTL | 용도 |
|---------|------|-----|------|
| `{tenant_id}:cache:agg:{type}` | String | 1h | 인기/트렌딩/최신 문서 집계 |
