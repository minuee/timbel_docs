# Aggregation 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [04-async-event-architecture.md](../../02-architecture/04-async-event-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 발행 이벤트

<!-- TODO: Aggregation은 주로 소비 전용. 발행 이벤트가 없다면 이 섹션 삭제 -->

### {event.name}

- **티어**:
- **채널**:
- **트리거**:
- **페이로드**:

```typescript
// TODO: 이벤트 페이로드 인터페이스
```

- **소비자**:

---

## 소비 이벤트

<!-- TODO: document.published, document.deleted, document.expired → 집계 캐시 무효화 -->

| 이벤트 | 발행자 | 채널 | 처리 내용 |
|--------|--------|------|----------|
| | | | |

---

## 외부 서비스 호출

<!-- TODO: 외부 서비스 호출 없음. 이 섹션 삭제 가능 -->

| 클라이언트 | 호출 시점 | 요청 페이로드 | 응답 |
|-----------|----------|-------------|------|
| | | | |
