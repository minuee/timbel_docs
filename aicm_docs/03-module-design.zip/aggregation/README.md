# Aggregation 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | AggregationModule |
| 문서 코드 | MS-AGG |
| 상태 | `미착수` |
| 기능정의서 | [FD-AGG-집계피드](../../01-requirements/features/FD-AGG-집계피드.md) |
| 데이터 모델 | [aggregation-module.md](./data.md) |
| 프로세스 흐름 | [flows/aggregation-feed/](../../01-requirements/flows/aggregation-feed/) |

---

## 모듈 책임

<!-- TODO: 사용자 대상 집계(인기/트렌딩/최신), 배치 갱신, 피드 -->

---

## 핵심 엔티티

| 엔티티 | 설명 |
|--------|------|
| AggregationCache | |

---

## 의존 관계

<!-- TODO: Aggregation → Document (읽기). EventBus에서 document.published, document.deleted, document.expired 소비 -->

```mermaid
graph LR
    %% TODO: 의존 관계 다이어그램 작성
```

---

## 인프라 사용 요약

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | | |
| Redis / BullMQ | | |
| Elasticsearch | | |
| MinIO | | |
| EventBus | | |
| 외부 서비스 클라이언트 | | |
