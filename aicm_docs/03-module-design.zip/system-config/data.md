# SystemConfigModule — RDB 엔티티

> 시스템 설정 (SystemConfigModule 소속 — Layer 1 독립 모듈)

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    %% SystemConfig는 완전 독립 — 다른 테이블과 FK 없음.
    %% Key-Value 방식의 시스템 전역 설정 저장소이다.
    %% ConfigOutbox는 Transactional Outbox 패턴으로 이벤트 유실 방지.

    SystemConfig {
        UUID id PK
        VARCHAR config_key
        JSONB config_value
        TEXT description
        VARCHAR category
        INTEGER version
        UUID updated_by
    }

    ConfigOutbox {
        UUID id PK
        VARCHAR event_type
        JSONB payload
        VARCHAR idempotency_key
        VARCHAR status
        INTEGER retry_count
        TIMESTAMPTZ published_at
    }

    SystemConfig ||--o{ ConfigOutbox : "변경 시 이벤트 기록"
```

---

## 2. 엔티티 필드

### 2.1 SystemConfig

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| config_key | VARCHAR(200) (UNIQUE) | 설정 키. `{scope}:{module}.{name}` 형식 (예: `lm:audit.retention_days`) |
| config_value | JSONB | 설정 값 |
| value_type | VARCHAR(20) | 값 타입: `number`, `string`, `boolean`, `object`, `array` |
| description | TEXT (nullable) | 관리자에게 표시되는 설정 설명 |
| category | VARCHAR(50) | 설정 분류 — UI 그룹핑 및 필터 용도 |
| version | INTEGER | 낙관적 동시성 제어(OCC)용 — 변경 시마다 +1, 초기값 1. FD-SYS §4.7 |
| updated_by | UUID (nullable) | 마지막 변경자 (외부 UserService의 userId, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(config_key)` — 설정 키 중복 방지
- `version >= 1` — CHECK 제약으로 최소값 보장
- `category`는 앱 레벨에서 검증 — 분류가 확장될 수 있으므로 CHECK 제약 대신 앱 레벨 검증

#### 설계 결정

**Key-Value 방식의 시스템 전역 설정**
— 단일 테이블에 모든 시스템 설정을 Key-Value 형태로 저장한다. 새로운 설정이 추가되어도 스키마 변경 없이 레코드만 추가하면 된다.

**config_key 네이밍 규칙**
— `{scope}:{module}.{name}` 형식으로, 본 모듈 문서에서 다루는 scope는 **`lm:`(제한값)** 과 **`pm:`(파라미터)** 이다. 앱 시작 시 SystemConfigService가 DB에서 설정을 로드하여 메모리 캐시한다. 검색 전용 파라미터는 SearchConfig, 파싱 전용은 ParsingConfig 싱글톤에 저장한다([ADR-009](../../adr/009-search-config-singleton-merge.md)).

**주요 설정 키 (예시)**

| 설정 키 | 분류 | 설명 |
|---------|------|------|
| `lm:system.max_upload_bytes` | system | 파일 업로드 최대 크기 (bytes) |
| `lm:document.max_tags` | document | 문서당 최대 태그 수 |
| `lm:document.draft_stale_days` | document | 드래프트 방치 알림 기준 일수 |
| `pm:aggregation.popular_weights` | aggregation | 인기 스코어 가중치 `{view: W1, like: W2, comment: W3}` |
| `pm:aggregation.trending_threshold_percent` | aggregation | 트렌딩 증가율 임계값 (%) |
| `lm:aggregation.trending_min_views` | aggregation | 트렌딩 최소 조회수 |
| `lm:audit.retention_days` | audit | 감사 로그 보관 기간 (일) |
| `pm:export.watermark_text` | export | 내보내기 워터마크 텍스트 |
| `lm:embedding.worker_count` | embedding | 임베딩 동시 처리 워커 수 |
| `lm:community.report_auto_hide_threshold` | community | 신고 N건 시 자동 비공개 |

**설정 변경 권한 및 감사**
— `lm:`/`pm:` 설정 변경은 ADMIN 역할 + `manage_system` AdminPermission이 필요하다. 변경 시 AuditLog에 `system_config.update` 액션으로 기록되어 변경 이력을 추적한다 ([FD-AUD](../../01-requirements/features/FD-AUD-감사로그.md) §2.4).

**하한선 보호 (Compliance Floor)**
— `lm:audit.retention_days` 등 컴플라이언스 관련 설정은 시드 데이터의 초기값 이하로 하향할 수 없다. 예를 들어 금융권 배포 시 최소값이 1825일(5년)이면 ADMIN은 이보다 짧게 설정할 수 없다. 상향은 자유롭게 가능하다.

**DB 시딩 규칙**
— 앱 최초 배포 시 시드 스크립트를 통해 `lm:`/`pm:` 키의 초기값을 INSERT한다. 이미 존재하는 키는 UPDATE하지 않아 관리자 변경 값을 보존한다.

**category 분류**
— 현재 정의된 분류: `system`, `document`, `approval`, `aggregation`, `audit`, `export`, `embedding`, `community`. 관리자 UI에서 카테고리별로 설정 목록을 그룹핑하여 표시한다.

**검색/파싱 전용 엔티티와의 역할 분리**
— 검색 설정은 SearchConfig 싱글톤(`kw_`/`rag_` 프리픽스), 파싱 설정은 ParsingConfig 싱글톤으로 각각 관리하고, SystemConfig은 범용 운영 설정만 담당한다. 두 모듈의 관심사가 명확히 분리된다.

### 2.2 ConfigOutbox

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| event_type | VARCHAR(100) | 이벤트 유형 (예: `system_config.changed`) |
| payload | JSONB | `SystemConfigChangedEvent` 페이로드 전체 |
| idempotency_key | VARCHAR(200) (UNIQUE) | 멱등 키 — `syscfg:{configKey}:{version}` 형식. 동일 이벤트 중복 발행 방지 |
| status | VARCHAR(20) | `pending` \| `published` \| `failed` |
| retry_count | INTEGER | 재시도 횟수 (최대 3). 기본값 0 |
| created_at | TIMESTAMPTZ | 아웃박스 레코드 생성 시각 |
| published_at | TIMESTAMPTZ (nullable) | EventBus 발행 완료 시각 |

#### 제약 조건

- `UNIQUE(idempotency_key)` — 동일 설정 변경의 중복 아웃박스 레코드 방지
- `status`는 앱 레벨에서 `pending` / `published` / `failed` 3종만 허용
- `retry_count >= 0` — CHECK 제약으로 음수 방지

#### 설계 결정

**SystemConfig와의 관계 — FK 미설정**
— ERD에서 `SystemConfig ||--o{ ConfigOutbox` 관계를 표시하지만, 실제 DB에 FK 제약은 걸지 않는다. `ConfigOutbox`는 `payload.configKey`로 원본 설정을 논리적으로 추적하며, 원본 SystemConfig 레코드가 삭제되거나 키가 변경되더라도 Outbox 레코드는 독립적으로 처리(발행/재시도)되어야 하기 때문이다. FK가 존재하면 원본 삭제 시 Outbox 레코드가 CASCADE 삭제되어 이벤트 유실이 발생할 수 있다.

**Transactional Outbox 패턴**
— 설정 변경 DB 커밋과 동일 트랜잭션에서 `config_outbox`에 이벤트 레코드를 INSERT한다. DB 커밋 후 EventBus 발행이 실패해도 Outbox Processor가 `pending` 레코드를 폴링하여 재발행하므로 at-least-once 전달을 보장한다. 상세 흐름: [events.md §2.1](events.md#21-transactional-outbox-패턴)

**보존 정책**
— `published` 상태 레코드는 24시간 후 자동 삭제(cron)하여 테이블 비대화를 방지한다. `failed` 상태 레코드는 운영자가 확인할 때까지 보존한다.

---

## 3. DDL 및 인덱스

### 3.1 SystemConfig

```sql
CREATE TABLE system_config (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  config_key   VARCHAR(200) NOT NULL,
  config_value JSONB NOT NULL,
  value_type   VARCHAR(20) NOT NULL DEFAULT 'string',
  description  TEXT,
  category     VARCHAR(50) NOT NULL,
  version      INTEGER NOT NULL DEFAULT 1,
  updated_by   UUID,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_system_config_key UNIQUE (config_key),
  CONSTRAINT ck_system_config_version CHECK (version >= 1)
);

-- 카테고리별 설정 목록: 관리자 UI에서 분류별 조회
CREATE INDEX idx_system_config_category
  ON system_config (category);
```

### 3.2 ConfigOutbox

```sql
CREATE TABLE config_outbox (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type      VARCHAR(100) NOT NULL,
  payload         JSONB NOT NULL,
  idempotency_key VARCHAR(200) NOT NULL,
  status          VARCHAR(20) NOT NULL DEFAULT 'pending',
  retry_count     INTEGER NOT NULL DEFAULT 0,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at    TIMESTAMPTZ,

  CONSTRAINT uq_config_outbox_idempotency UNIQUE (idempotency_key),
  CONSTRAINT ck_config_outbox_retry CHECK (retry_count >= 0)
);

-- Outbox Processor 폴링: pending/failed 레코드를 생성순으로 조회
CREATE INDEX idx_config_outbox_status_created
  ON config_outbox (status, created_at)
  WHERE status IN ('pending', 'failed');

-- 보존 정책: published 레코드 24시간 후 자동 삭제 대상 조회
CREATE INDEX idx_config_outbox_published_at
  ON config_outbox (published_at)
  WHERE status = 'published';
```

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [audit-log.md](../audit-log/data.md) — AuditLog (설정 변경 감사 기록)
- [aggregation.md](../aggregation/data.md) — AggregationCache (인기 스코어 가중치, 트렌딩 임계값 참조)
- [notification.md](../notification/data.md) — Notification (`draft_stale_days` 설정 참조)
- [search-config.md](../search/data.md) — SearchConfig(검색) + ParsingConfig(파싱) 싱글톤 2테이블 (검색/파싱 전용 엔티티와의 역할 분리)
