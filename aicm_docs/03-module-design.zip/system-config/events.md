# SystemConfig 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 모듈 아키텍처: [02-module-architecture.md §3.3](../../02-architecture/02-module-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 발행 이벤트

SystemConfigModule이 발행하는 이벤트를 신뢰성 티어별로 정리한다.

### 1.1 Best-effort 티어 — EventBus (NestJS EventEmitter)

#### `system_config.changed`

- **티어**: Best-effort
- **채널**: EventBus (NestJS EventEmitter)
- **트리거**: 설정값 변경 성공 시 (`PATCH /system-configs/:key`, `PATCH /system-configs/bulk`) [BR-SYS-006]
- **페이로드**:

```typescript
interface SystemConfigChangedEvent {
  configKey: string;          // 변경된 설정 키
  category: string;           // 설정 카테고리
  before: any;                // 변경 전 값
  after: any;                 // 변경 후 값
  changedBy: string;          // 변경한 관리자 UUID
  changedAt: string;          // 변경 일시 (ISO 8601)
  version: number;            // 변경 후 version (OCC용)
}
```

- **소비자**:

| 소비자 모듈 | 소비 목적 |
|------------|----------|
| DocumentModule | 문서 관련 설정(`lm:document.*`) 인메모리 캐시 무효화 |
| SearchModule | 검색 관련 설정 캐시 무효화 (SystemConfig 범위에 한함) |
| AI AssistantModule | 임베딩 워커 수(`lm:embedding.*`), 재시도 설정 캐시 무효화 |
| AggregationModule | 인기/트렌딩 가중치(`pm:aggregation.*`) 설정 캐시 무효화 |
| AuditLogModule | 설정 변경 감사 로그 비동기 기록 |

- **소비자 처리**: 각 모듈은 `configKey`의 scope/module 부분을 확인하여 자기 모듈 관련 설정인 경우에만 캐시를 무효화한다. 무관한 키의 이벤트는 무시.

---

## 2. 이벤트 전달 보장

> **하이브리드 전략**: EventBus(Best-effort, §1.1)로 설정 변경 이벤트를 즉시 전파하되, EventBus 발행이 실패하거나 소비자가 미처 처리하지 못하는 상황에 대비하여 Transactional Outbox로 at-least-once 보장을 추가한다. 정상 경로에서는 EventBus가 밀리초 단위로 소비자에게 전달하여 지연을 최소화하고, Outbox는 DB 커밋 시점에 이벤트 레코드를 함께 기록하여 EventBus 실패 시에도 폴링 기반 재발행으로 유실을 방지한다. 두 경로가 동시에 성공하면 소비자가 중복 이벤트를 수신할 수 있으므로, 소비자는 `configKey` + `version` 기반 멱등 처리를 수행한다.

### 2.1 Transactional Outbox 패턴

설정 변경과 이벤트 발행의 원자성을 보장하기 위해 Transactional Outbox 패턴을 적용한다. DB 커밋 후 EventBus 발행이 실패해도 이벤트가 유실되지 않는다.

**흐름**:

```
PATCH /system-configs/:key
  │
  ├── DB 트랜잭션 시작
  │     ├── SystemConfig UPDATE (값 변경 + version 증가)
  │     └── config_outbox INSERT (이벤트 페이로드 기록, status = 'pending')
  │
  ├── DB 커밋
  │
  ├── EventBus 발행 시도 (즉시)
  │     ├── 성공 → config_outbox status = 'published'
  │     └── 실패 → WARN 로그, Outbox Processor가 후속 처리
  │
  └── API 응답 반환
```

**Outbox 테이블 스키마**:

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| event_type | VARCHAR(100) | `system_config.changed` |
| payload | JSONB | `SystemConfigChangedEvent` 페이로드 |
| idempotency_key | VARCHAR(200) (UNIQUE) | `syscfg:{configKey}:{version}` |
| status | VARCHAR(20) | `pending` \| `published` \| `failed` |
| retry_count | INTEGER | 재시도 횟수 (최대 3) |
| created_at | TIMESTAMPTZ | |
| published_at | TIMESTAMPTZ (nullable) | 발행 완료 시각 |

### 2.2 Outbox Processor

미발행(`pending`) 또는 실패(`failed`) 상태의 이벤트를 주기적으로 재발행한다.

- **실행 주기**: 5초 간격 폴링
- **배치 크기**: 최대 100건
- **다중 인스턴스 동시성 제어**: Outbox Processor가 여러 인스턴스에서 동시에 실행될 때 동일 아웃박스 레코드를 중복 처리하지 않도록 `SELECT ... FOR UPDATE SKIP LOCKED`를 사용한다. 각 인스턴스는 `pending`/`failed` 레코드를 조회할 때 이미 다른 인스턴스가 잠근 행을 건너뛰고 잠기지 않은 행만 가져온다. 이를 통해 별도의 분산 락 없이도 레코드 수준의 배타적 처리를 보장한다.

  ```sql
  SELECT * FROM config_outbox
  WHERE status IN ('pending', 'failed')
    AND retry_count < 3
  ORDER BY created_at ASC
  LIMIT 100
  FOR UPDATE SKIP LOCKED;
  ```

- **재시도 정책**: 최대 3회, 지수 백오프 (초기 지연 500ms → 1s → 2s)
- **멱등 키**: `syscfg:{configKey}:{version}` — 동일 이벤트의 중복 처리를 방지. 소비자는 `configKey` + `version` 조합으로 이미 처리한 이벤트를 건너뛴다
- **DLQ 처리**: 재시도 3회 소진 시 `status = 'failed'`로 마킹, 운영 관리자에게 알림 발송
- **보존 정책**: `published` 상태 이벤트는 24시간 후 자동 삭제 (cron)

### 2.3 이벤트 발행 실패 폴백

재시도가 소진된 경우에도 서비스 정상 동작을 보장한다.

| 상황 | 폴백 | 영향 |
|------|------|------|
| EventBus 발행 실패 (재시도 소진) | Redis 캐시 TTL(1시간) 만료 시 자연 갱신 | 최대 1시간 stale 데이터 허용 |
| 소비 모듈 처리 실패 | 각 모듈의 캐시 TTL로 자연 갱신 | 모듈별 TTL에 따른 지연 |

- 운영 모니터링 지표 `sys.event_publish_failure_count`를 증가시킨다
- DLQ 적체 시 운영 관리자에게 인앱 + 이메일 알림을 발송한다

### 2.4 다중 인스턴스 전파

단일 인스턴스의 EventBus(NestJS EventEmitter)는 로컬 프로세스 내에서만 전파된다. 다중 인스턴스 환경에서는 Redis pub/sub 채널을 통해 모든 인스턴스에 캐시 무효화를 전파한다.

- **채널**: `{tenant_id}:syscfg:invalidation`
- **메시지**: `{ configKey, version }`
- **수신 시 동작**: 해당 `config_key`의 인메모리 캐시(향후 도입 시) 무효화. Redis 캐시는 변경 시점에 이미 DEL 처리되었으므로 추가 무효화 불필요

---

### 2.5 Outbox 모니터링 메트릭

| 메트릭 | 타입 | 설명 | 알림 임계값 |
|--------|------|------|-----------|
| `syscfg_outbox_pending_count` | Gauge | 현재 `pending` 상태 아웃박스 레코드 수 | > 50건 — Outbox Processor 정상 동작 여부 점검 필요 |
| `syscfg_outbox_processed_total` | Counter | Outbox Processor가 성공적으로 발행한 누적 이벤트 수 | — |
| `syscfg_outbox_failed_total` | Counter | 재시도 소진으로 `failed` 상태가 된 누적 이벤트 수 | > 0 — 즉시 운영 관리자 알림 |
| `syscfg_outbox_age_seconds` | Gauge | 가장 오래된 `pending` 레코드의 대기 시간 (초) | > 30초 — Outbox Processor 지연 또는 장애 의심 |
| `syscfg_outbox_poll_duration` | Histogram | Outbox Processor 1회 폴링 사이클 소요 시간 (ms) | p99 > 3000ms — DB 쿼리 성능 점검 필요 |

> 알림 채널: 인앱 관리자 알림 + 이메일. SigNoz 대시보드에서 메트릭 추이를 확인한다. 캐시 관련 메트릭은 [cache.md §4](cache.md#4-모니터링-메트릭) 참조.

---

## 3. 소비 이벤트

SystemConfigModule은 외부 모듈의 이벤트를 소비하지 않는다. Layer 1 독립 모듈로서 다른 도메인 모듈에 대한 의존이 없다.

---

## 4. 감사 로그 액션

SystemConfigModule이 기록하는 감사 로그 액션 목록. 전역 Interceptor(`tap()`)와 EventBus(`system_config.changed` → AuditLogModule) 이중 경로로 기록된다.

| 액션 | 트리거 | 규칙 |
|------|--------|------|
| `system_config.update` | 설정값 단건 변경 | BR-SYS-005 |
| `system_config.bulk_update` | 설정 일괄 변경 | BR-SYS-005, BR-SYS-011 |

> 감사 로그 이중 경로(Interceptor + EventBus)의 설계 근거는 [횡단 관심사 §8.1](../../02-architecture/07-cross-cutting-concerns.md) 참조
