# SystemConfig 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | SystemConfigModule |
| 문서 코드 | MS-SYS |
| 상태 | `draft` |
| 기능정의서 | [FD-SYS-시스템설정](../../01-requirements/features/FD-SYS-시스템설정.md) |
| 데이터 모델 | [system-config-module.md](./data.md) |

---

## 모듈 책임

SystemConfigModule은 AICM의 **시스템 전역 운영 파라미터 관리 단위**를 담당하는 독립 모듈(Layer 1)이다. 다른 도메인 모듈에 대한 DI 의존이 없으며, 대부분의 도메인 모듈이 이 모듈의 설정값을 읽기 참조한다.

| 영역 | 설명 |
|------|------|
| 운영 파라미터 저장 | `lm:`/`pm:` Key-Value를 SystemConfig 테이블에 저장하고 관리자 UI에서 변경 |
| 설정 CRUD | 설정값 조회·변경 — `lm:`/`pm:` scope만 API로 변경 가능([BR-SYS-002](rules.md#br-sys-002-변경-가능-scope-제한)) |
| 카테고리 그룹핑 | `category` 필드 기반 UI 그룹핑 (system, document, approval, aggregation, audit, export, embedding, community) |
| 하한선 보호 (Compliance Floor) | 컴플라이언스 관련 설정(`lm:audit.retention_days` 등)의 최소값 보장 — 시드 초기값 이하 하향 불가 |
| DB 시딩 | 앱 최초 배포 시 `lm:`/`pm:` 항목을 SystemConfig 테이블에 INSERT — 기존 키 미덮어쓰기 |
| 감사 로그 연동 | 모든 설정 변경을 AuditLog에 before/after diff로 기록 |
| 변경 즉시 적용 | 설정 변경 시 캐시 무효화 후 즉시 반영 — 앱 재시작 불필요 |
| 값 캐싱 | 설정값을 Redis에 캐싱하여 읽기 성능 최적화 — 변경 시 캐시 무효화 |

> **모듈 경계 참고**: FD-SYS §6.2의 변경 미리보기(인기 가중치/트렌딩 기준 시뮬레이션)는 설정값을 소비하는 AggregationModule의 책임이다. SystemConfigModule은 설정값의 저장·변경·조회만 담당한다.

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — system-config-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **SystemConfig** | 시스템 전역 설정 Key-Value 저장소. `config_key`(`{scope}:{module}.{name}` 형식, UNIQUE), `config_value`(JSONB), `value_type`(number/string/boolean/object/array), `description`, `category`(UI 그룹핑), `version`(OCC용, 변경 시 +1), `updated_by`. 스키마 변경 없이 레코드 추가만으로 새 설정 확장 가능 |

> **설계 결정**: 단일 테이블에 모든 시스템 설정을 Key-Value 형태로 저장한다. 검색/파싱 전용 파라미터는 SearchConfig/ParsingConfig 싱글톤으로 분리되어 있다 — [ADR-009](../../adr/009-search-config-singleton-merge.md) 참조.

---

## 의존 관계

```mermaid
graph LR
    SysCfg["<b>SystemConfigModule</b>"]

    Doc["DocumentModule"] -->|"읽기"| SysCfg
    Appr["ApprovalModule"] -->|"읽기"| SysCfg
    Agg["AggregationModule"] -->|"읽기"| SysCfg
    Audit["AuditLogModule"] -->|"읽기"| SysCfg
    Admin["AdminModule"] -->|"CRUD UI"| SysCfg

    classDef hub fill:#dcfce7,stroke:#16a34a,stroke-width:2px
    classDef consumer fill:#f3f4f6,stroke:#6b7280

    class SysCfg hub
    class Doc,Appr,Agg,Audit,Admin consumer
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Doc → SysCfg | DocumentModule | 읽기 | `lm:document.*` 설정값 조회 (태그 수 제한, 자동 저장 간격 등) |
| Approval → SysCfg | ApprovalModule | 읽기 | `lm:approval.*` 설정값 조회 (리마인더 기준일 등) |
| Aggregation → SysCfg | AggregationModule | 읽기 | `pm:aggregation.*` 설정값 조회 (인기 가중치, 트렌딩 기준) |
| AuditLog → SysCfg | AuditLogModule | 읽기 | `lm:audit.*` 설정값 조회 (보관 기간 등) |
| SysCfg → AuditLog | AuditLogModule | 읽기 | 설정 변경 이력 조회 (`GET /system-configs/:key/history`) |
| Admin → SysCfg | AdminModule | CRUD UI | 관리자 대시보드에서 설정 조회·변경 UI 제공 |

> **모듈 의존성**: SystemConfigModule은 다른 도메인 모듈에 대한 DI 의존이 없으나, `GET /system-configs/:key/history` 엔드포인트에서 AuditLog 데이터를 읽기 참조한다. 이 읽기 의존성은 관리자 UX를 위한 것으로, AuditLogModule의 Service를 DI 주입하여 구현한다. 위 다이어그램에서 소비 모듈(Doc, Approval 등) → SysCfg 방향의 화살표는 NestJS 모듈 DI import가 아닌 **런타임 설정값 읽기**(`SystemConfigService` 경유)를 표현한다. CommunityModule(`lm:community.*`), ExportModule(`pm:export.*`) 등 대부분의 도메인 모듈이 동일 방식으로 설정값을 읽기 참조한다. 내부 서비스 인터페이스 상세: [api.md §내부 서비스 인터페이스](api.md#내부-서비스-인터페이스)

**AuditLogModule 읽기 의존 인터페이스**:

`GET /system-configs/:key/history`가 호출하는 AuditLogModule의 서비스 메서드:

```typescript
// AuditLogModule이 제공하는 읽기 인터페이스 (SystemConfigModule이 DI 주입하여 사용)
interface AuditLogQueryService {
  /**
   * 특정 리소스의 감사 로그를 페이지네이션으로 조회한다.
   * SystemConfigModule에서는 resourceType = 'system_config', action = 'system_config.update'로 호출.
   */
  findByResource(params: {
    resourceType: string;
    resourceId: string;        // config_key
    action?: string;
    from?: Date;
    to?: Date;
    page: number;
    limit: number;
  }): Promise<{ items: AuditLogEntry[]; total: number }>;
}
```

---

## 현재 구현 범위

| 구분 | 항목 | 상태 |
|------|------|------|
| **현재 라운드** | 설정 CRUD (조회·변경·일괄 변경) | ✅ |
| | 카테고리 그룹핑 | ✅ |
| | 하한선 보호 (Compliance Floor) | ✅ |
| | DB 시딩 | ✅ |
| | 캐시 전략 (Redis cache-aside) | ✅ |
| | 감사 로그 연동 | ✅ |
| | 낙관적 동시성 제어 (OCC) | ✅ |
| | 변경 이벤트 발행 (`system_config.changed`) | ✅ |
| | 설정값 유효 범위 검증 | ✅ |
| **후속 라운드** | 설정 롤백 (개별/일괄) | 🔜 FD-SYS §4.8 |
| | 설정 긴급 잠금 | 🔜 FD-SYS §4.9 |
| | 설정 내보내기/가져오기 | 🔜 FD-SYS §4.10 |
| | 변경 미리보기 (인기 가중치 시뮬레이션) | 🔜 FD-SYS §9.2 |

> 후속 라운드 항목은 FD-SYS에 정의되어 있으나, 현재 모듈 스펙에서는 핵심 CRUD·캐시·이벤트·OCC를 우선 설계한다. 롤백·긴급잠금·내보내기/가져오기는 API 엔드포인트·규칙·에러 코드를 포함하여 후속 라운드에서 상세화한다.

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | SystemConfig 엔티티 |
| Redis / BullMQ | ● | 설정값 읽기 캐시 — cache-aside, 변경 시 단일 키 무효화. Transactional Outbox 처리. 상세: [cache.md](cache.md) |
| Elasticsearch | — | |
| MinIO | — | |
| EventBus | ● | `system_config.changed` 이벤트 발행 — 설정 변경 시 소비 모듈 캐시 무효화 트리거 + 감사 로그 비동기 기록. 상세: [events.md](events.md) |
| 외부 서비스 클라이언트 | — | |

---

## 교차 리뷰 이력

> ✅ **에러 코드 접두사 `SYS_`** — [횡단 관심사 §8.2.3](../../02-architecture/07-cross-cutting-concerns.md#823-에러-코드-네이밍-규칙) 예약 접두사 테이블에 등록 완료. 모든 에러 코드는 SCREAMING_SNAKE_CASE(`SYS_*`)로 통일되었다.

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-SYS-시스템설정](../../01-requirements/features/FD-SYS-시스템설정.md) | 기능정의서 (입력 원본) |
| [system-config-module.md](./data.md) | RDB 엔티티/DDL |
| [events.md](./events.md) | 이벤트 발행/소비, Outbox 패턴 |
| [FD-AUD-감사로그](../../01-requirements/features/FD-AUD-감사로그.md) | 설정 변경 감사 로그 (§2.4) |
| [인가 아키텍처](../../02-architecture/04-permission-architecture.md) | ADMIN + `manage_system` AdminPermission (§5) |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 모듈 분류 |
| [ADR-009](../../adr/009-search-config-singleton-merge.md) | 검색·파싱 설정을 SystemConfig에서 분리한 근거 |
