# SystemConfig 비즈니스 규칙

> 기능정의서: [FD-SYS-시스템설정](../../01-requirements/features/FD-SYS-시스템설정.md)
> API 스펙: [api.md](api.md)

> **API 경로 표기**: 글로벌 `/api` prefix는 배포 환경에서 리버스 프록시로 부여되며, 모듈 스펙에서는 prefix 없이 기술한다.

---

## 1. 상태 전이

SystemConfig 엔티티는 라이프사이클 status를 갖지 않는다. Key-Value 형태의 설정 저장소로, 값의 생성(시딩)과 변경(업데이트)만 존재한다.

```mermaid
stateDiagram-v2
    [*] --> seeded: DB 시딩 [BR-SYS-009]

    seeded --> updated: 설정값 변경 [BR-SYS-002]
    updated --> updated: 설정값 재변경 [BR-SYS-002]

    note right of updated
        lm:/pm: 키만
        API로 변경 [BR-SYS-002]
    end note
```

---

## 2. 규칙 카탈로그

### 설정 조회

#### BR-SYS-001: 설정 조회 권한

- **트리거**: `GET /system-configs`, `GET /system-configs/:key`, `GET /system-configs/:key/history`
- **조건**: 요청자가 ADMIN 역할 + `manage_system` AdminPermission 보유
- **동작**: 설정 목록/상세/이력 조회 허용
- **위반 시**: `FORBIDDEN` (403) — manage_system 권한 없음
- **근거**: FD-SYS §4.1, 인가 아키텍처 §5 — 시스템 설정은 관리 자원이므로 ADMIN + `manage_system` 필요

---

### 설정 변경

#### BR-SYS-002: 변경 가능 scope 제한

- **트리거**: `PATCH /system-configs/:key`, `PATCH /system-configs/bulk`
- **조건**: 대상 설정의 config_key가 `lm:` 또는 `pm:` scope에 해당
- **동작**: 설정값 변경 허용. `updated_by`를 요청자 ID로 갱신, `updated_at`을 현재 시각으로 갱신
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SYS_IMMUTABLE_SCOPE | 403 | 이 설정 키는 API로 변경할 수 없습니다 (`lm:`/`pm:`만 변경 가능) |

- **근거**: FD-SYS §4.5 — 운영 중 관리자 API로 변경 가능한 것은 `lm:`/`pm:` 범위로 한정한다

#### BR-SYS-003: value_type 타입 검증

- **트리거**: `PATCH /system-configs/:key`, `PATCH /system-configs/bulk`
- **조건**: 요청 값의 JSON 타입이 해당 설정의 `value_type`과 일치해야 함
- **동작**:

  | value_type | 허용 JSON 타입 |
  |------------|---------------|
  | `number` | number (정수/실수) |
  | `string` | string |
  | `boolean` | boolean |
  | `object` | object |
  | `array` | array |

- **위반 시**: `SYS_TYPE_MISMATCH` (422) — 설정값 타입이 일치하지 않습니다. 기대: {valueType}, 수신: {actualType}
- **근거**: FD-SYS §2.1 — value_type에 따른 값 검증으로 잘못된 타입의 값 저장 방지

#### BR-SYS-004: 하한선 보호 (Compliance Floor)

- **트리거**: `PATCH /system-configs/:key`, `PATCH /system-configs/bulk`
- **조건**: 대상 설정이 하한선 보호 대상이며, 요청 값이 시드 초기값(Compliance Floor) 이상
- **동작**: 시드 초기값 이상이면 변경 허용. 상향은 제한 없음
- **위반 시**: `SYS_BELOW_COMPLIANCE_FLOOR` (422) — 최소 {floorValue} 이상이어야 합니다

  > **보호 대상 설정**:
  >
  > | config_key | 보호 방식 | 설명 |
  > |------------|----------|------|
  > | `lm:audit.retention_days` | 시드 초기값 체크 | 금융권 1825일(5년) 미만 설정 불가, 상향만 가능 |

- **근거**: FD-SYS §4.3 — 컴플라이언스 관련 설정은 시드·정책이 정한 최소값 이하로 하향 불가. ADMIN의 실수로 금융권 규제(5년 보관) 위반을 방지

#### BR-SYS-005: 감사 로그 기록

- **트리거**: 설정값 변경 성공 시 (`PATCH /system-configs/:key`, `PATCH /system-configs/bulk`)
- **조건**: —
- **동작**: AuditLog에 변경 이력 기록. **전역 Interceptor(`tap()`) + EventBus(`system_config.changed` → AuditLogModule) 이중 경로**로 비동기 전달한다 — [횡단 관심사 §8.1](../../02-architecture/07-cross-cutting-concerns.md) 참조

  | 기록 항목 | 설명 |
  |----------|------|
  | `actor` | 변경한 관리자 |
  | `action` | `system_config.update` |
  | `target` | config_key |
  | `details.before` | 변경 전 값 |
  | `details.after` | 변경 후 값 |
  | `timestamp` | 변경 일시 |
  | `source` | `interceptor` \| `event` — 기록 경로 구분 |

  > Interceptor는 HTTP 요청 자체를 캡처하고, EventBus는 비즈니스 이벤트(`system_config.changed`)를 캡처한다. 두 경로의 관점이 다르며, `audit_log.source` 필드로 구분한다.

- **위반 시**: —
- **근거**: FD-SYS §7 — 모든 SystemConfig 변경은 감사 로그에 기록. FD-AUD §2.3 관리자 액션 로그. 횡단 관심사 §8.1 감사 로그 전략

#### BR-SYS-006: 변경 즉시 적용 및 캐시 무효화

- **트리거**: 설정값 변경 성공 시
- **조건**: —
- **동작**:
  1. DB 업데이트 커밋
  2. Redis 캐시에서 해당 config_key 무효화
  3. 다음 읽기 시 DB에서 최신값을 조회하여 캐시 재적재
- **위반 시**: —
- **근거**: FD-SYS §4.2 — 설정 변경은 저장 시 즉시 반영. 앱 재시작 불필요

---

### 설계 원칙

#### BR-SYS-007: [설계 원칙] SearchConfig·ParsingConfig와의 역할 분리

- **트리거**: —
- **조건**: —
- **동작**: 범용 운영 파라미터는 SystemConfig(`lm:`/`pm:`)에 저장하고, 검색·파싱 전용 파라미터는 SearchConfig/ParsingConfig 싱글톤으로 별도 관리한다 — [ADR-009](../../adr/009-search-config-singleton-merge.md)
- **위반 시**: —
- **근거**: 검색·파싱 설정의 스키마·캐시 수명이 다르므로 분리

#### BR-SYS-009: [설계 원칙] DB 시딩 규칙

- **트리거**: 앱 최초 배포 또는 시드 키 추가 배포 시
- **조건**: —
- **동작**:
  1. `lm:`/`pm:` 항목을 SystemConfig 테이블에 시딩
  2. `config_key`가 DB에 이미 존재하면 → UPDATE 하지 않음 (관리자 변경 보존)
  3. `config_key`가 DB에 없으면 → 시드 정의값으로 INSERT (초기 배포 또는 새 키 추가)

  ```
  DB에 해당 config_key가 존재하는가?
    ├── 없음 → 시드 값으로 INSERT (초기 배포)
    └── 있음 → UPDATE 하지 않음 (관리자 변경 보존)
  ```

- **위반 시**: —
- **근거**: FD-SYS §7 — 관리자가 운영 중 변경한 값을 재배포로 덮어쓰지 않음. 시드에 새 키가 추가된 경우에만 해당 키를 INSERT

  **구현 가이드라인**:
  - **실행 위치**: `SystemConfigModule`의 `OnModuleInit` 훅에서 실행 — NestJS 부트스트랩 단계에서 자동 수행
  - **실행 순서**: DB 마이그레이션 완료 후, 캐시 preload([cache.md](cache.md) §2.2) 전에 실행. 아래 순서를 보장해야 한다:
    1. **DB 마이그레이션** — TypeORM migration 완료 (테이블/컬럼 존재 보장)
    2. **시딩** — 시드 스크립트 기반 INSERT ... ON CONFLICT DO NOTHING
    3. **캐시 Warm-up** — 시딩 완료 후 전체 설정을 Redis에 preload
    > 순서 보장 방법: `OnModuleInit`에서 `await this.seedConfigs()` → `await this.warmUpCache()` 를 순차 호출한다. TypeORM 마이그레이션은 `DatabaseModule`의 `onModuleInit`에서 먼저 실행되며, NestJS 모듈 초기화 순서는 `imports` 배열 순서를 따르므로 `SystemConfigModule`이 `DatabaseModule`을 import하면 마이그레이션이 선행된다.
  - **트랜잭션**: 전체 시딩을 단일 트랜잭션으로 처리. 부분 실패 방지
  - **실패 처리**: 시딩 실패 시 앱 시작을 **중단**한다 (`throw` → 프로세스 종료). 설정이 없는 상태에서 서비스가 동작하면 예측 불가능한 비즈니스 로직 오류 발생. 캐시 Warm-up 실패는 앱 시작을 중단하지 않는다 — WARN 로그 후 cache miss 시 DB fallback
  - **멱등성**: INSERT ... ON CONFLICT (config_key) DO NOTHING 패턴으로 멱등성 보장. 반복 실행해도 기존 값 보존
  - **로깅**: 새로 INSERT된 키 목록을 INFO 로그로 출력하여 배포 시 추가된 설정을 확인 가능하게 함

  > 시드 소스는 앱 리포지토리의 시드 스크립트 또는 마이그레이션에 정의된 `lm:`/`pm:` 목록을 따른다.

---

### 데이터 검증

#### BR-SYS-010: 설정 키 존재 확인

- **트리거**: config_key를 경로 파라미터로 참조하는 API 호출 시 (`GET /system-configs/:key`, `PATCH /system-configs/:key`, `GET /system-configs/:key/history`, `PATCH /system-configs/bulk`의 각 항목)
- **조건**: 해당 config_key의 SystemConfig 레코드가 존재해야 함
- **동작**: 비즈니스 처리 전 DB에서 존재 여부를 확인한다
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SYS_CONFIG_NOT_FOUND | 404 | 설정을 찾을 수 없습니다: {key} |

- **근거**: config_key 참조 API의 공통 선행 검증. 변경([BR-SYS-002](#br-sys-002-변경-가능-scope-제한))·하한선 보호([BR-SYS-004](#br-sys-004-하한선-보호-compliance-floor))는 본 규칙을 선행 만족한 뒤 각 규칙의 추가 조건을 평가한다

---

### 일괄 변경

#### BR-SYS-011: 일괄 변경 트랜잭션

- **트리거**: `PATCH /system-configs/bulk`
- **조건**: 요청 항목이 1건 이상 50건 이하. 모든 항목이 [BR-SYS-002](#br-sys-002-변경-가능-scope-제한), [BR-SYS-003](#br-sys-003-value_type-타입-검증), [BR-SYS-004](#br-sys-004-하한선-보호-compliance-floor), [BR-SYS-010](#br-sys-010-설정-키-존재-확인)을 만족
- **동작**: 단일 DB 트랜잭션으로 모든 항목을 일괄 변경. 하나라도 실패하면 전체 롤백. 성공 시 각 항목에 대해 감사 로그 기록 [BR-SYS-005](#br-sys-005-감사-로그-기록) 및 캐시 무효화 [BR-SYS-006](#br-sys-006-변경-즉시-적용-및-캐시-무효화)
- **위반 시**:
  - 개별 항목 검증 실패 시: 해당 항목의 에러 코드 반환 + 전체 롤백
  - `SYS_BULK_LIMIT_EXCEEDED` (422) — 일괄 변경은 최대 50건까지 가능합니다
- **근거**: 카테고리별 설정을 한꺼번에 변경하는 관리자 UI 워크플로 지원. 부분 성공 시 설정 간 정합성이 깨질 수 있으므로 원자적 처리

---

### 동시성 제어

#### BR-SYS-012: 낙관적 동시성 제어 (OCC)

- **트리거**: `PATCH /system-configs/:key`, `PATCH /system-configs/bulk`
- **조건**: 요청 본문에 포함된 `version`이 DB의 현재 `version`과 일치해야 함
- **동작**:
  1. 요청의 `version`과 DB의 `version`을 비교한다
  2. 일치 → 변경 적용 + `version` 1 증가 (`UPDATE ... SET version = version + 1 WHERE config_key = :key AND version = :requestVersion`)
  3. 불일치 → 변경 거부
  4. bulk 변경 시 각 항목별로 version 체크, 하나라도 불일치하면 전체 롤백 [BR-SYS-011]
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SYS_CONCURRENT_MODIFICATION | 409 | 다른 관리자가 이 설정을 변경했습니다. 최신 값을 확인해주세요. 충돌 키: {key}, 요청 version: {requestVersion}, 현재 version: {currentVersion} |

- **근거**: FD-SYS §4.7 — 설정 변경 빈도가 낮아 충돌 확률이 낮고, 비관적 락킹 대비 구현 단순·성능 우수. 관리자는 최신 값을 확인한 후 다시 변경할 수 있다

---

### 데이터 검증 (확장)

#### BR-SYS-013: 설정값 유효 범위 검증

- **트리거**: `PATCH /system-configs/:key`, `PATCH /system-configs/bulk`
- **조건**: 요청 값이 해당 설정의 유효 범위 내에 있어야 함
- **동작**:
  - **숫자형(`number`)**: `0 이상` 필수. 항목별 상한이 정의된 경우 해당 상한 이하
  - **문자열(`string`)**: 최대 길이 검증 (기본 상한 2000자)
  - **배열(`array`)**: 최대 요소 수 검증 (기본 상한 100개)
  - **boolean/object**: 타입 검증만 수행 (BR-SYS-003에서 처리)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SYS_VALUE_OUT_OF_RANGE | 422 | 설정값이 허용 범위를 벗어났습니다. 허용 범위: {min}~{max}, 수신값: {value} |

- **근거**: [FD-SYS §4.3 BR-SYS-012(유효 범위 검증)](../../01-requirements/features/FD-SYS-시스템설정.md) — 숫자형 0 이상 및 항목별 상한 검증으로 잘못된 설정값이 서비스에 영향을 미치는 것을 방지. 참고: FD-SYS의 BR-SYS-012와 본 모듈 스펙의 BR-SYS-012(OCC)는 번호가 동일하나 다른 규칙이다 — §5 매핑 테이블 참조

---

## 3. 에러 코드 카탈로그

> 전역 에러 코드 (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

| 에러 코드 | HTTP | 발생 규칙 | 메시지 템플릿 |
|-----------|------|----------|--------------|
| SYS_BELOW_COMPLIANCE_FLOOR | 422 | BR-SYS-004 | 최소 {floorValue} 이상이어야 합니다 |
| SYS_BULK_LIMIT_EXCEEDED | 422 | BR-SYS-011 | 일괄 변경은 최대 50건까지 가능합니다 |
| SYS_CONCURRENT_MODIFICATION | 409 | BR-SYS-012 | 다른 관리자가 이 설정을 변경했습니다. 최신 값을 확인해주세요 |
| SYS_CONFIG_NOT_FOUND | 404 | BR-SYS-010 | 설정을 찾을 수 없습니다: {key} |
| SYS_IMMUTABLE_SCOPE | 403 | BR-SYS-002 | 이 설정 키는 API로 변경할 수 없습니다 (`lm:`/`pm:`만 변경 가능) |
| SYS_TYPE_MISMATCH | 422 | BR-SYS-003 | 설정값 타입이 일치하지 않습니다. 기대: {valueType}, 수신: {actualType} |
| SYS_VALUE_OUT_OF_RANGE | 422 | BR-SYS-013 | 설정값이 허용 범위를 벗어났습니다. 허용 범위: {min}~{max} |

---

## 4. 규칙 요약 매트릭스

| 규칙 ID | 이름 | 주요 트리거 | 에러 코드 |
|---------|------|-----------|-----------|
| BR-SYS-001 | 설정 조회 권한 | GET /system-configs* | FORBIDDEN |
| BR-SYS-002 | 변경 가능 scope 제한 | PATCH /system-configs/:key | SYS_IMMUTABLE_SCOPE |
| BR-SYS-003 | value_type 타입 검증 | PATCH /system-configs/:key | SYS_TYPE_MISMATCH |
| BR-SYS-004 | 하한선 보호 (Compliance Floor) | PATCH /system-configs/:key | SYS_BELOW_COMPLIANCE_FLOOR |
| BR-SYS-005 | 감사 로그 기록 | 설정 변경 성공 시 | — |
| BR-SYS-006 | 변경 즉시 적용 및 캐시 무효화 | 설정 변경 성공 시 | — |
| BR-SYS-007 | [설계 원칙] SearchConfig·ParsingConfig와의 역할 분리 | — | — |
| BR-SYS-009 | [설계 원칙] DB 시딩 규칙 | 앱 배포 시 | — |
| BR-SYS-010 | 설정 키 존재 확인 | config_key 참조 API | SYS_CONFIG_NOT_FOUND |
| BR-SYS-011 | 일괄 변경 트랜잭션 | PATCH /system-configs/bulk | SYS_BULK_LIMIT_EXCEEDED |
| BR-SYS-012 | 낙관적 동시성 제어 (OCC) | PATCH /system-configs/:key | SYS_CONCURRENT_MODIFICATION |
| BR-SYS-013 | 설정값 유효 범위 검증 | PATCH /system-configs/:key | SYS_VALUE_OUT_OF_RANGE |

---

## 5. FD ↔ 모듈 스펙 BR 매핑

> FD-SYS의 BR 번호와 모듈 스펙의 BR 번호는 상세화 수준이 다르며, 1:1로 대응하지 않는 항목이 있다. 아래 매핑으로 추적성을 보장한다.

| FD-SYS BR | FD 규칙명 | 모듈 스펙 BR | 비고 |
|-----------|----------|-------------|------|
| BR-SYS-001 | 필요 권한 (§4.1) | BR-SYS-001 | 일치 |
| BR-SYS-002 | 변경 전파 메커니즘 (§4.2) | BR-SYS-006 | FD는 전파 절차, 모듈 스펙은 캐시 무효화 상세 |
| BR-SYS-003 | 하한선 보호 (§4.4) | BR-SYS-004 | 번호 불일치 — 모듈 스펙에서 scope 제한(002)·타입 검증(003)이 선행 |
| BR-SYS-004 | Manifest 비활성 기능 (§4.5) | — | 모듈 스펙에서는 목록 필터링 규칙을 두지 않음 — FD와 정합은 제품 구현 시 검토 |
| BR-SYS-005 | 변경 범위 제한 (§4.6) | BR-SYS-002 | FD는 변경 범위, 모듈 스펙은 scope 제한으로 통합 |
| BR-SYS-006 | 동시성 제어 (§4.7) | BR-SYS-012 | 모듈 스펙에서 OCC 상세 규칙 신설 |
| BR-SYS-007 | 롤백 규칙 (§4.8) | — | 후속 라운드 deferral |
| BR-SYS-008 | 긴급 잠금 (§4.9) | — | 후속 라운드 deferral |
| BR-SYS-009 | 내보내기/가져오기 (§4.10) | — | 후속 라운드 deferral |
| BR-SYS-010 | 감사 로그 기록 (§7) | BR-SYS-005 | 번호 불일치 — 모듈 스펙에서 변경 규칙 직후 배치 |
| BR-SYS-011 | DB 시딩 (§11) | BR-SYS-009 | 모듈 스펙에서 설계 원칙으로 분류 |
| BR-SYS-012 | 유효 범위 검증 (§4.3) | BR-SYS-013 | 모듈 스펙에서 OCC(012) 먼저 배치하여 번호 차이 |
| BR-SYS-013 | config_key 존재 확인 (§4.3) | BR-SYS-010 | 모듈 스펙에서 데이터 검증 섹션에 배치 |
