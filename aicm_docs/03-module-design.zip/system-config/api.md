# SystemConfig API 스펙

> 기능정의서: [FD-SYS-시스템설정](../../01-requirements/features/FD-SYS-시스템설정.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [system-config-module.md](./data.md)

> 에러 응답은 [횡단 관심사 §8.2.1](../../02-architecture/07-cross-cutting-concerns.md)의 공통 에러 응답 포맷(`{ error, message, details? }`)을 따른다. 도메인 에러 코드(`SYS_*`)는 `error` 필드에 포함된다.

> **응답 형식**: 모든 응답은 [횡단 관심사 §8.4](../../02-architecture/07-cross-cutting-concerns.md)의 공통 래퍼 `{ data, meta, pagination }` 형식을 따른다. 본 문서의 DTO 인터페이스(`PaginatedResponse` 등)는 래퍼의 `data` 필드 내부 구조만 기술한다 — 래퍼 자체는 전역 ResponseInterceptor가 자동 적용하므로 모듈 스펙에서는 비즈니스 데이터 구조에 집중한다. 단, 본 모듈은 오프셋 기반 페이지네이션을 적용한다 (하단 페이지네이션 방식 참조).

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| GET | /system-configs | 설정 목록 조회 | ADMIN (`manage_system`) |
| GET | /system-configs/:key | 설정 상세 조회 | ADMIN (`manage_system`) |
| PATCH | /system-configs/:key | 설정 변경 | ADMIN (`manage_system`) |
| PATCH | /system-configs/bulk | 설정 일괄 변경 | ADMIN (`manage_system`) |
| GET | /system-configs/:key/history | 설정 변경 이력 조회 | ADMIN (`manage_system`) |

> `:key`는 URL 인코딩된 `config_key` 값이다 (예: `lm%3Aaudit.retention_days`). `config_key`는 `{scope}:{module}.{name}` 형식이며 scope에 포함된 콜론(`:`)은 URL 인코딩이 필요하다.

> **페이지네이션 방식**: 시스템 설정은 카테고리 전체를 합산해도 수백 건 이내이므로, 커서 기반 대신 오프셋 기반 페이지네이션을 적용한다. 횡단 관심사 §8.4의 커서 기반 기본 정책에 대한 예외이며, 전체 건수가 수백 건을 초과하지 않는 Key-Value 설정 특성상 오프셋 방식의 성능 저하가 발생하지 않는다.

---

## 상세 API

### `GET` /system-configs

**설명**: 시스템 설정 목록을 조회한다. 카테고리 필터와 검색을 지원한다.

**권한**: ADMIN (`manage_system`)

**Request**:

- Query params:

```typescript
interface ListSystemConfigsQuery {
  category?: string;                // 카테고리 필터 (system, document, approval, aggregation, audit, export, embedding, community)
  search?: string;                  // config_key 또는 description LIKE 검색
  scope?: 'ft' | 'md' | 'lm' | 'pm'; // scope 필터
  page?: number;                    // 기본 1
  limit?: number;                   // 기본 50, 최대 200
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface SystemConfigListItem {
  id: string;
  configKey: string;
  configValue: any;
  valueType: 'number' | 'string' | 'boolean' | 'object' | 'array';
  description: string | null;
  category: string;
  version: number;                  // OCC용 현재 버전 — 목록에서도 노출하여 즉시 변경 시 활용
  updatedBy: string | null;
  updatedAt: string;
}
```

**비즈니스 규칙 참조**: [BR-SYS-001](rules.md#br-sys-001-설정-조회-권한)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SYS-001](rules.md#br-sys-001-설정-조회-권한) |

---

### `GET` /system-configs/:key

**설명**: 특정 설정의 상세 정보를 조회한다.

**권한**: ADMIN (`manage_system`)

**Request**:

- Path params: `key` — URL 인코딩된 config_key

**Response** (`200`):

```typescript
interface SystemConfigResponse {
  id: string;
  configKey: string;
  configValue: any;
  valueType: 'number' | 'string' | 'boolean' | 'object' | 'array';
  description: string | null;
  category: string;
  version: number;                  // OCC용 현재 버전
  updatedBy: string | null;
  updatedByName: string | null;
  createdAt: string;
  updatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SYS-001](rules.md#br-sys-001-설정-조회-권한) |
| SYS_CONFIG_NOT_FOUND | 404 | [BR-SYS-010](rules.md#br-sys-010-설정-키-존재-확인) |

---

### `PATCH` /system-configs/:key

**설명**: 설정값을 변경한다. `lm:`/`pm:` scope만 변경 가능하며([BR-SYS-002](rules.md#br-sys-002-변경-가능-scope-제한)), 그 외 키는 거부된다.

**권한**: ADMIN (`manage_system`)

**Request**:

- Path params: `key` — URL 인코딩된 config_key
- Body:

```typescript
interface UpdateSystemConfigDto {
  value: any;                       // 필수 — 새 설정값 (value_type과 일치해야 함)
  version: number;                  // 필수 — 현재 version (OCC 충돌 감지용) [BR-SYS-012]
}
```

**Response** (`200`): `SystemConfigResponse`

**비즈니스 규칙 참조**: [BR-SYS-002](rules.md#br-sys-002-변경-가능-scope-제한), [BR-SYS-003](rules.md#br-sys-003-value_type-타입-검증), [BR-SYS-004](rules.md#br-sys-004-하한선-보호-compliance-floor), [BR-SYS-005](rules.md#br-sys-005-감사-로그-기록), [BR-SYS-006](rules.md#br-sys-006-변경-즉시-적용-및-캐시-무효화), [BR-SYS-012](rules.md#br-sys-012-낙관적-동시성-제어-occ), [BR-SYS-013](rules.md#br-sys-013-설정값-유효-범위-검증)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SYS-001](rules.md#br-sys-001-설정-조회-권한) |
| SYS_IMMUTABLE_SCOPE | 403 | [BR-SYS-002](rules.md#br-sys-002-변경-가능-scope-제한) |
| SYS_CONFIG_NOT_FOUND | 404 | [BR-SYS-010](rules.md#br-sys-010-설정-키-존재-확인) |
| SYS_TYPE_MISMATCH | 422 | [BR-SYS-003](rules.md#br-sys-003-value_type-타입-검증) |
| SYS_BELOW_COMPLIANCE_FLOOR | 422 | [BR-SYS-004](rules.md#br-sys-004-하한선-보호-compliance-floor) |
| SYS_CONCURRENT_MODIFICATION | 409 | [BR-SYS-012](rules.md#br-sys-012-낙관적-동시성-제어-occ) |
| SYS_VALUE_OUT_OF_RANGE | 422 | [BR-SYS-013](rules.md#br-sys-013-설정값-유효-범위-검증) |

---

### `PATCH` /system-configs/bulk

**설명**: 여러 설정값을 한 번에 변경한다. 단일 트랜잭션으로 처리되어 모두 성공 또는 모두 실패한다.

**권한**: ADMIN (`manage_system`)

**Request**:

- Body:

```typescript
interface BulkUpdateSystemConfigDto {
  items: BulkUpdateItem[];          // 필수 — 변경 항목 배열 (최소 1건, 최대 50건)
}

interface BulkUpdateItem {
  key: string;                      // 필수 — config_key
  value: any;                       // 필수 — 새 설정값
  version: number;                  // 필수 — 현재 version (OCC 충돌 감지용) [BR-SYS-012]
}
```

**Response** (`200`):

```typescript
interface BulkUpdateResponse {
  updated: SystemConfigListItem[];
  updatedCount: number;
}
```

**비즈니스 규칙 참조**: [BR-SYS-011](rules.md#br-sys-011-일괄-변경-트랜잭션), [BR-SYS-002](rules.md#br-sys-002-변경-가능-scope-제한), [BR-SYS-003](rules.md#br-sys-003-value_type-타입-검증), [BR-SYS-004](rules.md#br-sys-004-하한선-보호-compliance-floor)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SYS-001](rules.md#br-sys-001-설정-조회-권한) |
| SYS_IMMUTABLE_SCOPE | 403 | [BR-SYS-002](rules.md#br-sys-002-변경-가능-scope-제한) |
| SYS_CONFIG_NOT_FOUND | 404 | [BR-SYS-010](rules.md#br-sys-010-설정-키-존재-확인) |
| SYS_TYPE_MISMATCH | 422 | [BR-SYS-003](rules.md#br-sys-003-value_type-타입-검증) |
| SYS_BELOW_COMPLIANCE_FLOOR | 422 | [BR-SYS-004](rules.md#br-sys-004-하한선-보호-compliance-floor) |
| SYS_CONCURRENT_MODIFICATION | 409 | [BR-SYS-012](rules.md#br-sys-012-낙관적-동시성-제어-occ) |
| SYS_VALUE_OUT_OF_RANGE | 422 | [BR-SYS-013](rules.md#br-sys-013-설정값-유효-범위-검증) |
| SYS_BULK_LIMIT_EXCEEDED | 422 | [BR-SYS-011](rules.md#br-sys-011-일괄-변경-트랜잭션) |

---

### `GET` /system-configs/:key/history

**설명**: 특정 설정의 변경 이력을 조회한다. AuditLog에서 해당 config_key의 `system_config.update` 액션을 조회한다.

**권한**: ADMIN (`manage_system`)

**Request**:

- Path params: `key` — URL 인코딩된 config_key
- Query params:

```typescript
interface ConfigHistoryQuery {
  from?: string;                    // 조회 시작 시점 (ISO 8601, FD-SYS §8.6 정렬)
  to?: string;                      // 조회 종료 시점 (ISO 8601, FD-SYS §8.6 정렬)
  page?: number;                    // 기본 1
  limit?: number;                   // 기본 20, 최대 100
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<ConfigHistoryItem> {
  items: ConfigHistoryItem[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface ConfigHistoryItem {
  id: string;                       // AuditLog ID
  configKey: string;
  beforeValue: any;
  afterValue: any;
  changedBy: string;
  changedByName: string | null;
  changedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-SYS-001](rules.md#br-sys-001-설정-조회-권한) |
| SYS_CONFIG_NOT_FOUND | 404 | [BR-SYS-010](rules.md#br-sys-010-설정-키-존재-확인) |

---

## 내부 서비스 인터페이스

> 위 REST API는 관리자 UI용이다. 대부분의 도메인 모듈은 아래 내부 서비스를 통해 설정값을 읽는다.

### SystemConfigService

다른 도메인 모듈이 설정값을 읽을 때 사용하는 내부 서비스 인터페이스. REST API를 경유하지 않고 `SystemConfigService`를 직접 DI하여 호출한다.

```typescript
@Injectable()
export class SystemConfigService {
  /**
   * 설정값 조회 — Redis 캐시 우선, miss 시 DB 조회
   * @returns 설정값 또는 null (키 미존재 시)
   */
  async getValue<T>(key: string): Promise<T | null>;

  /**
   * 설정값 조회 (기본값 포함) — 키 미존재 시 defaultValue 반환
   */
  async getValueOrDefault<T>(key: string, defaultValue: T): Promise<T>;

  /**
   * 카테고리별 설정 목록 조회
   */
  async getByCategory(category: string): Promise<SystemConfig[]>;

  /**
   * 설정값 변경 — DB 업데이트 + 캐시 무효화 + 감사 로그
   * REST API(PATCH /system-configs/:key)의 내부 구현체
   * @param version 현재 version (OCC 충돌 감지용) [BR-SYS-012]
   */
  async updateValue(key: string, value: any, version: number, actorId: string): Promise<SystemConfig>;
}
```

**사용 예시** (DocumentModule):

```typescript
@Injectable()
export class DocumentService {
  constructor(private readonly systemConfig: SystemConfigService) {}

  async addTags(documentId: string, tags: string[]) {
    const maxTags = await this.systemConfig.getValueOrDefault<number>(
      'lm:document.max_tags', 10,
    );
    if (tags.length > maxTags) {
      throw new BadRequestException(`태그는 최대 ${maxTags}개까지 가능합니다.`);
    }
  }
}
```

> **캐시 전략**: `getValue`/`getValueOrDefault`는 내부적으로 Redis cache-aside 패턴을 적용한다. Redis 장애 시 DB 직접 조회로 폴백한다. 상세: [cache.md](cache.md)

---

## 라우팅 주의사항

NestJS에서 `PATCH /system-configs/:key`의 `:key` 파라미터 라우트는 `PATCH /system-configs/bulk` 경로도 매칭할 수 있다. `bulk` 핸들러를 `:key` 핸들러보다 **컨트롤러 내에서 먼저 선언**하여 라우트 우선순위를 확보해야 한다.

```typescript
@Controller('system-configs')
export class SystemConfigController {
  @Patch('bulk')       // ← 먼저 선언
  async bulkUpdate() { /* ... */ }

  @Patch(':key')       // ← 나중에 선언
  async update() { /* ... */ }
}
```

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **SystemConfig 도메인 에러** 전체 목록은 [rules.md §3 에러 코드 카탈로그](rules.md#3-에러-코드-카탈로그) 참조
>
> **에러 코드 접두사 `SYS_`**: SystemConfigModule은 독립 도메인 모듈로서 `SYS_` 접두사를 사용한다. 횡단 관심사 §8.2.3의 모듈별 접두사 예약 테이블에서 AdminModule이 `SYSTEM_` 접두사를 예약하고 있으나, SystemConfigModule은 AdminModule과 분리된 독립 모듈이며 `SYS_`와 `SYSTEM_`는 문자열이 달라 네임스페이스가 충돌하지 않는다.
