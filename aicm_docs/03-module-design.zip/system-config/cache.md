# SystemConfig 캐시 전략

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 캐시 개요

| 캐시 대상 | 전략 | 저장소 | 키 패턴 | TTL | 무효화 트리거 |
|-----------|------|--------|---------|-----|-------------|
| 설정값 | cache-aside | Redis | `{tenant_id}:cache:syscfg:{config_key}` | 1h (3600s) | 설정 변경 시 즉시 무효화 [BR-SYS-006] |

---

## 2. 캐시 상세

### 2.1 설정값 캐시 (Config Value Cache)

#### 기본 정보

- **전략**: cache-aside (읽기 시 캐시 조회 → miss 시 DB → 캐시 적재)
- **키 패턴**: `{tenant_id}:cache:syscfg:{config_key}` (예: `default:cache:syscfg:lm:audit.retention_days`)
- **TTL**: 3600초 (1시간) — 무효화 누락 시 최대 1시간 내 최신값 보장하는 안전망
- **직렬화**: JSON — `config_value`(JSONB)와 `value_type`을 함께 직렬화

```typescript
interface CachedConfigEntry {
  value: any;         // config_value 원본
  valueType: string;  // value_type (역직렬화 시 타입 힌트)
}
```

#### 읽기 흐름

```
SystemConfigService.getValue(key)
  │
  ├── Redis GET {tenant_id}:cache:syscfg:{key}
  │     ├── HIT → JSON.parse → 반환
  │     └── MISS ──┐
  │                │
  ├── DB SELECT WHERE config_key = {key}
  │     ├── 존재 → Redis SET + TTL 3600s → 반환
  │     └── 미존재 → null 반환 (캐시 적재하지 않음)
  │
  └── Redis 장애 시 → §2.3 폴백 참조
```

#### 무효화

- **트리거**: 설정값 변경 성공 시 [BR-SYS-006]
- **방식**: 단일 키 무효화 (`DEL {tenant_id}:cache:syscfg:{config_key}`)
  - 전체 flush가 아닌 변경된 키만 삭제하여 캐시 스톰 방지
  - bulk 변경 시 변경된 N개 키를 Redis 파이프라인으로 일괄 DEL
- **무효화 실패 시**:
  - TTL(1시간)이 안전망으로 작동 — 최대 1시간 내 자동 만료
  - 무효화 실패를 WARN 로그로 기록하되, DB 커밋은 롤백하지 않음 (eventual consistency 허용)
  - 재시도하지 않음 — TTL 안전망이 있으므로 불필요한 복잡도 방지

```
PATCH /system-configs/:key (변경 요청)
  │
  ├── DB에서 현재 version 조회
  │     ├── 요청 version == DB version → 변경 진행
  │     └── 요청 version != DB version → SYS_CONCURRENT_MODIFICATION (409) [BR-SYS-012]
  │
  ├── DB UPDATE (value, version+1) + COMMIT
  │
  ├── Redis DEL {tenant_id}:cache:syscfg:{key}
  │     ├── 성공 → 다음 읽기 시 cache miss → DB → 캐시 재적재
  │     └── 실패 → WARN 로그, TTL 만료까지 stale 데이터 허용
  │
  ├── EventBus 발행: system_config.changed [events.md §1.1]
  │
  └── AuditLog 기록 [BR-SYS-005]
```

### 2.2 Warm-up (서비스 시작 시 Preload)

SystemConfigModule은 대부분의 도메인 모듈이 의존하는 Layer 1 모듈이므로, 서비스 시작 직후 cache miss 폭주를 방지하기 위해 전체 설정을 preload한다.

- **실행 시점**: `OnModuleInit` 훅
- **동작**: SystemConfig 전체 레코드를 DB에서 조회하여 Redis에 일괄 SET (파이프라인)
- **실패 처리**: preload 실패 시에도 서비스 시작은 진행 — WARN 로그 기록. 이후 읽기 요청에서 개별 cache miss → DB 조회로 점진적 적재

```typescript
async onModuleInit(): Promise<void> {
  try {
    const configs = await this.repository.find();
    const pipeline = this.redis.pipeline();
    for (const config of configs) {
      const cached: CachedConfigEntry = {
        value: config.configValue,
        valueType: config.valueType,
      };
      pipeline.set(
        `${this.tenantId}:cache:syscfg:${config.configKey}`,
        JSON.stringify(cached),
        'EX', 3600,
      );
    }
    await pipeline.exec();
  } catch (error) {
    this.logger.warn('SystemConfig preload 실패 — cache miss 시 DB fallback', error);
  }
}
```

### 2.3 Redis 장애 시 폴백

SystemConfigModule은 Layer 1 인프라이므로 Redis 장애가 전체 서비스 장애로 이어지지 않도록 DB 직접 조회 폴백을 제공한다.

| 상황 | 동작 |
|------|------|
| Redis 응답 정상 | cache-aside 정상 흐름 |
| Redis 연결 실패 / 타임아웃 | DB 직접 조회로 폴백, WARN 로그 |
| Redis 연속 실패 ≥ 3회 | Circuit Breaker OPEN — 일정 시간(30초) Redis 건너뛰고 DB 직접 조회 |
| Circuit Breaker OPEN 상태에서 30초 경과 | HALF-OPEN — 다음 1건은 Redis 시도, 성공 시 CLOSED 복귀 |

```
SystemConfigService.getValue(key)
  │
  ├── Circuit Breaker 상태 확인
  │     ├── CLOSED → Redis 시도
  │     │     ├── 성공 → 정상 흐름
  │     │     └── 실패 → 실패 카운터 증가 → DB 폴백
  │     │           └── 카운터 ≥ 3 → OPEN 전환
  │     ├── OPEN → Redis 건너뜀 → DB 직접 조회
  │     └── HALF-OPEN → Redis 1건 시도
  │           ├── 성공 → CLOSED 복귀
  │           └── 실패 → OPEN 유지
  │
  └── DB 폴백 결과는 Redis에 적재하지 않음 (장애 중이므로)
```

### 2.4 앱 레벨 메모리 캐시 (2차 캐시)

현재 미적용. 모든 설정값 읽기는 Redis(1차) → DB(폴백) 경로를 사용한다.

향후 읽기 빈도가 극단적으로 높은 키(예: `lm:system.max_upload_bytes` — 모든 파일 업로드 요청마다 조회)에 대해 프로세스 메모리 캐시(TTL 30초) 도입을 검토할 수 있다. 도입 시 설정 변경 → 메모리 캐시 갱신 메커니즘이 필요하며, 이 때 EventBus 발행(`system_config.changed` — [events.md §1.1](events.md#11-best-effort-티어--eventbus-nestjs-eventemitter))을 함께 검토한다.

---

## 3. Redis 작업 타임아웃

모든 Redis 작업에 개별 타임아웃을 설정하여 Redis 지연이 API 응답에 전파되지 않도록 한다.

| 작업 | 타임아웃 | 실패 시 동작 |
|------|---------|------------|
| GET (캐시 조회) | 200ms | DB 직접 조회 폴백 (cache miss 취급) |
| SET (캐시 적재) | 500ms | WARN 로그, 다음 읽기 시 재시도 |
| DEL (캐시 무효화) | 500ms | WARN 로그, TTL 만료까지 stale 허용 |
| Pipeline (Warm-up 일괄 SET) | 5000ms | WARN 로그, 개별 cache miss → DB fallback |

> 타임아웃 값은 Redis 네트워크 라운드트립(< 1ms 로컬, < 10ms 원격)과 키 크기(설정값 평균 < 1KB)를 고려하여 설정한다. SigNoz에서 `syscfg_cache_*_duration` 메트릭으로 실제 레이턴시를 모니터링하여 조정한다.

---

## 4. 모니터링 메트릭

| 메트릭 | 타입 | 설명 | 알림 임계값 |
|--------|------|------|-----------|
| `syscfg_cache_hit_total` | Counter | 캐시 히트 수 | — |
| `syscfg_cache_miss_total` | Counter | 캐시 미스 수 | 히트율 < 80% (5분 윈도우) — 캐시 효율 저하 경고 |
| `syscfg_cache_invalidation_total` | Counter | 캐시 무효화 수 | — |
| `syscfg_cache_invalidation_failure_total` | Counter | 캐시 무효화 실패 수 | > 0 (1분 윈도우) — 즉시 WARN 알림 |
| `syscfg_cache_fallback_total` | Counter | Redis 장애 시 DB 폴백 수 | > 10회/분 — Redis 연결 상태 점검 필요 |
| `syscfg_circuit_breaker_state` | Gauge | Circuit Breaker 상태 (0=CLOSED, 1=OPEN, 2=HALF-OPEN) | = 1 (OPEN) — 즉시 관리자 알림 |
| `syscfg_cache_get_duration` | Histogram | Redis GET 레이턴시 (ms) | p99 > 100ms — Redis 성능 점검 필요 |
| `syscfg_cache_set_duration` | Histogram | Redis SET 레이턴시 (ms) | p99 > 200ms |

> 알림 채널: 인앱 관리자 알림 + 이메일. SigNoz 대시보드에서 메트릭 추이를 확인한다.

---

## 5. 키 패턴 요약

> `redis.md`와 일치를 보장한다.

| 키 패턴 | 타입 | TTL | 용도 |
|---------|------|-----|------|
| `{tenant_id}:cache:syscfg:{config_key}` | STRING (JSON) | 3600s | 설정값 읽기 캐시 |
