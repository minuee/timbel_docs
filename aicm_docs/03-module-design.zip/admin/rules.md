# Admin 비즈니스 규칙

> 기능정의서: [FD-ADM-관리자](../../01-requirements/features/FD-ADM-관리자.md)
> API 스펙: [api.md](api.md)

---

## 상태 전이

<!-- Admin에는 상태 전이 없음. 이 섹션 삭제 가능 -->

---

## 규칙 카탈로그

<!-- TODO: ADMIN 역할 + AdminPermission 기반 접근 제어, 권한 출처 역추적, 관리 기능 17종 규칙 등 -->

### BR-ADM-001: {규칙 이름}

- **트리거**:
- **조건**:
- **동작**:
- **위반 시**:
- **근거**:
