# Admin API 스펙

> 기능정의서: [FD-ADM-관리자](../../01-requirements/features/FD-ADM-관리자.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 엔드포인트 요약

<!-- TODO: 관리자 대시보드, 통계, 게시판/템플릿/태그/사용자/그룹/역할 관리, 검색 튜닝, 임베딩 모니터링, 프롬프트 관리, 신고 처리 -->

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| | | | |

---

## 상세 API

### `{METHOD}` /api/admin/{path}

**설명**:

**권한**:

**Request**:

- Path params:
- Query params:
- Body:

```typescript
// TODO: Request DTO
```

**Response** (`200`):

```typescript
// TODO: Response DTO
```

**에러 코드**:

| HTTP | 코드 | 설명 |
|------|------|------|
| | | |

**비즈니스 규칙 참조**: BR-ADM-xxx
