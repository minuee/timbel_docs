# Admin 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | AdminModule |
| 문서 코드 | MS-ADM |
| 상태 | `미착수` |
| 기능정의서 | [FD-ADM-관리자](../../01-requirements/features/FD-ADM-관리자.md) |
| 데이터 모델 | — |
| 프로세스 흐름 | [flows/admin-settings/](../../01-requirements/flows/admin-settings/) |

---

## 모듈 책임

<!-- TODO: 관리자 대시보드, 관리자 전용 통계, 시스템 설정 조회 -->

---

## 핵심 엔티티

<!-- TODO: AdminModule은 자체 엔티티 없이 다른 모듈 데이터를 조회 -->

| 엔티티 | 설명 |
|--------|------|
| — | 자체 엔티티 없음 |

---

## 의존 관계

<!-- TODO: Admin → Document (읽기), Admin → Board (읽기), Admin → Prompt (읽기) -->

```mermaid
graph LR
    %% TODO: 의존 관계 다이어그램 작성
```

---

## 인프라 사용 요약

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | | |
| Redis / BullMQ | | |
| Elasticsearch | | |
| MinIO | | |
| EventBus | | |
| 외부 서비스 클라이언트 | | |
