# Document API 스펙

> 기능정의서: [FD-DOC-문서관리](../../01-requirements/features/FD-DOC-문서관리.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 데이터 모델: [document-module.md](./data.md)

---

## 엔드포인트 요약

| 메서드 | 경로 | 설명 | 권한 |
|--------|------|------|------|
| POST | /documents | 문서 생성 | EDIT |
| GET | /documents | 문서 목록 조회 | VIEW |
| GET | /documents/:id | 문서 상세 조회 | VIEW |
| PATCH | /documents/:id | 문서 메타데이터 수정 | EDIT |
| DELETE | /documents/:id | 문서 소프트 삭제 | EDIT |
| POST | /documents/:id/restore | 삭제 복구 | ADMIN |
| POST | /documents/:id/submit | 승인 요청 | EDIT |
| POST | /documents/:id/withdraw | 승인 철회 | EDIT (작성자) |
| POST | /documents/:id/publish | 직접 발행 (자유 모드) | EDIT |
| POST | /documents/:id/edit | 수정 시작 (재편집) | EDIT |
| POST | /documents/:id/archive | 아카이빙 | APPROVE / ADMIN |
| POST | /documents/:id/reactivate | 재활성화 | APPROVE / ADMIN |
| POST | /documents/:id/suspend | 긴급 회수 | EDIT / APPROVE |
| POST | /documents/:id/unsuspend | 회수 해제 | EDIT / APPROVE |
| POST | /documents/:id/cancel-schedule | 예약 취소 | APPROVE / ADMIN |
| POST | /documents/:id/rollback | 버전 롤백 | EDIT |
| PUT | /documents/:id/blocks | 블록 일괄 저장 (자동 저장) | EDIT (락 보유자) |
| POST | /documents/:id/lock | 편집 락 획득 | EDIT |
| DELETE | /documents/:id/lock | 편집 락 해제 | EDIT (락 보유자) |
| GET | /documents/:id/lock | 편집 락 상태 조회 | 인증 필요 |
| PATCH | /documents/:id/restriction | 문서 제한 모드 전환 | APPROVE / ADMIN |
| GET | /documents/:id/restrictions | 문서 제한 목록 조회 | APPROVE / ADMIN |
| PUT | /documents/:id/restrictions | 문서 제한 목록 설정 | APPROVE / ADMIN |
| PATCH | /documents/:documentId/blocks/:blockId/restriction | 블록 제한 모드 전환 | APPROVE / ADMIN |
| GET | /documents/:id/versions | 버전 목록 조회 | VIEW |
| GET | /documents/:id/versions/:versionId | 버전 상세 조회 | VIEW |
| GET | /documents/:id/versions/:versionId/diff | 버전 간 diff | VIEW |
| POST | /documents/:id/tags | 태그 추가 | EDIT |
| DELETE | /documents/:id/tags/:tagId | 태그 제거 | EDIT |
| GET | /tags | 태그 목록/자동완성 | 인증 필요 |
| GET | /boards/:boardId/banners | 크로스보드 공지 배너 목록 조회 | 인증 필요 (VIEW 불필요) |
| GET | /documents/:id/toc | 문서 목차 조회 | VIEW |
| POST | /documents/:id/ai/improve | AI 글쓰기 개선 | EDIT |

---

## 상세 API

### `POST` /documents

**설명**: 새 문서를 생성한다. draft 상태로 시작.

**권한**: 지정 게시판의 EDIT

**Request**:

- Body:

```typescript
interface CreateDocumentDto {
  boardId: string;                    // 필수 — 소속 게시판 UUID
  templateId?: string;                // 선택 — 템플릿 UUID (보일러플레이트 적용)
  title: string;                      // 필수 — 문서 제목 (max 500자)
  tags?: string[];                    // 선택 — 태그명 배열 (max 10개, 없는 태그는 자동 생성)
  assigneeId?: string;                // 선택 — 담당자 UUID (미지정 시 작성자)
  expiresAt?: string;                 // 선택 — 유효기간 ISO 8601
  retentionPolicyId?: string;         // 선택 — 보존 정책 UUID (미지정 시 게시판 기본값 적용)
}
```

**Response** (`201`):

```typescript
interface DocumentResponse {
  id: string;
  boardId: string;
  templateId: string | null;
  title: string;
  status: DocumentStatus;
  isSuspended: boolean;
  isRestricted: boolean;
  summary: string | null;
  embeddingStatus: EmbeddingStatus;
  assigneeId: string;
  expiresAt: string | null;
  retentionPolicyId: string | null;
  retentionExpiresAt: string | null;
  viewCount: number;
  tags: TagResponse[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

interface TagResponse {
  id: string;
  name: string;
  slug: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-001](rules.md#br-doc-001-문서-생성-필수-조건) |
| BOARD_NOT_FOUND | 404 | [BR-DOC-001](rules.md#br-doc-001-문서-생성-필수-조건) |
| TEMPLATE_NOT_FOUND | 404 | [BR-DOC-001](rules.md#br-doc-001-문서-생성-필수-조건) |
| TAG_LIMIT_EXCEEDED | 422 | [BR-DOC-002](rules.md#br-doc-002-문서당-태그-수-제한) |

---

### `GET` /documents

**설명**: 문서 목록을 조회한다. 권한 필터 자동 적용.

**권한**: VIEW (접근 가능 게시판의 문서만 반환)

**Request**:

- Query params:

```typescript
interface ListDocumentsQuery {
  boardId?: string;             // 게시판 필터
  status?: DocumentStatus;      // 상태 필터
  tagIds?: string[];            // 태그 필터 (AND 조건)
  assigneeId?: string;          // 담당자 필터
  createdBy?: string;           // 작성자 필터
  search?: string;              // 제목 LIKE 검색
  sort?: 'createdAt' | 'updatedAt' | 'title' | 'viewCount';
  order?: 'ASC' | 'DESC';
  page?: number;                // 기본 1
  limit?: number;               // 기본 20, 최대 100
  includeDeleted?: boolean;     // 관리자 전용 — 삭제된 문서 포함
}
```

**Response** (`200`):

```typescript
interface PaginatedResponse<T> {
  items: T[];
  meta: {
    page: number;
    limit: number;
    totalItems: number;
    totalPages: number;
  };
}

interface DocumentListItem {
  id: string;
  boardId: string;
  boardName: string;
  title: string;
  status: DocumentStatus;
  isSuspended: boolean;
  isRestricted: boolean;
  summary: string | null;
  embeddingStatus: EmbeddingStatus;
  tags: TagResponse[];
  viewCount: number;
  assigneeId: string | null;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  publishedVersionNumber: number | null;
}
```

---

### `GET` /documents/:id

**설명**: 문서 상세 정보 + 블록 콘텐츠를 조회한다. 발행된 문서는 published_version_id 기준, draft는 Working Copy 기준.

**권한**: VIEW (Restriction 평가 포함)

**Request**:

- Path params: `id` — 문서 UUID

**Response** (`200`):

```typescript
interface DocumentDetailResponse {
  id: string;
  boardId: string;
  boardName: string;
  templateId: string | null;
  publishedVersionId: string | null;
  title: string;
  status: DocumentStatus;
  isSuspended: boolean;
  isRestricted: boolean;
  summary: string | null;
  embeddingStatus: EmbeddingStatus;
  currentEditorId: string | null;
  editorLockAt: string | null;
  expiresAt: string | null;
  retentionPolicyId: string | null;
  retentionExpiresAt: string | null;
  scheduledPublishAt: string | null;
  assigneeId: string | null;
  assigneeName: string | null;
  viewCount: number;
  attachments: AttachmentResponse[];
  tags: TagResponse[];
  blocks: BlockResponse[];
  createdBy: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
}

interface BlockResponse {
  id: string;
  blockType: 'text' | 'image' | 'table' | 'file';
  contentRaw: Record<string, any>;    // Tiptap JSON
  contentText: string | null;
  headingLevel: number | null;
  sequence: number;
  caption: string | null;
  annotation: { text: string; visible: boolean } | null;
  embeddable: boolean;
  visible: boolean;
  isRestricted: boolean;
  metadata: Record<string, any> | null;
}

interface AttachmentResponse {
  id: string;
  fileName: string;
  fileUrl: string;
  thumbnailUrl: string | null;
  fileSize: number;
  mimeType: string;
  createdAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| DOCUMENT_NOT_FOUND | 404 | — |

**비즈니스 규칙 참조**: BR-DOC-032 (조회수 증가), BR-DOC-036 (검색 필터)

---

### `PATCH` /documents/:id

**설명**: 문서 메타데이터를 수정한다. 블록 콘텐츠 수정은 PUT /documents/:id/blocks 사용.

**권한**: EDIT (일부 필드는 추가 권한 필요)

**Request**:

- Body:

```typescript
interface UpdateDocumentDto {
  title?: string;                     // max 500자
  summary?: string;
  assigneeId?: string;                // 작성자/APPROVE/ADMIN만 [BR-DOC-035]
  expiresAt?: string | null;          // 담당자/ADMIN만 [BR-DOC-029]
  retentionPolicyId?: string | null;  // ADMIN만
  scheduledPublishAt?: string | null; // ISO 8601 미래 시점. null이면 예약 취소 [BR-DOC-042]
  attachments?: AttachmentDto[];
}

interface AttachmentDto {
  id?: string;                        // 기존 첨부파일 유지 시
  fileName: string;
  fileUrl: string;
  thumbnailUrl?: string;
  fileSize: number;
  mimeType: string;
}
```

**Response** (`200`): `DocumentResponse`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| RETENTION_PERIOD_ACTIVE | 403 | [BR-DOC-018](rules.md#br-doc-018-보존기간-내-삭제상태변경-차단) |
| DOCUMENT_NOT_FOUND | 404 | — |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-042](rules.md#br-doc-042-예약-게시-취소-free-모드) — 예약 취소 대상이 draft 상태가 아니거나 scheduled_publish_at이 없는 경우 |

---

### `DELETE` /documents/:id

**설명**: 문서를 소프트 삭제한다. 관리 모드 게시판에서는 삭제 승인이 필요할 수 있음.

**권한**: EDIT (작성자 또는 게시판 EDIT 권한)

**Response** (`200` / `202`):

- `200`: 즉시 삭제 완료
- `202`: 삭제 승인 워크플로 진입 (관리 모드)

```typescript
interface DeleteDocumentResponse {
  id: string;
  deletedAt: string | null;           // 즉시 삭제 시
  approvalRequired: boolean;          // true이면 202
  approvalId?: string;                // 승인 워크플로 ID
}
```

> **FD 대비 변경**: FD-DOC §1.8에서 `DELETE → 204 No Content`로 정의하였으나, 모듈 스펙에서는 `200`(삭제 정보 반환)과 `202`(승인 워크플로 진입) 두 응답을 사용한다. 관리 모드 게시판에서의 삭제 승인 워크플로를 프론트엔드가 구분하려면 응답 본문이 필요하기 때문이다.

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-015](rules.md#br-doc-015-소프트-삭제) |
| RETENTION_PERIOD_ACTIVE | 403 | [BR-DOC-018](rules.md#br-doc-018-보존기간-내-삭제상태변경-차단) |
| DOCUMENT_NOT_FOUND | 404 | — |

**비즈니스 규칙 참조**: BR-DOC-015

---

### `POST` /documents/:id/submit

**설명**: 승인 요청 (관리 모드 게시판). draft → pending_review 전이.

**권한**: EDIT (작성자)

**Request**:

- Body:

```typescript
interface SubmitDocumentDto {
  comment?: string;           // 승인 요청 코멘트 → CreateApprovalInternalDto.comment
  ccUserIds?: string[];       // 참조라인 (BR-APR-009) → CreateApprovalInternalDto.ccUserIds
  selectedApprovers?: Record<number, string[]>;  // 승인자 직접 지정 → CreateApprovalInternalDto.selectedApprovers
  scheduledAt?: string;       // 선택 — 예약 배포 일시 (ISO 8601)
}
```

**Response** (`200`):

```typescript
interface SubmitDocumentResponse {
  id: string;
  status: 'pending_review';
  version: {
    id: string;
    versionNumber: number;
    status: 'submitted';
    createdAt: string;
  };
  approvalId: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-003](rules.md#br-doc-003-승인-요청-전이-관리-모드) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-003](rules.md#br-doc-003-승인-요청-전이-관리-모드) |
| FREE_MODE_BOARD | 409 | [BR-DOC-003](rules.md#br-doc-003-승인-요청-전이-관리-모드) |

---

### `POST` /documents/:id/publish

**설명**: 직접 발행 (자유 모드 게시판). draft → published 전이. `scheduledPublishAt` 지정 시 즉시 발행 대신 예약 게시.

**권한**: EDIT

**Request**:

- Body (선택):

```typescript
interface PublishDocumentDto {
  scheduledPublishAt?: string;  // ISO 8601 미래 시점. 지정 시 즉시 발행 대신 예약
}
```

**Response** (`200`):

- 즉시 발행 시:

```typescript
interface PublishDocumentResponse {
  id: string;
  status: 'published';
  publishedAt: string;
}
```

- `scheduledPublishAt` 지정 시:

```typescript
interface ScheduledPublishDocumentResponse {
  id: string;
  status: 'draft';
  scheduledPublishAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-004](rules.md#br-doc-004-직접-발행-전이-자유-모드) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-004](rules.md#br-doc-004-직접-발행-전이-자유-모드) |
| MANAGED_MODE_BOARD | 409 | [BR-DOC-004](rules.md#br-doc-004-직접-발행-전이-자유-모드) |

---

### `POST` /documents/:id/edit

**설명**: 발행된 문서의 수정을 시작한다. published → draft 전이 + 편집 락 획득.

**권한**: EDIT

**Response** (`200`):

```typescript
interface EditDocumentResponse {
  id: string;
  status: 'draft';
  currentEditorId: string;
  editorLockAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-010](rules.md#br-doc-010-수정-시작-재편집) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-010](rules.md#br-doc-010-수정-시작-재편집) |
| DOCUMENT_LOCKED | 423 | [BR-DOC-024](rules.md#br-doc-024-편집-락-획득) |

---

### `POST` /documents/:id/suspend

**설명**: 긴급 회수. is_suspended = true 전환.

**권한**: EDIT / APPROVE

**Request**:

- Body:

```typescript
interface SuspendDocumentDto {
  reason: string;             // 필수 — 회수 사유
}
```

**Response** (`200`):

```typescript
interface SuspendDocumentResponse {
  id: string;
  isSuspended: true;
  suspendedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-013](rules.md#br-doc-013-긴급-회수-is_suspended--true) |
| SUSPEND_ONLY_PUBLISHED | 409 | [BR-DOC-013](rules.md#br-doc-013-긴급-회수-is_suspended--true) |

---

### `POST` /documents/:id/unsuspend

**설명**: 긴급 회수를 해제한다. is_suspended = false 전환.

**권한**: EDIT / APPROVE

**Response** (`200`):

```typescript
interface UnsuspendDocumentResponse {
  id: string;
  isSuspended: false;
  unsuspendedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-014](rules.md#br-doc-014-회수-해제-is_suspended--false) |
| NOT_SUSPENDED | 409 | [BR-DOC-014](rules.md#br-doc-014-회수-해제-is_suspended--false) |

---

### `POST` /documents/:id/withdraw

**설명**: 승인 요청을 작성자가 철회한다. pending_review → draft 전이.

**권한**: EDIT (작성자)

**Response** (`200`):

```typescript
interface WithdrawDocumentResponse {
  id: string;
  status: 'draft';
  withdrawnAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-005](rules.md#br-doc-005-반려철회-전이) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-005](rules.md#br-doc-005-반려철회-전이) |

---

### `POST` /documents/:id/restore

**설명**: 소프트 삭제된 문서를 복구한다. 관리자 전용.

**권한**: ADMIN (`manage_boards`)

**Response** (`200`):

```typescript
interface RestoreDocumentResponse {
  id: string;
  status: string;
  restoredAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-016](rules.md#br-doc-016-삭제-복구) |
| DOCUMENT_NOT_FOUND | 404 | [BR-DOC-016](rules.md#br-doc-016-삭제-복구) |

---

### `POST` /documents/:id/archive

**설명**: 발행된 문서를 아카이빙한다. 검색/RAG에서 제외.

**권한**: APPROVE / ADMIN

**Response** (`200`):

```typescript
interface ArchiveDocumentResponse {
  id: string;
  status: 'archived';
  archivedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-011](rules.md#br-doc-011-아카이빙) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-011](rules.md#br-doc-011-아카이빙) |
| RETENTION_PERIOD_ACTIVE | 403 | [BR-DOC-018](rules.md#br-doc-018-보존기간-내-삭제상태변경-차단) |

---

### `POST` /documents/:id/reactivate

**설명**: 아카이빙된 문서를 재활성화한다. archived → draft 전이.

**권한**: APPROVE / ADMIN

**Response** (`200`):

```typescript
interface ReactivateDocumentResponse {
  id: string;
  status: 'draft';
  reactivatedAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-012](rules.md#br-doc-012-재활성화) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-012](rules.md#br-doc-012-재활성화) |

---

### `POST` /documents/:id/cancel-schedule

**설명**: 예약 배포를 취소한다. approved_scheduled → draft 전이.

**권한**: APPROVE / ADMIN

**Response** (`200`):

```typescript
interface CancelScheduleResponse {
  id: string;
  status: 'draft';
  cancelledAt: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-009](rules.md#br-doc-009-예약-취소) |
| INVALID_STATUS_TRANSITION | 409 | [BR-DOC-009](rules.md#br-doc-009-예약-취소) |

---

### `POST` /documents/:id/rollback

**설명**: 이전 발행 버전으로 Working Copy를 복원한다. Copy-forward 패턴.

**권한**: EDIT

**Request**:

- Body:

```typescript
interface RollbackDocumentDto {
  targetVersionId: string;    // 필수 — 롤백 대상 DocumentVersion UUID
}
```

**Response** (`200`):

```typescript
interface RollbackDocumentResponse {
  id: string;
  status: 'draft';
  restoredFromVersion: {
    id: string;
    versionNumber: number;
  };
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-023](rules.md#br-doc-023-버전-롤백-copy-forward) |
| VERSION_NOT_FOUND | 404 | [BR-DOC-023](rules.md#br-doc-023-버전-롤백-copy-forward) |
| VERSION_NOT_PUBLISHED | 409 | [BR-DOC-023](rules.md#br-doc-023-버전-롤백-copy-forward) |

---

### `PUT` /documents/:id/blocks

**설명**: 블록 일괄 저장 (자동 저장). 변경된 블록만 diff로 전송.

**권한**: EDIT (편집 락 보유자만)

**Request**:

- Body:

```typescript
interface SaveBlocksDto {
  upsertBlocks: UpsertBlockDto[];     // 생성/수정 블록
  deleteBlockIds: string[];            // 삭제 블록 ID
  reorderSequence?: { id: string; sequence: number }[];  // 순서 변경
}

interface UpsertBlockDto {
  id?: string;                         // 기존 블록 수정 시 필수
  blockType: 'text' | 'image' | 'table' | 'file';
  contentRaw: Record<string, any>;     // Tiptap JSON
  sequence: number;
  caption?: string;
  annotation?: { text: string; visible: boolean };
  embeddable?: boolean;                // 기본 true
  visible?: boolean;                   // 기본 true
  metadata?: Record<string, any>;
}
```

**Response** (`200`):

```typescript
interface SaveBlocksResponse {
  savedAt: string;
  blocks: { id: string; sequence: number }[];   // 저장된 블록 ID/순서
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | — |
| NOT_DRAFT | 409 | [BR-DOC-026](rules.md#br-doc-026-자동-저장) |
| DOCUMENT_LOCKED | 423 | [BR-DOC-024](rules.md#br-doc-024-편집-락-획득) |

**비즈니스 규칙 참조**: BR-DOC-026 (자동 저장)

---

### `POST` /documents/:id/lock

**설명**: 편집 락을 획득한다.

**권한**: EDIT

**Response** (`200`):

```typescript
interface LockResponse {
  documentId: string;
  currentEditorId: string;
  editorLockAt: string;
  expiresAt: string;          // 락 만료 시각
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| DOCUMENT_LOCKED | 423 | [BR-DOC-024](rules.md#br-doc-024-편집-락-획득) |

---

### `DELETE` /documents/:id/lock

**설명**: 편집 락을 명시적으로 해제한다.

**권한**: EDIT (락 보유자)

**Response** (`200`): `{ released: true }`

---

### `GET` /documents/:id/lock

**설명**: 문서의 편집 락 상태를 조회한다.

**권한**: 인증 필요

**Response** (`200`):

```typescript
interface LockStatusResponse {
  documentId: string;
  isLocked: boolean;
  currentEditorId: string | null;
  currentEditorName: string | null;
  editorLockAt: string | null;
  expiresAt: string | null;
}
```

---

### `PATCH` /documents/:id/restriction

**설명**: 문서 제한 모드를 전환한다.

**권한**: APPROVE / ADMIN

**Request**:

- Body:

```typescript
interface UpdateRestrictionDto {
  isRestricted: boolean;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| FORBIDDEN | 403 | [BR-DOC-030](rules.md#br-doc-030-문서-제한-모드-전환) |
| RESTRICTION_REQUIRES_ENTRIES | 422 | [BR-DOC-030](rules.md#br-doc-030-문서-제한-모드-전환) |

---

### `GET` /documents/:id/restrictions

**설명**: 문서 제한 대상 목록을 조회한다.

**권한**: APPROVE / ADMIN

**Response** (`200`):

```typescript
interface RestrictionListResponse {
  documentId: string;
  isRestricted: boolean;
  restrictions: RestrictionResponse[];
}
```

> 제한 대상은 문서당 수십 건 이내로 예상되므로 페이지네이션을 적용하지 않고 전체 목록을 반환한다. 향후 대규모 팀 환경에서 제한 대상이 100건을 초과하는 사례가 발생하면 커서 기반 페이지네이션 도입을 검토한다.

---

### `PUT` /documents/:id/restrictions

**설명**: 문서 제한 대상 목록을 설정한다 (전체 교체).

**권한**: APPROVE / ADMIN

**Request**:

- Body:

```typescript
interface SetRestrictionsDto {
  restrictions: RestrictionEntry[];
}

interface RestrictionEntry {
  subjectType: 'USER' | 'TEAM';
  subjectId: string;
  action: 'VIEW' | 'EDIT' | 'APPROVE';
}
```

**Response** (`200`): `RestrictionListResponse` — GET /documents/:id/restrictions와 동일 구조 반환

```typescript
interface RestrictionListResponse {
  documentId: string;
  isRestricted: boolean;
  restrictions: RestrictionResponse[];
}

interface RestrictionResponse {
  id: string;
  subjectType: 'USER' | 'TEAM';
  subjectId: string;
  subjectName: string;
  action: 'VIEW' | 'EDIT' | 'APPROVE';
  createdAt: string;
}
```

---

---

### `GET` /documents/:id/versions

**설명**: 문서의 버전 목록을 조회한다 (관리 모드 전용).

**권한**: VIEW

**Response** (`200`):

```typescript
interface VersionListItem {
  id: string;
  versionNumber: number;
  status: 'submitted' | 'published' | 'rejected';
  rejectionReason: string | null;
  title: string;
  embeddingStatus: EmbeddingStatus;
  createdBy: string;
  createdByName: string;
  createdAt: string;
}
```

---

### `GET` /documents/:id/versions/:versionId

**설명**: 특정 버전의 상세 정보와 블록 스냅샷을 조회한다.

**권한**: VIEW

**Request**:

- Path params: `id` — 문서 UUID, `versionId` — 버전 UUID

**Response** (`200`):

```typescript
interface VersionDetailResponse {
  id: string;
  documentId: string;
  versionNumber: number;
  status: 'submitted' | 'published' | 'rejected';
  rejectionReason: string | null;
  title: string;
  embeddingStatus: EmbeddingStatus;
  approvalId: string | null;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  blocks: BlockSnapshotResponse[];
}

interface BlockSnapshotResponse {
  id: string;
  blockId: string;
  blockType: 'text' | 'image' | 'table' | 'file';
  contentRaw: Record<string, any>;
  contentText: string | null;
  headingLevel: number | null;
  sequence: number;
  caption: string | null;
  embeddable: boolean;
  visible: boolean;
  contentHash: string;
}
```

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| DOCUMENT_NOT_FOUND | 404 | — |
| VERSION_NOT_FOUND | 404 | — |

---

### `GET` /documents/:id/versions/:versionId/diff

**설명**: 두 버전 간 블록 diff를 조회한다.

**권한**: VIEW

**Request**:

- Query params:

```typescript
interface DiffQuery {
  compareVersionId?: string;    // 비교 대상 버전 ID (미지정 시 직전 버전)
}
```

**Response** (`200`):

```typescript
interface VersionDiffResponse {
  baseVersion: { id: string; versionNumber: number };
  compareVersion: { id: string; versionNumber: number };
  changes: BlockChange[];
}

interface BlockChange {
  blockId: string;
  blockType: string;
  changeType: 'added' | 'modified' | 'caption_modified' | 'content_changed_caption_stale' | 'deleted' | 'unchanged';
  oldContentText?: string;
  newContentText?: string;
  oldCaption?: string;
  newCaption?: string;
}
```

---

### `POST` /documents/:id/tags

**설명**: 문서에 태그를 추가한다. 없는 태그는 자동 생성.

**권한**: EDIT

**Request**:

- Body:

```typescript
interface AddTagDto {
  tagName: string;          // 태그명 (정규화 후 검색/생성)
}
```

**Response** (`201`): `TagResponse`

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| TAG_LIMIT_EXCEEDED | 422 | [BR-DOC-002](rules.md#br-doc-002-문서당-태그-수-제한) |
| TAG_ALREADY_ATTACHED | 409 | — |

---

### `GET` /tags

**설명**: 태그 목록/자동완성 조회.

**권한**: 인증 필요 (VIEW 불필요)

**Request**:

- Query params:

```typescript
interface TagsQuery {
  q?: string;               // prefix 검색
  boardId?: string;          // 게시판 맥락 (자동완성 정렬에 활용)
  limit?: number;            // 기본 10
}
```

**Response** (`200`): `TagResponse[]`

**비즈니스 규칙 참조**: BR-DOC-034 (자동완성 정렬)

---

### `GET` /boards/:boardId/banners

**설명**: 특정 게시판에 표시할 크로스보드 공지 배너 목록을 조회한다. Document 데이터를 조회하나 게시판 진입 UX 맥락상 경로는 Board API 하위에 둔다. 구현 시 Board(또는 BFF) Controller가 `DocumentService`(또는 동등 계층)를 오케스트레이션한다 — 기존 Board → Document 읽기 의존과 동일 패턴.

**권한**: 인증 필요. 대상 게시판 `VIEW`는 요구하지 않는다 — 배너 가시성은 `notice_options.notification_target_type` / `notification_target_ids` 기준으로 서버에서 필터링한다 (FD-NTC [BR-NTC-042](../../01-requirements/features/FD-NTC-공지사항.md)).

**Request**:

- Path params: `boardId` — 배너를 표시할 게시판 UUID
- Query params:

```typescript
interface GetBannersQuery {
  limit?: number; // 기본: board_config.banner.maxBannerCount(저장 JSON: max_banner_count, FD-NTC §1.3) 또는 시스템 기본값 3(lm:banner.max_banner_count)
}
```

**Response** (`200`): `BannerItem[]`

```typescript
interface BannerItem {
  documentId: string;
  title: string;
  boardId: string; // 원본 공지가 속한 게시판 ID
  boardName: string; // 원본 공지 게시판명
  publishedAt: string;
  requiresConfirmation: boolean; // 읽음 확인 필수 여부
  isConfirmed: boolean; // 현재 사용자의 확인 여부
}
```

**정렬**: BR-DOC-040 규칙에 따라 읽음 확인 필수(`requires_confirmation = true`) 공지 우선 → 게시일 최신순(`publishedAt DESC`)

**비즈니스 규칙 참조**: [BR-NTC-041](../../01-requirements/features/FD-NTC-공지사항.md), [BR-NTC-042](../../01-requirements/features/FD-NTC-공지사항.md), [BR-DOC-040](rules.md#br-doc-040-크로스보드-배너-표시-조건)

**에러 코드**:

| 코드 | HTTP | 규칙 |
|------|------|------|
| BRD_BOARD_NOT_FOUND | 404 | [BR-DOC-040](rules.md#br-doc-040-크로스보드-배너-표시-조건) |

---

### `GET` /documents/:id/toc

**설명**: 문서의 목차(Table of Contents)를 조회한다. heading_level이 있는 블록 기반.

**권한**: VIEW

**Response** (`200`):

```typescript
interface TocEntry {
  blockId: string;
  headingLevel: number;       // 1~6
  text: string;               // 헤딩 텍스트
  sequence: number;
}
```

---

### `POST` /documents/:id/ai/improve

**설명**: AI 글쓰기 개선을 요청한다. LlmOrchestratorClient 직접 호출.

**비고**: AI 글쓰기 개선이 비활성인 경우 `403 FEATURE_DISABLED`

**권한**: EDIT (편집 락 보유자)

**Request**:

- Body:

```typescript
interface AiImproveDto {
  blockId: string;                    // 대상 블록 ID
  action: 'polish' | 'simplify' | 'elaborate' | 'change_tone' | 'translate';
  tone?: string;                      // change_tone 시 목표 톤
  targetLanguage?: string;            // translate 시 목표 언어
}
```

**Response** (`200`):

```typescript
interface AiImproveResponse {
  blockId: string;
  originalText: string;
  improvedText: string;
  action: string;
}
```

---

## 에러 코드 참조

> **전역 에러** (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED, EXTERNAL_SERVICE_UNAVAILABLE 등)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조
>
> **Document 도메인 에러** 전체 목록은 [rules.md §4 에러 코드 카탈로그](rules.md#4-에러-코드-카탈로그) 참조

---

## 공통 타입

```typescript
type DocumentStatus = 'draft' | 'pending_review' | 'approved_scheduled' | 'published' | 'archived';

type EmbeddingStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'partial' | 'skipped';

/** 공지 게시판 문서의 notice_options — API는 camelCase, 저장은 JSONB 스네이크케이스(data.md). 전체 키는 FD-NTC §2.2 */
interface NoticeOptions {
  // ... FD-NTC §2.2 기타 필드
  isBanner?: boolean; // 기본: false
  bannerTargetType?: 'all' | 'selected'; // 기본: 'all'
  bannerTargetBoardIds?: string[]; // 기본: []
}
```
