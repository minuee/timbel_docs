# DocumentModule — RDB 엔티티

> 문서 CRUD, 블록 콘텐츠, 버전 관리, 청크 매핑, 태그, 접근 제한

---

## 1. 엔티티 관계도

```mermaid
erDiagram
    Document ||--o{ Block : "1:N"
    Document ||--o{ DocumentVersion : "1:N (versioning_enabled = true 게시판에서만)"
    Document ||--o{ Chunk : "1:N (비정규화)"
    Document ||--o{ DocumentRestriction : "1:N (제한 시에만)"
    Document ||--o{ DocumentTag : "1:N"

    DocumentVersion ||--o{ BlockSnapshot : "1:N"

    Tag ||--o{ DocumentTag : "1:N"

    RetentionPolicy ||--o{ Document : "1:N (선택)"

    %% 외부 모듈 참조 (FK)
    Document }o--|| Board : "N:1 (BoardModule)"
    Document }o--o| Template : "N:0..1 (TemplateModule)"
    Document }o--o| DocumentVersion : "published_version_id"
```

---

## 2. 엔티티 필드

### 2.1 Document

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| board_id | UUID (FK) | 소속 게시판 |
| template_id | UUID (FK, nullable) | 사용한 템플릿 |
| published_version_id | UUID (FK → DocumentVersion, nullable) | 최신 발행 버전 참조. 발행 전이면 null |
| title | VARCHAR | 문서 제목 |
| status | VARCHAR(30) | `draft`, `pending_review`, `approved_scheduled`, `published`, `archived` |
| is_suspended | BOOLEAN (default false) | 검색 일시 정지 — published 상태에서만 true 허용 |
| is_restricted | BOOLEAN (default false) | 접근 제한 모드 — true이면 DocumentRestriction에 지정된 사용자만 접근 |
| summary | TEXT (nullable) | 문서 요약 |
| current_editor_id | UUID (nullable) | 비관적 락킹 — 현재 편집자 |
| editor_lock_at | TIMESTAMPTZ (nullable) | 락 획득 시간 |
| expires_at | TIMESTAMPTZ (nullable) | 문서 유효기간 (콘텐츠 관점). null이면 무기한 |
| retention_policy_id | UUID (FK → RetentionPolicy, nullable) | 법정 보존 정책. null이면 보존 제한 없음 |
| retention_expires_at | TIMESTAMPTZ (nullable) | 보존 만료 예정일. `retention_start_date + retention_period_days`로 자동 계산 |
| assignee_id | UUID (nullable) | 담당자 (작성자와 별도). 기본값은 created_by와 동일하게 설정 |
| view_count | INT (default 0) | 조회수. Redis 카운터 버퍼에서 주기적으로 flush (근사치) |
| is_pinned | BOOLEAN (default false) | 게시판 내 상단 고정 여부. published 상태에서만 true 허용 |
| pinned_at | TIMESTAMPTZ (nullable) | 고정 시각. is_pinned = true일 때만 유의미 |
| pinned_by | UUID (nullable) | 고정 수행자 (외부 UserService, FK 없음) |
| notice_options | JSONB (nullable) | 공지 전용 옵션. board_type = 'notice'인 게시판의 문서에서만 유의미 |
| embedding_status | VARCHAR(20) (default 'pending') | 현재 게시본의 임베딩 상태 SSoT. `pending`, `processing`, `completed`, `failed`, `partial`, `skipped`. RAG 파이프라인 미적용 시 `skipped` |
| attachments | JSONB (default '[]') | 문서 하단 첨부파일 목록. 아래 JSONB 구조 참조 |
| created_by | UUID | 작성자 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |
| scheduled_publish_at | TIMESTAMPTZ (nullable) | 예약 게시 일시. `Board.approval_required = false` 게시판에서 사용 — draft 상태에서 설정, 시점 도래 시 published 전환. `Board.approval_required = true` 게시판(승인·예약 배포)은 `Approval.scheduled_publish_at` 사용 |
| deleted_at | TIMESTAMPTZ (nullable) | 소프트 딜리트 |

#### 제약 조건

- `CHECK (is_suspended = false OR status = 'published')`
- `CHECK (is_restricted = false OR EXISTS(...))` — 앱 레벨에서 검증. is_restricted = true이면 DocumentRestriction에 최소 1건 이상 존재해야 한다
- `CHECK (is_pinned = false OR status = 'published')` — published 상태에서만 고정 허용
- `CHECK (is_pinned = false OR (pinned_at IS NOT NULL AND pinned_by IS NOT NULL))` — 고정 시 메타데이터 필수
- 검색 필터: `status = 'published' AND is_suspended = false AND deleted_at IS NULL`
- 보존기간 차단 (앱 레벨): `retention_expires_at`이 미래인 문서에 대해 soft_delete, is_suspended 전환, `archived` 상태 전환을 거부

#### 설계 결정

**`approved_scheduled` 상태**
— 승인 완료되었으나 예약 배포 시간이 지정된 문서. 승인 시점에 `pending_review` → `approved_scheduled`로 전환되고, 예약 시간 도래 시 `approved_scheduled` → `published`로 전환된다. 예약 대기 중에는 검색/RAG 대상에서 제외된다. 예약 정보는 Approval의 `scheduled_at`, `bull_job_id` 컬럼에 저장한다.

**scheduled_publish_at (예약 게시)**
— `Board.approval_required = false` 게시판에서 즉시 발행 대신 미래 시점 자동 발행을 지원한다. `status = 'draft'` 상태를 유지하며 BullMQ delayed job으로 예약 시점에 published 전환. `Board.approval_required = true` 게시판에서는 사용하지 않는다(`Approval.scheduled_publish_at` 사용).

**Working Copy 원칙**
— Document 테이블의 `title` 등 메타데이터 필드는 **지금 편집 중인 최신 상태**이다. 발행된 확정 메타데이터는 `DocumentVersion`에 보존되어 있으며, 열람자에게 표시할 제목 등은 `published_version_id`가 가리키는 DocumentVersion에서 읽어야 한다.

| 시점 | Document.title | DocumentVersion.title | 열람자에게 보이는 제목 |
|------|---|---|---|
| 최초 작성 중 (draft) | "초안 제목" | (없음) | — (미발행) |
| v1 발행 후 | "계좌 개설 매뉴얼" | v1: "계좌 개설 매뉴얼" | "계좌 개설 매뉴얼" |
| 재편집 중 | "계좌 개설 매뉴얼 (개정)" | v1: "계좌 개설 매뉴얼" | "계좌 개설 매뉴얼" (v1 기준) |
| v2 발행 후 | "계좌 개설 매뉴얼 (개정)" | v2: "계좌 개설 매뉴얼 (개정)" | "계좌 개설 매뉴얼 (개정)" |

**embedding_status는 DocumentVersion에 위치**
— 임베딩은 버전(발행) 단위로 수행되므로, Document가 아닌 DocumentVersion에서 상태를 추적한다.

**is_restricted 필드**
— [03-auth-architecture.md](../../02-architecture/03-auth-architecture.md)의 권한 모델에서, 문서 제한 모드 전환을 위한 플래그. 기본값 false(열림)이면 게시판 권한을 그대로 상속하고, true(제한됨)이면 DocumentRestriction에 명시된 User 또는 Team만 접근 가능하다. APPROVE 보유자 또는 ADMIN(manage_boards)만 변경할 수 있다.

**expires_at (유효기간)**
— 문서의 유효기간을 설정한다. null이면 무기한 유효하다. 만료 시 `is_suspended = true`로 전환하여 검색/RAG에서 제외한다 (published 상태는 유지). 만료 처리는 BullMQ cron job(매일 00:00)으로 `WHERE expires_at <= now() AND deleted_at IS NULL AND is_suspended = false` 대상을 배치 처리한다. 만료 7일 전 담당자(assignee_id)에게 알림을 발송한다(NotificationModule 연동). 담당자 또는 관리자가 `expires_at`를 갱신하면 기간 연장되며, 감사 로그 `document.extended`가 기록된다.

**view_count (조회수)**
— Redis 카운터 버퍼(`access:counts` Hash)에서 BullMQ cron job(10분 주기)으로 flush되는 근사치이다. 실시간 정확도가 아닌 정렬/필터링용으로 충분한 수준이다. 정확한 실시간 조회수가 필요하면 Redis(`HGET access:counts {docId}`)의 미flush 카운트와 PG `view_count`를 합산한다. 상세 조회 이력(누가/언제)은 ES `aicm_access_logs` 인덱스에서 조회한다.

**assignee_id (담당자)**
— 문서의 담당자를 작성자(created_by)와 별도로 지정한다. 문서 생성 시 기본값은 작성자와 동일하게 설정한다. 담당자는 만료 알림 수신 대상이며, 담당자 변경 시 감사 로그 `document.owner_changed`가 기록된다. assignee_id는 외부 UserService의 userId로, FK 없이 논리적 참조한다.

**attachments (첨부파일 JSONB)**
— 기존 DocumentAttachment 별도 테이블을 JSONB 배열로 통합한다. 문서당 소량(0~10개)이며, 항상 문서와 함께 로드되고, 독립 쿼리("특정 mime_type 첨부 검색")가 불필요하다. 검색/임베딩 대상 아님. `file` 타입 블록의 첨부 정보는 `Block.content_raw.attrs`와 `metadata`에 이미 포함되어 있으므로, `attachments`는 문서 하단 첨부파일 목록 전용이다. 목록 조회 시 `SELECT *` 대신 필요한 컬럼만 명시하여 불필요한 JSONB 로딩을 방지한다.

**embedding_status (임베딩 상태 SSoT)**
— FD-DOC §1.1의 정의에 따라, Document.embedding_status는 현재 게시본(published)의 임베딩 상태를 추적하는 Single Source of Truth이다. DocumentVersion.embedding_status는 개별 제출본의 이력을 보존하며, 게시본 승인(published 전이) 시 해당 버전의 값이 Document로 복사된다. RAG·임베딩 파이프라인이 적용되지 않는 경우 `skipped`로 설정되어 임베딩을 거치지 않았음을 명시한다.

**summary (문서 요약)**
— FD-DOC §1.5에서 `auto_summary`로 정의된 필드를 모듈 스펙에서 `summary`로 변경하였다. AI 자동 생성 요약 외에 수동 요약 입력도 허용할 여지를 두기 위함이며, 요약 생성 방식(자동/수동)에 대한 구분은 `summary_source` 등 향후 필드 추가로 대응한다.

**is_pinned (상단 고정)**
— 게시판 목록에서 특정 문서를 최상단에 고정하는 플래그. 게시판 스코프로 동작하며, `Document.board_id`로 소속이 유일하므로 별도 스코프 컬럼 불필요. notice 타입뿐 아니라 knowledge/community 게시판에서도 사용 가능. APPROVE 권한 보유자 또는 ADMIN(manage_boards)만 설정 가능. 게시판당 고정 문서 수 상한은 `lm:notice.max_pinned_count` 설정으로 제어. [FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md) §3 참조.

**notice_options (공지 전용 옵션 JSONB)**
— `board_type = 'notice'`인 게시판의 문서에서만 사용하는 공지 전용 설정. 읽음 확인, 팝업, 알림 대상 등을 문서별로 관리. board_config.notice의 기본값을 상속하되 문서별 오버라이드 가능. [FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md) §2.2 참조.

| 키 (JSON) | 타입 | 기본값 | 설명 |
|-----------|------|--------|------|
| `is_banner` | boolean | false | 크로스보드 배너 표시 여부 |
| `banner_target_type` | string | `"all"` | `"all"` \| `"selected"` — 배너를 띄울 게시판 범위 |
| `banner_target_board_ids` | UUID[] | [] | `banner_target_type = 'selected'`일 때 대상 게시판 ID 목록 |

```jsonc
// Document.notice_options JSONB — 키 전체·의미는 FD-NTC §2.2와 동일 (스네이크케이스 저장)
{
  // ... FD-NTC §2.2 기타 키 (requires_confirmation, is_popup 등)
  "is_banner": false,
  "banner_target_type": "all",
  "banner_target_board_ids": []
}
```

```jsonc
// Document.attachments JSONB 구조
[
  {
    "id": "uuid-...",
    "file_name": "가이드.pdf",
    "file_url": "minio://...",
    "thumbnail_url": "minio://...",
    "file_size": 1048576,
    "mime_type": "application/pdf",
    "created_at": "2026-03-25T10:00:00Z"
  }
]
```

---

### 2.2 Block

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | 서버 생성 UUID. Tiptap 노드 ID와 별개 |
| document_id | UUID (FK) | 소속 문서 |
| content_raw | JSONB | Tiptap 노드 JSON — 최상위 노드 1개 = Block 1건 |
| content_text | TEXT (nullable) | content_raw에서 추출한 순수 텍스트. text: 원본, table: 셀 텍스트, image/file: null |
| content_hash | VARCHAR (nullable) | SHA-256 해시 — 변경 감지용. text 블록은 재임베딩 판단 기준이기도 함 |
| block_type | VARCHAR(10) | `text`, `image`, `table`, `file` |
| heading_level | SMALLINT (nullable) | content_raw에서 추출한 헤딩 레벨(1~6). heading이 아닌 블록은 NULL. [ADR-006](../../adr/006-block-heading-level-derived-field.md) 참조 |
| sequence | INT | 문서 내 순서 |
| caption | TEXT (nullable) | image/table 전용 — 임베딩 설명 텍스트 겸 UI 캡션. text/file은 null |
| annotation | JSONB (nullable) | 블록 메모/포스트잇. 검색·임베딩 대상 아님. `{ text, visible }` |
| embeddable | BOOLEAN (default true) | 임베딩 포함/제외 제어 — false이면 청킹/임베딩 파이프라인에서 스킵 |
| metadata | JSONB (nullable) | image: `{ thumbnailUrl }`, file: `{ thumbnailUrl, fileSize, mimeType }` 등 |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

#### 설계 결정

**Block.id = 프론트-백엔드 공통 식별자**
— 서버가 생성하는 UUID이며, 프론트엔드와 백엔드 모두 `Block.id`로 블록을 식별한다. Tiptap UniqueID의 노드 ID는 `content_raw.attrs.id`에 포함되지만, 별도 컬럼으로 관리하지 않는다.

**Working Copy 원칙**
— Block 테이블은 항상 현재 편집 상태(임시 저장 포함)를 보유한다. 별도 DraftBlock 테이블 없이 Block 테이블이 직접 업데이트된다. 발행된 확정본은 BlockSnapshot에 스냅샷으로 보존된다.

**heading_level 파생 필드** ([ADR-006](../../adr/006-block-heading-level-derived-field.md))
— `content_raw`에서 추출하는 파생 필드로, `content_text`, `content_hash`와 동일한 패턴이다. Tiptap의 `node_type` 전체(`paragraph`, `bulletList`, `codeBlock` 등)를 미러링하지 않고, 문서의 논리적 구조(섹션 계층)를 정의하는 heading level만 추출한다. "heading level"은 에디터 불문 보편적 개념이므로 에디터 교체 시에도 추출 로직만 변경하면 된다. 용도: 검색 스니펫의 `section_title` 부착, 문서 목차 조회, 섹션 단위 컨텍스트 확장.

#### content_raw 예시

| block_type | content_raw 예시 |
|------------|-----------------|
| `text` | `{ "type": "paragraph", "content": [{ "type": "text", "text": "영업점 방문 시...", "marks": [{ "type": "bold" }] }] }` |
| `text` (heading) | `{ "type": "heading", "attrs": { "level": 2 }, "content": [{ "type": "text", "text": "계좌 개설 절차" }] }` — `heading_level = 2` |
| `table` | `{ "type": "table", "content": [{ "type": "tableRow", "content": [{ "type": "tableCell", ... }] }] }` |
| `image` | `{ "type": "image", "attrs": { "src": "minio://...", "alt": "서류 목록", "width": 800 } }` |
| `file` | `{ "type": "file", "attrs": { "src": "minio://...", "fileName": "가이드.pdf" } }` |

#### content_hash 산출 규칙

| block_type | content_hash 소스 | 변경 감지 대상 |
|------------|------------------|--------------|
| `text` | `SHA-256(content_text)` | 텍스트 수정 시 |
| `table` | `SHA-256(content_text)` | 테이블 셀 내용 수정 시 |
| `image` | `SHA-256(content_raw.attrs.src)` | 이미지 교체 시 (URL 변경) |
| `file` | `null` | 임베딩 대상 아님 |

content_hash와 caption은 독립적이며, **재임베딩 판단 기준이 블록 타입별로 다르다**: text 블록은 content_hash로, image/table 블록은 caption으로 판단한다. image/table의 원본(content_hash)이 변경되어도 caption이 동일하면 재임베딩은 불필요하다 — 동일 caption으로 동일 벡터가 생성되기 때문이다.

#### 블록 타입별 검색 데이터 소스

| block_type | 키워드 검색 (ES `aicm_blocks`) | 시맨틱/하이브리드 검색 (Milvus + ES `aicm_chunks`) | 비고 |
|------------|-------------------------------|--------------------------------------------------|------|
| `text` | `block_text` ← content_text | content_text | 키워드·시맨틱 모두 원본 텍스트 |
| `table` | `block_text` ← content_text, `block_caption` ← caption | caption | 키워드: 셀 데이터 + 표 설명. 시맨틱: 표의 의미 설명 |
| `image` | `block_caption` ← caption | caption | caption이 없으면 키워드 검색에도 안 걸림 |
| `file` | X | X | 검색 대상 아님 |

- **caption은 시맨틱·키워드 검색 양쪽에서 사용된다.** ES `aicm_blocks`에 `block_caption(nori)` 필드를 두어 `multi_match`로 `block_text`와 동시 검색한다.
- **문서 태그(`tags`)는 검색 필터로 동작한다.** 검색 대상이 아니라 범위를 좁히는 필터이다.

#### caption 전략

**블록 타입별 caption 역할:**

| block_type | caption | 임베딩 입력 |
|------------|---------|-----------|
| `text` | **null** | content_text (원본 텍스트) |
| `table` | 표의 텍스트 설명 (AI 생성 또는 사용자 작성) | caption이 있으면 caption, 없으면 스킵 |
| `image` | 이미지의 텍스트 설명 (AI 생성 또는 사용자 작성) | caption이 있으면 caption, 없으면 스킵 |
| `file` | **항상 null** | 임베딩 대상 아님 |

표나 이미지는 그 자체로는 텍스트가 아니므로 임베딩할 "의미"가 존재하지 않는다. `caption`이 비어있는 비텍스트 블록은 임베딩을 스킵한다.

---

### 2.3 Chunk

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | Milvus chunk_id와 동일 값 사용 |
| block_ids | JSONB | 이 청크를 생성한 블록 ID 목록. Block과 Chunk는 M:N 관계 — FK 없음. [ADR-012](../../adr/012-block-group-chunking.md) 참조 |
| document_id | UUID (FK → Document) | 소속 문서 (비정규화 — Block JOIN 없이 문서 단위 조회 가능) |
| chunk_index | INT | 그룹 내 청크 순서 |
| content_text | TEXT | 청크 텍스트 원문 |
| embedded_content_hash | VARCHAR | 임베딩 시점의 콘텐츠 해시 — 재임베딩 필요 여부 판단용 |
| created_at | TIMESTAMPTZ | |

#### 설계 결정

**Block과 Chunk는 M:N 관계 — FK 없음**
— 인접 짧은 블록이 그룹으로 병합되어 청크를 생성한다(ADR-012). 하나의 청크가 여러 블록에서 파생되고, 하나의 블록이 여러 청크에 걸칠 수 있다. `block_ids` JSONB 배열로 역추적하며, Block 테이블과의 FK 제약은 설정하지 않는다.

**현재 발행본의 청크만 유지**
— Chunk 테이블에는 `version_id`가 없다. 현재 발행본(`published_version_id`)에 대한 청크만 보유하며, 재임베딩 시 변경된 블록의 기존 Chunk를 삭제하고 새 Chunk로 교체한다.

**Block↔Chunk 매핑 테이블 역할 겸임**
— retrieval-service가 청킹/임베딩 완료 후 반환하는 `IngestResult`를 이 테이블에 저장한다. 별도 매핑 테이블 없이 `block_ids`와 `embedded_content_hash`로 매핑 추적과 변경 감지를 모두 수행한다. Milvus `metadata.block_ids`와 동일한 값이 저장되어 고아 청크 reconciliation에도 활용된다.

---

### 2.4 DocumentVersion

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 소속 문서 |
| version_number | INT | 순차 증가 (제출할 때마다 +1) |
| approval_id | UUID (FK → Approval, nullable) | 이 버전을 생성한 승인 요청 |
| status | VARCHAR(20) | `submitted`, `published`, `rejected` |
| rejection_reason | TEXT (nullable) | 반려 사유 — `rejected`일 때만 유의미 |
| title | VARCHAR | 제출 시점의 문서 제목 |
| embedding_status | VARCHAR(20) | `pending`, `processing`, `completed`, `failed`, `partial`, `skipped` — `published` 버전에서만 유의미. 피처 비활성 시 `skipped` |
| created_by | UUID | 제출자 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `CHECK (status IN ('submitted', 'published', 'rejected'))`
- `CHECK (embedding_status IN ('pending', 'processing', 'completed', 'failed', 'partial', 'skipped'))`
- `UNIQUE(document_id, version_number)` — 동일 문서 내 버전 번호 중복 방지

#### 설계 결정

**버전 관리 활성화 게시판에서만 생성**
— DocumentVersion과 BlockSnapshot은 `Board.versioning_enabled = true`인 게시판(루트에서 상속)에서만 생성된다. `versioning_enabled = false`인 게시판에서는 DocumentVersion을 생성하지 않고, 발행 시 Block을 직접 덮어쓴다. 승인 필요 여부(`approval_required`)와 버전 스냅샷 생성은 독립이며, 상세는 [board-module.md](../board/data.md) §2.1 참조. `versioning_enabled = true`이면 모든 발행(최초·재발행 모두) 시 새 DocumentVersion이 생성된다 — 이력 추적은 항상 유지한다.

**버전 생성 시점 = 승인 신청(제출) 시점**
— 발행(승인 완료) 시점이 아닌 제출 시점에 생성된다. 반려된 제출 이력도 보존되어 "무엇이 반려됐는지" 이전 제출본과 비교할 수 있다.

**재임베딩 비교는 published 버전끼리만**
— 예: v1(rejected) → v2(published) → v3(rejected) → v4(published) — 재임베딩 비교는 v2 vs v4의 BlockSnapshot.

**롤백 메커니즘 (Copy-forward)**
— 이전 발행 버전으로 되돌리는 롤백은 SharedContent 모듈과 동일한 **Copy-forward** 패턴을 사용한다. 대상 버전의 BlockSnapshot을 Block(Working Copy)에 복사하고, Document.status를 `draft`로 전환하여 새 편집 세션을 시작한다. 이후 승인 요청 시 새 DocumentVersion이 생성되며, 기존 승인 워크플로를 그대로 거친다. 이전 버전들은 **절대 삭제하지 않는다** (append-only). 롤백도 승인 워크플로를 통과해야 하므로 무승인 콘텐츠 변경이 불가능하다.

| 시점 | 상태 |
|------|------|
| v1 published, v2 published (현재) | published_version_id = v2 |
| "v1으로 롤백" 실행 | Block ← v1 BlockSnapshot 복사, status = draft |
| 승인 요청 | v3 (submitted) 생성. 내용은 v1과 동일 |
| 승인 완료 | v3 (published), published_version_id = v3 |

롤백 시 Block 복원 절차:
1. 대상 버전의 BlockSnapshot 전체를 조회한다
2. 현재 Block 테이블의 해당 `document_id` 행을 모두 삭제한다
3. BlockSnapshot의 각 행을 Block으로 INSERT한다 (`block_id`를 유지하여 버전 간 동일 블록 추적이 계속 동작)
4. `Document.title`을 대상 `DocumentVersion.title`로 덮어쓴다
5. `Document.status`를 `draft`로 전환한다
6. 감사 로그 `document.rollback_started`를 기록한다 (대상 버전 정보 포함)

---

### 2.5 BlockSnapshot

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| version_id | UUID (FK → DocumentVersion) | 소속 버전 |
| block_id | UUID | 원본 Block 참조 (버전 간 동일 블록 추적·복원용) |
| content_raw | JSONB | 해당 시점의 Tiptap 노드 JSON |
| content_text | TEXT (nullable) | 해당 시점의 순수 텍스트 |
| content_hash | VARCHAR (nullable) | text: 재임베딩 판단 기준. image/table: 원본 변경 감지용 |
| caption | TEXT (nullable) | image/table 블록의 재임베딩 판단 기준 |
| block_type | VARCHAR(10) | `text`, `image`, `table`, `file` |
| heading_level | SMALLINT (nullable) | 해당 시점의 헤딩 레벨(1~6). heading이 아닌 블록은 NULL |
| sequence | INT | 해당 시점의 문서 내 순서 |
| annotation | JSONB (nullable) | 해당 시점의 메모 |
| embeddable | BOOLEAN | 해당 시점의 임베딩 포함/제외 설정 |
| metadata | JSONB (nullable) | |
| created_at | TIMESTAMPTZ | |

#### 설계 결정

**전체 스냅샷 방식**
— 제출 시 해당 문서의 모든 블록을 BlockSnapshot에 저장한다. delta 방식 대비 복원이 단순하다 (해당 버전만 읽으면 즉시 복원). 50개 블록 문서를 10번 제출해도 500건에 불과하여 저장 비용이 문제되지 않는다. 단, 문서 1,000개 × 200블록 × 20회 제출 = 400만 건 규모에 도달하면 `created_at` 기반 RANGE 파티셔닝(월/분기 단위)을 검토한다. 파티셔닝 도입 시 audit_log와 동일한 패턴을 적용한다.

**block_id로 버전 간 동일 블록 추적**
— Block.id는 한 번 생성되면 변하지 않는다. 두 버전의 BlockSnapshot을 block_id 기준으로 매칭하여 변경·추가·삭제된 블록을 식별할 수 있다.

#### 버전 간 블록 비교 (재임베딩 판단)

재임베딩 판단 기준은 블록 타입에 따라 다르다: **text → content_hash**, **image/table → caption**.

```sql
SELECT v_new.block_id, v_new.block_type,
  CASE
    WHEN v_old.block_id IS NULL THEN 'added'

    WHEN v_new.block_type = 'text'
         AND v_new.content_hash != v_old.content_hash
         THEN 'modified'

    WHEN v_new.block_type IN ('image', 'table')
         AND COALESCE(v_new.caption, '') != COALESCE(v_old.caption, '')
         THEN 'caption_modified'

    WHEN v_new.block_type IN ('image', 'table')
         AND v_new.content_hash != v_old.content_hash
         AND COALESCE(v_new.caption, '') = COALESCE(v_old.caption, '')
         THEN 'content_changed_caption_stale'

    ELSE 'unchanged'
  END AS change_type
FROM block_snapshot v_new
LEFT JOIN block_snapshot v_old
  ON v_new.block_id = v_old.block_id
  AND v_old.version_id = :prev_published_version_id
WHERE v_new.version_id = :new_published_version_id

UNION

SELECT v_old.block_id, v_old.block_type, 'deleted' AS change_type
FROM block_snapshot v_old
WHERE v_old.version_id = :prev_published_version_id
  AND v_old.block_id NOT IN (
    SELECT block_id FROM block_snapshot WHERE version_id = :new_published_version_id
  )
```

`content_changed_caption_stale`는 **재임베딩하지 않는다** — caption이 동일하면 동일 벡터가 생성되므로 낭비이다. 대신 호출자에게 경고를 반환하여 사용자에게 caption 재생성을 유도한다.

---

### 2.6 Tag

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(100) | 태그 표시명 (정규화 후 저장, UNIQUE) |
| slug | VARCHAR(100) | URL/필터용 정규화 키 (UNIQUE). name에서 공백 제거·소문자 변환 |
| usage_count | INT (default 0) | 사용 건수 (비정규화 카운터) — 자동완성 정렬, 인기 태그에 활용 |
| created_by | UUID | 최초 생성자 |
| created_at | TIMESTAMPTZ | |

#### 설계 결정

**자유 입력 + 자동완성**
— 사전 등록 없이 작성자가 새 태그를 자유롭게 생성한다. 입력 시 기존 태그를 자동완성으로 제안하여 중복을 방지한다.

**name 정규화 규칙**
— 대소문자 구분 없이 저장 (`LOWER(TRIM(name))`). 공백은 보존하되 앞뒤 트림. "고객 상담"과 "고객상담"은 slug 기준으로 동일 태그로 간주한다.

**usage_count 비정규화**
— DocumentTag INSERT/DELETE 시 트리거 또는 앱 레벨에서 증감한다. 정확도보다 성능 우선 — 자동완성 보조 정렬(동일 매칭 시 tiebreaker)과 인기 태그 표시에 사용하므로 약간의 오차는 허용한다. 자동완성 1차 정렬은 입력 문자열 prefix 매칭 → 게시판 내 사용 빈도 순이다([FD-DOC §8](../../01-requirements/features/FD-DOC-문서관리.md) 참조).

**문서당 태그 수 제한**
— 문서당 최대 10개. 앱 레벨에서 검증한다.

---

### 2.7 DocumentTag

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 소속 문서 |
| tag_id | UUID (FK → Tag) | 참조 태그 |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(document_id, tag_id)` — 동일 문서에 같은 태그 중복 부착 방지

---

### 2.8 DocumentRestriction

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| document_id | UUID (FK → Document) | 제한 대상 문서 |
| subject_type | VARCHAR(10) | 대상 유형: `USER`, `TEAM` |
| subject_id | UUID | 접근 허용 대상 ID (USER이면 외부 userId, TEAM이면 team_id) |
| action | VARCHAR(10) | 허용 액션: `VIEW`, `EDIT`, `APPROVE` |
| created_at | TIMESTAMPTZ | |

#### 제약 조건

- `UNIQUE(document_id, subject_type, subject_id, action)` — 동일 대상에게 같은 액션을 중복 부여 방지
- `CHECK (subject_type IN ('USER', 'TEAM'))` — 허용된 대상 유형만
- `CHECK (action IN ('VIEW', 'EDIT', 'APPROVE'))` — 허용된 액션만
- `Document.is_restricted = true`일 때만 유의미. false이면 이 테이블의 레코드는 무시된다.
- `subject_type = 'TEAM'`일 때 `subject_id`는 team 테이블의 id를 참조하나, FK 제약 대신 앱 레벨에서 검증한다 (polymorphic 참조).

#### 설계 결정

**User 또는 Team 단위 허용 (Polymorphic Subject)**
— `subject_type`으로 대상 유형을 구분한다. `USER`이면 특정 사용자만, `TEAM`이면 해당 팀의 active 멤버(TeamMember) 전원이 접근 가능하다. 팀의 Role이 아니라 소속 여부만 확인한다. Restriction은 BoardPermission 상속을 차단하는 축소 메커니즘이므로, 정규 권한 경로(Role)가 아닌 실체(사람/조직) 기반 화이트리스트를 사용한다.

**DENY 규칙 없음**
— Grant(부여) + Restriction(제한)만 사용한다. 화이트리스트 방식이므로 `Document.is_restricted = true`이면 여기에 명시된 대상만 접근 가능하고 나머지는 모두 차단된다.

**APPROVE 보유자 또는 ADMIN(manage_boards)만 제한 상태 변경 가능**
— 해당 게시판의 APPROVE 보유자 또는 ADMIN(manage_boards)만 `Document.is_restricted`를 변경하고 DocumentRestriction을 관리할 수 있다.

---

## 3. DDL 및 인덱스

### 3.1 Document

```sql
CREATE TABLE document (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id        UUID NOT NULL REFERENCES board(id),
  template_id     UUID REFERENCES template(id),
  published_version_id UUID REFERENCES document_version(id),
  title           VARCHAR(500) NOT NULL,
  status          VARCHAR(30) NOT NULL DEFAULT 'draft',
  is_suspended    BOOLEAN NOT NULL DEFAULT false,
  is_restricted   BOOLEAN NOT NULL DEFAULT false,
  summary         TEXT,
  current_editor_id UUID,
  editor_lock_at  TIMESTAMPTZ,
  expires_at      TIMESTAMPTZ,
  assignee_id     UUID,
  view_count      INT NOT NULL DEFAULT 0,
  is_pinned       BOOLEAN NOT NULL DEFAULT false,
  pinned_at       TIMESTAMPTZ,
  pinned_by       UUID,
  notice_options  JSONB,
  attachments     JSONB NOT NULL DEFAULT '[]',
  retention_policy_id UUID REFERENCES retention_policy(id),
  retention_expires_at TIMESTAMPTZ,
  embedding_status VARCHAR(20) NOT NULL DEFAULT 'pending',
  scheduled_publish_at TIMESTAMPTZ,
  created_by      UUID NOT NULL,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  deleted_at      TIMESTAMPTZ,

  CONSTRAINT chk_document_status
    CHECK (status IN ('draft', 'pending_review', 'approved_scheduled', 'published', 'archived')),
  CONSTRAINT chk_suspended_only_published
    CHECK (is_suspended = false OR status = 'published'),
  CONSTRAINT chk_embedding_status
    CHECK (embedding_status IN ('pending', 'processing', 'completed', 'failed', 'partial', 'skipped')),
  CONSTRAINT chk_pinned_only_published
    CHECK (is_pinned = false OR status = 'published'),
  CONSTRAINT chk_pinned_metadata
    CHECK (is_pinned = false OR (pinned_at IS NOT NULL AND pinned_by IS NOT NULL))
);

CREATE INDEX idx_document_board_status
  ON document (board_id, status, deleted_at);

CREATE INDEX idx_document_created_by
  ON document (created_by, status);

CREATE INDEX idx_document_published
  ON document (status, is_suspended)
  WHERE deleted_at IS NULL;

CREATE INDEX idx_document_deleted_at
  ON document (deleted_at)
  WHERE deleted_at IS NOT NULL;

-- 보존기간 만료 배치 조회: 보존 만료 예정일이 설정된 미삭제 문서
CREATE INDEX idx_document_retention_expires
  ON document (retention_expires_at)
  WHERE retention_expires_at IS NOT NULL AND deleted_at IS NULL;

-- 만료 대상 배치 조회: 유효기간이 설정된 미삭제 문서
CREATE INDEX idx_document_expires
  ON document (expires_at)
  WHERE expires_at IS NOT NULL AND deleted_at IS NULL;

-- 담당자별 문서 조회
CREATE INDEX idx_document_assignee
  ON document (assignee_id)
  WHERE assignee_id IS NOT NULL;

-- 게시판별 고정 문서 조회
CREATE INDEX idx_document_pinned
  ON document (board_id, pinned_at DESC)
  WHERE is_pinned = true AND deleted_at IS NULL;

-- 예약 게시 대상 배치 조회 (approval_required = false 게시판의 draft 예약)
CREATE INDEX idx_document_scheduled_publish
  ON document (scheduled_publish_at)
  WHERE scheduled_publish_at IS NOT NULL AND status = 'draft' AND deleted_at IS NULL;

```

### 3.2 Block

```sql
CREATE TABLE block (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id     UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  content_raw     JSONB NOT NULL,
  content_text    TEXT,
  content_hash    VARCHAR(64),
  block_type      VARCHAR(10) NOT NULL,
  heading_level   SMALLINT,
  sequence        INT NOT NULL,
  caption         TEXT,
  annotation      JSONB,
  embeddable      BOOLEAN NOT NULL DEFAULT true,
  metadata        JSONB,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),

);

CREATE UNIQUE INDEX idx_block_document_sequence
  ON block (document_id, sequence);

CREATE INDEX idx_block_type
  ON block (document_id, block_type);

CREATE INDEX idx_block_heading
  ON block (document_id, sequence)
  WHERE heading_level IS NOT NULL;
```

### 3.3 Chunk

```sql
CREATE TABLE chunk (
  id                    UUID PRIMARY KEY,
  block_ids             JSONB NOT NULL,
  document_id           UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  chunk_index           INT NOT NULL,
  content_text          TEXT NOT NULL,
  embedded_content_hash VARCHAR(64) NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_chunk_block_ids
  ON chunk USING GIN (block_ids);

CREATE INDEX idx_chunk_document
  ON chunk (document_id);
```

### 3.4 DocumentVersion

```sql
CREATE TABLE document_version (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id      UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  version_number   INT NOT NULL,
  approval_id      UUID,
  status           VARCHAR(20) NOT NULL DEFAULT 'submitted',
  rejection_reason TEXT,
  title            VARCHAR(500) NOT NULL,
  embedding_status VARCHAR(20) NOT NULL DEFAULT 'pending',
  created_by       UUID NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_version_status
    CHECK (status IN ('submitted', 'published', 'rejected')),
  CONSTRAINT chk_embedding_status
    CHECK (embedding_status IN ('pending', 'processing', 'completed', 'failed', 'partial', 'skipped'))
);

CREATE UNIQUE INDEX idx_version_document_number
  ON document_version (document_id, version_number);

CREATE INDEX idx_version_document_status
  ON document_version (document_id, status);
```

### 3.5 BlockSnapshot

```sql
CREATE TABLE block_snapshot (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  version_id   UUID NOT NULL REFERENCES document_version(id) ON DELETE CASCADE,
  block_id     UUID NOT NULL,
  content_raw  JSONB NOT NULL,
  content_text TEXT,
  content_hash VARCHAR(64),
  caption      TEXT,
  block_type   VARCHAR(10) NOT NULL,
  heading_level SMALLINT,
  sequence     INT NOT NULL,
  annotation   JSONB,
  embeddable   BOOLEAN NOT NULL DEFAULT true,
  metadata     JSONB,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX idx_snapshot_version_sequence
  ON block_snapshot (version_id, sequence);

CREATE INDEX idx_snapshot_version_block
  ON block_snapshot (version_id, block_id);

CREATE INDEX idx_snapshot_block
  ON block_snapshot (block_id, version_id);

CREATE INDEX idx_snapshot_heading
  ON block_snapshot (version_id, sequence)
  WHERE heading_level IS NOT NULL;
```

### 3.6 Tag

```sql
CREATE TABLE tag (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name         VARCHAR(100) NOT NULL,
  slug         VARCHAR(100) NOT NULL,
  usage_count  INT NOT NULL DEFAULT 0,
  created_by   UUID NOT NULL,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_tag_name UNIQUE (name),
  CONSTRAINT uq_tag_slug UNIQUE (slug)
);

CREATE INDEX idx_tag_usage
  ON tag (usage_count DESC);
```

### 3.7 DocumentTag

```sql
CREATE TABLE document_tag (
  id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id  UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  tag_id       UUID NOT NULL REFERENCES tag(id) ON DELETE CASCADE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_document_tag UNIQUE (document_id, tag_id)
);

CREATE INDEX idx_document_tag_document
  ON document_tag (document_id);

CREATE INDEX idx_document_tag_tag
  ON document_tag (tag_id);
```

### 3.8 DocumentRestriction

```sql
CREATE TABLE document_restriction (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id   UUID NOT NULL REFERENCES document(id) ON DELETE CASCADE,
  subject_type  VARCHAR(10) NOT NULL,
  subject_id    UUID NOT NULL,
  action        VARCHAR(10) NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_doc_restriction UNIQUE (document_id, subject_type, subject_id, action),
  CONSTRAINT chk_doc_restriction_subject CHECK (subject_type IN ('USER', 'TEAM')),
  CONSTRAINT chk_doc_restriction_action CHECK (action IN ('VIEW', 'EDIT', 'APPROVE'))
);

CREATE INDEX idx_doc_restriction_document
  ON document_restriction (document_id);

CREATE INDEX idx_doc_restriction_subject
  ON document_restriction (subject_type, subject_id);
```

### 3.9 RetentionPolicy

```sql
CREATE TABLE retention_policy (
  id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name                     VARCHAR(200) NOT NULL,
  description              TEXT,
  retention_period_days    INT NOT NULL,
  retention_start_type     VARCHAR(20) NOT NULL DEFAULT 'published_at',
  expiry_action            VARCHAR(20) NOT NULL DEFAULT 'archive',
  require_disposal_approval BOOLEAN NOT NULL DEFAULT false,
  is_active                BOOLEAN NOT NULL DEFAULT true,
  created_by               UUID NOT NULL,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT chk_retention_start_type
    CHECK (retention_start_type IN ('published_at', 'last_modified_at')),
  CONSTRAINT chk_expiry_action
    CHECK (expiry_action IN ('archive', 'mark_for_disposal')),
  CONSTRAINT chk_retention_period_positive
    CHECK (retention_period_days > 0)
);

CREATE INDEX idx_retention_policy_active
  ON retention_policy (is_active)
  WHERE is_active = true;
```

---

### 2.9 RetentionPolicy

| 필드 | 타입 | 설명 |
|------|------|------|
| id | UUID (PK) | |
| name | VARCHAR(200) | 정책명 (예: "투자권유 문서", "내부통제 문서") |
| description | TEXT (nullable) | 정책 설명 |
| retention_period_days | INT | 보존 기간 일수 (예: 3650 = 10년, 1825 = 5년) |
| retention_start_type | VARCHAR(20) | 기산일 기준: `published_at` \| `last_modified_at` |
| expiry_action | VARCHAR(20) | 만료 시 처리: `archive` \| `mark_for_disposal` |
| require_disposal_approval | BOOLEAN (default false) | 폐기 시 승인 필요 여부 |
| is_active | BOOLEAN (default true) | 활성 여부. 비활성 시 신규 적용만 차단, 기존 적용은 유지 |
| created_by | UUID | 생성자 (외부 UserService, FK 없음) |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

#### 제약 조건

- `CHECK (retention_start_type IN ('published_at', 'last_modified_at'))`
- `CHECK (expiry_action IN ('archive', 'mark_for_disposal'))`
- `CHECK (retention_period_days > 0)`
- 사용 중인 정책(문서 또는 게시판에 연결)은 삭제 차단 (앱 레벨)

#### 설계 결정

**법정 보존기간 관리**
— 금융권 규제(자본시장법, 금융회사 내부통제기준 등)에 따라 문서의 최소 보관 의무를 정의한다. RetentionPolicy 기능을 사용하는 테넌트에서 적용한다 ([FD-DOC](../../01-requirements/features/FD-DOC-문서관리.md) §9).

**expires_at과의 구분**
— `Document.expires_at`은 **콘텐츠 유효기간**(내용의 유효성 관점), `retention_expires_at`은 **법정 보존기간**(규제 관점에서 최소 보관 의무)이다. 두 필드는 독립적이다.

**보존기간 내 삭제/상태변경 차단**
— `retention_expires_at`이 미래인 문서에 대해 `soft_delete`, `is_suspended = true`, `archived` 전환을 앱 레벨에서 차단한다. 정상 운영 범위(수정, 재승인 등)만 허용한다.

**만료 자동 처리**
— BullMQ cron 배치로 `retention_expires_at` 도래 문서를 탐색한다. `expiry_action = 'archive'`이면 자동 아카이빙, `'mark_for_disposal'`이면 폐기 대기 상태로 전환하여 관리자 대시보드에 노출한다.

**폐기 승인 연동**
— `require_disposal_approval = true`인 경우 ApprovalModule의 폐기 전용 승인 유형을 사용하여 폐기 전 승인 절차를 거친다. 폐기 감사 로그에 `document.disposed` 액션이 기록된다.

---

## 4. 관련 문서

- [RDB 전체 조감도](../../02-architecture/data/aicm/rdb.md) — ERD, 공통 설계 원칙
- [ES 인덱스](../../02-architecture/data/aicm/es.md) — `aicm_blocks` (키워드 검색), `aicm_access_logs` (접근 로그)
- [MinIO 전략](../../02-architecture/data/aicm/minio.md) — 파일 스토리지 (Document.attachments, Block 이미지/파일)
- [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) — 3계층 권한 모델, DocumentRestriction
- [board-module.md](../board/data.md) — Board, BoardPermission (Document가 참조, 승인=버전 동기화 규칙)
- [template-module.md](../template/data.md) — Template (Document가 참조)
- [approval-module.md](../approval/data.md) — Approval, ApprovalHistory (DocumentVersion과 연동)
