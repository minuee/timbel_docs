# Document 비즈니스 규칙

> 기능정의서: [FD-DOC-문서관리](../../01-requirements/features/FD-DOC-문서관리.md)
> API 스펙: [api.md](api.md)
> 프로세스 흐름: [문서 라이프사이클](../../01-requirements/flows/document-lifecycle/)

---

## 1. 상태 전이

### 1.1 Document.status 상태 전이

```mermaid
stateDiagram-v2
    [*] --> draft: 문서 생성

    draft --> pending_review: 승인 요청 [BR-DOC-003]<br/>(approval_required = true 게시판)
    draft --> published: 직접 발행 [BR-DOC-004]<br/>(approval_required = false 게시판)
    draft --> published: 예약 시점 도래 [BR-DOC-008]<br/>(approval_required = false 예약 게시)

    pending_review --> draft: 반려 / 철회 [BR-DOC-005]
    pending_review --> published: 최종 승인 (즉시 발행) [BR-DOC-006]
    pending_review --> approved_scheduled: 승인 + 예약 배포 [BR-DOC-007]

    approved_scheduled --> published: 예약 시점 도래 [BR-DOC-008]
    approved_scheduled --> draft: 예약 취소 [BR-DOC-009]

    published --> draft: 수정 시작 [BR-DOC-010]
    published --> archived: 아카이빙 [BR-DOC-011]

    archived --> draft: 재활성화 + 수정 [BR-DOC-012]
```

> **운영 플래그**는 status 전이와 독립적으로 동작한다:
> - `is_suspended`: published 상태에서만 true 허용 [BR-DOC-013, BR-DOC-014]
> - `deleted_at`: 어떤 상태에서든 소프트 삭제 가능 [BR-DOC-015]

### 1.2 DocumentVersion.status 상태 전이

```mermaid
stateDiagram-v2
    [*] --> submitted: 승인 요청 시 생성

    submitted --> published: 최종 승인 [BR-DOC-020]
    submitted --> rejected: 반려 [BR-DOC-021]
```

### 1.3 DocumentVersion.embedding_status 상태 전이

```mermaid
stateDiagram-v2
    [*] --> pending: 버전 생성 시 기본값

    pending --> processing: 임베딩 파이프라인 시작 [BR-DOC-022]
    processing --> completed: 전체 블록 임베딩 성공
    processing --> partial: 일부 블록 실패
    processing --> failed: 전체 실패

    failed --> pending: 재시도 요청
    partial --> pending: 재시도 요청
```

---

## 2. 규칙 카탈로그

### 문서 생성

#### BR-DOC-001: 문서 생성 필수 조건

- **트리거**: `POST /api/documents`
- **조건**: `board_id`(필수) — 유효한 게시판 존재, 삭제되지 않음. 요청자가 해당 게시판 EDIT 권한 보유
- **동작**: Document 레코드 생성 (`status = 'draft'`), `template_id`가 지정되면 해당 템플릿의 보일러플레이트 블록을 Block으로 복사, `assignee_id` 미지정 시 `created_by`로 설정, 게시판에 `default_retention_policy_id`가 있으면 자동 적용
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | 게시판 EDIT 권한 없음 |
  | BOARD_NOT_FOUND | 404 | 게시판 미존재 또는 삭제됨 |
  | TEMPLATE_NOT_FOUND | 404 | 템플릿 미존재 또는 비활성 |
- **근거**: 모든 문서는 게시판에 소속되어야 하며, 문서 생성은 EDIT 권한이 필요

#### BR-DOC-002: 문서당 태그 수 제한

- **트리거**: 문서 태그 추가 시
- **조건**: 해당 문서의 태그 수가 `lm:document.max_tags` 설정값 미만
- **동작**: DocumentTag 레코드 생성, Tag.usage_count 증가
- **위반 시**: `TAG_LIMIT_EXCEEDED` (422) — 문서당 최대 {maxTags}개 태그를 부착할 수 있습니다
- **근거**: FD-DOC §8 — 과도한 태그 방지, 분류 일관성 유지

---

### 상태 전이 — 승인 요청

#### BR-DOC-003: 승인 요청 전이 (approval_required = true)

- **트리거**: `POST /api/documents/:id/submit`
- **조건**: `Document.status == 'draft'`, 게시판이 `Board.approval_required = true`(루트 게시판에서 상속), 요청자가 작성자 또는 EDIT 권한 보유
- **동작**:
  1. `Document.status` → `pending_review`
  2. DocumentVersion 생성 (`status = 'submitted'`, `version_number` 자동 증가)
  3. 모든 Block → BlockSnapshot으로 스냅샷 저장
  4. ApprovalModule에 승인 요청 전달
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | INVALID_STATUS_TRANSITION | 409 | draft 상태에서만 승인 요청 가능 |
  | FORBIDDEN | 403 | 권한 없음 |
  | FREE_MODE_BOARD | 409 | approval_required = false 게시판에서는 submit 불가 |
- **근거**: FD-DOC §1.1 — 버전 생성 시점은 제출(승인 요청) 시점

#### BR-DOC-004: 직접 발행 전이 (approval_required = false)

- **트리거**: `POST /api/documents/:id/publish`
- **조건**: `Document.status == 'draft'`, 게시판이 `Board.approval_required = false`(루트 게시판에서 상속), 요청자가 작성자 또는 EDIT 권한 보유
- **동작**:
  1. `Document.status` → `published`
  2. `published_version_id`는 null 유지 (`versioning_enabled = false`이면 DocumentVersion 미생성)
  3. ES `aicm_blocks` 인덱싱 큐 enqueue (항상)
  4. **외부 연동 조건부 enqueue** (RAG·자동 요약이 활성이고 게시판이 대상일 때만):
     - RAG(임베딩) 연동 활성 → `embedding` 큐 enqueue
     - 자동 요약 연동 활성 → `summary` 큐 enqueue
     - 연동이 꺼져 있으면 해당 큐는 **스킵** (에러 아님, 로그만 기록)
  5. EventBus `document.published` 이벤트 발행

  > **1a. 예약 게시 대안 흐름**: `scheduledPublishAt`이 지정된 경우 — `Document.scheduled_publish_at`에 값 설정, `scheduled-publish` BullMQ delayed job 등록, status는 `draft` 유지. 응답에 `scheduledPublishAt` 포함

- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | INVALID_STATUS_TRANSITION | 409 | draft 상태에서만 직접 발행 가능 |
  | FORBIDDEN | 403 | 권한 없음 |
  | MANAGED_MODE_BOARD | 409 | approval_required = true 게시판에서는 직접 발행 불가 |

- **근거**: FD-DOC §1 — approval_required = false 게시판은 draft → published 직행. 임베딩/요약은 RAG·요약 연동 활성 여부에 따라 선택적 수행. 예약 게시 지정 시 draft 상태를 유지하며 BullMQ delayed job으로 예약 시점에 발행 처리

---

### 상태 전이 — 승인 결과

#### BR-DOC-005: 반려/철회 전이

- **트리거**: ApprovalModule 콜백 (반려) 또는 `POST /api/documents/:id/withdraw` (철회)
- **조건**: `Document.status == 'pending_review'`
- **동작**:
  1. `Document.status` → `draft`
  2. DocumentVersion.status → `rejected` (반려 시), `rejection_reason` 기록
  3. 철회 시 DocumentVersion.status → `rejected`, `rejection_reason = '작성자 철회'`
- **위반 시**: `INVALID_STATUS_TRANSITION` (409) — pending_review 상태에서만 반려/철회 가능
- **근거**: FD-DOC §1 — 반려 시 draft로 복귀

#### BR-DOC-006: 즉시 발행 전이 (승인 완료)

- **트리거**: `ApprovalModule.transitionToPublished()` — Critical tx 동일 트랜잭션
- **조건**: `Document.status == 'pending_review'`, 최종 승인 + 예약 배포 없음
- **동작**:
  1. `Document.status` → `published`
  2. `Document.published_version_id` → 해당 DocumentVersion.id
  3. DocumentVersion.status → `published`
  4. `es-indexing` 큐 enqueue (ES `aicm_blocks` 인덱싱, 항상)
  5. **외부 연동 조건부 enqueue** (RAG·자동 요약이 활성이고 게시판이 대상일 때만):
     - RAG(임베딩) 연동 활성 → `embedding` 큐 enqueue (retrieval-service 청킹·임베딩)
     - 자동 요약 연동 활성 → `summary` 큐 enqueue (LLM 자동 요약)
     - 연동이 꺼져 있으면 해당 큐는 **스킵** (에러 아님, 로그만 기록)
  6. EventBus `document.published` 이벤트 발행
- **위반 시**: 트랜잭션 롤백 (**큐 enqueue는 트랜잭션 커밋 이후 수행** — 트랜잭션 성공과 큐 enqueue를 분리하여, 외부 서비스 불가 시에도 상태 전이는 보장)
- **근거**: 모듈 아키텍처 §3.3 — Critical 상태 전이는 동일 트랜잭션. 큐 enqueue는 비동기 부수효과이므로 트랜잭션과 분리

#### BR-DOC-007: 예약 배포 승인 전이

- **트리거**: `ApprovalModule.transitionToApprovedScheduled()` — Critical tx
- **조건**: `Document.status == 'pending_review'`, 최종 승인 + 예약 시간 지정
- **동작**:
  1. `Document.status` → `approved_scheduled`
  2. DocumentVersion.status → `published` (승인은 완료)
  3. Approval.scheduled_at, Approval.bull_job_id에 예약 정보 저장
  4. `scheduled-publish` BullMQ delayed job 등록
- **위반 시**: 트랜잭션 롤백
- **근거**: 데이터 아키텍처 — approved_scheduled 상태 설계 결정

#### BR-DOC-008: 예약 시점 도래 자동 발행

- **트리거**: BullMQ `scheduled-publish` 큐 delayed job 실행
- **조건**: `Document.status == 'approved_scheduled'` OR (`Document.status == 'draft' AND Document.scheduled_publish_at IS NOT NULL AND scheduled_publish_at <= now()`)
- **동작**: BR-DOC-006과 동일한 발행 처리 (status → `published`, 임베딩/인덱싱/요약 큐 enqueue). `approval_required = false` 경로(문서 `scheduled_publish_at` 예약)인 경우 `scheduled_publish_at = NULL`로 초기화
- **위반 시**: 문서가 이미 다른 상태이면 job 무시 + 로그 기록
- **근거**: FD-DOC §1 상태 관리, FD-APR 예약 배포

#### BR-DOC-009: 예약 취소

- **트리거**: `POST /api/documents/:id/cancel-schedule`
- **조건**: `Document.status == 'approved_scheduled'`, 요청자가 APPROVE 권한 보유 또는 ADMIN
- **동작**:
  1. `Document.status` → `draft`
  2. BullMQ delayed job 제거 (`bull_job_id`로 식별)
  3. 감사 로그 `document.schedule_cancelled` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | INVALID_STATUS_TRANSITION | 409 | approved_scheduled 상태에서만 예약 취소 가능 |
  | FORBIDDEN | 403 | 권한 없음 |

- **근거**: 예약 배포 후에도 취소 가능해야 함

---

### 상태 전이 — 발행 후

#### BR-DOC-010: 수정 시작 (재편집)

- **트리거**: `POST /api/documents/:id/edit`
- **조건**: `Document.status == 'published'`, 요청자가 EDIT 권한 보유
- **동작**:
  1. `Document.status` → `draft`
  2. 기존 published_version_id 유지 (열람자는 이전 발행본 계속 조회)
  3. Block(Working Copy)에 대해 편집 시작
  4. 편집 락 획득 (`current_editor_id`, `editor_lock_at`)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | INVALID_STATUS_TRANSITION | 409 | published 상태에서만 수정 시작 가능 |
  | FORBIDDEN | 403 | 권한 없음 |
  | DOCUMENT_LOCKED | 423 | 다른 사용자가 편집 중 |

- **근거**: FD-DOC §1.1 — 운영 중 수정 시 새 draft 생성, 기존 published 유지

#### BR-DOC-011: 아카이빙

- **트리거**: `POST /api/documents/:id/archive`
- **조건**: `Document.status == 'published'`, 요청자가 APPROVE 권한 또는 ADMIN, 보존기간 내가 아닐 것 [BR-DOC-018]
- **동작**:
  1. `Document.status` → `archived`
  2. 검색/RAG 대상에서 제외 (ES 인덱스 삭제, Milvus 벡터 마킹)
  3. 감사 로그 `document.archived` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | INVALID_STATUS_TRANSITION | 409 | published 상태에서만 아카이빙 가능 |
  | FORBIDDEN | 403 | 권한 없음 |
  | RETENTION_PERIOD_ACTIVE | 403 | 보존기간 내 아카이빙 불가 |

- **근거**: archived는 status ENUM에 통합 (FD-DOC §1 설계 결정)

#### BR-DOC-012: 재활성화

- **트리거**: `POST /api/documents/:id/reactivate`
- **조건**: `Document.status == 'archived'`, 요청자가 APPROVE 권한 또는 ADMIN
- **동작**:
  1. `Document.status` → `draft`
  2. 재승인 워크플로를 거쳐야 published 복원 가능
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | INVALID_STATUS_TRANSITION | 409 | archived 상태에서만 재활성화 가능 |
  | FORBIDDEN | 403 | 권한 없음 |

- **근거**: 아카이빙된 문서도 필요 시 복원 가능해야 함

---

### 운영 플래그

#### BR-DOC-013: 긴급 회수 (is_suspended = true)

- **트리거**: `POST /api/documents/:id/suspend`
- **조건**: `Document.status == 'published'`, 요청자가 EDIT 또는 APPROVE 권한 보유
- **동작**:
  1. `Document.is_suspended` → `true`
  2. 검색 필터에서 즉시 제외 (벡터 DB 물리 삭제 없이 필터로 제외)
  3. 감사 로그 `document.recalled` 기록 (회수 사유 포함)
  4. 관리자 알림 발송
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | SUSPEND_ONLY_PUBLISHED | 409 | published 상태에서만 긴급 회수 가능 |
  | FORBIDDEN | 403 | 권한 없음 |

- **근거**: FD-DOC §1 — is_suspended는 published 상태에서만 적용. DB CHECK 제약조건으로 방어

#### BR-DOC-014: 회수 해제 (is_suspended = false)

- **트리거**: `POST /api/documents/:id/unsuspend`
- **조건**: `Document.status == 'published' AND is_suspended == true`, 요청자가 EDIT 또는 APPROVE 권한 보유
- **동작**:
  1. `Document.is_suspended` → `false`
  2. 검색 필터에 즉시 복원 (재임베딩 불필요)
  3. 감사 로그 `document.recall_released` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | NOT_SUSPENDED | 409 | 현재 회수 상태가 아닙니다 |
  | FORBIDDEN | 403 | 권한 없음 |

- **근거**: 프로세스 흐름도 — 회수 해제 시 플래그만 변경으로 즉시 복원

#### BR-DOC-015: 소프트 삭제

- **트리거**: `DELETE /api/documents/:id`
- **조건**: 요청자가 작성자 또는 EDIT 권한 보유. 보존기간 내가 아닐 것 [BR-DOC-018]. `Board.approval_required = true`이면 `mandatory_approval_config` 등에 따라 삭제 승인 필요 여부 확인
- **동작**:
  1. `Document.deleted_at` = `now()`
  2. ES `aicm_blocks`에서 제외
  3. Milvus 벡터 정리 마킹 (비동기 배치 삭제)
  4. 댓글 숨김 처리 (복구 시 함께 복원)
  5. 좋아요 보존 (집계/랭킹에서만 제외)
  6. 진행 중인 승인 요청 취소 (pending_review인 경우)
  7. 예약 발행 취소 (approved_scheduled인 경우)
  8. 감사 로그 `document.deleted` 기록
  9. EventBus `document.deleted` 이벤트 발행
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | RETENTION_PERIOD_ACTIVE | 403 | 보존기간 내 삭제 불가 |
  | FORBIDDEN | 403 | 권한 없음 |

  > `202 ACCEPTED` — approval_required = true 게시판에서 삭제 승인이 필요한 경우 승인 워크플로 진입

- **근거**: FD-DOC §1 — 소프트 딜리트, 관리자 복구 가능. 문서 라이프사이클 흐름 — 삭제 시 연쇄 처리

#### BR-DOC-016: 삭제 복구

- **트리거**: `POST /api/documents/:id/restore` (관리자 전용)
- **조건**: `Document.deleted_at IS NOT NULL`, 요청자가 ADMIN(`manage_boards`)
- **동작**:
  1. `Document.deleted_at` = `null`
  2. 삭제 전 status에 따라 ES/Milvus 재인덱싱 필요 여부 판단
  3. 숨김 처리된 댓글 복원
  4. 감사 로그 `document.restored` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | DOCUMENT_NOT_FOUND | 404 | 문서를 찾을 수 없습니다 |
  | FORBIDDEN | 403 | 권한 없음 (ADMIN 필요) |

- **근거**: FD-DOC §1 — 관리자만 복구 가능

---

### 보존기간

#### BR-DOC-017: 보존기간 자동 계산

- **트리거**: 문서 발행(published) 시, 또는 RetentionPolicy 적용/변경 시
- **조건**: `Document.retention_policy_id IS NOT NULL`
- **동작**: `retention_expires_at = retention_start_date + retention_period_days` 자동 계산. `retention_start_type`에 따라 기산일 결정 (`published_at` 또는 `last_modified_at`)
- **위반 시**: —
- **근거**: FD-DOC §9.2 — retention_expires_at은 자동 계산 필드

#### BR-DOC-018: 보존기간 내 삭제/상태변경 차단

- **트리거**: soft_delete, archive, suspend 요청 시
- **조건**: `Document.retention_expires_at IS NOT NULL AND retention_expires_at > now()`
- **동작**: 요청 거부
- **위반 시**: `RETENTION_PERIOD_ACTIVE` (403) — 법정 보존기간 내 문서는 삭제할 수 없습니다. 만료일: {expiresAt}
- **근거**: FD-DOC §9.3 — 보존기간 만료 전에는 삭제 차단. RetentionPolicy·보존 기능이 켜진 테넌트에서 적용

#### BR-DOC-019: 보존기간 만료 자동 처리

- **트리거**: BullMQ cron 배치 (매일)
- **조건**: `retention_expires_at <= now() AND deleted_at IS NULL`
- **동작**:
  - `expiry_action = 'archive'`: 자동 아카이빙 (status → archived)
  - `expiry_action = 'mark_for_disposal'`: 폐기 대기 상태 전환, 관리자 대시보드 노출
  - `require_disposal_approval = true`: 폐기 승인 워크플로 진입
  - 감사 로그 `document.retention_expired` 기록
- **위반 시**: —
- **근거**: FD-DOC §9.3 — BullMQ cron 배치로 만료 문서 자동 처리

---

### 버전 관리

#### BR-DOC-020: 버전 발행 (published)

- **트리거**: 최종 승인 시 (BR-DOC-006, BR-DOC-008)
- **조건**: `DocumentVersion.status == 'submitted'`
- **동작**:
  1. `DocumentVersion.status` → `published`
  2. `Document.published_version_id` → 해당 버전 ID
  3. 이전 발행 버전의 BlockSnapshot과 현재 버전 비교하여 변경 블록 감지
  4. 변경 블록만 재임베딩 대상으로 큐 enqueue
- **위반 시**: —
- **근거**: 데이터 아키텍처 §2.4 — 재임베딩 비교는 published 버전끼리만

#### BR-DOC-021: 버전 반려 (rejected)

- **트리거**: 승인 반려 시 (BR-DOC-005)
- **조건**: `DocumentVersion.status == 'submitted'`
- **동작**: `DocumentVersion.status` → `rejected`, `rejection_reason` 기록. 반려된 버전은 영구 보관 (이력 추적)
- **위반 시**: —
- **근거**: FD-DOC §1.1 — 버전은 절대 자동 삭제하지 않음 (영구 보관)

#### BR-DOC-022: 임베딩 상태 추적

- **트리거**: 임베딩 파이프라인 진행 콜백
- **조건**: `DocumentVersion.status == 'published'`
- **동작**: `embedding_status` 전이: `pending` → `processing` → `completed` / `partial` / `failed`
- **위반 시**: —
- **근거**: 데이터 아키텍처 §2.4 — embedding_status는 published 버전에서만 유의미

#### BR-DOC-023: 버전 롤백 (Copy-forward)

- **트리거**: `POST /api/documents/:id/rollback`
- **조건**: 대상 버전이 `published` 상태였던 이력 존재. 요청자가 EDIT 권한 보유
- **동작**:
  1. 대상 버전의 BlockSnapshot 전체 조회
  2. 현재 Block 테이블의 해당 document_id 행 삭제
  3. BlockSnapshot → Block INSERT (`block_id` 유지)
  4. `Document.title` ← 대상 DocumentVersion.title
  5. `Document.status` → `draft`
  6. 감사 로그 `document.rollback_started` 기록
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | VERSION_NOT_FOUND | 404 | 대상 버전을 찾을 수 없습니다 |
  | VERSION_NOT_PUBLISHED | 409 | 대상 버전이 published 이력 없음 |
  | FORBIDDEN | 403 | 권한 없음 |

- **근거**: 데이터 아키텍처 §2.4 — Copy-forward 패턴. 이전 버전 절대 삭제 안 함 (append-only)

---

### 편집 락

#### BR-DOC-024: 편집 락 획득

- **트리거**: 문서 편집 시작 (에디터 진입)
- **조건**: `Document.current_editor_id IS NULL` 또는 락 만료 (editor_lock_at + TTL 초과)
- **동작**: `current_editor_id` = 요청자 ID, `editor_lock_at` = now()
- **위반 시**: `DOCUMENT_LOCKED` (423) — 다른 사용자가 편집 중입니다 (편집자: {userName})
- **근거**: FD-DOC §3 — 비관적 락킹, 동일 드래프트 동시 편집 방지

#### BR-DOC-025: 편집 락 해제

- **트리거**: 에디터 이탈, 브라우저 종료, 명시적 해제, TTL 만료
- **조건**: `Document.current_editor_id == 요청자 ID` 또는 TTL 만료
- **동작**: `current_editor_id` = null, `editor_lock_at` = null
- **위반 시**: —
- **근거**: FD-DOC §3 — 비관적 락킹

---

### 자동 저장

#### BR-DOC-026: 자동 저장

- **트리거**: 에디터 유휴 감지 (5~10초 간격)
- **조건**: `Document.status == 'draft'`, 편집 락 보유자
- **동작**: 변경된 블록만 diff로 서버에 전송, Block 테이블 직접 업데이트 (Working Copy 원칙)
- **위반 시**: 자동 저장 실패 시 클라이언트에서 재시도, 에디터 UI에 "저장 실패" 표시
- **근거**: FD-DOC §3 — 노션 스타일 자동 저장

---

### 유효기간

#### BR-DOC-027: 유효기간 만료 배치

- **트리거**: BullMQ cron 배치 (매일 00:00)
- **조건**: `expires_at <= now() AND deleted_at IS NULL AND is_suspended = false`
- **동작**:
  1. `Document.is_suspended` → `true` (검색/RAG에서 즉시 제외)
  2. 감사 로그 `document.expired` 기록
  3. EventBus `document.expired` 이벤트 발행
  4. 담당자(assignee_id)에게 만료 알림 발송
- **위반 시**: —
- **근거**: FD-DOC §1.3 — 만료 시 is_suspended = true 전환

#### BR-DOC-028: 유효기간 사전 알림

- **트리거**: BullMQ cron 배치 (매일)
- **조건**: `expires_at BETWEEN now() AND now() + N days`, `status = 'published'`, `is_suspended = false`
- **동작**: 담당자(assignee_id)에게 사전 알림 발송 — "유효기간 만료 N일 전"
- **위반 시**: —
- **근거**: FD-DOC §1.3 — 만료 N일 전 담당자에게 사전 알림

#### BR-DOC-029: 유효기간 연장

- **트리거**: `PATCH /api/documents/:id` (expires_at 변경)
- **조건**: 요청자가 담당자(assignee_id) 또는 ADMIN
- **동작**: `expires_at` 갱신, `is_suspended = false`인 경우 그대로 유지. 이미 만료(is_suspended = true)였다면 `is_suspended = false`로 복원 가능. 감사 로그 `document.extended` 기록
- **위반 시**: `FORBIDDEN` (403) — 권한 없음
- **근거**: FD-DOC §1.3 — 담당자 또는 관리자가 유효기간 연장 가능

---

### 접근 제한

#### BR-DOC-030: 문서 제한 모드 전환

- **트리거**: `PATCH /api/documents/:id/restriction`
- **조건**: 요청자가 해당 게시판 APPROVE 권한 보유 또는 ADMIN(`manage_boards`)
- **동작**:
  - `is_restricted = true` 전환 시: DocumentRestriction에 최소 1건 이상 필요 (앱 레벨 검증)
  - `is_restricted = false` 전환 시: 기존 DocumentRestriction 레코드는 유지 (비활성)
- **위반 시**:

  | 에러 코드 | HTTP | 메시지 |
  |-----------|------|--------|
  | FORBIDDEN | 403 | APPROVE/ADMIN 권한 없음 |
  | RESTRICTION_REQUIRES_ENTRIES | 422 | 제한 대상을 1명 이상 지정해야 합니다 |

- **근거**: 인증/인가 아키텍처 §5.4 — APPROVE 보유자 또는 ADMIN만 제한 상태 변경 가능

---

### 조회수

#### BR-DOC-032: 조회수 증가

- **트리거**: 문서 상세 조회 시
- **조건**: `Document.status == 'published'`, 중복 방지 (Redis `access:dedup` — 동일 사용자 + 문서 1회/N분)
- **동작**:
  1. Redis `access:counts` Hash에 HINCRBY
  2. Redis `access:log:stream`에 접근 로그 추가
  3. BullMQ `access-count-flush` (10분 주기) → PG `document.view_count` 배치 flush
  4. BullMQ `access-log-flush` (5분 주기) → ES `aicm_access_logs` 배치 flush
- **위반 시**: —
- **근거**: 데이터 아키텍처 §2.1 view_count — Redis 카운터 버퍼에서 주기적 flush (근사치)

---

### 태그

#### BR-DOC-033: 태그 정규화

- **트리거**: 태그 생성/검색 시
- **조건**: —
- **동작**: `name = LOWER(TRIM(input))`, `slug = name에서 공백 제거 + 소문자`. "고객 상담"과 "고객상담"은 slug 기준 동일 태그
- **위반 시**: `TAG_ALREADY_EXISTS` (409) — 태그 slug 충돌
- **근거**: 데이터 아키텍처 §2.6 — 대소문자 구분 없이 저장, 중복 방지

#### BR-DOC-034: 태그 자동완성 정렬

- **트리거**: 태그 입력 시 자동완성 조회
- **조건**: —
- **동작**: 정렬 우선순위: ① prefix 매칭 → ② 현재 게시판 내 사용 빈도 → ③ 전체 usage_count
- **위반 시**: —
- **근거**: FD-DOC §8 — 게시판 맥락에 적합한 태그 우선 노출

---

### 담당자

#### BR-DOC-035: 담당자 변경

- **트리거**: `PATCH /api/documents/:id` (assignee_id 변경)
- **조건**: 요청자가 문서 작성자, 해당 게시판 APPROVE 권한 보유자, 또는 ADMIN
- **동작**: `assignee_id` 변경, 감사 로그 `document.owner_changed` 기록
- **위반 시**: `FORBIDDEN` (403) — 권한 없음
- **근거**: FD-DOC §1.2 — 담당자 변경 권한 제한, 감사 로그 필수

---

### 검색 필터 조건

#### BR-DOC-036: 검색 가능 문서 필터

- **트리거**: 검색 쿼리 실행 시 (키워드/RAG)
- **조건**: —
- **동작**: `status = 'published' AND is_suspended = false AND deleted_at IS NULL AND board.deleted_at IS NULL` 조건 적용. 추가로 소속 게시판의 삭제 상태도 확인한다 (`board.deleted_at IS NULL`) — 소프트 삭제된 게시판의 문서는 검색/RAG 대상에서 제외된다. 권한 필터 추가 적용 (accessible board_id, restricted document_id 제외)
- **위반 시**: —
- **근거**: FD-DOC §1 — 검색 필터 조건 정의, 인증/인가 아키텍처 §5.6

#### BR-DOC-037: 문서 목록 조회 게시판 가시성 필터

- **트리거**: 문서 목록 조회 시 (`GET /api/boards/:boardId/documents` 등)
- **조건**: 일반 사용자 조회 시 (관리자 전용 조회 제외)
- **동작**: 조회 결과에 `board.deleted_at IS NULL` 필터를 적용한다. 소프트 삭제된 게시판에 소속된 문서는 일반 사용자 목록에서 제외된다. 관리자 전용 조회(`includeDeleted` 등)에서는 삭제된 게시판의 문서도 조회 가능하다
- **위반 시**: —
- **근거**: Board 독립 모듈 원칙 — BoardModule이 문서를 연쇄 삭제하지 않고, DocumentModule이 조회 시 자체 필터링

#### BR-DOC-038: 외부 연동 비활성 시 큐 enqueue 스킵

- **트리거**: 문서 발행(published) 전환 후 큐 enqueue 시점
- **조건**: RAG(임베딩) 또는 자동 요약 연동이 비활성이거나 게시판이 해당 파이프라인 대상이 아님
- **동작**: 해당 큐 enqueue를 스킵하고, RAG 미대상 시 `Document.embedding_status = 'skipped'`로 설정. 로그만 기록하며 에러를 발생시키지 않음
- **위반 시**: — (방어 코드이므로 위반 없음)
- **근거**: 모듈 아키텍처 §3.3 — 상태 전이(트랜잭션)와 큐 enqueue(부수효과) 분리 원칙. 외부 서비스 미연동 환경에서도 핵심 기능(문서 발행)이 정상 동작하도록 보장

#### BR-DOC-039: 블록 수 상한

- **트리거**: 블록 추가/저장 시 (`PUT /api/documents/:id/blocks`)
- **조건**: 해당 문서의 블록 수가 `lm:document.max_blocks` 설정값 이상
- **동작**: 추가 블록 삽입 거부. 상한 근접 시(90%) 편집기에 경고 표시
- **위반 시**: `BLOCK_LIMIT_EXCEEDED` (422) — 문서당 최대 {maxBlocks}개 블록까지 허용됩니다
- **근거**: FD-DOC §2 BR-DOC-019 — 대형 문서 성능 보호, `lm:document.max_blocks` 등 운영 상한

---

### 크로스보드 배너

#### BR-DOC-040: 크로스보드 배너 표시 조건

- **트리거**: 게시판 배너 조회 시 (`GET /api/boards/:boardId/banners`)
- **조건**: `notice_options.is_banner = true` AND `status = 'published'` AND `is_suspended = false` AND `deleted_at IS NULL` AND (`expires_at IS NULL` OR `expires_at > now()`) AND 대상 게시판 매칭(`banner_target_type` / `banner_target_board_ids`, `board_config.banner.show_cross_board_banner`) AND 현재 사용자가 `notification_target_type` / `notification_target_ids` 알림 대상에 포함
- **동작**: 위 조건을 모두 충족하는 공지 문서만 배너 목록에 포함한다. 정렬: ① `notice_options.requires_confirmation = true`인 공지 우선 ② `publishedAt DESC`(게시일 최신순). 가시성은 FD-NTC [BR-NTC-042](../../01-requirements/features/FD-NTC-공지사항.md)에 따라 알림 대상 기준이며, 게시판 `VIEW` 권한과 무관하다
- **위반 시**: —
- **근거**: FD-NTC [BR-NTC-041](../../01-requirements/features/FD-NTC-공지사항.md)

#### BR-DOC-041: 배너 자동 해제

- **트리거**: 문서 상태 전환, 삭제, 유효기간 만료, 긴급 회수 시
- **조건**: `notice_options.is_banner = true`인 문서가 게시됨 상태를 벗어나는 경우
- **동작**: 배너 조회 결과에서 자동 제외. `notice_options.is_banner` 값 자체는 변경하지 않으며, 조회 시 필터링으로만 제외한다
- **위반 시**: —
- **근거**: FD-NTC [BR-NTC-043](../../01-requirements/features/FD-NTC-공지사항.md)

#### BR-DOC-042: 예약 게시 취소 (approval_required = false)

- **트리거**: `PATCH /api/documents/:id` (`scheduledPublishAt = null`)
- **조건**: `Document.status == 'draft' AND scheduled_publish_at IS NOT NULL`
- **동작**: `scheduled_publish_at = NULL` 설정, BullMQ delayed job 제거, 감사 로그(`schedule.cancelled`) 기록
- **위반 시**: `INVALID_STATUS_TRANSITION` (409) — draft 상태이며 예약이 설정된 문서에서만 취소 가능
- **근거**: approval_required = false 게시판의 예약 게시 후에도 발행 전 취소가 가능해야 함

---

## 3. 규칙 요약 매트릭스

| 규칙 ID | 이름 | 주요 트리거 | 에러 코드 |
|---------|------|-----------|-----------|
| BR-DOC-001 | 문서 생성 필수 조건 | POST /api/documents | FORBIDDEN, BOARD_NOT_FOUND, TEMPLATE_NOT_FOUND |
| BR-DOC-002 | 문서당 태그 수 제한 | 태그 추가 | TAG_LIMIT_EXCEEDED |
| BR-DOC-003 | 승인 요청 전이 | POST /api/documents/:id/submit | INVALID_STATUS_TRANSITION, FORBIDDEN, FREE_MODE_BOARD |
| BR-DOC-004 | 직접 발행 전이 | POST /api/documents/:id/publish | INVALID_STATUS_TRANSITION, FORBIDDEN, MANAGED_MODE_BOARD |
| BR-DOC-005 | 반려/철회 전이 | 승인 반려/철회 | INVALID_STATUS_TRANSITION |
| BR-DOC-006 | 즉시 발행 전이 | ApprovalModule Critical tx | — (트랜잭션 롤백) |
| BR-DOC-007 | 예약 배포 승인 전이 | ApprovalModule Critical tx | — (트랜잭션 롤백) |
| BR-DOC-008 | 예약 시점 도래 자동 발행 | BullMQ scheduled-publish | — |
| BR-DOC-009 | 예약 취소 | POST /api/documents/:id/cancel-schedule | INVALID_STATUS_TRANSITION, FORBIDDEN |
| BR-DOC-010 | 수정 시작 | POST /api/documents/:id/edit | INVALID_STATUS_TRANSITION, FORBIDDEN, DOCUMENT_LOCKED |
| BR-DOC-011 | 아카이빙 | POST /api/documents/:id/archive | INVALID_STATUS_TRANSITION, FORBIDDEN, RETENTION_PERIOD_ACTIVE |
| BR-DOC-012 | 재활성화 | POST /api/documents/:id/reactivate | INVALID_STATUS_TRANSITION, FORBIDDEN |
| BR-DOC-013 | 긴급 회수 | POST /api/documents/:id/suspend | SUSPEND_ONLY_PUBLISHED, FORBIDDEN |
| BR-DOC-014 | 회수 해제 | POST /api/documents/:id/unsuspend | NOT_SUSPENDED, FORBIDDEN |
| BR-DOC-015 | 소프트 삭제 | DELETE /api/documents/:id | RETENTION_PERIOD_ACTIVE, FORBIDDEN |
| BR-DOC-016 | 삭제 복구 | POST /api/documents/:id/restore | DOCUMENT_NOT_FOUND, FORBIDDEN |
| BR-DOC-017 | 보존기간 자동 계산 | 문서 발행 시 | — |
| BR-DOC-018 | 보존기간 내 삭제 차단 | 삭제/아카이빙/회수 요청 | RETENTION_PERIOD_ACTIVE |
| BR-DOC-019 | 보존기간 만료 자동 처리 | BullMQ cron 배치 | — |
| BR-DOC-020 | 버전 발행 | 최종 승인 | — |
| BR-DOC-021 | 버전 반려 | 승인 반려 | — |
| BR-DOC-022 | 임베딩 상태 추적 | 임베딩 콜백 | — |
| BR-DOC-023 | 버전 롤백 | POST /api/documents/:id/rollback | VERSION_NOT_FOUND, VERSION_NOT_PUBLISHED, FORBIDDEN |
| BR-DOC-024 | 편집 락 획득 | 에디터 진입 | DOCUMENT_LOCKED |
| BR-DOC-025 | 편집 락 해제 | 에디터 이탈/TTL 만료 | — |
| BR-DOC-026 | 자동 저장 | 에디터 유휴 감지 | — (클라이언트 재시도) |
| BR-DOC-027 | 유효기간 만료 배치 | BullMQ cron (매일) | — |
| BR-DOC-028 | 유효기간 사전 알림 | BullMQ cron (매일) | — |
| BR-DOC-029 | 유효기간 연장 | PATCH /api/documents/:id | FORBIDDEN |
| BR-DOC-030 | 문서 제한 모드 전환 | PATCH /api/documents/:id/restriction | FORBIDDEN, RESTRICTION_REQUIRES_ENTRIES |
| BR-DOC-032 | 조회수 증가 | 문서 상세 조회 | — |
| BR-DOC-033 | 태그 정규화 | 태그 생성/검색 | TAG_ALREADY_EXISTS |
| BR-DOC-034 | 태그 자동완성 정렬 | 태그 자동완성 | — |
| BR-DOC-035 | 담당자 변경 | PATCH /api/documents/:id | FORBIDDEN |
| BR-DOC-036 | 검색 가능 문서 필터 | 검색 쿼리 실행 | — |
| BR-DOC-037 | 문서 목록 조회 게시판 가시성 필터 | 문서 목록 조회 | — |
| BR-DOC-038 | 외부 연동 비활성 시 큐 스킵 | 문서 발행 후 큐 enqueue | — |
| BR-DOC-039 | 블록 수 상한 | PUT /api/documents/:id/blocks | BLOCK_LIMIT_EXCEEDED |
| BR-DOC-040 | 크로스보드 배너 표시 조건 | GET /api/boards/:boardId/banners | BRD_BOARD_NOT_FOUND |
| BR-DOC-041 | 배너 자동 해제 | 문서 상태/삭제/만료/회수 | — |
| BR-DOC-042 | 예약 게시 취소 (approval_required = false) | PATCH /api/documents/:id | INVALID_STATUS_TRANSITION |

---

## 4. 에러 코드 카탈로그

> 전역 에러 코드 (VALIDATION_ERROR, UNAUTHORIZED, FORBIDDEN, FEATURE_DISABLED, EXTERNAL_SERVICE_UNAVAILABLE)는 [횡단 관심사 §8.2.4](../../02-architecture/07-cross-cutting-concerns.md#824-전역-에러-코드-카탈로그) 참조

| 에러 코드 | HTTP | 발생 규칙 | 메시지 템플릿 |
|-----------|------|----------|--------------|
| BLOCK_LIMIT_EXCEEDED | 422 | BR-DOC-039 | 문서당 최대 {maxBlocks}개 블록까지 허용됩니다 (`lm:document.max_blocks` 설정값) |
| BRD_BOARD_NOT_FOUND | 404 | BR-DOC-040 | 배너 조회 대상 게시판 미존재 또는 삭제됨 |
| BOARD_NOT_FOUND | 404 | BR-DOC-001 | 게시판 미존재 또는 삭제됨 |
| DOCUMENT_LOCKED | 423 | BR-DOC-024 | 다른 사용자가 편집 중입니다 (편집자: {userName}) |
| DOCUMENT_NOT_FOUND | 404 | BR-DOC-016 | 문서를 찾을 수 없습니다 |
| FREE_MODE_BOARD | 409 | BR-DOC-003 | approval_required = false 게시판에서는 승인 요청 불가 |
| INVALID_STATUS_TRANSITION | 409 | BR-DOC-003~012 | {currentStatus} 상태에서 {action} 불가 |
| MANAGED_MODE_BOARD | 409 | BR-DOC-004 | approval_required = true 게시판에서는 직접 발행 불가 |
| NOT_DRAFT | 409 | — | draft 상태에서만 편집 가능 |
| NOT_SUSPENDED | 409 | BR-DOC-014 | 현재 회수 상태가 아닙니다 |
| RESTRICTION_REQUIRES_ENTRIES | 422 | BR-DOC-030 | 제한 대상을 1명 이상 지정해야 합니다 |
| RETENTION_PERIOD_ACTIVE | 403 | BR-DOC-018 | 법정 보존기간 내 문서는 삭제할 수 없습니다. 만료일: {expiresAt} |
| SUSPEND_ONLY_PUBLISHED | 409 | BR-DOC-013 | published 상태에서만 긴급 회수 가능 |
| TAG_ALREADY_ATTACHED | 409 | — | 이미 부착된 태그 |
| TAG_ALREADY_EXISTS | 409 | BR-DOC-033 | 태그 slug 충돌 |
| TAG_LIMIT_EXCEEDED | 422 | BR-DOC-002 | 문서당 최대 {maxTags}개 태그를 부착할 수 있습니다 (`lm:document.max_tags` 설정값) |
| TEMPLATE_NOT_FOUND | 404 | BR-DOC-001 | 템플릿 미존재 또는 비활성 |
| VERSION_NOT_FOUND | 404 | BR-DOC-023 | 대상 버전을 찾을 수 없습니다 |
| VERSION_NOT_PUBLISHED | 409 | BR-DOC-023 | 대상 버전이 published 이력 없음 |
