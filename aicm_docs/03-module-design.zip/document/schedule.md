# Document 스케줄 및 배치 작업

> - 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> - 비즈니스 규칙: [rules.md](./rules.md)
> - 이벤트: [events.md](./events.md)

## 1. 스케줄 작업 개요

| # | 작업명 | 목적 | cron 주기 | 예상 실행 시간 | 설정 키 |
|---|--------|------|-----------|:-------------:|---------|
| 1 | 예약 배포 실행 | `approved_scheduled` 상태 문서를 예약 시점에 `published`로 전이 | BullMQ delayed job (개별 예약) | ~1초/건 | — |
| 2 | 유효기간 만료 배치 | 만료 도래 문서의 is_suspended 전환 | 매일 00:00 | ~5초/100건 | `sc:document.expiry_cron` |
| 3 | 유효기간 사전 알림 | 만료 N일 전 담당자 알림 | 매일 06:00 | ~3초/100건 | `sc:document.expiry_alert_cron` |
| 4 | 보존기간 만료 배치 | 보존 만료 문서의 정책별 자동 처리 | 매일 01:00 | ~10초/100건 | `sc:document.retention_cron` |
| 5 | 편집 락 정리 | TTL 초과 락 자동 해제 | 5분 | ~1초 | `sc:document.lock_cleanup_cron` |
| 6 | Reconciliation — Embedding 보정 | embedding 실패/누락 문서 재처리 | 30분 | ~3초/50건 | `sc:document.embedding_recon_cron` |
| 7 | Reconciliation — ES Indexing 보정 | ES 인덱싱 실패/누락 문서 재처리 | 30분 | ~5초/100건 | `sc:document.es_recon_cron` |
| 8 | 드래프트 방치 감지 | 장기 방치된 draft 문서 담당자에게 알림 | 매일 09:00 | ~3초/100건 | `sc:document.stale_draft_cron` |

## 2. 작업 상세

### 2.1 예약 배포 실행

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 예약 시점이 도래한 문서를 자동으로 게시 상태로 전이 (managed: approved_scheduled → published, free: draft(예약) → published) |
| 실행 방식 | BullMQ delayed job (managed: BR-DOC-007에서 등록, free: BR-DOC-004 대안 1a에서 등록, BR-DOC-008에서 실행) |
| BR 참조 | BR-DOC-004 (대안 1a), BR-DOC-007, BR-DOC-008 |

#### 실행 로직

1. BullMQ delayed job이 예약 시점에 자동 실행
2. 문서 상태 확인:
   - **managed 모드**: `Document.status == 'approved_scheduled'` 확인
   - **free 모드**: `Document.status == 'draft' AND scheduled_publish_at IS NOT NULL` 확인
3. BR-DOC-006과 동일한 발행 처리 수행 (status → published, 큐 enqueue, EventBus 발행). free 모드인 경우 `scheduled_publish_at = NULL`로 초기화
4. 문서가 이미 다른 상태이면 job 무시 + 로그 기록

#### 동시 실행 제어

- BullMQ Job ID에 `documentId`를 포함하여 중복 job 방지
- job 실행 시 `SELECT FOR UPDATE`로 Document 행 잠금

#### 실패 처리

- BullMQ 재시도: 3회, 지수 백오프
- 3회 실패 시 DLQ(`scheduled-publish-dlq`)로 이동
- 관리자 알림: DLQ 진입 시 Slack 알림

---

### 2.2 유효기간 만료 배치

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 유효기간 도래 문서를 is_suspended 전환하여 검색/RAG에서 제외 |
| cron 표현식 | `0 0 * * *` (매일 00:00) |
| BR 참조 | BR-DOC-027 |

#### 실행 로직

1. `WHERE expires_at <= now() AND is_suspended = false AND deleted_at IS NULL AND status = 'published'` 대상 조회
2. 각 문서에 대해:
   - `Document.is_suspended → true`
   - 감사 로그 `document.expired` 기록
   - EventBus `document.expired` 이벤트 발행
   - 담당자 알림 발송
3. 배치 사이즈: 100건 단위 페이징 처리

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:document-expiry` (TTL 10분)
- 획득 실패 시 스킵 (다음 주기에 재실행)

#### 실패 처리

- 부분 실패 허용 — 개별 문서 처리 실패 시 로그 기록 후 다음 문서 계속 처리
- 전체 배치 실패 시 관리자 알림

---

### 2.3 유효기간 사전 알림

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 만료 N일 전 담당자에게 사전 알림 |
| cron 표현식 | `0 6 * * *` (매일 06:00) |
| BR 참조 | BR-DOC-028 |

#### 실행 로직

1. `WHERE expires_at BETWEEN now() AND now() + interval '{alertDays} days' AND status = 'published' AND is_suspended = false AND deleted_at IS NULL` 대상 조회
2. `alertDays`는 `lm:document.expiry_alert_days` 설정값 (기본 7일)
3. 담당자(assignee_id)에게 NotificationModule을 통해 알림 발송

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:document-expiry-alert` (TTL 5분)

#### 실패 처리

- 부분 실패 허용 — 알림 발송 실패 시 로그 기록 후 계속

---

### 2.4 보존기간 만료 배치

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 보존기간 만료 문서를 정책에 따라 자동 처리 |
| cron 표현식 | `0 1 * * *` (매일 01:00) |
| BR 참조 | BR-DOC-019 |

#### 실행 로직

1. `WHERE retention_expires_at <= now() AND deleted_at IS NULL` 대상 조회
2. 문서의 RetentionPolicy.expiry_action에 따라:
   - `'archive'`: 자동 아카이빙 (status → archived), ES/Milvus 인덱스 삭제
   - `'mark_for_disposal'`: 폐기 대기 상태 전환, 관리자 대시보드 노출
3. `require_disposal_approval = true`인 경우 ApprovalModule 폐기 승인 워크플로 진입
4. 감사 로그 `document.retention_expired` 기록

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:retention-expiry` (TTL 10분)

#### 실패 처리

- 부분 실패 허용 — 규제 관련이므로 실패 건은 별도 테이블에 기록 + 관리자 알림
- 재시도: 다음 주기에 자동 재처리 (실패 건은 재대상 포함)

---

### 2.5 편집 락 정리

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | TTL 초과 편집 락 자동 해제 |
| cron 표현식 | `*/5 * * * *` (5분마다) |
| BR 참조 | BR-DOC-025 |

#### 실행 로직

1. `WHERE current_editor_id IS NOT NULL AND editor_lock_at + interval '{lockTimeout} minutes' < now()` 대상 조회
2. `lockTimeout`은 `lm:document.lock_timeout_minutes` 설정값 (기본 30분)
3. 대상 문서의 `current_editor_id → NULL, editor_lock_at → NULL` 갱신
4. Redis 락 키(`{tenant_id}:lock:doc:{documentId}`)가 존재하면 함께 삭제

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:lock-cleanup` (TTL 2분)

#### 실패 처리

- 부분 실패 허용 — 개별 문서 처리 실패 시 다음 주기에 재시도

---

### 2.6 Reconciliation — Embedding 보정

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | embedding 큐 처리 실패 또는 누락된 문서를 탐지하여 재처리 큐에 투입 |
| cron 표현식 | `*/30 * * * *` (30분마다) |
| 관련 큐 | `embedding` |
| BR 참조 | BR-DOC-022 |

#### 실행 로직

1. RAG·임베딩 연동이 꺼져 있거나 대상 게시판이 아니면 스킵
2. 대상 조건: `Document.status = 'published' AND Document.embedding_status IN ('pending', 'failed') AND Document.deleted_at IS NULL`
3. 추가 필터: `Document.updated_at < now() - interval '30 minutes'` (최근 발행 건은 아직 큐 처리 중일 수 있으므로 제외)
4. 대상 문서를 `embedding` 큐에 `priority = 'bulk_re_embed'`로 재투입
5. 배치 사이즈: 50건 단위

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:recon:embedding` (TTL 15분)

#### 실패 처리

- 부분 실패 허용 — 개별 문서 enqueue 실패 시 로그 기록 후 계속
- 연속 3회 전체 실패 시 관리자 알림

---

### 2.7 Reconciliation — ES Indexing 보정

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | ES 인덱싱 실패 또는 누락된 문서를 탐지하여 재처리 큐에 투입 |
| cron 표현식 | `15,45 * * * *` (30분마다, embedding 보정과 15분 오프셋) |
| 관련 큐 | `es-indexing` |

#### 실행 로직

1. `Document.status = 'published' AND Document.deleted_at IS NULL` 중 ES `aicm_blocks`에 해당 documentId가 없는 문서 탐지
2. ES `_search` API로 documentId 존재 여부 확인 (배치 사이즈 100건)
3. 누락 문서를 `es-indexing` 큐에 `action = 'index'`로 재투입

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:recon:es-indexing` (TTL 15분)

#### 실패 처리

- ES 자체 장애 시 보정 배치도 실패 — 다음 주기에 재시도
- 연속 3회 전체 실패 시 관리자 알림

### 2.8 드래프트 방치 감지

#### 기본 정보

| 항목 | 값 |
|------|---|
| 목적 | 장기간 방치된 draft 문서를 담당자에게 알려 정리 또는 작성 완료를 유도 |
| cron 표현식 | `0 9 * * *` (매일 09:00) |
| BR 참조 | — (운영 편의 기능) |

#### 실행 로직

1. 대상 조건: `WHERE status = 'draft' AND updated_at < now() - interval '{staleDraftDays} days' AND deleted_at IS NULL`
2. `staleDraftDays`는 `lm:document.stale_draft_days` 설정값 (기본 30일)
3. 대상 문서별로:
   - 담당자(assignee_id, 없으면 created_by)에게 NotificationModule을 통해 방치 알림 발송
   - EventBus `document.draft-stale` 이벤트 발행
4. 배치 사이즈: 100건 단위 페이징 처리
5. 동일 문서에 대해 중복 알림 방지: Redis 키 `{tenant_id}:stale-alert:{documentId}` (TTL = `lm:document.stale_draft_alert_interval_days` × 86400초, 기본 7일)를 설정하여, 키 존재 시 알림을 스킵한다. 알림 발송 성공 후 키를 SET하며, Redis 장애 시에는 dedup 없이 알림을 발송한다 (중복 알림 > 알림 누락)

#### 동시 실행 제어

- 분산 락: `{tenant_id}:lock:batch:stale-draft-detect` (TTL 10분)

#### 실패 처리

- 부분 실패 허용 — 개별 알림 발송 실패 시 로그 기록 후 계속
- 다음 주기에 재처리 (알림 미발송 건은 재대상 포함)

---

## 3. 작업 의존 관계

```mermaid
graph TD
    A["문서 발행 (트랜잭션)"] --> B["es-indexing 큐"]
    A --> C["embedding 큐"]
    A --> D["summary 큐"]
    
    E["Embedding 보정 (30분)"] -.->|"실패/누락 재투입"| C
    F["ES Indexing 보정 (30분)"] -.->|"누락 재투입"| B
    
    G["유효기간 만료 배치 (매일)"] --> H["EventBus document.expired"]
    I["보존기간 만료 배치 (매일)"] --> J["정책별 자동 처리"]
    K["편집 락 정리 (5분)"] --> L["stale 락 해제"]
    M["드래프트 방치 감지 (매일)"] --> N["EventBus document.draft-stale"]
```

> Embedding 보정과 ES Indexing 보정은 독립적으로 실행된다. Embedding은 retrieval-service 의존, ES Indexing은 Elasticsearch 의존이므로 한쪽 장애가 다른 쪽에 영향을 주지 않는다.
