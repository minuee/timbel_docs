# Document 이벤트 및 부수효과

> 비동기 이벤트 아키텍처: [05-async-event-architecture.md](../../02-architecture/05-async-event-architecture.md)
> 모듈 아키텍처: [02-module-architecture.md §3.3](../../02-architecture/02-module-architecture.md)
> 비즈니스 규칙: [rules.md](rules.md)

---

## 1. 발행 이벤트

DocumentModule이 발행하는 이벤트와 큐를 신뢰성 티어별로 정리한다.

### 1.1 Important 티어 — BullMQ 직접 enqueue

```typescript
/** 모든 BullMQ Job 페이로드의 공통 컨텍스트 (05-async-event-architecture.md §6.5) */
interface AsyncJobContext {
  actorId: string;
  orgId: string;
  traceId: string;
  triggeredAt: string;            // ISO 8601
}
```

#### `embedding` 큐

- **티어**: Important
- **채널**: BullMQ `embedding`
- **트리거**: `DocumentService.transitionToPublished()` — 문서가 published로 전환될 때 [BR-DOC-004, BR-DOC-006, BR-DOC-008]
- **조건**: RAG(임베딩) 연동이 활성이고, 게시판 타입이 `knowledge`이거나 (`custom`이면서 BoardRagConfig에서 RAG 활성화된 경우). **연동이 꺼져 있으면 enqueue를 스킵** (Worker 등록도 생략)
- **페이로드**:

```typescript
interface EmbeddingJobPayload extends AsyncJobContext {
  documentId: string;
  documentVersionId: string;        // published 버전
  boardId: string;
  previousVersionId?: string;       // 재발행 시 이전 published 버전 (diff 재임베딩용)
  priority: 'new_publish' | 'edit_republish' | 'bulk_re_embed';
  triggerSource: 'approval' | 'direct_publish' | 'scheduled_publish';
}
```

- **소비자**: Worker → RetrievalServiceClient → retrieval-service (청킹·임베딩)
- **재시도**: 최대 3회, 지수 백오프
- **보정 배치**: 서비스 시작 시 `status = 'published' AND embedding_status = 'pending'` 문서 재투입

---

#### `es-indexing` 큐

- **티어**: Important
- **채널**: BullMQ `es-indexing`
- **트리거**: `DocumentService.transitionToPublished()` — published 전환 시 [BR-DOC-004, BR-DOC-006, BR-DOC-008]
- **페이로드**:

```typescript
interface EsIndexingJobPayload extends AsyncJobContext {
  documentId: string;
  action: 'index' | 'update' | 'delete';
  blocks?: {
    id: string;
    blockType: string;
    contentText: string | null;
    caption: string | null;
    headingLevel: number | null;
    sequence: number;
    visible: boolean;
  }[];
  metadata: {
    boardId: string;
    title: string;
    tags: string[];
    status: string;
    isSuspended: boolean;
    createdBy: string;
    publishedAt: string;
  };
}
```

- **소비자**: Worker → Elasticsearch `aicm_blocks` 인덱스
- **추가 트리거**: 소프트 삭제 시 `action = 'delete'` [BR-DOC-015]

---

#### `summary` 큐

- **티어**: Important
- **채널**: BullMQ `summary`
- **트리거**: `DocumentService.transitionToPublished()` — published 전환 시 [BR-DOC-004, BR-DOC-006, BR-DOC-008]
- **조건**: 자동 요약 연동이 활성이고, 게시판 타입이 `knowledge`이거나 (`custom`이면서 board_config에서 요약 활성화된 경우). **연동이 꺼져 있으면 enqueue를 스킵** (Worker 등록도 생략)
- **페이로드**:

```typescript
interface SummaryJobPayload extends AsyncJobContext {
  documentId: string;
  documentVersionId: string;
  title: string;
  blocks: { contentText: string; sequence: number }[];
}
```

- **소비자**: Worker → LlmOrchestratorClient → LLM Orchestrator (자동 요약 생성)
- **완료 시**: `Document.summary` 업데이트

---

#### `access-count-flush` 큐

- **티어**: Important
- **채널**: BullMQ `access-count-flush`
- **트리거**: BullMQ cron (10분 주기)
- **페이로드**:

```typescript
interface AccessCountFlushPayload extends AsyncJobContext {
  triggerType: 'cron';
}
```

- **소비자**: Worker — Redis `access:counts` Hash → PG `document.view_count` 배치 flush
- **처리**: `HGETALL access:counts` → 각 documentId별로 `UPDATE document SET view_count = view_count + N` → `HDEL` 처리된 키

---

#### `access-log-flush` 큐

- **티어**: Important
- **채널**: BullMQ `access-log-flush`
- **트리거**: BullMQ cron (5분 주기)
- **페이로드**:

```typescript
interface AccessLogFlushPayload extends AsyncJobContext {
  triggerType: 'cron';
}
```

- **소비자**: Worker — Redis `access:log:stream` → ES `aicm_access_logs` 배치 flush
- **처리**: `XRANGE access:log:stream` → ES bulk index → `XTRIM` 처리된 항목 정리

---

### 1.2 Best-effort 티어 — EventBus (NestJS EventEmitter)

#### `document.published`

- **티어**: Best-effort
- **채널**: EventBus (NestJS EventEmitter)
- **트리거**: `DocumentService.transitionToPublished()` [BR-DOC-004, BR-DOC-006, BR-DOC-008]
- **페이로드**:

```typescript
interface DocumentPublishedEvent {
  documentId: string;
  boardId: string;
  title: string;
  versionNumber: number | null;       // versioning_enabled = false 게시판에서는 null
  createdBy: string;
  publishedAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 작성자·구독자 알림 발송
  - AggregationModule — 집계 캐시 무효화

---

#### `document.deleted`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: `DocumentService.softDelete()` [BR-DOC-015]
- **페이로드**:

```typescript
interface DocumentDeletedEvent {
  documentId: string;
  boardId: string;
  title: string;
  deletedBy: string;
  deletedAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 삭제 알림
  - AggregationModule — 집계 캐시 무효화

---

#### `document.expired`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: 유효기간 만료 배치 [BR-DOC-027]
- **페이로드**:

```typescript
interface DocumentExpiredEvent {
  documentId: string;
  boardId: string;
  title: string;
  assigneeId: string | null;
  expiresAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 담당자 만료 알림
  - AggregationModule — 집계 캐시 무효화

---

#### `document.suspended`

- **티어**: Best-effort
- **채널**: EventBus (NestJS EventEmitter)
- **트리거**: `DocumentService.suspend()` [BR-DOC-013]
- **페이로드**:

```typescript
interface DocumentSuspendedEvent {
  documentId: string;
  boardId: string;
  reason: string;
  suspendedBy: string;
  suspendedAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 관리자 알림 발송
  - SearchModule — 검색 필터 즉시 반영

---

#### `document.unsuspended`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: `DocumentService.unsuspend()` [BR-DOC-014]
- **페이로드**:

```typescript
interface DocumentUnsuspendedEvent {
  documentId: string;
  boardId: string;
  restoredBy: string;
  restoredAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 복원 알림
  - SearchModule — 검색 필터 복원

---

#### `document.archived`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: `DocumentService.archive()` [BR-DOC-011]
- **페이로드**:

```typescript
interface DocumentArchivedEvent {
  documentId: string;
  boardId: string;
  archivedBy: string;
  archivedAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - SearchModule — ES/Milvus 인덱스 삭제
  - AggregationModule — 집계 캐시 무효화

---

#### `document.restored`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: `DocumentService.restore()` [BR-DOC-016]
- **페이로드**:

```typescript
interface DocumentRestoredEvent {
  documentId: string;
  boardId: string;
  restoredBy: string;
  restoredAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 복구 알림

---

#### `document.assignee-changed`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: `DocumentService.updateAssignee()` [BR-DOC-035]
- **페이로드**:

```typescript
interface DocumentAssigneeChangedEvent {
  documentId: string;
  boardId: string;
  oldAssigneeId: string | null;
  newAssigneeId: string;
  changedBy: string;
  changedAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 신규 담당자 알림
  - AuditLogModule — 감사 로그 기록

---

#### `document.retention-expired`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: 보존기간 만료 배치 [BR-DOC-019]
- **페이로드**:

```typescript
interface DocumentRetentionExpiredEvent {
  documentId: string;
  retentionPolicyId: string;
  expiryAction: 'archive' | 'mark_for_disposal';
  expiredAt: string;
  schemaVersion: number;
}
```

- **소비자**:
  - DocumentModule (배치 잡) — 정책별 자동 처리

---

#### `document.draft-stale`

- **티어**: Best-effort
- **채널**: EventBus
- **트리거**: 드래프트 방치 감지 배치
- **페이로드**:

```typescript
interface DocumentDraftStaleEvent {
  documentId: string;
  lastModifiedAt: string;
  ownerId: string;
  schemaVersion: number;
}
```

- **소비자**:
  - NotificationModule — 작성자 방치 알림

---

## 2. 소비 이벤트

DocumentModule이 외부 모듈로부터 수신하는 이벤트/콜백.

| 이벤트/콜백 | 발행자 | 채널 | 처리 내용 | 호출 실패 시 동작 |
|------------|--------|------|----------|------------------|
| `transitionToPublished()` | ApprovalModule | 직접 호출 (Critical tx) | Document.status → published, DocumentVersion.status → published, 임베딩/인덱싱/요약 큐 enqueue [BR-DOC-006] | 트랜잭션 전체 롤백 — 승인도 취소됨 |
| `transitionToApprovedScheduled()` | ApprovalModule | 직접 호출 (Critical tx) | Document.status → approved_scheduled [BR-DOC-007] | 트랜잭션 전체 롤백 — 승인도 취소됨 |
| `transitionToDraftOnReject()` | ApprovalModule | 직접 호출 (Critical tx) | Document.status → draft, DocumentVersion.status → rejected [BR-DOC-005] | 트랜잭션 전체 롤백 — 반려도 취소됨 |
| 임베딩 완료 콜백 | retrieval-service | HTTP callback / BullMQ 완료 이벤트 | DocumentVersion.embedding_status 갱신 [BR-DOC-022] | embedding_status `failed` 유지, Reconciliation 배치(schedule.md §2.6)에서 재처리 |
| 요약 완료 콜백 | LLM Orchestrator | BullMQ 완료 이벤트 | Document.summary 업데이트 | summary `null` 유지, 수동 재요약 트리거 가능 |
| ParsedBlock 저장 | ParsingModule | 직접 서비스 호출 (쓰기) | ParsedBlock → Block 변환·INSERT | 에러를 ParsingModule에 전파 — 파싱 재시도 유도 |

### 2.1 Critical tx 메서드 시그니처

ApprovalModule이 트랜잭션 내에서 직접 호출하는 DocumentService 메서드의 계약이다. 모든 메서드는 호출자가 제공하는 `EntityManager`를 사용하여 승인 트랜잭션과 원자적으로 실행된다.

```typescript
class DocumentService {
  /**
   * 승인 완료 → 즉시 발행.
   * Document·DocumentVersion 상태 전이 + 큐 enqueue.
   * 외부 연동 비활성 큐는 BR-DOC-038에 따라 스킵.
   */
  async transitionToPublished(
    documentId: string,
    versionId: string,
    txManager: EntityManager,
  ): Promise<void>;

  /**
   * 승인 완료 → 예약 발행.
   * Document.status → approved_scheduled,
   * BullMQ delayed job 등록 (scheduled-publish 큐).
   */
  async transitionToApprovedScheduled(
    documentId: string,
    versionId: string,
    scheduledAt: Date,
    txManager: EntityManager,
  ): Promise<void>;

  /**
   * 승인 반려 → 초안 복귀.
   * Document.status → draft, DocumentVersion.status → rejected,
   * rejection_reason 기록.
   */
  async transitionToDraftOnReject(
    documentId: string,
    versionId: string,
    rejectionReason: string,
    txManager: EntityManager,
  ): Promise<void>;
}
```

---

## 3. 외부 서비스 호출

DocumentModule이 직접 호출하는 외부 서비스 클라이언트.

### 3.1 RetrievalServiceClient

| 호출 시점 | 메서드 | 요청 | 응답 | 비고 |
|----------|--------|------|------|------|
| 소프트 삭제 시 벡터 정리 | `deleteDocumentVectors(documentId)` | `{ documentId }` | `{ deleted: boolean }` | Milvus 벡터 마킹 → 비동기 배치 삭제 |
| 임베딩 상태 확인 | `getEmbeddingStatus(documentVersionId)` | `{ documentVersionId }` | `{ status, progress, failedBlocks[] }` | 관리자 대시보드용 |

### 3.2 LlmOrchestratorClient

| 호출 시점 | 메서드 | 요청 | 응답 | 비고 |
|----------|--------|------|------|------|
| AI 글쓰기 개선 | `improveWriting(request)` | `{ text, action, tone?, targetLanguage? }` | `{ improvedText }` | 에디터 내 실시간 호출 |
| 자동 요약 (큐 Worker) | `generateSummary(request)` | `{ title, blocks[].contentText }` | `{ summary }` | BullMQ `summary` 큐 Worker에서 호출 |

### 3.3 서킷브레이커 정책

외부 서비스(RetrievalServiceClient, LlmOrchestratorClient)의 장시간 장애 시 큐 적체를 방지하기 위해 서킷브레이커 패턴을 적용한다.

| 서비스 | 실패 임계 | 반개방 시점 | 타임아웃 | 폴백 |
|--------|----------|-----------|---------|------|
| RetrievalServiceClient | 5회 연속 실패 | 60초 후 | 30초 | embedding_status → `failed`, 보정 배치에서 재시도 |
| LlmOrchestratorClient (요약) | 5회 연속 실패 | 60초 후 | 120초 | summary → null 유지, 로그 기록 |
| LlmOrchestratorClient (글쓰기 개선) | 3회 연속 실패 | 30초 후 | 30초 | API 503 반환, 프론트엔드 재시도 유도 |

> 서킷 상태(Open/HalfOpen/Closed)는 Redis 키(`{tenant_id}:circuit:{service_name}`)로 관리하여 인스턴스 간 공유한다.

---

## 4. BullMQ 큐 요약

| 큐 이름 | 트리거 | 우선순위 | 재시도 | 타임아웃 | DLQ | cron | 처리 내용 |
|---------|--------|---------|--------|---------|-----|------|----------|
| `embedding` | published 전환 | new_publish > edit_republish > bulk_re_embed | 3회 (지수 백오프) | 5분 | `embedding-dlq` | — | retrieval-service 청킹·임베딩 |
| `es-indexing` | published 전환 / 삭제 | — | 3회 | 1분 | `es-indexing-dlq` | — | ES `aicm_blocks` 인덱싱/삭제 |
| `summary` | published 전환 | — | 2회 | 2분 | `summary-dlq` | — | LLM 자동 요약 생성 |
| `access-count-flush` | — | — | 1회 | 30초 | — | 10분 | Redis Hash → PG view_count (실패 시 HDEL 스킵, 다음 주기에 재시도) |
| `access-log-flush` | — | — | 1회 | 30초 | — | 5분 | Redis Stream → ES aicm_access_logs (실패 시 XTRIM 스킵, 다음 주기에 재시도) |

> **flush 실패 안전성**: `access-count-flush`와 `access-log-flush`는 cron 기반이므로 실패 시 별도 DLQ 없이 다음 주기에 자동 재실행된다. 핵심 안전 규칙은 **flush가 완전히 성공한 후에만 HDEL/XTRIM을 수행**하여, 부분 실패 시 데이터 유실을 방지한다.

> DocumentModule은 `Board.approval_required = false` 게시판의 예약 게시 시 `scheduled-publish` 큐에 직접 delayed job을 등록한다 [BR-DOC-004 대안 1a]. `Board.approval_required = true` 게시판에서는 ApprovalModule이 예약 배포 시 직접 enqueue한다.
> `re-embedding` 큐도 SharedContentModule이 담당한다.

### 4.1 멱등성 보장 패턴

BullMQ Job의 중복 실행을 방어하기 위한 멱등성 키 전략이다.

| 큐 | 멱등성 키 패턴 | 보장 방식 |
|-----|---------------|-----------|
| `embedding` | `embed:{documentVersionId}` | BullMQ `jobId` 옵션으로 중복 enqueue 방지. Worker에서 `embedding_status` 현재 값 확인 후 `'completed'`이면 스킵 |
| `es-indexing` | `es:{documentId}:{action}` | BullMQ `jobId` 옵션. action이 `index`이면 ES upsert(PUT), `delete`이면 ES delete — 자체 멱등 |
| `summary` | `summary:{documentId}:{documentVersionId}` | BullMQ `jobId` 옵션으로 버전별 중복 방지. Worker에서 기존 summary와 소스 블록 해시를 비교하여 변경 없으면 스킵. versioning_enabled = false(versionId=null)일 경우 `summary:{documentId}:{publishedAt}` 사용 |
| `access-count-flush` | cron Job ID | BullMQ cron Job은 동시 실행 방지가 내장. HGETALL 시점 필드만 선택적 HDEL하여 flush 중 신규 HINCRBY와 경합 방지 (상세: cache.md §2.3) |
| `access-log-flush` | cron Job ID | BullMQ cron Job 동시 실행 방지. ES `_id`에 `{documentId}:{timestamp}` 사용하여 중복 인덱싱 방지 |

### 4.2 Graceful Shutdown

배포 시 BullMQ Worker의 안전한 종료를 위한 전략이다.

1. **SIGTERM 수신 시**: `worker.close()` 호출 — 현재 처리 중인 Job이 완료될 때까지 대기 (최대 `gracefulShutdownTimeout` 설정값, 기본 30초)
2. **타임아웃 초과 시**: 처리 중이던 Job은 `stalled` 상태로 전환되어 다른 인스턴스가 재처리
3. **cron Job**: `access-count-flush`와 `access-log-flush`는 shutdown 시점에 마지막 flush를 한 번 더 실행하여 Redis 잔여 데이터 최소화
4. **분산 락**: shutdown 시 보유 중인 배치 분산 락을 명시적으로 해제하여 다음 주기 실행 차단 방지

---

## 5. cron 배치 작업

| 작업 | 주기 | 대상 조건 | 처리 | 규칙 |
|------|------|----------|------|------|
| 유효기간 만료 | 매일 00:00 | `expires_at <= now() AND is_suspended = false AND deleted_at IS NULL` | is_suspended → true, 감사 로그, 알림 | BR-DOC-027 |
| 유효기간 사전 알림 | 매일 | `expires_at BETWEEN now() AND now() + N days AND status = 'published'` | 담당자 알림 | BR-DOC-028 |
| 보존기간 만료 | 매일 | `retention_expires_at <= now() AND deleted_at IS NULL` | 정책별 자동 처리 (archive / mark_for_disposal) | BR-DOC-019 |
| 편집 락 정리 | 5분 | `editor_lock_at + TTL < now()` | current_editor_id → null | BR-DOC-025 |
| 조회수 flush | 10분 | Redis `access:counts` Hash | PG view_count 갱신 | BR-DOC-032 |
| 접근 로그 flush | 5분 | Redis `access:log:stream` | ES aicm_access_logs bulk index | BR-DOC-032 |
| Embedding 보정 | 30분 | `status = 'published' AND embedding_status IN ('pending', 'failed')` | embedding 큐 재투입 | BR-DOC-022 |
| ES Indexing 보정 | 30분 | `status = 'published'` 중 ES 누락 건 | es-indexing 큐 재투입 | — |
| 드래프트 방치 감지 | 매일 09:00 | `status = 'draft' AND updated_at < now() - N days` | 담당자 알림, EventBus `document.draft-stale` 발행 | — |

> 각 배치 작업의 상세 실행 로직, 동시 실행 제어(분산 락), 실패 처리 전략은 [schedule.md](./schedule.md) 참조.

---

## 6. 감사 로그 액션

DocumentModule이 기록하는 감사 로그 액션 목록. AuditLogModule의 NestJS Interceptor로 전역 기록.

| 액션 | 트리거 | 규칙 |
|------|--------|------|
| `document.created` | 문서 생성 | BR-DOC-001 |
| `document.updated` | 문서 메타데이터 수정 | — |
| `document.blocks_saved` | 블록 저장 (자동 저장) | BR-DOC-026 |
| `document.submitted` | 승인 요청 | BR-DOC-003 |
| `document.published` | 발행 | BR-DOC-006 |
| `document.rejected` | 반려 | BR-DOC-005 |
| `document.withdrawn` | 철회 | BR-DOC-005 |
| `document.recalled` | 긴급 회수 | BR-DOC-013 |
| `document.recall_released` | 회수 해제 | BR-DOC-014 |
| `document.deleted` | 소프트 삭제 | BR-DOC-015 |
| `document.restored` | 삭제 복구 | BR-DOC-016 |
| `document.archived` | 아카이빙 | BR-DOC-011 |
| `document.reactivated` | 재활성화 | BR-DOC-012 |
| `document.expired` | 유효기간 만료 | BR-DOC-027 |
| `document.extended` | 유효기간 연장 | BR-DOC-029 |
| `document.owner_changed` | 담당자 변경 | BR-DOC-035 |
| `document.rollback_started` | 버전 롤백 시작 | BR-DOC-023 |
| `document.schedule_cancelled` | 예약 취소 | BR-DOC-009 |
| `document.retention_expired` | 보존기간 만료 | BR-DOC-019 |
| `document.disposed` | 문서 폐기 | BR-DOC-019 |
| `document.restriction_changed` | 제한 모드 변경 | BR-DOC-030 |

---

## 7. 외부 서비스 미연동 시 Graceful Degradation

retrieval-service·LLM Orchestrator가 부재하거나 조직에서 해당 연동을 끈 환경에서의 동작을 정의한다.

### 7.1 연동별 방어 전략

| 연동 | 관련 큐/서비스 | 끈 경우 동작 | 영향 범위 |
|------|--------------|-------------|----------|
| RAG·임베딩 | `embedding` 큐, RetrievalServiceClient | enqueue 스킵, Worker 미등록, `embedding_status`는 `'skipped'` | 시맨틱 검색 불가 → 키워드 검색(`keyword`)만 제공, `all` 모드는 키워드로 폴백 |
| 자동 요약 | `summary` 큐, LlmOrchestratorClient | enqueue 스킵, Worker 미등록, `Document.summary`는 null 유지 | 자동 요약 미생성 |
| AI 글쓰기 개선 | LlmOrchestratorClient | 비활성 시 관련 API `403` | AI 글쓰기 개선만 비활성 |

### 7.2 구현 원칙

```
┌────────────────────────────────────────────────────────────┐
│  문서 발행 (publish) 흐름                                    │
│                                                             │
│  1. Document.status → published  (트랜잭션 — 항상 수행)       │
│  2. 트랜잭션 커밋 ✅                                         │
│  3. 큐 enqueue (트랜잭션 밖에서 수행)                          │
│     ├── es-indexing: 항상 enqueue                            │
│     ├── embedding:  RAG 연동 활성·게시판 대상일 때만 enqueue   │
│     └── summary:    자동 요약 연동 활성·게시판 대상일 때만     │
│                                                             │
│  ⚠ 상태 전이 성공 ≠ 큐 enqueue 필수                           │
│    → 상태 전이는 핵심, 큐 작업은 부수효과                       │
│    → 큐 enqueue 실패 시에도 문서 발행은 성공 처리              │
└────────────────────────────────────────────────────────────┘
```

**핵심 규칙:**

1. **연동이 꺼져 있으면 enqueue 자체를 하지 않는다** — Worker가 빈 큐를 폴링하는 낭비 없음
2. **연동은 켜져 있으나 외부 서비스 불가 시** — BullMQ 재시도(지수 백오프, 최대 3회) + 보정 배치로 복구
3. **상태 전이와 큐 enqueue를 분리** — 트랜잭션 커밋 후 큐에 넣어, 외부 서비스 장애가 상태 전이를 블로킹하지 않음
4. **embedding_status 추적** — RAG 미적용이면 `'skipped'`, 큐 처리 중 `'processing'`, 실패 `'failed'`, 완료 `'completed'`

### 7.3 RAG·요약 미구축 시나리오 (예시)

```
→ 문서 발행 시:
  ✅ Document.status → published
  ✅ es-indexing 큐 → ES 키워드 인덱싱 (ES만 있으면 동작)
  ⏭ embedding 큐 → 스킵 (enqueue 안 함)
  ⏭ summary 큐 → 스킵 (enqueue 안 함)
  ✅ EventBus document.published → 알림/캐시 갱신

→ 검색 시:
  ✅ mode=keyword — 정상 동작 (ES + nori)
  ⏭ mode=ai — 403 FEATURE_DISABLED (retrieval-service 호출 불가)
  ✅ mode=all — keyword로 자동 폴백 (AI 결과는 빈 배열, 에러 아님)
```

### 7.4 서비스 레벨 분기 코드 가이드

```typescript
async afterPublishTransaction(document: Document, board: Board): Promise<void> {
  await this.esIndexingQueue.add('index', { documentId: document.id, action: 'index' });

  const isRagEligible =
    board.type === 'knowledge' ||
    (board.type === 'custom' && board.ragConfig?.enabled === true);

  if (this.ragIntegration.isEnabled() && isRagEligible) {
    await this.embeddingQueue.add('embed', {
      documentId: document.id,
      documentVersionId: document.published_version_id,
      boardId: board.id,
    });
  } else {
    await this.documentRepo.update(document.id, { embedding_status: 'skipped' });
  }

  const isSummaryEligible =
    board.type === 'knowledge' ||
    (board.type === 'custom' && board.config?.summary?.enabled === true);

  if (this.summaryIntegration.isEnabled() && isSummaryEligible) {
    await this.summaryQueue.add('summarize', { documentId: document.id });
  }
}
```
