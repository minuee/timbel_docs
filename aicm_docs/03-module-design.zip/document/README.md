# Document 모듈 상세 설계

| 항목 | 값 |
|------|---|
| 모듈명 | DocumentModule |
| 문서 코드 | MS-DOC |
| 상태 | `draft` |
| 기능정의서 | [FD-DOC-문서관리](../../01-requirements/features/FD-DOC-문서관리.md) |
| 데이터 모델 | [document-module.md](./data.md) |
| 프로세스 흐름 | [flows/document-lifecycle/](../../01-requirements/flows/document-lifecycle/) |

---

## 모듈 책임

DocumentModule은 AICM의 **의존 허브**로, 11개 도메인 모듈이 이 모듈에 의존한다. 다음 책임을 담당한다:

| 영역 | 설명 |
|------|------|
| 문서 CRUD | 문서 생성·조회·수정·소프트 삭제, 게시판/템플릿 참조 |
| 블록 콘텐츠 관리 | Tiptap 블록 배열의 저장·순서 변경·타입 변환, Working Copy 원칙 |
| 자동 저장 | 5~10초 유휴 감지 기반 서버 자동 저장, 변경 블록 diff 전송 |
| 비관적 락킹 | 동시 편집 충돌 방지 — `current_editor_id` + `editor_lock_at` 기반 |
| 상태 전이 | `draft` → `pending_review` → `approved_scheduled` → `published` → `archived` 라이프사이클 + 운영 플래그(`is_suspended`, `deleted_at`) |
| 버전 관리 | `Board.versioning_enabled = true` 게시판에서 DocumentVersion/BlockSnapshot 생성, 롤백(Copy-forward) |
| 임베딩 상태 추적 | DocumentVersion.embedding_status 관리, Block↔Chunk 매핑 추적 |
| 문서 접근 제한 | DocumentRestriction 기반 화이트리스트 관리 |
| 태그 관리 | 자유 입력 + 자동완성, 태그 정규화, usage_count 비정규화 |
| 조회수 추적 | Redis 카운터 버퍼 → PG 주기적 flush |
| 공지 배너(크로스보드) | `notice_options`의 배너 필드가 있는 공지 문서 중, 조건 충족분을 `GET /boards/:boardId/banners`로 조회해 제공 — 구현은 Board 경로에서 Document 데이터를 오케스트레이션 ([FD-NTC](../../01-requirements/features/FD-NTC-공지사항.md) §2.5, [api.md](api.md), [rules.md](rules.md) BR-DOC-040~041) |
| 유효기간 관리 | expires_at 기반 만료 배치 처리, 담당자 알림 |
| 법정 보존기간 | RetentionPolicy 연동, 보존기간 내 삭제/상태변경 차단 |
| 글쓰기 개선 | LlmOrchestratorClient 직접 호출을 통한 AI 글쓰기 개선. 에디터 내 실시간 호출이므로 DocumentModule이 직접 담당하며, AI AssistantModule의 오케스트레이션 범위에는 포함하지 않는다 (단순 프록시 패턴) |

### 현재 범위 제외 기능

| 기능 | FD 참조 | 제외 사유 | 향후 계획 |
|------|---------|----------|----------|
| 문서 복제 (Clone) | FD-DOC §1.4 BR-DOC-013~014 | MVP 범위 외 — 복제 없이도 템플릿 + 수동 복사로 대응 가능 | Phase 2에서 `POST /documents/:id/clone` 추가 예정 |
| 재요약 API | FD-DOC §1.5 BR-DOC-016 | AI 요약 재생성은 AI AssistantModule에서 오케스트레이션 예정 | AI AssistantModule 구현 시 통합 |
| 인쇄 기능 | FD-DOC §1.6 BR-DOC-017~018 | 프론트엔드 전용 기능 — 백엔드 모듈 스펙 범위 외 (워터마크는 프론트엔드 렌더링) | 프론트엔드 스펙에서 정의 |

---

## 핵심 엔티티

> 필드 상세: [데이터 아키텍처 — document-module.md](./data.md)

| 엔티티 | 설명 |
|--------|------|
| **Document** | 문서 메타데이터 + Working Copy. 게시판(Board)에 소속, 템플릿 참조(선택). 핵심 라이프사이클 status + 운영 플래그(is_suspended, deleted_at) |
| **Block** | 문서 본문의 블록 단위 콘텐츠. Tiptap JSON(content_raw) + 파생 필드(content_text, content_hash, heading_level). 임베딩/가시성/접근제한 제어 |
| **Chunk** | Block에서 분할된 임베딩 단위. Milvus chunk_id와 동일. 현재 발행본 청크만 유지 |
| **DocumentVersion** | `Board.versioning_enabled = true` 게시판 전용. 제출(submitted)/발행(published)/반려(rejected) 버전 이력. embedding_status 추적 |
| **BlockSnapshot** | DocumentVersion에 종속. 제출 시점의 블록 전체 스냅샷. 버전 간 diff 비교/롤백 복원용 |
| **Tag** | 자유 입력 태그. name(정규화) + slug(URL용) + usage_count(비정규화) |
| **DocumentTag** | Document ↔ Tag M:N 관계 테이블. 문서당 최대 10개 |
| **DocumentRestriction** | 문서 단위 접근 제한 화이트리스트. Polymorphic Subject(USER/TEAM) × Action(VIEW/EDIT/APPROVE) |

| **RetentionPolicy** | 법정 보존기간 정책 정의. RetentionPolicy 기능을 사용하는 테넌트에서 적용 |

---

## 의존 관계

```mermaid
graph LR
    %% DocumentModule이 의존하는 대상 (읽기)
    Doc["<b>DocumentModule</b>"]

    Board["BoardModule"]
    Tmpl["TemplateModule"]

    Doc -->|"읽기"| Board
    Doc -->|"읽기"| Tmpl

    %% DocumentModule에 의존하는 대상
    SC["SharedContentModule"] -->|"읽기"| Doc
    Search["SearchModule"] -->|"읽기"| Doc
    Comm["CommunityModule"] -->|"읽기"| Doc
    Notif["NotificationModule"] -->|"읽기"| Doc
    Agg["AggregationModule"] -->|"읽기"| Doc
    Admin["AdminModule"] -->|"읽기"| Doc
    Export["ExportModule"] -->|"읽기"| Doc

    Appr["ApprovalModule"] ==>|"Critical tx<br/>transitionToPublished()"| Doc
    Parse["ParsingModule"] -.->|"쓰기<br/>ParsedBlock → Block"| Doc

    classDef hub fill:#dbeafe,stroke:#2563eb,stroke-width:2px
    classDef provider fill:#dcfce7,stroke:#16a34a
    classDef consumer fill:#f3f4f6,stroke:#6b7280
    classDef critical fill:#fee2e2,stroke:#dc2626,stroke-width:2px
    classDef writer fill:#fef3c7,stroke:#d97706

    class Doc hub
    class Board,Tmpl provider
    class SC,Search,Comm,Notif,Agg,Admin,Export consumer
    class Appr critical
    class Parse writer
```

| 방향 | 대상 | 유형 | 용도 |
|------|------|------|------|
| Doc → Board | BoardModule | 읽기 | 게시판 설정 조회 (`approval_required`, `versioning_enabled`, `mandatory_approval_config`, 게시판 타입, 기본 템플릿, 기본 보존 정책) |
| Doc → Template | TemplateModule | 읽기 | 템플릿 구조 조회 (문서 생성 시 보일러플레이트) |
| Approval → Doc | ApprovalModule | **Critical tx** | 승인 완료 시 `transitionToPublished()` — 동일 트랜잭션 내 호출 |
| Parsing → Doc | ParsingModule | 쓰기 | ParsedBlock → Block 변환·저장 |
| 기타 7개 모듈 → Doc | — | 읽기 | 문서 메타/블록 조회 (검색, 내보내기, 통계 등) |

> **확장성 참고 — 읽기 모델 분리**: 현재 11개 모듈의 읽기 요청이 DocumentModule에 집중(fan-in)되어 있다. SP-2(마이크로서비스 분리) 단계에서 읽기 부하가 성능 병목이 될 경우, CQRS 패턴을 적용하여 EventBus 이벤트 기반의 읽기 전용 프로젝션(Materialized View 또는 별도 Read Model)을 도입할 수 있다. 구체적인 분리 전략은 [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md)에서 다룬다.

---

## 인프라 사용 요약

> 참조: [모듈 아키텍처 §3.3 표 C](../../02-architecture/02-module-architecture.md)

| 인프라 | 사용 여부 | 용도 |
|--------|:---------:|------|
| DB (PostgreSQL) | ● | Document, Block, Chunk, DocumentVersion, BlockSnapshot, Tag, DocumentTag, DocumentRestriction, RetentionPolicy |
| Redis / BullMQ | ● | 편집 락, `embedding` 큐, `es-indexing` 큐, `summary` 큐, `access-log-flush` 큐(5분), `access-count-flush` 큐(10분), `access:dedup` 중복 방지, `access:counts` 조회수 Hash, `access:log:stream` 접근 로그 Stream |
| Elasticsearch | ● | `aicm_access_logs` 인덱스 (접근 로그 조회) |
| MinIO | ● | 이미지/파일 첨부 업로드·다운로드 |
| EventBus | ● 발행 | `document.published`, `document.deleted`, `document.expired` |
| 외부 서비스 클라이언트 | ● | RetrievalServiceClient (임베딩 삭제), LlmOrchestratorClient (자동 요약, 글쓰기 개선) |

---

## 외부 서비스 미연동 시 Graceful Degradation

retrieval-service·LLM Orchestrator가 부재하거나 해당 연동이 꺼진 환경에서도 문서 핵심 기능이 정상 동작하도록 방어 코드를 적용한다. 상세: [events.md §7](events.md#7-외부-서비스-미연동-시-graceful-degradation)

| 구분 | 연동 없을 때 영향 | 핵심 기능 영향 |
|------|------------------|--------------|
| RAG·임베딩 | 임베딩 큐 스킵, 시맨틱 검색 불가 | **없음** — 키워드 검색(ES)은 독립 동작 |
| 자동 요약 | 요약 큐 스킵, 자동 요약 미생성 | **없음** — 문서 발행/조회 정상 |
| AI 글쓰기 개선 | AI 개선 API 비활성 시 `403` 등으로 응답 | **없음** — 에디터 기능 정상 |

> **원칙**: 상태 전이(트랜잭션)와 큐 enqueue(부수효과)를 분리하여, 외부 서비스 장애가 문서 발행을 블로킹하지 않는다. → [BR-DOC-037](rules.md#br-doc-037-문서-목록-조회-게시판-가시성-필터), [BR-DOC-038](rules.md#br-doc-038-외부-연동-비활성-시-큐-enqueue-스킵)

### SearchModule 연계 설계 (참고)

검색 API(SearchModule 소관)에서 호출자가 검색 모드를 **요청 파라미터로 선택**할 수 있도록 설계한다.

```typescript
interface SearchQueryDto {
  query: string;
  mode?: 'keyword' | 'ai' | 'all';   // 미지정 시 기본값 적용
  boardIds?: string[];
  tags?: string[];
  // ...
}
```

| 모드 | 동작 | retrieval-service 호출 |
|------|------|----------------------|
| `keyword` | AICM 자체 ES(`aicm_blocks`) 직접 쿼리 | 없음 |
| `ai` | retrieval-service에 검색 위임 | 있음 |
| `all` | ES 키워드 + retrieval-service AI 검색 **둘 다 실행**, 결과 병합 | 있음 |

> retrieval-service 내부적으로 hybrid/semantic/keyword 중 어떤 전략을 사용할지는 **관리자가 SearchConfig에서 설정**하는 내부 관심사이며, AICM API 파라미터로 노출하지 않는다. (참조: [검색 전략](../../01-requirements/flows/search-rag/03-search.md), [검색 튜닝](../../01-requirements/flows/search-rag/04-search-tuning.md))

**RAG 연동이 없을 때:**

- `mode = 'keyword'` → 정상 동작
- `mode = 'ai'` → `403 FEATURE_DISABLED` (또는 제품 정책에 따른 동일 의미 코드)
- `mode = 'all'` → 자동으로 `keyword`로 폴백 (AI 결과는 빈 배열, 에러 아님)
- 프론트엔드는 검색 설정·가용 모드를 반영하여 `ai`/`all` 옵션 노출을 조정한다

> RAG·retrieval-service 미구축 환경에서는 키워드 모드 중심으로 동작하며, 연동을 켠 뒤에는 시맨틱·하이브리드 검색을 활성화할 수 있다.

---

## 주요 메트릭

| 메트릭 | 설명 | 수집 방식 |
|--------|------|----------|
| `document.publish_count` | 시간당 문서 발행 건수 | EventBus `document.published` 카운터 |
| `document.lock_timeout_count` | 편집 락 TTL 만료 건수 | cron 배치 (BR-DOC-025) 카운터 |
| `document.auto_save_latency_ms` | 자동 저장 평균 응답 시간 | API 미들웨어 |
| `embedding.queue_lag` | embedding 큐 대기 Job 수 | BullMQ Dashboard |
| `embedding.failure_rate` | embedding 실패율 (최근 1시간) | BullMQ completed/failed 비율 |
| `es_indexing.queue_lag` | es-indexing 큐 대기 Job 수 | BullMQ Dashboard |
| `access_flush.failure_count` | 조회수/접근 로그 flush 실패 횟수 | cron 배치 로그 |
| `document.expired_count` | 유효기간 만료 처리 건수 (일간) | cron 배치 (BR-DOC-027) 카운터 |
| `document.retention_blocked_count` | 보존기간 차단 거부 건수 | API 에러 카운터 (BR-DOC-018) |
| `circuit.retrieval.state_change` | RetrievalServiceClient 서킷 상태 전이 (Open/HalfOpen/Closed) | Redis 키 변경 감지 |
| `circuit.llm_summary.state_change` | LlmOrchestratorClient(요약) 서킷 상태 전이 | Redis 키 변경 감지 |
| `circuit.llm_writing.state_change` | LlmOrchestratorClient(글쓰기) 서킷 상태 전이 | Redis 키 변경 감지 |

---

## 모니터링 알림 임계값

| 대상 | 조건 | 심각도 | 채널 |
|------|------|--------|------|
| embedding 큐 지연 | `embedding.queue_lag > 100` (10분 이상 지속) | WARNING | Slack + 대시보드 |
| embedding 실패율 | `embedding.failure_rate > 20%` (최근 1시간) | CRITICAL | Slack + PagerDuty |
| 자동 저장 지연 | `document.auto_save_latency_ms > 2000` (5분 평균) | WARNING | 대시보드 |
| 편집 락 고착 | `document.lock_timeout_count > 10` (1시간) | WARNING | Slack |
| access flush 실패 | `access_flush.failure_count > 0` (연속 3회 이상) | WARNING | Slack |
| Redis 메모리 | `access:counts` Hash 키 수 > 10,000 | WARNING | 대시보드 |
| 서킷브레이커 Open | `circuit.*.state_change == Open` | CRITICAL | Slack + PagerDuty |

---

## 로그 레벨 가이드

| 모듈/작업 | 로그 레벨 | 설명 |
|-----------|----------|------|
| 보존기간 만료 배치 | `WARN` | 규제 관련 처리이므로 모든 실행·실패를 WARN 이상으로 기록 |
| access flush 실패 | `ERROR` | 데이터 유실 가능성이 있으므로 ERROR로 기록 |
| 서킷브레이커 상태 전이 | `WARN` (Open/HalfOpen), `INFO` (Closed) | Open 진입 시 즉시 인지 필요 |
| 편집 락 TTL 만료 | `WARN` | 비정상 세션 종료 가능성 |
| Reconciliation 보정 재투입 | `INFO` | 정상 복구 흐름이므로 INFO로 기록 |
| DLQ 진입 | `ERROR` | 재시도 소진, 수동 개입 필요 |
| 의도적 큐 스킵 | `INFO` | 외부 연동 비활성 등 의도된 스킵은 INFO로 기록 (디버깅 용도) |

---

## 외부 설정값 카탈로그

DocumentModule이 참조하는 외부 설정값 목록이다. 모든 설정은 `lm:` (런타임 제한값) 또는 `sc:` (스케줄) 접두사로 네임스페이스가 분리되어 있으며, 테넌트·환경별로 SystemConfig 등을 통해 조정한다.

| 설정 키 | 기본값 | 용도 | 참조 |
|---------|--------|------|------|
| `lm:document.max_blocks` | 200 | 문서당 블록 수 상한 | BR-DOC-039 |
| `lm:document.max_tags` | 10 | 문서당 태그 수 상한 | BR-DOC-002 |
| `lm:document.lock_timeout_minutes` | 30 | 편집 락 TTL | BR-DOC-025, schedule.md §2.5 |
| `lm:document.stale_draft_days` | 30 | 드래프트 방치 기준 일수 | schedule.md §2.8 |
| `lm:document.stale_draft_alert_interval_days` | 7 | 드래프트 방치 중복 알림 방지 간격 | schedule.md §2.8 |
| `lm:document.expiry_alert_days` | 7 | 유효기간 사전 알림 일수 | BR-DOC-028, schedule.md §2.3 |
| `sc:document.expiry_cron` | `0 0 * * *` | 유효기간 만료 배치 주기 | schedule.md §2.2 |
| `sc:document.expiry_alert_cron` | `0 6 * * *` | 유효기간 사전 알림 주기 | schedule.md §2.3 |
| `sc:document.retention_cron` | `0 1 * * *` | 보존기간 만료 배치 주기 | schedule.md §2.4 |
| `sc:document.lock_cleanup_cron` | `*/5 * * * *` | 편집 락 정리 주기 | schedule.md §2.5 |
| `sc:document.embedding_recon_cron` | `*/30 * * * *` | Embedding 보정 주기 | schedule.md §2.6 |
| `sc:document.es_recon_cron` | `15,45 * * * *` | ES Indexing 보정 주기 | schedule.md §2.7 |
| `sc:document.stale_draft_cron` | `0 9 * * *` | 드래프트 방치 감지 주기 | schedule.md §2.8 |

---

## 관련 문서

| 문서 | 설명 |
|------|------|
| [FD-DOC-문서관리](../../01-requirements/features/FD-DOC-문서관리.md) | 기능정의서 (입력 원본) |
| [UC-DOC-문서관리](../../01-requirements/usecases/user/UC-DOC-문서관리.md) | 유즈케이스 |
| [document-module.md](./data.md) | RDB 엔티티/DDL |
| [문서 라이프사이클 흐름](../../01-requirements/flows/document-lifecycle/) | 상태 전이 다이어그램, 시퀀스 다이어그램 |
| [인증/인가 아키텍처](../../02-architecture/03-auth-architecture.md) | 3계층 권한 모델, Restriction |
| [모듈 아키텍처 §3.3](../../02-architecture/02-module-architecture.md) | 의존성 규칙, 이벤트 신뢰성 티어 |
