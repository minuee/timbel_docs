# Document 캐시 전략

> Redis 키 설계: [redis.md](../../02-architecture/data/aicm/redis.md)
> 비즈니스 규칙: [rules.md](rules.md)
> 이벤트/부수효과: [events.md](events.md)

---

## 1. 캐시 개요

| 캐시 대상 | 전략 | 저장소 | 키 패턴 | TTL | 무효화 트리거 |
|-----------|------|--------|---------|-----|-------------|
| 편집 락 | lock | Redis String | `{tenant_id}:lock:doc:{document_id}` | 30m | heartbeat 갱신 / 해제 / TTL 만료 |
| 조회 중복 방지 | dedup | Redis String | `{tenant_id}:access:dedup:{userId}:{documentId}` | 5m | TTL 자동 만료 |
| 조회수 카운터 버퍼 | buffer-flush | Redis Hash | `{tenant_id}:access:counts` | — | 10분 주기 PG flush 후 HDEL |
| 접근 로그 스트림 | buffer-flush | Redis Stream | `{tenant_id}:access:log:stream` | — | 5분 주기 ES flush 후 XTRIM |

---

## 2. 캐시 상세

### 2.1 편집 락 (Pessimistic Lock)

#### 기본 정보

- **전략**: lock (분산 락)
- **키 패턴**: `{tenant_id}:lock:doc:{document_id}`
- **TTL**: 30분 (heartbeat로 갱신)
- **직렬화**: String (editor userId)

#### 무효화

- **명시적 해제** (BR-DOC-025): `DELETE /documents/:id/lock` 요청 시 `DEL {tenant_id}:lock:doc:{document_id}`
- **브라우저 종료/이탈**: WebSocket heartbeat(30초 간격) 미수신 시 서버가 3회 연속 실패 감지 후 자동 `DEL`. heartbeat는 프론트엔드 `beforeunload` 이벤트에서도 해제 요청 전송
- **TTL 만료**: 30분 경과 시 Redis 자동 만료. 이 경우 DB의 `editor_lock_at`이 stale 상태이므로, 다음 락 획득 시 `editor_lock_at + TTL < now()` 조건으로 DB도 정리
- **관리자 강제 해제**: ADMIN이 잠금 관리 화면에서 `DEL` 실행 + DB `current_editor_id = NULL` 동시 갱신

#### Warm-up / Fallback

- **Warm-up**: 불필요 — 락은 on-demand 생성이므로 서비스 시작 시 사전 로딩 없음
- **Fallback**: Redis 장애 시 DB의 `current_editor_id` + `editor_lock_at` 컬럼으로 폴백. DB 기반 락은 Redis 대비 성능이 낮으므로(SELECT FOR UPDATE), Redis 복구 시 즉시 Redis 락으로 전환
- **정리 배치**: cron(5분 주기)으로 `editor_lock_at + TTL < now()` 인 문서의 `current_editor_id → NULL` 정리 (BR-DOC-025). Redis TTL 만료 후 DB만 stale한 케이스 방어

---

### 2.2 조회 중복 방지 (Access Dedup)

#### 기본 정보

- **전략**: dedup (TTL 기반 중복 방지)
- **키 패턴**: `{tenant_id}:access:dedup:{userId}:{documentId}`
- **TTL**: 5분
- **직렬화**: String (타임스탬프 또는 "1")

#### 무효화

- **SET NX EX 패턴**: `SET {tenant_id}:access:dedup:{userId}:{documentId} 1 NX EX 300` (5분). 키가 이미 존재하면(NX 실패) 조회수 증가를 스킵
- **TTL 자동 만료**: 5분 후 자동 삭제. 수동 무효화 불필요

#### Warm-up / Fallback

- **Warm-up**: 불필요 — on-demand 생성
- **Fallback**: Redis 장애 시 dedup 없이 조회수를 카운트한다 (정확도 < 가용성). 동일 사용자 연속 새로고침으로 조회수가 부풀 수 있으나, 조회수 자체가 근사치이므로 허용 가능한 trade-off

---

### 2.3 조회수 카운터 버퍼 (Access Counter Buffer)

#### 기본 정보

- **전략**: buffer-flush (Redis → PG 배치 동기화)
- **키 패턴**: `{tenant_id}:access:counts` (Hash)
- **TTL**: 없음 (수동 관리 — flush 후 HDEL)
- **직렬화**: Hash (field = documentId, value = increment count)

#### 무효화

- **flush 사이클**: `HGETALL {tenant_id}:access:counts` → 각 documentId별 `UPDATE document SET view_count = view_count + N` → **UPDATE 성공 후에만** `HDEL {tenant_id}:access:counts field1 field2 ...`
- **안전 규칙**: flush 도중 실패 시(DB 에러 등) HDEL을 수행하지 않는다 — 다음 flush 주기에서 재시도. 이로 인해 중복 카운트(최대 10분치)가 발생할 수 있으나, 조회수는 근사치이므로 허용
- **경합 방지**: flush 중 새로 유입되는 HINCRBY와 HDEL이 경합하지 않도록, flush 시점에 HGETALL로 가져온 필드만 HDEL 대상으로 한다

#### Warm-up / Fallback

- **Warm-up**: 불필요 — 서비스 재시작 시 Redis Hash에 미flush 카운트가 남아있으며, 다음 cron 주기에서 자동 flush
- **Fallback**: Redis 장애 시 PG `view_count`에 직접 `UPDATE ... SET view_count = view_count + 1` 수행. 성능 저하(매 요청 DB write)를 감수하되 데이터 유실 방지. Redis 복구 감지 시 자동으로 버퍼 모드 전환
- **미flush 데이터 보존**: Redis는 AOF persistence가 활성화된 환경에서 미flush 데이터 유실 가능성이 낮음. RDB-only 환경에서는 최대 10분치 조회수 유실 가능 (허용 범위)

---

### 2.4 접근 로그 스트림 (Access Log Stream)

#### 기본 정보

- **전략**: buffer-flush (Redis Stream → ES 배치 동기화)
- **키 패턴**: `{tenant_id}:access:log:stream` (Stream)
- **TTL**: 없음 (수동 관리 — flush 후 XTRIM)
- **직렬화**: Stream entry (userId, documentId, boardId, timestamp 등)

#### 무효화

- **flush 사이클**: `XRANGE {tenant_id}:access:log:stream - + COUNT 1000` → ES bulk index → **bulk 성공 후에만** `XTRIM {tenant_id}:access:log:stream MINID {마지막 처리 ID}`
- **안전 규칙**: ES bulk 일부 실패 시 XTRIM 하지 않는다 — 다음 flush에서 재처리. 중복 인덱싱은 ES `_id`(entry ID 기반) 멱등성으로 방어
- **Consumer Group**: 단일 Consumer (`document-access-flusher`)로 순서 보장. 멀티 인스턴스 배포 시 분산 락(`{tenant_id}:lock:access-log-flush`, TTL 5분)으로 중복 실행 방지

#### Warm-up / Fallback

- **Warm-up**: 불필요 — Stream은 서비스 재시작 후에도 미처리 항목이 유지됨
- **Fallback**: ES 장애 시 Stream 적체 관리 — `XLEN` 모니터링, maxlen 상한(100,000 entries)에 도달 시 가장 오래된 항목부터 자동 TRIM + 알림 발송. ES 복구 후 TRIM된 접근 로그는 복구 불가하므로 알림 즉시 대응 필요
- **ES 장애 지속 시**: 24시간 이상 ES 장애 지속 시 접근 로그 flush 일시 중단 + 관리자 알림. Redis Stream이 메모리를 과다 사용하는 것을 방지

---

## 3. 키 패턴 요약

> `redis.md`와 일치를 보장한다.

| 키 패턴 | 타입 | TTL | 용도 |
|---------|------|-----|------|
| `{tenant_id}:lock:doc:{document_id}` | String | 30m | 비관적 편집 락 |
| `{tenant_id}:access:dedup:{userId}:{documentId}` | String | 5m | 조회수 중복 방지 |
| `{tenant_id}:access:counts` | Hash | — | 조회수 원자적 집계 버퍼 |
| `{tenant_id}:access:log:stream` | Stream | — | 접근 로그 이벤트 버퍼 |
| `{tenant_id}:stale-alert:{documentId}` | String | 7d | 드래프트 방치 알림 중복 방지 (schedule.md §2.8) |
| `{tenant_id}:circuit:{service_name}` | String | — | 서킷브레이커 상태 공유 (events.md §3.3) |
